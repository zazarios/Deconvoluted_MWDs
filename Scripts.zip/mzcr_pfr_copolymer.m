function [Mw_avg, Mn_avg, PDI, C2_wt_pct, MW, dW] = mzcr_pfr_copolymer( ...
    T_degC, P_total_Pa, r_Do, X_gas_riser, X_gas_barrier, ...
    mcat_in_gph, tau_riser_h, tau_downer_h, L_D, Ac_D, epsilon_D, r1, r2, S_prod)
% MZCR_PFR_COPOLYMER  Downer PFR for propylene/ethylene copolymerisation.
%   [Mw, Mn, PDI, C2_wt%, MW, dW] = mzcr_pfr_copolymer(...)
%   r1 = kp11/kp12, r2 = kp22/kp21 (reactivity ratios)
%   S_prod multiplies the specific activity from activity_model to scale
%   from lab to industrial productivity.

    T_K = T_degC + 273.15;
    R = 8.314;
    M_C3 = 42.08e-3;   % kg/mol
    M_C2 = 28.05e-3;

    % Riser H2 partial pressure (psi)
    P_H2_riser_psi = X_gas_riser.H2 * P_total_Pa / 6894.76;

    % Downer geometry and catalyst inventory
    V_D = Ac_D * L_D;
    m_cat_D = mcat_in_gph * tau_downer_h;
    rho_cat_D = m_cat_D / V_D;

    % ---- Inlet molar flows (barrier feed) ----
    u_g_D_in = 0.5;   % m/s
    F_tot_in = u_g_D_in * Ac_D * (P_total_Pa / (R * T_K));
    F_C3_in  = X_gas_barrier.C3H6 * F_tot_in;
    F_H2_in  = X_gas_barrier.H2   * F_tot_in;
    F_C2_in  = 0;
    if isfield(X_gas_barrier, 'C2H4')
        F_C2_in = X_gas_barrier.C2H4 * F_tot_in;
    end

    % Initial state: [F_C3, F_H2, F_C2, polymer mass]
    y0 = [F_C3_in; F_H2_in; F_C2_in; 0];

    % Solve ODE
    opts = odeset('RelTol', 1e-6, 'AbsTol', 1e-8);
    [z, y] = ode15s(@(z, y) downer_ode_copol(z, y, T_degC, P_total_Pa, r_Do, ...
        Ac_D, epsilon_D, rho_cat_D, P_H2_riser_psi, r1, r2, S_prod), [0, L_D], y0, opts);

    % Final state
    y_end = y(end, :)';
    F_C3_end = y_end(1);
    F_H2_end = y_end(2);
    F_C2_end = y_end(3);

    % Outlet gas mole fractions
    F_tot_end = F_C3_end + F_H2_end + F_C2_end;
    if F_tot_end <= 0
        Mw_avg = 0; Mn_avg = 0; PDI = 0; C2_wt_pct = 0; MW=[]; dW=[];
        return;
    end
    X_end.C3H6 = F_C3_end / F_tot_end;
    X_end.H2   = F_H2_end / F_tot_end;
    X_end.C2H4 = F_C2_end / F_tot_end;

    % Amorphous phase concentrations at outlet
    [cC3_am, cH2_am, cC2_am] = get_monomer_concentrations(X_end, T_K, P_total_Pa, 'gas');

    % Effective H2 partial pressure (psi)
    P_H2_end_psi = X_end.H2 * P_total_Pa / 6894.76;

    % Multi‑site Flory parameters (homopolymer reference)
    [w_out, Mn_out] = local_flory(T_degC, P_H2_end_psi, r_Do);

    % --- Ethylene weight fraction by Mayo‑Lewis ----
    f1 = cC3_am / (cC3_am + cC2_am);
    F1 = (r1*f1^2 + f1*(1-f1)) / (r1*f1^2 + 2*f1*(1-f1) + r2*(1-f1)^2);
    C2_wt_frac = (1 - F1) * M_C2 / (F1 * M_C3 + (1 - F1) * M_C2);
    C2_wt_pct = C2_wt_frac * 100;

    % MWD (same as homopolymer at same H2)
    MW = logspace(log10(100), log10(10*max(Mn_out)), 2000);
    dW = zeros(size(MW));
    for i = 1:5
        if w_out(i) > 0
            tau = 1 / Mn_out(i);
            dW = dW + w_out(i) * 2.3026 * MW.^2 * tau^2 .* exp(-MW * tau);
        end
    end
    Mn_avg = 1 / sum(w_out ./ Mn_out);
    Mw_avg = sum(w_out .* (2 * Mn_out));
    PDI = Mw_avg / Mn_avg;
end

% =========================================================================
function dy = downer_ode_copol(z, y, T_degC, P_total_Pa, r_Do, Ac, eps, ...
    rho_cat, P_H2_riser_psi, r1, r2, S_prod)
% ODE for propylene/ethylene/hydrogen copolymerisation in the downer.
    dy = zeros(4,1);   % column vector
    F_C3 = y(1);
    F_H2 = y(2);
    F_C2 = y(3);
    F_tot = F_C3 + F_H2 + F_C2;
    if F_tot <= 0, return; end

    % Partial pressures
    P_C3 = F_C3 / F_tot * P_total_Pa;
    P_H2 = F_H2 / F_tot * P_total_Pa;
    P_C2 = F_C2 / F_tot * P_total_Pa;

    X_cur.C3H6 = P_C3 / P_total_Pa;
    X_cur.H2   = P_H2 / P_total_Pa;
    X_cur.C2H4 = P_C2 / P_total_Pa;

    % Amorphous phase concentrations
    [cC3_am, cH2_am, cC2_am] = get_monomer_concentrations(X_cur, T_degC+273.15, P_total_Pa, 'gas');

    % Effective H2 partial pressure (psi)
    P_H2_eff = P_H2 / 6894.76;

    % Flory interpolation
    [w, Mn] = local_flory(T_degC, P_H2_eff, r_Do);
    Mn_avg = 1 / sum(w ./ Mn);

    % Polymerisation rate (scaled)
    Rp_sp = activity_model(T_degC, P_H2_eff, r_Do) * S_prod;   % <-- scale
    Rp_vol = Rp_sp * rho_cat;

    % Instantaneous copolymer composition (Mayo‑Lewis)
    f1 = cC3_am / (cC3_am + cC2_am);
    F1 = (r1*f1^2 + f1*(1-f1)) / (r1*f1^2 + 2*f1*(1-f1) + r2*(1-f1)^2);
    M_avg = F1 * 42.08 + (1-F1) * 28.05;   % g/mol

    % Molar consumption rates
    total_monomer_mol_s = Rp_vol / (M_avg * 3600);   % mol monomer/(m³ bed·s)
    Rp_C3_mol_s = F1 * total_monomer_mol_s;
    Rp_C2_mol_s = (1 - F1) * total_monomer_mol_s;

    % H2 consumption
    R_H2_sp = Rp_sp / Mn_avg;
    R_H2_vol = R_H2_sp * rho_cat;
    R_H2_mol_s = R_H2_vol / 3600;

    % ODE right‑hand sides (mol/s per metre)
    dF_C3_dz = - Rp_C3_mol_s * (1 - eps) * Ac;
    dF_C2_dz = - Rp_C2_mol_s * (1 - eps) * Ac;
    dF_H2_dz = - R_H2_mol_s  * (1 - eps) * Ac;
    mass_rate_g_per_s_per_m = Rp_vol * (1 - eps) * Ac / 3600;  % g/(m·s)

    dy(1) = dF_C3_dz;
    dy(2) = dF_H2_dz;
    dy(3) = dF_C2_dz;
    dy(4) = mass_rate_g_per_s_per_m;
end