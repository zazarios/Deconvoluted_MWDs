function [cC3_molL, cH2_molL, cC2_molL] = get_monomer_concentrations(Xgas, T_K, P_total_Pa, stage)
% GET_MONOMER_CONCENTRATIONS  Monomer concentrations in amorphous PP (mol/L).
%   Ternary correlation (Kulajanpeng et al. 2023, 2025) for PROPYLENE in GAS phase.
%   Validated SL‑EoS value for PROPYLENE in LIQUID pool (≈2.87 mol/L at 70°C).
%   Henry's law for ETHYLENE and HYDROGEN in all reactors.
%
%   Inputs:
%     Xgas : struct with fields C3H6, H2, C2H4 (mole fractions, 0..1)
%     T_K  : temperature (K)
%     P_total_Pa : total pressure (Pa)
%     stage: 'liquid' (MZCR) or 'gas' (gas‑phase reactor)
%
%   Outputs: concentrations in mol/L.

    P_bar_total = P_total_Pa / 1e5;
    P_C3 = Xgas.C3H6 * P_bar_total;
    P_H2 = Xgas.H2   * P_bar_total;
    if isfield(Xgas, 'C2H4')
        P_C2 = Xgas.C2H4 * P_bar_total;
    else
        P_C2 = 0;
    end

    % ------- Propylene -------
    if strcmpi(stage, 'liquid')
        % Liquid-pool MZCR: use SL‑EoS benchmark value (obtained at 70°C, 35 bar)
        % with a simple temperature correction using activation energy of sorption.
        T_ref = 70 + 273.15;   % K
        cC3_ref = 2.87;        % mol/L
        E_sol = 5000;          % J/mol
        cC3 = cC3_ref * exp(-E_sol/8.314 * (1/T_K - 1/T_ref));
    else
        % Gas‑phase: ternary correlation (Kulajanpeng et al. 2023, Eq. S15)
        % Valid for T = 70-85 °C, P_C3 <= 20 bar, propylene/propane ≈ 80/20 mol%.
        % The correlation provides concentration in mol/m^3; convert to mol/L.
        if P_C3 > 0
            a0 = 0.00010875 * T_K^2 - 0.072807 * T_K + 12.0;
            a1 = -0.5656 * T_K + 233.3;
            cC3 = (a0 * P_C3^2 + a1 * P_C3) / 1000;   % mol/L
        else
            cC3 = 0;
        end
    end
    cC3_molL = max(cC3, 0);

    % ------- Hydrogen (Henry's law) -------
    H_H2_ref = 0.015;   % mol/(L·bar) at 70°C
    T_ref = 70 + 273.15;
    E_sol_H2 = 2000;    % J/mol
    H_H2 = H_H2_ref * exp(-E_sol_H2/8.314 * (1/T_K - 1/T_ref));
    cH2_molL = max(H_H2 * P_H2, 0);

    % ------- Ethylene (Henry's law) -------
    if P_C2 > 0
        H_C2_ref = 0.11;   % mol/(L·bar)
        E_sol_C2 = 3000;   % J/mol
        H_C2 = H_C2_ref * exp(-E_sol_C2/8.314 * (1/T_K - 1/T_ref));
        cC2_molL = max(H_C2 * P_C2, 0);
    else
        cC2_molL = 0;
    end
end