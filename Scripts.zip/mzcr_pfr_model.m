function [Mw_avg, Mn_avg, PDI, MW, dW] = mzcr_pfr_model( ...
    T_degC, P_total_Pa, r_Do, X_gas_riser, X_gas_barrier, ...
    mcat_in_gph, tau_riser_h, tau_downer_h, L_D, Ac_D, epsilon_D, S_prod)
% MZCR_PFR_MODEL  Downer PFR with local multi‑site Flory MWD prediction.
%   [Mw, Mn, PDI, MW, dW] = mzcr_pfr_model(...)
%
%   Assumptions:
%     - Riser is a CSTR with inlet gas composition X_gas_riser (no conversion).
%     - Downer is a PFR; inlet gas is X_gas_barrier (barrier fluid).
%     - Solid phase porosity constant, catalyst loading from residence time.
%     - Propylene solubility from ternary correlation; H2 Henry's law.

    T_K = T_degC + 273.15;
    R = 8.314;                  % J/(mol K)

    % ---- Riser H2 partial pressure (psi) ----
    P_H2_riser_psi = X_gas_riser.H2 * P_total_Pa / 6894.76;

    % ---- Downer geometry and catalyst inventory ----
    V_D = Ac_D * L_D;                        % m³
    m_cat_D = mcat_in_gph * tau_downer_h;    % g catalyst in downer
    rho_cat_D = m_cat_D / V_D;               % g cat / m³ bed

    % ---- Inlet molar flows (barrier feed) ----
    u_g_D_in = 0.5;   % m/s (typical)
    F_tot_in = u_g_D_in * Ac_D * (P_total_Pa / (R * T_K));   % mol/s
    F_C3_in  = X_gas_barrier.C3H6 * F_tot_in;
    F_H2_in  = X_gas_barrier.H2   * F_tot_in;

    % Initial state [F_C3, F_H2, polymer mass] (column vector)
    y0 = [F_C3_in; F_H2_in; 0];

    % Solve ODE over downer length – now passes S_prod
    opts = odeset('RelTol', 1e-6, 'AbsTol', 1e-8);
    [z, y] = ode15s(@(z, y) downer_ode(z, y, T_degC, P_total_Pa, r_Do, ...
    Ac_D, epsilon_D, rho_cat_D, P_H2_riser_psi, S_prod), [0, L_D], y0, opts);

    % Final state
    y_end = y(end, :)';
    F_C3_end = y_end(1);
    F_H2_end = y_end(2);

    % Gas phase compositions at outlet
    F_tot_end = F_C3_end + F_H2_end;
    P_C3_end = F_C3_end / F_tot_end * P_total_Pa;
    P_H2_end = F_H2_end / F_tot_end * P_total_Pa;
    P_H2_end_psi = P_H2_end / 6894.76;

    % Multi‑site Flory parameters at outlet conditions
    [w_out, Mn_out] = local_flory(T_degC, P_H2_end_psi, r_Do);

    % Compute overall MWD from these parameters
    MW = logspace(log10(100), log10(10 * max(Mn_out)), 2000);
    dW = zeros(size(MW));
    for i = 1:5
        if w_out(i) > 0
            tau = 1 / Mn_out(i);
            dW = dW + w_out(i) * 2.3026 * MW.^2 * tau^2 .* exp(-MW * tau);
        end
    end
    Mn_avg = 1 / sum(w_out ./ Mn_out);
    Mw_avg = sum(w_out .* (2 * Mn_out));
    PDI = Mw_avg / Mn_avg;
end

% =========================================================================
function dy = downer_ode(z, y, T_degC, P_total_Pa, r_Do, Ac, eps, rho_cat, P_H2_riser_psi, S_prod)
% ODE right‑hand side for the downer PFR.  Now includes S_prod.
    dy = zeros(3,1);   % column vector
    F_C3 = y(1);
    F_H2 = y(2);
    F_tot = F_C3 + F_H2;
    if F_tot <= 0, return; end

    % Partial pressures (Pa)
    P_C3 = F_C3 / F_tot * P_total_Pa;
    P_H2 = F_H2 / F_tot * P_total_Pa;

    % Gas composition at this point
    X_cur.C3H6 = P_C3 / P_total_Pa;
    X_cur.H2   = P_H2 / P_total_Pa;
    X_cur.C2H4 = 0;

    % Amorphous phase concentrations (ternary for C3, Henry for H2)
    [cC3_am, cH2_am] = get_monomer_concentrations(X_cur, T_degC+273.15, P_total_Pa, 'gas');

    % Effective H2 partial pressure for Flory interpolation (psi)
    P_H2_eff = max(P_H2 / 6894.76, 0.1);   % floor 0.1 psi

    % Multi‑site Flory parameters
    [w, Mn] = local_flory(T_degC, P_H2_eff, r_Do);
    Mn_avg = 1 / sum(w ./ Mn);

    % Polymerisation rate per g cat (scaled)
    Rp_sp = activity_model(T_degC, P_H2_eff, r_Do) * S_prod;   % gPP/(gcat·h)
    Rp_vol = Rp_sp * rho_cat;                          % gPP/(m³ bed·h)

    % Convert to mol C3 consumed per m³ bed per second
    Rp_mol_C3_s = Rp_vol / (42.08 * 3600);            % mol/(m³·s)

    % H2 consumption per m³ per second (correct formula)
    R_H2_sp = Rp_sp / Mn_avg;               % mol H2/(gcat·h)
    R_H2_vol = R_H2_sp * rho_cat;                     % mol H2/(m³·h)
    R_H2_mol_s = R_H2_vol / 3600;                     % mol/(m³·s)

    % Mass balance ODEs (mol/s per m)
    dF_C3_dz = - Rp_mol_C3_s * (1 - eps) * Ac;
    dF_H2_dz = - R_H2_mol_s  * (1 - eps) * Ac;
    mass_rate_g_per_s_per_m = Rp_vol * (1 - eps) * Ac / 3600;  % g/(m·s)

    dy(1) = dF_C3_dz;
    dy(2) = dF_H2_dz;
    dy(3) = mass_rate_g_per_s_per_m;      % just accumulation, not used further
end