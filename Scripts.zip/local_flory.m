function [w, Mn] = local_flory(T_degC, P_H2_psi, DoTi)
% LOCAL_FLORY  Multi‑site Flory parameters at local conditions.
%   [w, Mn] = local_flory(T, P_H2, DoTi)
%   T_degC   : temperature (°C)
%   P_H2_psi : hydrogen partial pressure (psi)
%   DoTi     : donor/Ti molar ratio
%   w        : 1×5 weight fractions (sum to 1)
%   Mn       : 1×5 number‑average molecular weights (g/mol)
%
%   This is a convenience wrapper for interpFlory.

    [w, Mn] = interpFlory(T_degC, P_H2_psi, DoTi);
end