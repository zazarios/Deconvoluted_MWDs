function [z, F_C3, F_H2, d_mean_vec, Mw_out, Mn_out, PDI_out, Rp_profile] = ...
    mzcr_pfr_model_PSD_simple(T_degC, P_total_Pa, r_Do, X_gas_barrier, ...
    mcat_in_gph, tau_downer_h, L_D, Ac_D, epsilon_D, S_prod, ...
    rho_p_solid, eps_pol, d_prep_m)
% MZCR_PFR_MODEL_PSD_SIMPLE  Downer PFR with deterministic particle growth.
%
% Inputs:
%   T_degC, P_total_Pa: temperature (°C) and total pressure (Pa)
%   r_Do : donor/Ti ratio
%   X_gas_barrier : struct with fields C3H6, H2 (mole fractions)
%   mcat_in_gph : catalyst feed rate (g/h)
%   tau_downer_h : mean residence time in downer (h)
%   L_D : downer length (m)
%   Ac_D : cross‑sectional area (m²)
%   epsilon_D : bed voidage
%   S_prod : activity scaling factor (~50)
%   rho_p_solid : bulk polymer density (kg/m³), e.g. 900
%   eps_pol : internal porosity of polymer particles (e.g. 0.3)
%   d_prep_m : prepolymer particle diameter (m), e.g. 50e-6
%
% Outputs:
%   z : axial positions (m)
%   F_C3, F_H2 : molar flows (mol/s)
%   d_mean_vec : volume‑weighted mean diameter (m) along reactor
%   Mw_out, Mn_out, PDI_out : molecular weight averages at outlet
%   Rp_profile : specific polymerisation rate (g/gcat/h)

    % ---------- Physical constants ----------
    M_C3 = 42.08e-3;                % kg/mol
    T_K  = T_degC + 273.15;
    R_gas = 8.314;
    rho_cat_solid = 2300;           % catalyst skeleton density (kg/m³)

    % ---------- Prepolymer particle ----------
    V_prep = pi/6 * d_prep_m^3;                    % m³
    mcat_per_particle_kg = rho_cat_solid * V_prep;  % kg catalyst per particle

    % ---------- Catalyst inventory ----------
    mcat_total_g = mcat_in_gph * tau_downer_h;          % g
    V_bed = Ac_D * L_D;                                 % m³ bed volume
    rho_cat_g_per_m3bed = mcat_total_g / V_bed;         % g cat per m³ bed

    % ---------- Solid velocity (consistent with residence time) ----------
    u_s = L_D / (tau_downer_h * 3600);   % m/s

    % ---------- Inlet molar flows ----------
    u_g_in = 0.5;   % m/s   (realistic barrier fluid)
    F_tot_in = u_g_in * Ac_D * (P_total_Pa / (R_gas * T_K));
    F_C3_in  = X_gas_barrier.C3H6 * F_tot_in;
    F_H2_in  = X_gas_barrier.H2   * F_tot_in;

    % Initial state: [F_C3; F_H2; particle volume (m³)]
    y0 = [F_C3_in; F_H2_in; V_prep];

    % ---------- ODE parameters ----------
    param.T_degC = T_degC;
    param.P_tot  = P_total_Pa;
    param.r_Do   = r_Do;
    param.Ac     = Ac_D;
    param.eps    = epsilon_D;
    param.S_prod = S_prod;
    param.u_s    = u_s;
    param.rho_cat_g_per_m3bed = rho_cat_g_per_m3bed;
    param.mcat_per_particle_kg = mcat_per_particle_kg;
    param.rho_p  = rho_p_solid;
    param.eps_pol = eps_pol;
    param.M_C3   = M_C3;
    param.R_gas  = R_gas;

    % ---------- Solve ODE ----------
    opts = odeset('RelTol',1e-6,'AbsTol',1e-10);
    [z, y] = ode15s(@downer_ode_simple, [0 L_D], y0, opts, param);

    % Unpack results
    F_C3 = y(:,1);
    F_H2 = y(:,2);
    nu_z = y(:,3);                     % particle volume (m³)
    d_mean_vec = (6/pi * nu_z).^(1/3);  % volume‑weighted mean diameter (m)

    % Outlet MWD (as in original model)
    F_tot_out = F_C3(end) + F_H2(end);
    P_H2_out = F_H2(end) / F_tot_out * P_total_Pa;
    % Effective H2 pressure at outlet (with floor)
    P_H2_eff_psi = max(P_H2_out / 6894.76, 0.1);
    [w, Mn_sites] = local_flory(T_degC, P_H2_eff_psi, r_Do);
    Mn_out = 1 / sum(w ./ Mn_sites);
    Mw_out = sum(w .* (2 * Mn_sites));
    PDI_out = Mw_out / Mn_out;

    % Rate profile
    Rp_profile = zeros(size(z));
    for k = 1:length(z)
        F_tot_k = F_C3(k) + F_H2(k);
        P_H2_k = F_H2(k) / F_tot_k * P_total_Pa;
        P_H2_eff_psi_k = max(P_H2_k / 6894.76, 0.1);
        Rp_profile(k) = activity_model(T_degC, P_H2_eff_psi_k, r_Do) * S_prod;
    end
end

function dy = downer_ode_simple(z, y, param)
% ODE: molar balances + particle volume growth
    F_C3 = y(1);
    F_H2 = y(2);
    nu   = y(3);          % particle volume (m³)

    F_tot = F_C3 + F_H2;
    if F_tot <= 0
        dy = zeros(3,1); return;
    end

    % Partial pressures
    P_C3 = F_C3 / F_tot * param.P_tot;
    P_H2 = F_H2 / F_tot * param.P_tot;

    % Effective H2 partial pressure (psi) with floor
    P_H2_eff_psi = max(P_H2 / 6894.76, 0.1);

    X_cur.C3H6 = P_C3 / param.P_tot;
    X_cur.H2   = P_H2 / param.P_tot;
    X_cur.C2H4 = 0;

    % Specific polymerisation rate (scaled)
    Rp_sp = activity_model(param.T_degC, P_H2_eff_psi, param.r_Do) * param.S_prod;

    % Volumetric polymerisation rate per m³ bed
    Rp_vol_g_per_m3bed_h = Rp_sp * param.rho_cat_g_per_m3bed;   % g/(m³ bed·h)

    % Molar consumption rates
    Rp_mol_C3_s = Rp_vol_g_per_m3bed_h / (param.M_C3 * 1000 * 3600); % mol/(m³ bed·s)

    % H2 consumption rate per m³ bed
    [w, Mn_sites] = local_flory(param.T_degC, P_H2_eff_psi, param.r_Do);
    Mn_avg = 1 / sum(w ./ Mn_sites);
    R_H2_sp = Rp_sp / Mn_avg;   % mol H2 / gcat / h
    R_H2_vol_mol_per_m3bed_s = R_H2_sp * param.rho_cat_g_per_m3bed / 3600; % mol/(m³ bed·s)

    % Mass balances
    dF_C3_dz = - Rp_mol_C3_s * (1 - param.eps) * param.Ac;
    dF_H2_dz = - R_H2_vol_mol_per_m3bed_s * (1 - param.eps) * param.Ac;

    % Particle volumetric growth rate (m³/s)
    Gp_vol = (Rp_sp / 3600) * param.mcat_per_particle_kg / ...
             (param.rho_p * (1 - param.eps_pol));   % m³/s

    dnu_dz = Gp_vol / param.u_s;   % m³/m

    dy = [dF_C3_dz; dF_H2_dz; dnu_dz];
end