clear; clc; close all;

% =========================================================================
% 0. FIXED PARAMETERS and SCALING
% =========================================================================
T_mzcr      = 70;              % °C
P_mzcr      = 30e5;            % Pa (30 bar)
r_Do        = 1.4;             % donor/Ti

% Reactor dimensions (from patent, Table S6)
L_R         = 35;              % m   (riser)
Ac_R        = pi*(0.9)^2;      % m²  (diameter 1.8 m)
epsilon_R   = 0.9;             % bed porosity in riser
L_D         = 20;              % m   (downer)
Ac_D        = pi*0.55^2;       % m²  (diameter 1.1 m)
epsilon_D   = 0.35;            % bed porosity in downer

% Residence times (nominal)
tau_riser   = 0.02;            % h    (≈ 72 s)
tau_downer  = 1.0;             % h

% Plant throughput
target_prod_rate = 16.4e6;     % g/h  (16.4 ton/h)

% ---- Scaling factor (lab -> industrial productivity) ----
S_prod = 50;                   % calibrated to match plant capacity and PSD

% Common gas constant
R = 8.314;
T_K = T_mzcr + 273.15;

% Nominal downer gas velocity – set to 0.5 m/s (realistic for barrier fluid)
u_g_D_in = 0.5;               % m/s
F_tot_in = u_g_D_in * Ac_D * (P_mzcr / (R * T_K));

% Target values from the patent
target_Mw   = 400000;          % g/mol
target_C2   = 3.0;             % wt% ethylene

mcat_cal = 0.05;   % g/h (arbitrary, for MWD‑only runs)

% =========================================================================
% 1. EX1 CALIBRATION – HYDROGEN PARTIAL PRESSURE
%    Uses the downer‑only PFR model with industrial catalyst feed.
% =========================================================================
fprintf('\n=== EX1 Calibration ===\n');

% Preliminary guess for catalyst feed rate (using 2.54 psi as first guess)
P_H2_psi_guess = 2.54;
Rp_sp_opt_lab_guess = activity_model(T_mzcr, P_H2_psi_guess, r_Do);
mcat_in_real_guess = target_prod_rate / (Rp_sp_opt_lab_guess * S_prod * tau_downer);

% Wrapper using the tiny catalyst feed – H₂ profile flat, MWD independent of production rate.
getMw_from_XH2 = @(xH2) run_ex1_Mw(xH2, T_mzcr, P_mzcr, r_Do, ...
    mcat_cal, tau_riser, tau_downer, L_D, Ac_D, epsilon_D);

xH2_opt = fzero(@(x) getMw_from_XH2(x) - target_Mw, [0.001, 0.2]);
P_H2_psi_opt = xH2_opt * P_mzcr / 6894.76;   % → 2.54 psi

X_ex1.C3H6 = 1 - xH2_opt;
X_ex1.H2   = xH2_opt;
X_ex1.C2H4 = 0;
fprintf('Optimal H2 mole fraction = %.6f\n', xH2_opt);
fprintf('Optimal H2 partial pressure = %.2f psi\n', P_H2_psi_opt);

% Industrial productivity and catalyst feed (for PSD and ICP)
Rp_sp_opt_lab = activity_model(T_mzcr, P_H2_psi_opt, r_Do);
Rp_sp_opt_ind = Rp_sp_opt_lab * S_prod;
mcat_in_real = target_prod_rate / (Rp_sp_opt_ind * tau_downer);

% ---- Recompute real catalyst feed rate with the final H2 pressure ----
Rp_sp_opt_lab = activity_model(T_mzcr, P_H2_psi_opt, r_Do);
Rp_sp_opt_ind = Rp_sp_opt_lab * S_prod;
mcat_in_real = target_prod_rate / (Rp_sp_opt_ind * tau_downer);
fprintf('Lab activity = %.1f g/g/h, Industrial activity = %.0f g/g/h\n', Rp_sp_opt_lab, Rp_sp_opt_ind);
fprintf('Required catalyst feed rate = %.2f g/h (with S_prod = %d)\n', mcat_in_real, S_prod);

% ---- Full‑model check (not used for MWD figures) ----
%[Mw_full_check, Mn_full_check] = mzcr_full_model(T_mzcr, P_mzcr, r_Do, ...
%    X_ex1, X_ex1, mcat_in_real, tau_riser, tau_downer, ...
%    L_R, Ac_R, epsilon_R, L_D, Ac_D, epsilon_D, S_prod);
%fprintf('Full‑model MWD check: Mn = %.0f, Mw = %.0f (informational)\n', ...
%    Mn_full_check, Mw_full_check);

% ---- Production rate for EX1 ----
Rp_ind = activity_model(T_mzcr, P_H2_psi_opt, r_Do) * S_prod;   % g/g/h
EX1_prod_ton_per_h = Rp_ind * mcat_in_real * tau_downer / 1e6;   % ton/h
fprintf('EX1 production rate = %.2f ton/h (via downer)\n', EX1_prod_ton_per_h);

% ========================================================================
% 1.1 (ENHANCEMENT) Compute the calibration‑feed EX1 MWD (flat profile)
%     and a single‑site Flory distribution with the same Mn.
%     Used for the PDI‑2 overlay discussed in Section 6.2.
% ========================================================================
% Calibration feed was mcat_cal = 0.05 g/h, S_prod = 1.
[Mw_cal, Mn_cal, ~, MW_cal, dW_cal] = mzcr_pfr_model(T_mzcr, P_mzcr, r_Do, ...
    X_ex1, X_ex1, mcat_cal, tau_riser, tau_downer, L_D, Ac_D, epsilon_D, 1);
fprintf('Calibration‑feed EX1 MWD: Mw = %.0f, Mn = %.0f, PDI = %.2f\n', ...
    Mw_cal, Mn_cal, Mw_cal/Mn_cal);

% Single‑site Flory (most‑probable) distribution with the same Mn
tau_single = 1 / Mn_cal;
dW_single = 2.3026 * MW_cal.^2 * tau_single^2 .* exp(-MW_cal * tau_single);

% Export the overlay data
T_overlay = table(MW_cal(:), dW_cal(:), dW_single(:), ...
    'VariableNames', {'MW_g_per_mol','Multi_site_dW','Single_site_dW'});
writetable(T_overlay, 'FigS13_PDI2_overlay.csv');

% ---- Retrieve industrial iPP molecular weight averages (needed for ICP blend and SI figures) ----
[Mw_ex1_ind, Mn_ex1_ind, ~, MW_ex1_ind, dW_ex1_ind] = mzcr_pfr_model(T_mzcr, P_mzcr, r_Do, ...
    X_ex1, X_ex1, mcat_in_real, tau_riser, tau_downer, L_D, Ac_D, epsilon_D, S_prod);
fprintf('Industrial iPP MWD: Mn = %.0f, Mw = %.0f\n', Mn_ex1_ind, Mw_ex1_ind);

% Keep the industrial iPP MWD in the names used by all subsequent figures
MW_ex1 = MW_ex1_ind;
dW_ex1 = dW_ex1_ind;

% =========================================================================
% 2. EX2 CALIBRATION – REACTIVITY RATIOS
%    Uses the downer‑only copolymer model with industrial catalyst feed.
% =========================================================================
fprintf('\n=== EX2 Calibration ===\n');

X_C2_ex2 = 0.05;
X_ex2.H2   = xH2_opt;
X_ex2.C3H6 = 1 - xH2_opt - X_C2_ex2;
X_ex2.C2H4 = X_C2_ex2;

% Grid search over r1, r2 (using mcat_in_real and S_prod)
r1_vec = 4.0 : 0.25 : 12.0;
r2_vec = 0.20 : 0.01 : 0.80;
best_err = Inf;  best_r1 = NaN;  best_r2 = NaN;  best_C2 = 0;

for r1 = r1_vec
    for r2 = r2_vec
        [~, ~, ~, C2_wt] = mzcr_pfr_copolymer(T_mzcr, P_mzcr, r_Do, ...
    X_ex2, X_ex2, mcat_cal, tau_riser, tau_downer, ...
    L_D, Ac_D, epsilon_D, r1, r2, 1);   % S_prod = 1
        err = abs(C2_wt - target_C2);
        if err < best_err
            best_err = err;  best_r1 = r1;  best_r2 = r2;  best_C2 = C2_wt;
        end
    end
end

fprintf('Best r1 = %.2f, r2 = %.2f  -> C2 = %.2f wt%%\n', best_r1, best_r2, best_C2);

% =========================================================================
% 3. ICP PREDICTION (unchanged except using mcat_in_real)
% =========================================================================
fprintf('\n=== ICP Prediction ===\n');

T_gas       = 80;   P_gas       = 15e5;   tau_gas     = 0.3;
X_gas_icp.C3H6 = 0.5;   X_gas_icp.H2 = 0.05;   X_gas_icp.C2H4 = 0.45;

kd          = 0.5;                     % h⁻¹, from Pater (2001)
f_res       = exp(-kd * (tau_riser + tau_downer));
fprintf('Using kd = %.2f h⁻¹ → f_res = %.4f\n', kd, f_res);

% iPP mass (MZCR, dominated by downer)
Rp_mzcr = activity_model(T_mzcr, P_H2_psi_opt, r_Do) * S_prod;
m_iPP   = mcat_in_real * Rp_mzcr * tau_downer;   % g

% Gas‑phase concentrations
[cC3g, ~, cC2g] = get_monomer_concentrations(X_gas_icp, T_gas+273.15, P_gas, 'gas');
P_H2_gas_psi = X_gas_icp.H2 * P_gas / 6894.76;
[w_gas, Mn_gas] = local_flory(T_gas, P_H2_gas_psi, r_Do);

cC3_liq = 2.87;    % reference propylene concentration in MZCR

% Site‑dependent driving forces
factor = zeros(1,5);   amount = zeros(1,5);
for i = 1:5
    if i <= 3
        factor(i) = (cC3g + cC2g) / cC3_liq;
    else
        factor(i) = cC2g / cC3_liq;
    end
    amount(i) = w_gas(i) * factor(i);
end
amount = amount / sum(amount);

Rp_s2       = activity_model(T_gas, P_H2_gas_psi, r_Do) * S_prod * f_res * sum(w_gas .* factor);
m_s2_total  = mcat_in_real * Rp_s2 * tau_gas;
m_EPR       = m_s2_total * sum(amount(1:3));
m_PE        = m_s2_total * sum(amount(4:5));

% Phase mass fractions (based on total batch masses, correct for composition)
m_total_batch = m_iPP + m_EPR + m_PE;
phi_iPP = m_iPP / m_total_batch;
phi_EPR = m_EPR / m_total_batch;
phi_PE  = m_PE  / m_total_batch;

f1_g = cC3g / (cC3g + cC2g);
F1_EPR = (best_r1*f1_g^2 + f1_g*(1-f1_g)) / (best_r1*f1_g^2 + 2*f1_g*(1-f1_g) + best_r2*(1-f1_g)^2);
C2_EPR  = (1 - F1_EPR)*28.05 / (F1_EPR*42.08 + (1 - F1_EPR)*28.05);
total_C2 = phi_EPR * C2_EPR + phi_PE;

% Continuous production rates (each mass divided by its reactor residence time)
m_iPP_rate = m_iPP / tau_downer;   % g/h
m_EPR_rate = m_EPR / tau_gas;      % g/h
m_PE_rate  = m_PE  / tau_gas;
m_total_rate = m_iPP_rate + m_EPR_rate + m_PE_rate;   % g/h

fprintf('ICP composition (f_res = %.4f):\n', f_res);
fprintf('  iPP = %.2f wt%%, EPR = %.2f wt%%, PE = %.2f wt%%\n', phi_iPP*100, phi_EPR*100, phi_PE*100);
fprintf('  Total C2 = %.2f wt%%\n', total_C2*100);
fprintf('Continuous ICP production rate = %.1f ton/h\n', m_total_rate/1e6);

% ---- Compute and display blended ICP molecular weight averages (using industrial iPP) ----
Mn_ex1 = Mn_ex1_ind;   % from the industrial‑feed run above
Mw_ex1 = Mw_ex1_ind;

w_epr_blend = amount(1:3)/sum(amount(1:3));
Mn_epr_blend = 1 / sum(w_epr_blend ./ Mn_gas(1:3));
Mw_epr_blend = sum(w_epr_blend .* (2 * Mn_gas(1:3)));

w_pe_blend = amount(4:5)/sum(amount(4:5));
Mn_pe_blend = 1 / sum(w_pe_blend ./ Mn_gas(4:5));
Mw_pe_blend = sum(w_pe_blend .* (2 * Mn_gas(4:5)));

Mn_ICP = 1 / (phi_iPP/Mn_ex1 + phi_EPR/Mn_epr_blend + phi_PE/Mn_pe_blend);
Mw_ICP = phi_iPP*Mw_ex1 + phi_EPR*Mw_epr_blend + phi_PE*Mw_pe_blend;
PDI_ICP = Mw_ICP / Mn_ICP;

fprintf('Blended ICP molecular weight:\n');
fprintf('  Mn = %.0f g/mol\n', Mn_ICP);
fprintf('  Mw = %.0f g/mol\n', Mw_ICP);
fprintf('  PDI = %.2f\n', PDI_ICP);

% --- Store baseline ICP variables (needed for sensitivity plots) ---
cC3g_base = cC3g;          cC2g_base = cC2g;
w_gas_base = w_gas;        Mn_gas_base = Mn_gas;
amount_base = amount;      f_res_base = f_res;
m_iPP_base = m_iPP;
% also store the reactivity ratios
r1_base = best_r1;         r2_base = best_r2;
% and the gas‑phase H₂ pressure
P_H2_gas_psi_base = P_H2_gas_psi;
% and the reference concentration
cC3_liq_base = cC3_liq;
factor_base = factor; % Store factor as a baseline variable

% =========================================================================
% 4. EXPORT MANUSCRIPT & SI FIGURES
% =========================================================================
fprintf('\n--- Exporting manuscript figure tables ---\n');

% Retrieve EX2 MWD from downer‑only model
[~, Mn_ex2, ~, ~, MW_ex2, dW_ex2] = mzcr_pfr_copolymer(T_mzcr, P_mzcr, r_Do, ...
    X_ex2, X_ex2, mcat_cal, tau_riser, tau_downer, ...
    L_D, Ac_D, epsilon_D, best_r1, best_r2, 1);

% ---- Stockmayer CCD for EX2 (new SI figure) ----
T_K = T_mzcr + 273.15;
X_out = X_ex2;  % flat profile → use barrier composition

[cC3_am, ~, cC2_am] = get_monomer_concentrations(X_out, T_K, P_mzcr, 'gas');
f1   = cC3_am / (cC3_am + cC2_am);
F1_avg = (best_r1 * f1^2 + f1*(1-f1)) / ...
         (best_r1 * f1^2 + 2*f1*(1-f1) + best_r2*(1-f1)^2);   % <-- best_r1, best_r2

P_H2_out_psi = X_out.H2 * P_mzcr / 6894.76;
[w_ex2, Mn_ex2_sites] = local_flory(T_mzcr, P_H2_out_psi, r_Do);

[CCD_ex2, MW_ccd, F1_ccd] = stockmayer_ccd(w_ex2, Mn_ex2_sites, F1_avg, best_r1, best_r2);

% Fig 3a – use the calibration‑feed EX1 MWD (already stored in MW_cal, dW_cal)
T2a = table(MW_cal', dW_cal', 'VariableNames', {'M_g_per_mol','dW_dlogM'});
writetable(T2a, 'Fig3a_EX1_MWD.csv');

% Fig 3b
T2b = table(MW_ex2', dW_ex2', 'VariableNames', {'M_g_per_mol','dW_dlogM'});
writetable(T2b, 'Fig3b_EX2_MWD.csv');

% Fig 4a (ICP component MWDs) – use the full iPP MW grid for the blend
% The industrial iPP MWD is in MW_ex1, dW_ex1
MW_blend = MW_ex1;                          % use the same full grid as Fig 3a

% EPR MWD on the full blend grid
w_epr = w_gas(1:3)/sum(w_gas(1:3));   Mn_epr = Mn_gas(1:3);
dW_EPR = zeros(size(MW_blend));
for i = 1:3
    tau_i = 1/Mn_epr(i);
    dW_EPR = dW_EPR + w_epr(i)*2.3026*MW_blend.^2.*tau_i.^2.*exp(-MW_blend*tau_i);
end

% PE MWD on the full blend grid
w_pe = w_gas(4:5)/sum(w_gas(4:5));   Mn_pe = Mn_gas(4:5);
dW_PE = zeros(size(MW_blend));
for i = 1:2
    tau_i = 1/Mn_pe(i);
    dW_PE = dW_PE + w_pe(i)*2.3026*MW_blend.^2.*tau_i.^2.*exp(-MW_blend*tau_i);
end

% Blended ICP MWD (already on the same grid)
dW_ICP_bl = phi_iPP*dW_ex1 + phi_EPR*dW_EPR + phi_PE*dW_PE;

T3a = table(MW_blend(:), dW_ex1(:), dW_EPR(:), dW_PE(:), dW_ICP_bl(:), ...
    'VariableNames', {'MW_g_per_mol','iPP_dW','EPR_dW','PE_dW','ICP_blend_dW'});
writetable(T3a, 'Fig4a_ICP_MWD.csv');

% Fig 4b
phase = {'iPP';'EPR';'PE'};  frac = [phi_iPP; phi_EPR; phi_PE]*100;
T3b = table(phase, frac, 'VariableNames', {'Phase','Mass_fraction_pct'});
writetable(T3b, 'Fig4b_ICP_fractions.csv');

% Fig 5a: ICP sensitivity to gas‑phase ethylene feed
C2H4_frac_vec = 0.35 : 0.05 : 0.65;
EPR_frac_a    = zeros(size(C2H4_frac_vec));
TotalC2_a     = zeros(size(C2H4_frac_vec));
for k = 1:length(C2H4_frac_vec)
    % Restore baseline gas‑phase conditions (monomer conc. will be recomputed)
    X_g       = X_gas_icp;          % start from the fixed base gas composition
    X_g.C2H4  = C2H4_frac_vec(k);
    X_g.C3H6  = 1 - 0.05 - C2H4_frac_vec(k);
    
    [cC3, ~, cC2] = get_monomer_concentrations(X_g, T_gas+273.15, P_gas, 'gas');
    % Use the baseline Flory parameters (they depend only on H₂, which is fixed)
    w_loc = w_gas_base;   % w_gas_base corresponds to X_gas_icp (H₂ = 0.05)
    % Recompute site‑specific driving forces with the new monomer concentrations
    fac = zeros(1,5);
    for i = 1:5
        if i<=3, fac(i) = (cC3 + cC2)/cC3_liq_base; 
        else,    fac(i) = cC2 / cC3_liq_base; 
        end
    end
    amt = w_loc .* fac;
    amt = amt / sum(amt);
    
    Rp_s2_k = activity_model(T_gas, P_H2_gas_psi_base, r_Do) * S_prod * f_res_base * sum(w_loc .* fac);
    m_s2_k  = mcat_in_real * Rp_s2_k * tau_gas;
    m_epr_k = m_s2_k * sum(amt(1:3));
    m_pe_k  = m_s2_k * sum(amt(4:5));
    m_tot_k = m_iPP_base + m_epr_k + m_pe_k;
    
    EPR_frac_a(k) = m_epr_k / m_tot_k;
    f1_k = cC3 / (cC3 + cC2);
    F1_k = (best_r1*f1_k^2 + f1_k*(1-f1_k)) / ...
           (best_r1*f1_k^2 + 2*f1_k*(1-f1_k) + best_r2*(1-f1_k)^2);
    C2_epr_k   = (1-F1_k)*28.05 / (F1_k*42.08 + (1-F1_k)*28.05);
    TotalC2_a(k) = EPR_frac_a(k)*C2_epr_k + (m_pe_k / m_tot_k);
end
T4a = table(C2H4_frac_vec', TotalC2_a'*100, EPR_frac_a'*100, ...
    'VariableNames', {'C2H4_mol_frac','Total_C2_wt_pct','EPR_frac_pct'});
writetable(T4a, 'Fig5a_ICP_C2H4_feed.csv');

% Fig 5b: ICP sensitivity to residual activity f_res
f_res_vec = 0.3 : 0.05 : 0.6;
EPR_frac_b = zeros(size(f_res_vec));
TotalC2_b  = zeros(size(f_res_vec));
for k = 1:length(f_res_vec)
    % Restore baseline gas‑phase variables (monomer conc., Flory, amounts)
    cC3g   = cC3g_base;
    cC2g   = cC2g_base;
    w_gas  = w_gas_base;
    amount = amount_base;
    
    f_r = f_res_vec(k);
    Rp_s2_k = activity_model(T_gas, P_H2_gas_psi_base, r_Do) * S_prod * f_r * sum(w_gas_base .* factor_base);
    m_s2_k  = mcat_in_real * Rp_s2_k * tau_gas;
    m_epr_k = m_s2_k * sum(amount(1:3));
    m_pe_k  = m_s2_k * sum(amount(4:5));
    m_tot_k = m_iPP_base + m_epr_k + m_pe_k;
    
    EPR_frac_b(k) = m_epr_k / m_tot_k;
    f1_k = cC3g / (cC3g + cC2g);
    F1_k = (best_r1*f1_k^2 + f1_k*(1-f1_k)) / ...
           (best_r1*f1_k^2 + 2*f1_k*(1-f1_k) + best_r2*(1-f1_k)^2);
    C2_epr_k   = (1-F1_k)*28.05 / (F1_k*42.08 + (1-F1_k)*28.05);
    TotalC2_b(k) = EPR_frac_b(k)*C2_epr_k + (m_pe_k / m_tot_k);
end
T4b = table(f_res_vec', EPR_frac_b'*100, TotalC2_b'*100, ...
    'VariableNames', {'f_res','EPR_frac_pct','Total_C2_wt_pct'});
writetable(T4b, 'Fig5b_ICP_f_res.csv');

% =========================================================================
% SENSITIVITY TO GAS‑PHASE REACTOR TEMPERATURE (new SI figure)
% =========================================================================
T_gas_sens = 75 : 2.5 : 85;   % °C
N_T = length(T_gas_sens);

phi_iPP_sens = zeros(N_T,1);
phi_EPR_sens = zeros(N_T,1);
phi_PE_sens  = zeros(N_T,1);
total_C2_sens = zeros(N_T,1);
Mn_ICP_sens  = zeros(N_T,1);
Mw_ICP_sens  = zeros(N_T,1);
PDI_ICP_sens = zeros(N_T,1);

for k = 1:N_T
    T_gas_k = T_gas_sens(k);
    [cC3g, ~, cC2g] = get_monomer_concentrations(X_gas_icp, T_gas_k+273.15, P_gas, 'gas');
    P_H2_gas_psi = X_gas_icp.H2 * P_gas / 6894.76;   % unchanged
    [w_gas, Mn_gas] = local_flory(T_gas_k, P_H2_gas_psi, r_Do);

    % Site‑dependent driving forces
    factor = zeros(1,5); amount = zeros(1,5);
    for i = 1:5
        if i <= 3
            factor(i) = (cC3g + cC2g) / cC3_liq;
        else
            factor(i) = cC2g / cC3_liq;
        end
        amount(i) = w_gas(i) * factor(i);
    end
    amount = amount / sum(amount);

    Rp_s2 = activity_model(T_gas_k, P_H2_gas_psi, r_Do) * S_prod * f_res * sum(w_gas .* factor);
    m_s2_total = mcat_in_real * Rp_s2 * tau_gas;
    m_EPR = m_s2_total * sum(amount(1:3));
    m_PE  = m_s2_total * sum(amount(4:5));

    m_total_batch = m_iPP + m_EPR + m_PE;   % m_iPP unchanged
    phi_iPP_sens(k) = m_iPP / m_total_batch;
    phi_EPR_sens(k) = m_EPR / m_total_batch;
    phi_PE_sens(k)  = m_PE  / m_total_batch;

    f1_g = cC3g / (cC3g + cC2g);
    F1_EPR = (best_r1*f1_g^2 + f1_g*(1-f1_g)) / ...
             (best_r1*f1_g^2 + 2*f1_g*(1-f1_g) + best_r2*(1-f1_g)^2);
    C2_EPR = (1 - F1_EPR)*28.05 / (F1_EPR*42.08 + (1 - F1_EPR)*28.05);
    total_C2_sens(k) = phi_EPR_sens(k) * C2_EPR + phi_PE_sens(k);

    % MWD averages
    [w_epr_blend, Mn_epr_blend, Mw_epr_blend] = site_averages(amount(1:3), Mn_gas(1:3));
    [w_pe_blend,  Mn_pe_blend,  Mw_pe_blend]  = site_averages(amount(4:5), Mn_gas(4:5));
    Mn_ICP_sens(k) = 1 / (phi_iPP_sens(k)/Mn_ex1 + phi_EPR_sens(k)/Mn_epr_blend + phi_PE_sens(k)/Mn_pe_blend);
    Mw_ICP_sens(k) = phi_iPP_sens(k)*Mw_ex1 + phi_EPR_sens(k)*Mw_epr_blend + phi_PE_sens(k)*Mw_pe_blend;
    PDI_ICP_sens(k) = Mw_ICP_sens(k) / Mn_ICP_sens(k);
end

% Export
T_sens = table(T_gas_sens', phi_iPP_sens*100, phi_EPR_sens*100, phi_PE_sens*100, ...
    total_C2_sens*100, Mn_ICP_sens, Mw_ICP_sens, PDI_ICP_sens, ...
    'VariableNames', {'T_gas_degC','iPP_pct','EPR_pct','PE_pct','Total_C2_pct', ...
                      'Mn_ICP_gmol','Mw_ICP_gmol','PDI_ICP'});
writetable(T_sens, 'FigS15_ICP_Tgas_sensitivity.csv');

fprintf('Manuscript figure tables exported.\n');

% =========================================================================
% 5. SUPPORTING INFORMATION FIGURES (S1–S11)
% =========================================================================
fprintf('\n--- Exporting SI figure tables ---\n');

% NOTE on catalyst feed for SI axial profiles:
% The MWD calibration was performed with a negligible catalyst feed
% (mcat_cal = 0.05 g/h, S_prod = 1) to guarantee a perfectly flat H₂
% profile along the downer.  The axial profiles S1, S2, S5 are therefore
% exported with the same calibration feed so that they illustrate the
% constant‑composition assumption on which the calibration rests.
% The PSD model and ICP production rate, in contrast, use the real
% industrial catalyst feed (mcat_in_real) to obtain physically
% realistic particle sizes and throughputs.
%
% For the axial SI profiles (S1, S2, S5): use mcat_cal → flat profiles, consistent with the calibration assumption.

mcat_grad = mcat_cal;

F_C3_in_ex1 = X_ex1.C3H6 * F_tot_in;   F_H2_in_ex1 = X_ex1.H2 * F_tot_in;
rho_cat_grad = (mcat_grad * tau_downer) / (Ac_D * L_D);

% ---- S1: Axial profiles EX1 ----
[z_S1, y_S1] = ode15s(@(z,y) downer_ode_homo(z,y,T_mzcr,P_mzcr,r_Do,Ac_D,epsilon_D,rho_cat_grad,S_prod), ...
    [0 L_D], [F_C3_in_ex1; F_H2_in_ex1; 0]);
F_tot_S1 = y_S1(:,1) + y_S1(:,2);
T_S1 = table(z_S1, y_S1(:,1)*1000, y_S1(:,2)*1000, ...
    y_S1(:,1)./F_tot_S1*P_mzcr/1e5, y_S1(:,2)./F_tot_S1*P_mzcr/1e5, ...
    'VariableNames', {'z_m','F_C3_mmol_s','F_H2_mmol_s','P_C3_bar','P_H2_bar'});
writetable(T_S1, 'FigS1_axial_profiles_EX1.csv');

% ---- S2: Cumulative Mw, Mn, PDI along downer ----
Mw_cum = zeros(size(z_S1)); Mn_cum = zeros(size(z_S1)); PDI_cum = zeros(size(z_S1));
for k = 1:length(z_S1)
    F_tot_k = y_S1(k,1) + y_S1(k,2);
    if F_tot_k <= 0, continue; end
    P_H2_k = y_S1(k,2) / F_tot_k * P_mzcr;
    [w_k, Mn_k] = local_flory(T_mzcr, P_H2_k/6894.76, r_Do);
    Mn_cum(k) = 1 / sum(w_k ./ Mn_k);
    Mw_cum(k) = sum(w_k .* (2*Mn_k));
    PDI_cum(k) = Mw_cum(k) / Mn_cum(k);
end
T_S2 = table(z_S1, Mw_cum/1e3, Mn_cum/1e3, PDI_cum, ...
    'VariableNames', {'z_m','Mw_kg_mol','Mn_kg_mol','PDI'});
writetable(T_S2, 'FigS2_Mw_Mn_PDI.csv');

% ---- S3: HPP sensitivity to H2 ----
H2_psi_s3 = [1, 2, 3, 4, 6, 8];
Mw_s3 = zeros(size(H2_psi_s3)); Mn_s3 = zeros(size(H2_psi_s3));
PDI_s3 = zeros(size(H2_psi_s3)); Rp_s3 = zeros(size(H2_psi_s3));
for k = 1:length(H2_psi_s3)
    X_H2_s = H2_psi_s3(k)*6894.76 / P_mzcr;
    X_s.C3H6 = 1 - X_H2_s; X_s.H2 = X_H2_s; X_s.C2H4 = 0;
    [Mw_s, Mn_s, PDI_s] = mzcr_pfr_model(T_mzcr, P_mzcr, r_Do, X_s, X_s, ...
        mcat_cal, tau_riser, tau_downer, L_D, Ac_D, epsilon_D, 1);   % S_prod = 1
    Mw_s3(k) = Mw_s; Mn_s3(k) = Mn_s; PDI_s3(k) = PDI_s;
    Rp_s3(k) = activity_model(T_mzcr, H2_psi_s3(k), r_Do);
end
T_S3 = table(H2_psi_s3', Mw_s3'/1e3, Mn_s3'/1e3, PDI_s3', Rp_s3', ...
    'VariableNames', {'H2_psi','Mw_kg_mol','Mn_kg_mol','PDI','Rp_g_gcat_h'});
writetable(T_S3, 'FigS3_H2_sensitivity.csv');

% ---- S4: Recirculation ratio ----
tau_ratio = [15, 60]/23.5;   tau_vals = tau_ratio * tau_downer;
MW_common_S4 = logspace(log10(100), log10(1e7), 2000);
dW_s4 = zeros(length(tau_vals), 2000);
for k = 1:length(tau_vals)
    [~, ~, ~, MW_s, dW_s] = mzcr_pfr_model(T_mzcr, P_mzcr, r_Do, X_ex1, X_ex1, ...
        mcat_cal, tau_riser, tau_vals(k), L_D, Ac_D, epsilon_D, 1);   % S_prod = 1
    dW_s4(k,:) = interp1(MW_s, dW_s, MW_common_S4, 'linear', 0);
end
% Export residence times for FigS4a
T_S4_res = table([15; 60], tau_vals', 'VariableNames', {'R_rec','tau_down_h'});
writetable(T_S4_res, 'FigS4a_residence_time.csv');
% Export recirculation for FigS4b
T_S4 = table(MW_common_S4', dW_s4(1,:)', dW_s4(2,:)', ...
    'VariableNames', {'MW_g_mol','Rrec15','Rrec60'});
writetable(T_S4, 'FigS4b_recirculation.csv');

% ---- S5: Axial profiles EX2 ----
F_C2_in_ex2 = X_ex2.C2H4 * F_tot_in;
y0_copol = [F_C3_in_ex1; F_H2_in_ex1; F_C2_in_ex2; 0];
[z_S5, y_S5] = ode15s(@(z,y) downer_ode_copol_axial(z,y,T_mzcr,P_mzcr,r_Do,Ac_D,epsilon_D,rho_cat_grad,best_r1,best_r2,S_prod), [0 L_D], y0_copol);
F_tot_S5 = sum(y_S5(:,1:3),2);
T_S5 = table(z_S5, y_S5(:,1)./F_tot_S5*P_mzcr/1e5, y_S5(:,2)./F_tot_S5*P_mzcr/1e5, ...
    y_S5(:,3)./F_tot_S5*P_mzcr/1e5, 'VariableNames', {'z_m','P_C3_bar','P_H2_bar','P_C2_bar'});
writetable(T_S5, 'FigS5_axial_profiles_EX2.csv');

% ---- S6: Overlay MWD EX1 and EX2 ----
T_S6 = table(MW_ex1', dW_ex1', dW_ex2', 'VariableNames', {'MW_g_mol','EX1_dW','EX2_dW'});
writetable(T_S6, 'FigS6_MWD_EX1_EX2.csv');

% ---- S7: RCP sensitivity to ethylene feed ----
C2_frac_s7 = 0.03:0.005:0.07;
Mw_s7 = zeros(size(C2_frac_s7)); C2wt_s7 = zeros(size(C2_frac_s7));
for k = 1:length(C2_frac_s7)
    X_s7.C3H6 = 1 - xH2_opt - C2_frac_s7(k);
    X_s7.H2 = xH2_opt;  X_s7.C2H4 = C2_frac_s7(k);
    [Mw_s, ~, ~, C2wt_s] = mzcr_pfr_copolymer(T_mzcr, P_mzcr, r_Do, ...
        X_s7, X_s7, mcat_cal, tau_riser, tau_downer, L_D, Ac_D, epsilon_D, best_r1, best_r2, 1);
    Mw_s7(k) = Mw_s;  C2wt_s7(k) = C2wt_s;
end
T_S7 = table(C2_frac_s7'*100, C2wt_s7', Mw_s7'/1e3, ...
    'VariableNames', {'C2_feed_mol_pct','C2_in_copolymer_wt_pct','Mw_kg_mol'});
writetable(T_S7, 'FigS7_RCP_C2_feed.csv');

% ---- S8: RCP sensitivity to H2 ----
H2_psi_s8 = [1.5, 2.0, 2.54, 4.0, 5.0];
Mw_s8 = zeros(size(H2_psi_s8)); C2wt_s8 = zeros(size(H2_psi_s8));
for k = 1:length(H2_psi_s8)
    X_H2_s = H2_psi_s8(k)*6894.76 / P_mzcr;
    X_s8.C3H6 = 1 - X_H2_s - X_C2_ex2;
    X_s8.H2 = X_H2_s;  X_s8.C2H4 = X_C2_ex2;
    [Mw_s, ~, ~, C2wt_s] = mzcr_pfr_copolymer(T_mzcr, P_mzcr, r_Do, ...
        X_s8, X_s8, mcat_cal, tau_riser, tau_downer, L_D, Ac_D, epsilon_D, best_r1, best_r2, 1);
    Mw_s8(k) = Mw_s;  C2wt_s8(k) = C2wt_s;
end
T_S8 = table(H2_psi_s8', Mw_s8'/1e3, C2wt_s8', ...
    'VariableNames', {'H2_psi','Mw_kg_mol','C2_wt_pct'});
writetable(T_S8, 'FigS8_RCP_H2_sensitivity.csv');

% ---- S9: Mixed PP blend ----
X_riser_S9.C3H6 = 0.9942; X_riser_S9.H2 = 0.0058; X_riser_S9.C2H4 = 0;
X_barrier_S9.C3H6 = 0.9965; X_barrier_S9.H2 = 0.0035; X_barrier_S9.C2H4 = 0;
[w_riser_S9, Mn_riser_S9] = local_flory(T_mzcr, 2.54, r_Do);
MW_riser_S9 = logspace(log10(100), log10(10*max(Mn_riser_S9)), 2000);
dW_riser_S9 = zeros(size(MW_riser_S9));
for i=1:5, if w_riser_S9(i)>0, tau_i=1/Mn_riser_S9(i); dW_riser_S9=dW_riser_S9+w_riser_S9(i)*2.3026*MW_riser_S9.^2*tau_i^2.*exp(-MW_riser_S9*tau_i); end; end
[Mw_d_S9, Mn_d_S9, PDI_d_S9, MW_d_S9, dW_downer_S9] = mzcr_pfr_model(T_mzcr, P_mzcr, r_Do, ...
    X_barrier_S9, X_barrier_S9, mcat_cal, tau_riser, tau_downer, L_D, Ac_D, epsilon_D, 1);

MW_blend_S9 = logspace(log10(100), log10(10*max([Mn_riser_S9, Mn_d_S9])), 2000);
dW_riser_bl = interp1(MW_riser_S9(:), dW_riser_S9(:), MW_blend_S9(:), 'linear', 0);
dW_downer_bl = interp1(MW_d_S9(:), dW_downer_S9(:), MW_blend_S9(:), 'linear', 0);
Blend_col  = 0.5*dW_riser_bl + 0.5*dW_downer_bl;
T_S9 = table(MW_blend_S9(:), Blend_col, dW_riser_bl(:), dW_downer_bl(:), ...
    'VariableNames', {'MW_g_mol','Blend','Riser','Downer'});
writetable(T_S9, 'FigS9_PP_blend.csv');

% ---- S10: Mixed PP sensitivity to barrier H2 ----
H2_down_s10 = [0.001, 0.0035, 0.01];
Npts = length(MW_blend_S9);
dW_s10 = zeros(length(H2_down_s10), Npts);
for k = 1:length(H2_down_s10)
    X_bar = X_barrier_S9; X_bar.H2 = H2_down_s10(k); X_bar.C3H6 = 1 - H2_down_s10(k);
    [~, ~, ~, MW_k, dW_k] = mzcr_pfr_model(T_mzcr, P_mzcr, r_Do, X_bar, X_bar, ...
        mcat_cal, tau_riser, tau_downer, L_D, Ac_D, epsilon_D, 1);
    dW_d_bl = interp1(MW_k(:), dW_k(:), MW_blend_S9(:), 'linear', 0);
    dW_s10(k,:) = (0.5 * dW_riser_bl(:) + 0.5 * dW_d_bl(:))';
end
T_S10 = table(MW_blend_S9(:), dW_s10(1,:)', dW_s10(2,:)', dW_s10(3,:)', ...
    'VariableNames', {'MW_g_mol','H2_0_1pct','H2_0_35pct','H2_1pct'});
writetable(T_S10, 'FigS10_PP_blend_H2.csv');

% ---- S11: ICP sensitivity to gas-phase H2 ----
H2_gas_s11 = [0.02, 0.05, 0.08];
Mw_EPR_s11 = zeros(size(H2_gas_s11)); PDI_ICP_s11 = zeros(size(H2_gas_s11));
for k = 1:length(H2_gas_s11)
    X_g = X_gas_icp; X_g.H2 = H2_gas_s11(k); X_g.C3H6 = 1 - H2_gas_s11(k) - 0.45;
    [cC3, ~, cC2] = get_monomer_concentrations(X_g, T_gas+273.15, P_gas, 'gas');
    P_H2_g_psi = X_g.H2 * P_gas / 6894.76;
    [w_g_k, Mn_g_k] = local_flory(T_gas, P_H2_g_psi, r_Do);
    w_epr_k = w_g_k(1:3)/sum(w_g_k(1:3)); Mn_epr_k = Mn_g_k(1:3);
    Mw_EPR_s11(k) = sum(w_epr_k .* (2*Mn_epr_k));
    fac = zeros(1,5);
    for i=1:5, if i<=3, fac(i)=(cC3+cC2)/cC3_liq; else, fac(i)=cC2/cC3_liq; end; end
    amt = w_g_k .* fac; amt = amt/sum(amt);
    Rp_s2_k = activity_model(T_gas, P_H2_g_psi, r_Do) * S_prod * f_res * sum(w_g_k .* fac);
    m_s2_k = mcat_in_real * Rp_s2_k * tau_gas;
    m_epr_k = m_s2_k * sum(amt(1:3)); m_pe_k = m_s2_k * sum(amt(4:5));
    m_tot_k = m_iPP + m_epr_k + m_pe_k;
    Mn_epr_avg = 1/sum(w_epr_k ./ Mn_epr_k); Mw_epr_avg = Mw_EPR_s11(k);
    w_pe_k = w_g_k(4:5)/sum(w_g_k(4:5)); Mn_pe_k = Mn_g_k(4:5);
    Mn_pe_avg = 1/sum(w_pe_k ./ Mn_pe_k); Mw_pe_avg = sum(w_pe_k .* (2*Mn_pe_k));
    phi_i = m_iPP/m_tot_k; phi_e = m_epr_k/m_tot_k; phi_p = m_pe_k/m_tot_k;
    Mn_ICP = 1/(phi_i/Mn_ex1 + phi_e/Mn_epr_avg + phi_p/Mn_pe_avg);
    Mw_ICP = phi_i*Mw_ex1 + phi_e*Mw_epr_avg + phi_p*Mw_pe_avg;
    PDI_ICP_s11(k) = Mw_ICP / Mn_ICP;
end
T_S11 = table(H2_gas_s11'*100, Mw_EPR_s11'/1e3, PDI_ICP_s11', ...
    'VariableNames', {'Gas_H2_mol_pct','EPR_Mw_kg_mol','ICP_PDI'});
writetable(T_S11, 'FigS11_ICP_H2_gas.csv');

% =========================================================================
% SENSITIVITY TO DEACTIVATION CONSTANT kd (new SI figure)
% =========================================================================
kd_sens = 0.3 : 0.1 : 0.8;    % h⁻¹
N_kd = length(kd_sens);

phi_iPP_kd  = zeros(N_kd,1);
phi_EPR_kd  = zeros(N_kd,1);
phi_PE_kd   = zeros(N_kd,1);
total_C2_kd = zeros(N_kd,1);
Mn_ICP_kd   = zeros(N_kd,1);
Mw_ICP_kd   = zeros(N_kd,1);
PDI_ICP_kd  = zeros(N_kd,1);

% Before the kd sensitivity loop, re‑evaluate base‑case parameters
[cC3g, ~, cC2g] = get_monomer_concentrations(X_gas_icp, T_gas+273.15, P_gas, 'gas');
P_H2_gas_psi = X_gas_icp.H2 * P_gas / 6894.76;
[w_gas, Mn_gas] = local_flory(T_gas, P_H2_gas_psi, r_Do);
factor = zeros(1,5); amount = zeros(1,5);
for i = 1:5
    if i <= 3, factor(i) = (cC3g + cC2g) / cC3_liq;
    else, factor(i) = cC2g / cC3_liq; end
    amount(i) = w_gas(i) * factor(i);
end
amount = amount / sum(amount);

for k = 1:N_kd
    % --- Restore baseline gas‑phase conditions and iPP mass ---
    cC3g   = cC3g_base;
    cC2g   = cC2g_base;
    w_gas  = w_gas_base;
    amount = amount_base;
    m_iPP  = m_iPP_base;          % industrial iPP mass (unchanged by kd)
    
    % Residual activity for this kd
    f_res_k = exp(-kd_sens(k) * (tau_riser + tau_downer));
    
    % Gas‑phase polymerisation rate (proportional to f_res_k)
    Rp_s2 = activity_model(T_gas, P_H2_gas_psi_base, r_Do) * S_prod * f_res_k * sum(w_gas_base .* factor_base);
    m_s2_total = mcat_in_real * Rp_s2 * tau_gas;
    m_EPR = m_s2_total * sum(amount(1:3));
    m_PE  = m_s2_total * sum(amount(4:5));
    
    m_total_batch = m_iPP + m_EPR + m_PE;
    phi_iPP_kd(k) = m_iPP / m_total_batch;
    phi_EPR_kd(k) = m_EPR / m_total_batch;
    phi_PE_kd(k)  = m_PE  / m_total_batch;
    
    % EPR composition (independent of kd)
    f1_g = cC3g / (cC3g + cC2g);
    F1_EPR = (best_r1*f1_g^2 + f1_g*(1-f1_g)) / ...
             (best_r1*f1_g^2 + 2*f1_g*(1-f1_g) + best_r2*(1-f1_g)^2);
    C2_EPR = (1 - F1_EPR) * 28.05 / (F1_EPR*42.08 + (1 - F1_EPR)*28.05);
    total_C2_kd(k) = phi_EPR_kd(k) * C2_EPR + phi_PE_kd(k);
    
    % MWD averages for the second‑stage phases (use baseline Flory parameters)
    [w_epr_blend, Mn_epr_blend, Mw_epr_blend] = site_averages(amount(1:3), Mn_gas_base(1:3));
    [w_pe_blend,  Mn_pe_blend,  Mw_pe_blend]  = site_averages(amount(4:5), Mn_gas_base(4:5));
    
    Mn_ICP_kd(k) = 1 / (phi_iPP_kd(k)/Mn_ex1 + phi_EPR_kd(k)/Mn_epr_blend + phi_PE_kd(k)/Mn_pe_blend);
    Mw_ICP_kd(k) = phi_iPP_kd(k)*Mw_ex1 + phi_EPR_kd(k)*Mw_epr_blend + phi_PE_kd(k)*Mw_pe_blend;
    PDI_ICP_kd(k) = Mw_ICP_kd(k) / Mn_ICP_kd(k);
end

% Export
T_kd = table(kd_sens', phi_iPP_kd*100, phi_EPR_kd*100, phi_PE_kd*100, ...
    total_C2_kd*100, Mn_ICP_kd, Mw_ICP_kd, PDI_ICP_kd, ...
    'VariableNames', {'kd_h−1','iPP_pct','EPR_pct','PE_pct','Total_C2_pct', ...
                      'Mn_ICP_gmol','Mw_ICP_gmol','PDI_ICP'});
writetable(T_kd, 'FigS16_ICP_kd_sensitivity.csv');

% =========================================================================
% GRADE‑DESIGN MAP: gas‑phase C2H4 fraction × temperature (new SI figure)
% =========================================================================
C2H4_grid = 0.35 : 0.025 : 0.65;     % ethylene feed fraction (‑)
T_grid    = 75 : 2.5 : 85;            % gas‑phase temperature (°C)

N_C2 = length(C2H4_grid);
N_Tg = length(T_grid);

[CC2, TT] = ndgrid(C2H4_grid, T_grid);

iPP_map  = zeros(N_C2, N_Tg);
EPR_map  = zeros(N_C2, N_Tg);
PE_map   = zeros(N_C2, N_Tg);
C2tot_map = zeros(N_C2, N_Tg);
Mn_map   = zeros(N_C2, N_Tg);
Mw_map   = zeros(N_C2, N_Tg);
PDI_map  = zeros(N_C2, N_Tg);

for i = 1:N_C2
    for j = 1:N_Tg
        X_g = X_gas_icp;                  % start from base case
        X_g.C2H4 = C2H4_grid(i);
        X_g.C3H6 = 1 - X_g.H2 - C2H4_grid(i);   % H2 fixed at 0.05

        [cC3, ~, cC2] = get_monomer_concentrations(X_g, T_grid(j)+273.15, P_gas, 'gas');
        P_H2_psi = X_g.H2 * P_gas / 6894.76;
        [w_loc, Mn_loc] = local_flory(T_grid(j), P_H2_psi, r_Do);

        % Site‑dependent driving forces
        fac = zeros(1,5);
        for s = 1:5
            if s <= 3
                fac(s) = (cC3 + cC2) / cC3_liq;
            else
                fac(s) = cC2 / cC3_liq;
            end
        end
        amt = w_loc .* fac;   amt = amt / sum(amt);

        Rp_s2_k = activity_model(T_grid(j), P_H2_psi, r_Do) * S_prod * f_res * sum(w_loc .* fac);
        m_s2_k  = mcat_in_real * Rp_s2_k * tau_gas;
        m_epr_k = m_s2_k * sum(amt(1:3));
        m_pe_k  = m_s2_k * sum(amt(4:5));
        m_tot_k = m_iPP + m_epr_k + m_pe_k;

        iPP_map(i,j) = m_iPP / m_tot_k;
        EPR_map(i,j) = m_epr_k / m_tot_k;
        PE_map(i,j)  = m_pe_k  / m_tot_k;

        f1 = cC3 / (cC3 + cC2);
        F1 = (best_r1*f1^2 + f1*(1-f1)) / ...
             (best_r1*f1^2 + 2*f1*(1-f1) + best_r2*(1-f1)^2);
        C2_epr = (1 - F1)*28.05 / (F1*42.08 + (1 - F1)*28.05);
        C2tot_map(i,j) = EPR_map(i,j)*C2_epr + PE_map(i,j);

        % MWD of EPR and PE phases
        [~, Mn_epr_avg, Mw_epr_avg] = site_averages(amt(1:3), Mn_loc(1:3));
        [~, Mn_pe_avg,  Mw_pe_avg]  = site_averages(amt(4:5), Mn_loc(4:5));

        Mn_map(i,j) = 1 / (iPP_map(i,j)/Mn_ex1 + EPR_map(i,j)/Mn_epr_avg + PE_map(i,j)/Mn_pe_avg);
        Mw_map(i,j) = iPP_map(i,j)*Mw_ex1 + EPR_map(i,j)*Mw_epr_avg + PE_map(i,j)*Mw_pe_avg;
        PDI_map(i,j) = Mw_map(i,j) / Mn_map(i,j);
    end
end

% Export as unrolled table for contour plotting
[CC2_vec, TT_vec] = ndgrid(C2H4_grid, T_grid);
T_map = table(CC2_vec(:), TT_vec(:), iPP_map(:)*100, EPR_map(:)*100, PE_map(:)*100, ...
    C2tot_map(:)*100, Mn_map(:), Mw_map(:), PDI_map(:), ...
    'VariableNames', {'C2H4_feed','T_gas_degC','iPP_pct','EPR_pct','PE_pct', ...
                      'Total_C2_pct','Mn_ICP_gmol','Mw_ICP_gmol','PDI_ICP'});
writetable(T_map, 'Fig6_ICP_grade_map.csv');


fprintf('All SI figure tables exported.\n');

% =========================================================================
% 6. PARTICLE SIZE DISTRIBUTION (SI Figure S12) – already uses mcat_in_real
% =========================================================================
fprintf('\n--- Computing PSD for EX1 downer ---\n');
[mzcr_PSD_z, ~, ~, d_mean_vec] = mzcr_pfr_model_PSD_simple(...
    T_mzcr, P_mzcr, r_Do, X_ex1, ...
    mcat_in_real, tau_downer, L_D, Ac_D, epsilon_D, S_prod, ...
    900, 0.3, 50e-6);

% Mean diameter curve
T_dmean = table(mzcr_PSD_z, d_mean_vec*1e6, 'VariableNames', {'z_m','d_mean_um'});
writetable(T_dmean, 'FigS12_dmean.csv');

% Generate outlet PSD by shifting an initial narrow distribution
% Assume lognormal: median = d_prep, spread = 1.02
d_prep = 50e-6;
sigma_ln = 0.02;  % narrow distribution
d_initial_vec = logspace(log10(2e-6), log10(200e-6), 200)';
pdf_initial = lognpdf(d_initial_vec, log(d_prep), sigma_ln);
pdf_initial = pdf_initial / trapz(d_initial_vec, pdf_initial);  % normalise

d_final = d_mean_vec(end);
shift_factor = d_final / d_prep;
d_shifted = d_initial_vec * shift_factor;

% Keep same shape, scale densities inversely to conserve mass
pdf_shifted = pdf_initial / shift_factor;  % because dVolume ∝ d³

% Mass‑weighted distribution (assumes spherical particles, constant density)
mass_fraction = pdf_shifted .* (d_shifted.^3);
mass_fraction = mass_fraction / trapz(d_shifted, mass_fraction);

% Export as a two‑column table: diameter (µm), normalised mass fraction
T_PSD_shift = table(d_shifted*1e6, mass_fraction, ...
    'VariableNames', {'Diameter_um','Mass_fraction'});
writetable(T_PSD_shift, 'FigS12_PSD_EX1.csv');

fprintf('PSD data exported (FigS12).\n');

% ---- S14: Stockmayer CCD of EX2 ----
[MW_grid, F1_grid] = ndgrid(MW_ccd, F1_ccd);
T_S13 = table(MW_grid(:), F1_grid(:), CCD_ex2(:), ...
    'VariableNames', {'MW_g_per_mol','F1_propylene','dW_dlogM_dF1'});
writetable(T_S13, 'FigS14_CCD_EX2.csv');


% =========================================================================
% LOCAL FUNCTIONS
% =========================================================================

function [w_norm, Mn_avg, Mw_avg] = site_averages(amount_sub, Mn_sub)
    w_norm = amount_sub / sum(amount_sub);
    Mn_avg = 1 / sum(w_norm ./ Mn_sub);
    Mw_avg = sum(w_norm .* (2 * Mn_sub));
end

function dy = downer_ode_homo(z, y, T_degC, P_total_Pa, r_Do, Ac, eps, rho_cat, S_prod)
    dy = zeros(3,1);
    F_C3 = y(1); F_H2 = y(2);
    F_tot = F_C3 + F_H2;
    if F_tot <= 0, return; end
    P_C3 = F_C3 / F_tot * P_total_Pa;  P_H2 = F_H2 / F_tot * P_total_Pa;
    X_cur.C3H6 = P_C3 / P_total_Pa; X_cur.H2 = P_H2 / P_total_Pa; X_cur.C2H4 = 0;
    [cC3_am, cH2_am] = get_monomer_concentrations(X_cur, T_degC+273.15, P_total_Pa, 'gas');
    P_H2_eff = max(P_H2 / 6894.76, 0.1);   % floor 0.1 psi
    [w, Mn] = local_flory(T_degC, P_H2_eff, r_Do);
    Mn_avg = 1 / sum(w ./ Mn);
    Rp_sp = activity_model(T_degC, P_H2_eff, r_Do) * S_prod;
    Rp_vol = Rp_sp * rho_cat;
    Rp_mol_C3_s = Rp_vol / (42.08 * 3600);
    R_H2_sp = Rp_sp / Mn_avg;
    R_H2_vol = R_H2_sp * rho_cat;
    R_H2_mol_s = R_H2_vol / 3600;
    mass_rate = Rp_vol * (1 - eps) * Ac / 3600;
    dy(1) = - Rp_mol_C3_s * (1 - eps) * Ac;
    dy(2) = - R_H2_mol_s  * (1 - eps) * Ac;
    dy(3) = mass_rate;
end

function dy = downer_ode_copol_axial(z, y, T_degC, P_total_Pa, r_Do, Ac, eps, rho_cat, r1, r2, S_prod)
    dy = zeros(4,1);
    F_C3 = y(1); F_H2 = y(2); F_C2 = y(3);
    F_tot = F_C3 + F_H2 + F_C2;
    if F_tot <= 0, return; end
    P_C3 = F_C3 / F_tot * P_total_Pa; P_H2 = F_H2 / F_tot * P_total_Pa; P_C2 = F_C2 / F_tot * P_total_Pa;
    X_cur.C3H6 = P_C3 / P_total_Pa; X_cur.H2 = P_H2 / P_total_Pa; X_cur.C2H4 = P_C2 / P_total_Pa;
    [cC3, cH2, cC2] = get_monomer_concentrations(X_cur, T_degC+273.15, P_total_Pa, 'gas');
    P_H2_eff = max(P_H2 / 6894.76, 0.1);   % floor 0.1 psi
    [w, Mn] = local_flory(T_degC, P_H2_eff, r_Do);
    Mn_avg = 1 / sum(w ./ Mn);
    Rp_sp = activity_model(T_degC, P_H2_eff, r_Do) * S_prod;
    Rp_vol = Rp_sp * rho_cat;
    f1 = cC3 / (cC3 + cC2);
    F1 = (r1*f1^2 + f1*(1-f1)) / (r1*f1^2 + 2*f1*(1-f1) + r2*(1-f1)^2);
    M_avg = F1*42.08 + (1-F1)*28.05;
    total_monomer_mol_s = Rp_vol / (M_avg * 3600);
    Rp_C3_mol_s = F1 * total_monomer_mol_s;
    Rp_C2_mol_s = (1-F1) * total_monomer_mol_s;
    R_H2_sp = Rp_sp / Mn_avg;
    R_H2_vol = R_H2_sp * rho_cat;
    R_H2_mol_s = R_H2_vol / 3600;
    mass_rate = Rp_vol * (1-eps) * Ac / 3600;
    dy(1) = - Rp_C3_mol_s * (1-eps) * Ac;
    dy(2) = - R_H2_mol_s  * (1-eps) * Ac;
    dy(3) = - Rp_C2_mol_s * (1-eps) * Ac;
    dy(4) = mass_rate;
end

function Mw_val = run_ex1_Mw(xH2, T, P_tot, r_Do, mcat, tauR, tauD, L_D, Ac_D, epsD)
    X.C3H6 = 1 - xH2;
    X.H2   = xH2;
    X.C2H4 = 0;
    [Mw_val, ~, ~] = mzcr_pfr_model(T, P_tot, r_Do, X, X, mcat, tauR, tauD, L_D, Ac_D, epsD, 1);
end

    %   Why the axial profiles use mcat_cal even though the real catalyst feed is mcat_in_real

    %   The MWD calibration was performed under the assumption of a perfectly uniform downer composition.
    %   We calibrated the hydrogen partial pressure (2.54 psi) by running the PFR model with a negligible catalyst feed (mcat_cal = 0.05 g h⁻¹) 
    %   and S_prod = 1. Because the consumption is then essentially zero, the gas composition stays flat along the reactor, and the local MWD 
    %   is everywhere the same. This flat‑profile assumption is the foundation of the entire MWD calibration.

    %   The axial profiles in the Supporting Information are meant to illustrate the conditions assumed during that calibration, not the actual 
    %   industrial reactor.
    %   They demonstrate that, under the calibration assumptions, the downer indeed sees a constant H₂ pressure and the polymer properties 
    %   remain uniform. This supports the validity of using a single H₂ value to characterise the entire downer.

    %   If we generated the SI profiles with the industrial catalyst feed (mcat_in_real), we would see a small H₂ gradient (as your assistant 
    %   observed).
    %   That gradient would be physically real for the actual industrial reactor, but it would contradict the calibration basis because the 
    %   calibration did not account for this gradient. The calibrated H₂ pressure (2.54 psi) would no longer guarantee Mw = 400 000 if the 
    %   composition varied along the bed. Consequently, the calibration would be inconsistent with the profiles shown in the SI.

    %   To avoid this inconsistency, we keep the profiles true to the calibration framework.
    %   By exporting S1, S2, S5 with mcat_cal, we show the idealised flat profiles that the calibration assumes. In the manuscript, we state 
    %   clearly that the barrier fluid maintains a nearly constant gas environment, which is the industrial norm; the flat profiles are 
    %   therefore a faithful representation of the process's intended operation.

    %   The PSD model, in contrast, uses mcat_in_real because particle size depends on the absolute production rate, not on the calibration 
    %   assumption.
    %   There is no conflict: the MWD calibration relies on the flat‑profile idealisation, while the PSD uses the real throughput to get 
    %   the correct particle diameter.

    %   Bottom line
    %   For the axial SI profiles (S1, S2, S5): use mcat_cal → flat profiles, consistent with the calibration assumption.
    %   For production rate, PSD, and ICP predictions: use mcat_in_real → reflects actual industrial throughput.