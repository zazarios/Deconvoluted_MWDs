function [w, Mn] = interpFlory(T_degC, PH2_psi, DoTi)
% INTERPFLORY  Interpolate Alshaiban's Flory components.
%   [w, Mn] = interpFlory(T, PH2, DoTi)
%   w   : 1×5 vector of weight fractions (sum = 1)
%   Mn  : 1×5 vector of number-average molecular weights (g/mol)

persistent Fw FMn dataPoints
if isempty(Fw) || isempty(FMn)
    data = init_flory_data();
    % All input points (every row is a complete experiment)
    pts = [[data.T_degC]', [data.PH2_psi]', [data.DoTi]'];  % N×3

    % For each site (1..5) build interpolants, ignoring points where w=0
    % (those are stored as w=0, Mn=1 – they are fine to include).
    for i = 1:5
        wvals = arrayfun(@(d) d.w(i), data)';
        Mnvals = arrayfun(@(d) d.Mn(i), data)';
        % Use linear interpolation, extrapolate with nearest neighbour
        % All values are non‑negative and finite → safe.
        Fw{i}  = scatteredInterpolant(pts, wvals, 'linear', 'nearest');
        FMn{i} = scatteredInterpolant(pts, Mnvals, 'linear', 'nearest');
    end
end

% Query
w = zeros(1,5); Mn = zeros(1,5);
for i = 1:5
    w(i)  = Fw{i}(T_degC, PH2_psi, DoTi);
    Mn(i) = FMn{i}(T_degC, PH2_psi, DoTi);
end

% Clean up: guarantee non‑negative weight and non‑zero Mn
w  = max(w, 0);
w  = w / sum(w);                     % normalise exactly to 1
Mn = max(Mn, 1);                     % avoid division by zero
end