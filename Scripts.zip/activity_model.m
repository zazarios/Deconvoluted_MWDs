function Rp = activity_model(T_degC, PH2_psi, DoTi)
% ACTIVITY_MODEL  Productivity (gPP / gcat·h) for the 4th gen Z-N catalyst.
%   Based on Alshaiban Table 4-2 and Pater's liquid pool kinetics (Chapter 3).

% --- Reference point (70 °C, 16 psi H2, Do/Ti = 1.4) ---
Rp_ref = 1010;          % gPP/(gcat·h)  (≈ 16.8 gPP/(gcat·min))
T_ref   = 70;           % °C
H2_ref  = 16;           % psi
Do_ref  = 1.4;

% --- Temperature effect (Arrhenius with levelling-off) ---
Ea  = 40e3;             % J/mol, typical for bulk propylene with this catalyst
R   = 8.314;
T_K = T_degC + 273.15;
T_K_ref = T_ref + 273.15;
fT = exp(-Ea/R*(1./T_K - 1/T_K_ref));

% --- Hydrogen enhancement (saturating function) ---
% From Pater Fig.3.8, fits: Rp = A * (1 - B*exp(-C*H2))
H2_fraction = PH2_psi / 100;   % normalised
fH2 = 1 - 0.78 * exp(-4.2 * H2_fraction);   % approximate fit

% --- Donor effect (mild quadratic) ---
dDo = (DoTi - Do_ref) / Do_ref;
fDo = 1 - 0.15 * dDo - 0.1 * dDo^2;        % small activity penalty for extremes

Rp = Rp_ref * fT * fH2 * fDo;
end