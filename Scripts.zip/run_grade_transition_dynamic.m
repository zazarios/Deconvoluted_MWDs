% run_grade_transition_dynamic.m   (fully corrected – dynamic CSTR)
% True dynamic CSTR simulation of the gas‑phase ICP reactor.
% Tracks the hold‑ups of iPP, EPR, PE and total ethylene.
% A step change in ethylene feed is applied at t = 0.

clear; clc;

% ---- Fixed parameters (from master script) ----
T_mzcr    = 70;             P_mzcr = 30e5;
r_Do      = 1.4;
tau_riser = 0.02;           tau_downer = 1.0;
L_D = 20;                   Ac_D = pi*(0.55)^2;
epsilon_D = 0.35;

P_H2_psi_opt = 2.54;
xH2_opt = P_H2_psi_opt * 6894.76 / P_mzcr;
X_ex1.C3H6 = 1 - xH2_opt; X_ex1.H2 = xH2_opt; X_ex1.C2H4 = 0;

S_prod = 50;
target_prod_rate = 16.4e6;   % g/h
Rp_sp_lab = activity_model(T_mzcr, P_H2_psi_opt, r_Do);
Rp_sp_ind = Rp_sp_lab * S_prod;
mcat_in_real = target_prod_rate / (Rp_sp_ind * tau_downer);

% iPP production rate (constant) & iPP MWD
Rp_mzcr = activity_model(T_mzcr, P_H2_psi_opt, r_Do) * S_prod;
m_iPP_rate = mcat_in_real * Rp_mzcr;   % g/h
[Mw_iPP, Mn_iPP] = mzcr_pfr_model(T_mzcr, P_mzcr, r_Do, ...
    X_ex1, X_ex1, mcat_in_real, tau_riser, tau_downer, ...
    L_D, Ac_D, epsilon_D, S_prod);

% Deactivation
kd = 0.5;
f_res = exp(-kd * (tau_riser + tau_downer));

% Gas‑phase reactor parameters
P_gas   = 15e5;     T_gas  = 80;
tau_gas = 0.3;      % h
H2_feed = 0.05;
cC3_liq = 2.87;
best_r1 = 4.00;     best_r2 = 0.79;
m_cat_gas = mcat_in_real * tau_gas;   % g catalyst in gas reactor

% ---- Function to get instantaneous production rates and composition ----
get_instant = @(C2) compute_instant(C2, T_gas, P_gas, H2_feed, ...
    best_r1, best_r2, r_Do, f_res, S_prod, mcat_in_real, cC3_liq);

% ---- Initial steady state at C2H4 = 0.45 ----
C2_base = 0.45;
[Rp_epr_base, Rp_pe_base, C2_EPR_base, amt_base, Mn_base, ~, ~] = get_instant(C2_base);
M_EPR_ss = Rp_epr_base * m_cat_gas * tau_gas;
M_PE_ss  = Rp_pe_base  * m_cat_gas * tau_gas;
M_C2_ss  = M_EPR_ss * C2_EPR_base + M_PE_ss;   % PE is pure ethylene

M_EPR = M_EPR_ss;
M_PE  = M_PE_ss;
M_C2  = M_C2_ss;

% ---- Time settings ----
t_start = 0;
t_end   = 4 * tau_gas;      % 4 residence times
dt      = tau_gas / 50;
t_vec   = t_start : dt : t_end;
Nt      = length(t_vec);
C2_target = 0.55;
switch_time = 0;

% Pre‑allocate
phi_iPP_dyn = zeros(Nt,1);
phi_EPR_dyn = zeros(Nt,1);
phi_PE_dyn  = zeros(Nt,1);
C2tot_dyn   = zeros(Nt,1);
Mn_dyn      = zeros(Nt,1);
Mw_dyn      = zeros(Nt,1);
PDI_dyn     = zeros(Nt,1);

for k = 1:Nt
    t = t_vec(k);
    C2_feed = (t >= switch_time) * C2_target + (t < switch_time) * C2_base;

    % Instantaneous production rates and EPR composition
    [Rp_epr, Rp_pe, C2_EPR_inst, amt_inst, Mn_inst, cC3g, cC2g] = get_instant(C2_feed);

    % ---- Dynamic mass balances ----
    dM_EPR_dt = Rp_epr * m_cat_gas - M_EPR / tau_gas;
    dM_PE_dt  = Rp_pe  * m_cat_gas - M_PE  / tau_gas;
    % Ethylene mass balance: production (EPR part + PE) − outflow
    dM_C2_dt  = (Rp_epr * m_cat_gas * C2_EPR_inst + Rp_pe * m_cat_gas) - M_C2 / tau_gas;

    M_EPR = M_EPR + dM_EPR_dt * dt;
    M_PE  = M_PE  + dM_PE_dt  * dt;
    M_C2  = M_C2  + dM_C2_dt  * dt;

    % ---- Outlet mass flow rates ----
    F_iPP_out = m_iPP_rate;
    F_EPR_out = M_EPR / tau_gas;
    F_PE_out  = M_PE  / tau_gas;
    F_total   = F_iPP_out + F_EPR_out + F_PE_out;

    % Outlet composition (instantaneous product)
    phi_iPP_dyn(k) = F_iPP_out / F_total;
    phi_EPR_dyn(k) = F_EPR_out / F_total;
    phi_PE_dyn(k)  = F_PE_out  / F_total;

    % Total C2 from the dynamic hold‑up
    C2tot_dyn(k) = (M_C2 / tau_gas) / F_total;

    % ---- Blended molecular weights ----
    % The EPR and PE in the reactor have the instantaneous composition
    % because the gas phase responds instantly.
    w_epr = amt_inst(1:3) / sum(amt_inst(1:3));
    Mn_EPR = 1 / sum(w_epr ./ Mn_inst(1:3));
    Mw_EPR = sum(w_epr .* (2 * Mn_inst(1:3)));
    w_pe   = amt_inst(4:5) / sum(amt_inst(4:5));
    Mn_PE  = 1 / sum(w_pe ./ Mn_inst(4:5));
    Mw_PE  = sum(w_pe .* (2 * Mn_inst(4:5)));

    Mn_dyn(k) = 1 / (phi_iPP_dyn(k)/Mn_iPP + phi_EPR_dyn(k)/Mn_EPR + phi_PE_dyn(k)/Mn_PE);
    Mw_dyn(k) = phi_iPP_dyn(k)*Mw_iPP + phi_EPR_dyn(k)*Mw_EPR + phi_PE_dyn(k)*Mw_PE;
    PDI_dyn(k) = Mw_dyn(k) / Mn_dyn(k);
end

% Export
T = table(t_vec', phi_iPP_dyn*100, phi_EPR_dyn*100, phi_PE_dyn*100, ...
    C2tot_dyn*100, Mn_dyn, Mw_dyn, PDI_dyn, ...
    'VariableNames', {'Time_h','iPP_pct','EPR_pct','PE_pct','Total_C2_pct', ...
                      'Mn_ICP_gmol','Mw_ICP_gmol','PDI_ICP'});
writetable(T, 'Fig7_grade_transition.csv');

fprintf('Initial: iPP %.2f, EPR %.2f, PE %.2f, C2 %.2f, Mn %.0f, Mw %.0f\n', ...
    phi_iPP_dyn(1)*100, phi_EPR_dyn(1)*100, phi_PE_dyn(1)*100, ...
    C2tot_dyn(1)*100, Mn_dyn(1), Mw_dyn(1));
fprintf('Final:   iPP %.2f, EPR %.2f, PE %.2f, C2 %.2f, Mn %.0f, Mw %.0f\n', ...
    phi_iPP_dyn(end)*100, phi_EPR_dyn(end)*100, phi_PE_dyn(end)*100, ...
    C2tot_dyn(end)*100, Mn_dyn(end), Mw_dyn(end));

% Plot
figure;
subplot(2,1,1);
plot(t_vec, phi_iPP_dyn*100, 'b', t_vec, phi_EPR_dyn*100, 'r', ...
     t_vec, phi_PE_dyn*100, 'g', 'LineWidth',1.5);
xlabel('Time (h)'); ylabel('Mass fraction (wt%)');
legend('iPP','EPR','PE'); title('Dynamic CSTR grade transition (step)');

subplot(2,1,2);
yyaxis left; plot(t_vec, Mn_dyn, 'b', t_vec, Mw_dyn, 'r', 'LineWidth',1.5);
ylabel('Molecular weight (g/mol)');
yyaxis right; plot(t_vec, PDI_dyn, 'k', 'LineWidth',1.5);
ylabel('PDI'); xlabel('Time (h)');
legend('M_n','M_w','PDI'); grid on;

% ------------------------------------------------------------------------
function [Rp_epr, Rp_pe, C2_EPR, amt, Mn, cC3g, cC2g] = compute_instant(C2, T_gas, P_gas, ...
    H2_feed, best_r1, best_r2, r_Do, f_res, S_prod, mcat_in_real, cC3_liq)

    X_gas.H2   = H2_feed;
    X_gas.C2H4 = C2;
    X_gas.C3H6 = 1 - H2_feed - C2;

    [cC3g, ~, cC2g] = get_monomer_concentrations(X_gas, T_gas+273.15, P_gas, 'gas');
    P_H2_psi = X_gas.H2 * P_gas / 6894.76;
    [w, Mn] = local_flory(T_gas, P_H2_psi, r_Do);

    fac = zeros(1,5);
    for i = 1:5
        if i <= 3, fac(i) = (cC3g + cC2g) / cC3_liq;
        else,       fac(i) = cC2g / cC3_liq; end
    end
    amt = w .* fac;
    amt = amt / sum(amt);

    Rp_total = activity_model(T_gas, P_H2_psi, r_Do) * S_prod * f_res * sum(w .* fac);

    Rp_epr = Rp_total * sum(amt(1:3));
    Rp_pe  = Rp_total * sum(amt(4:5));

    % Mayo‑Lewis for instantaneous EPR composition
    f1 = cC3g / (cC3g + cC2g);
    F1_EPR = (best_r1*f1^2 + f1*(1-f1)) / ...
             (best_r1*f1^2 + 2*f1*(1-f1) + best_r2*(1-f1)^2);
    C2_EPR = (1 - F1_EPR) * 28.05 / (F1_EPR*42.08 + (1 - F1_EPR)*28.05);
end