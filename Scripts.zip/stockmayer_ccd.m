function [CCD, MW_vec, F1_vec] = stockmayer_ccd(w, Mn, F1_avg, r1, r2)
% Multi‑site Stockmayer bivariate weight distribution
%   w : site weight fractions (1×5)
%   Mn: site number‑average molecular weights (1×5)
%   F1_avg: average propylene molar fraction in the copolymer
%   r1, r2 : reactivity ratios

N_MW = 200;    % grid resolution
N_F1 = 100;
MW_vec = logspace(log10(100), log10(10 * max(Mn)), N_MW)';
F1_vec = linspace(0, 1, N_F1);

M_C3 = 42.08;
M_C2 = 28.05;
M_avg = F1_avg * M_C3 + (1 - F1_avg) * M_C2;

beta = F1_avg * (1 - F1_avg) * sqrt(1 - 4 * F1_avg * (1 - F1_avg) * (1 - r1 * r2));

[MW_grid, F1_grid] = ndgrid(MW_vec, F1_vec);
r = MW_grid / M_avg;

CCD = zeros(size(MW_grid));
for i = 1:length(w)
    tau = 1 / Mn(i);
    dW_dlogM = 2.3026 * MW_grid.^2 * tau^2 .* exp(-tau * MW_grid);
    dw_dF1 = (1 ./ sqrt(2 * pi * beta ./ r)) .* exp(- (F1_grid - F1_avg).^2 .* r / (2 * beta));
    CCD = CCD + w(i) * dW_dlogM .* dw_dF1;
end
end