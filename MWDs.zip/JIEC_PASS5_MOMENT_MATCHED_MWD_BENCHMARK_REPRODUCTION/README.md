# JIEC Pass-5 Moment-Matched MWD Benchmark Reproduction

## Purpose

This package closes the repository-level reproducibility gap for the conventional
moment-matched MWD benchmark used in Supporting Information Section S16 and
main-text Figure 6.

The original numerical audit is preserved unchanged under:

```text
sealed_reference/Hardening_Pass5_Conventional_Representation_Benchmark_SEALED/
```

Its internal manifest verifies **13/13** payload files.

The companion MATLAB reproducer in this directory reconstructs the primary
12-case benchmark from frozen Stage-E MWD curves and the comparator parameters
preserved by the sealed Pass-5 audit. It does not rerun or alter the reactor model.

## Inputs

`inputs/` contains:

- `StageE_reference_MWD_curves.csv`
- `StageE_worst_witness_MWD_curves.csv`
- `Pass5_comparator_parameters.csv`
- `Pass5_case_targets.csv`

The two Stage-E curve files are byte-identical copies of the qualified Stage-K
cumulative inputs. The comparator parameters originate from the sealed Pass-5
audit. `Pass5_case_targets.csv` is a compact extraction of the unique target
Mn/Mw values from the sealed final-distribution benchmark.

Input origin and SHA-256 values are recorded in `INPUT_PROVENANCE.csv`.

## Comparator construction

### Lognormal

The frozen Pass-5 `mu_ln_number` and `sigma_ln` define a lognormal number
distribution. Its induced weight distribution on `x = log10(M)` is reconstructed
and normalized on the frozen Stage-E molecular-weight grid.

### Schulz-Zimm/gamma

The frozen Pass-5 `k_number_gamma` and `theta_gmol` define a gamma number
distribution. The induced weight distribution is reconstructed on the same grid
and normalized. The sealed parameters were numerically adjusted in the original
Pass-5 audit to match the specified Mn and Mw under the benchmark quadrature.

### Phase-wise single-Flory

The contextual phase-wise single-Flory curves are read directly from the frozen
Stage-E exports.

## Metrics

The reproducer computes:

- Wasserstein-1 distance on `log10(M)`;
- Jensen-Shannon divergence in bits;
- M90 and M99 ratios;
- tail excess above the comparator M90; and
- direct lognormal-versus-Schulz-Zimm separation.

The 12 final cases consist of six transparent reference cases and six qualified
adverse-witness cases: DIRECT and repeat-mass-corrected (`DP`) transfer modes at
10, 20, and 30 wt% second-stage polymer fraction.

## Run

In MATLAB R2025b:

```matlab
Run_JIEC_Pass5_MomentMatched_Benchmark_Reproduction
```

Outputs are written to `Outputs_Pass5_Reproduced/`.

## Verification

The reproduced casewise metrics, same-moment pairwise metrics, and W1 tolerance
counts are compared directly against the unchanged sealed Pass-5 audit.

The archived reconstruction performed while preparing this repository gave:

- maximum casewise metric difference: `8.53e-14`;
- maximum same-moment pairwise metric difference: `7.28e-15`;
- W1 tolerance-count difference: `0`.

These are numerical-precision differences only.

## Scientific scope

This benchmark does not show that component-resolved representations are always
necessary. It shows that matching Mn and Mw alone does not uniquely select an
MWD shape: the exact-Mn/Mw lognormal and Schulz-Zimm closures can remain strongly
separated in full-distribution space.

## Archival use

The deposited directory is a frozen reproducibility artifact. To preserve its
SHA-256 manifest, run the MATLAB launcher in a working copy of the directory.
A rerun may rewrite CSV formatting or status files even when the numerical
values are unchanged.
