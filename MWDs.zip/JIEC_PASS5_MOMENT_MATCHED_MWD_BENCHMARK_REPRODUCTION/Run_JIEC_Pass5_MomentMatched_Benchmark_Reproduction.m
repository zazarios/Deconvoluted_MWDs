function Run_JIEC_Pass5_MomentMatched_Benchmark_Reproduction()
% Reproduction/verification of the primary 12-case conventional-MWD benchmark.
% This is a transparent MATLAB reproducer built from frozen Stage-E MWD curves
% and the sealed Pass-5 comparator parameters. It does not rerun the reactor model.
% MATLAB R2025b.

root = fileparts(mfilename('fullpath'));
inDir = fullfile(root,'inputs');
outDir = fullfile(root,'Outputs_Pass5_Reproduced');
sealedDir = fullfile(root,'sealed_reference','Hardening_Pass5_Conventional_Representation_Benchmark_SEALED');
if ~exist(outDir,'dir'); mkdir(outDir); end

R = readtable(fullfile(inDir,'StageE_reference_MWD_curves.csv'),'VariableNamingRule','preserve');
W = readtable(fullfile(inDir,'StageE_worst_witness_MWD_curves.csv'),'VariableNamingRule','preserve');
P = readtable(fullfile(inDir,'Pass5_comparator_parameters.csv'),'VariableNamingRule','preserve');
T = readtable(fullfile(inDir,'Pass5_case_targets.csv'),'VariableNamingRule','preserve');

M = R.M_gmol;
x = log10(M);

n = height(T);
StateGroup = string(T.StateGroup);
TransferMode = string(T.TransferMode);
EPC_wtfrac = T.EPC_wtfrac;

compNames = ["LOGNORMAL_MnMw","PHASEWISE_SINGLE_FLORY","SCHULZ_ZIMM_MnMw"];
JS = zeros(n,3); M90r=zeros(n,3); M99r=zeros(n,3); W1=zeros(n,3); Tail=zeros(n,3);
PairW1=zeros(n,1); PairJS=zeros(n,1);

for i=1:n
    sg=StateGroup(i); mode=TransferMode(i); epc=EPC_wtfrac(i);
    epci=round(100*epc);
    resName=sprintf('%s_EPC_%d_resolved',char(mode),epci);
    phaseName=sprintf('%s_EPC_%d_phasewise_collapsed',char(mode),epci);
    if sg=="REFERENCE_FINAL"
        res=R.(resName);
        phase=R.(phaseName);
        caseID=sprintf('REFERENCE_FINAL_%s_EPC%d',char(mode),epci);
    else
        res=W.(resName);
        phase=W.(phaseName);
        caseID=sprintf('ADVERSE_WITNESS_%s_EPC%d',char(mode),epci);
    end
    res=normdens(res,x);
    phase=normdens(phase,x);

    % Frozen Pass-5 lognormal parameters.
    m = strcmp(string(P.CaseID),caseID) & strcmp(string(P.Comparator),'LOGNORMAL_MnMw');
    mu=P.mu_ln_number(m); sig=P.sigma_ln(m);
    fN=exp(-0.5*((log(M)-mu)./sig).^2)./(M.*sig.*sqrt(2*pi));
    gl=log(10).*M.^2.*fN./T.Target_Mn(i);
    gl=normdens(gl,x);

    % Frozen Pass-5 Schulz-Zimm/gamma parameters.
    m = strcmp(string(P.CaseID),caseID) & strcmp(string(P.Comparator),'SCHULZ_ZIMM_MnMw');
    k=P.k_number_gamma(m); theta=P.theta_gmol(m);
    logf=(k-1).*log(M)-M./theta-gammaln(k)-k.*log(theta);
    f=exp(logf);
    gs=log(10).*M.^2.*f./(k.*theta);
    gs=normdens(gs,x);

    C={gl,phase,gs};
    for j=1:3
        c=C{j};
        [JS(i,j),M90r(i,j),M99r(i,j),W1(i,j),Tail(i,j)] = compare_mwd(res,c,M,x);
    end
    PairW1(i)=wasserstein1(gl,gs,x);
    PairJS(i)=jsbits(gl,gs,x);
end

Tout=table(StateGroup,TransferMode,EPC_wtfrac, ...
    JS(:,1),JS(:,2),JS(:,3), ...
    M90r(:,1),M90r(:,2),M90r(:,3), ...
    M99r(:,1),M99r(:,2),M99r(:,3), ...
    W1(:,1),W1(:,2),W1(:,3), ...
    Tail(:,1),Tail(:,2),Tail(:,3), ...
    'VariableNames',{'StateGroup','TransferMode','EPC_wtfrac', ...
    'JS_LOGNORMAL_MnMw','JS_PHASEWISE_SINGLE_FLORY','JS_SCHULZ_ZIMM_MnMw', ...
    'M90_ratio_LOGNORMAL_MnMw','M90_ratio_PHASEWISE_SINGLE_FLORY','M90_ratio_SCHULZ_ZIMM_MnMw', ...
    'M99_ratio_LOGNORMAL_MnMw','M99_ratio_PHASEWISE_SINGLE_FLORY','M99_ratio_SCHULZ_ZIMM_MnMw', ...
    'W1_LOGNORMAL_MnMw','W1_PHASEWISE_SINGLE_FLORY','W1_SCHULZ_ZIMM_MnMw', ...
    'tail_excess_LOGNORMAL_MnMw','tail_excess_PHASEWISE_SINGLE_FLORY','tail_excess_SCHULZ_ZIMM_MnMw'});
writetable(Tout,fullfile(outDir,'Pass5_Reproduced_casewise_comparator_metrics.csv'));

Tpair=table(StateGroup,TransferMode,EPC_wtfrac,PairW1,PairJS, ...
    'VariableNames',{'StateGroup','TransferMode','EPC_wtfrac', ...
    'W1_LOGNORMAL_vs_SCHULZ','JS_LOGNORMAL_vs_SCHULZ_bits'});
writetable(Tpair,fullfile(outDir,'Pass5_Reproduced_same_moment_nonuniqueness.csv'));

% Comparator summaries.
Comparator=strings(3,1); N=zeros(3,1);
W1_min=zeros(3,1); W1_median=zeros(3,1); W1_max=zeros(3,1);
JS_min=zeros(3,1); JS_median=zeros(3,1); JS_max=zeros(3,1);
M90_ratio_min=zeros(3,1); M90_ratio_median=zeros(3,1); M90_ratio_max=zeros(3,1);
M99_ratio_min=zeros(3,1); M99_ratio_median=zeros(3,1); M99_ratio_max=zeros(3,1);
TailExcess_min=zeros(3,1); TailExcess_median=zeros(3,1); TailExcess_max=zeros(3,1);
for j=1:3
    Comparator(j)=compNames(j); N(j)=n;
    W1_min(j)=min(W1(:,j)); W1_median(j)=median(W1(:,j)); W1_max(j)=max(W1(:,j));
    JS_min(j)=min(JS(:,j)); JS_median(j)=median(JS(:,j)); JS_max(j)=max(JS(:,j));
    M90_ratio_min(j)=min(M90r(:,j)); M90_ratio_median(j)=median(M90r(:,j)); M90_ratio_max(j)=max(M90r(:,j));
    M99_ratio_min(j)=min(M99r(:,j)); M99_ratio_median(j)=median(M99r(:,j)); M99_ratio_max(j)=max(M99r(:,j));
    TailExcess_min(j)=min(Tail(:,j)); TailExcess_median(j)=median(Tail(:,j)); TailExcess_max(j)=max(Tail(:,j));
end
Tsum=table(Comparator,N,W1_min,W1_median,W1_max,JS_min,JS_median,JS_max, ...
    M90_ratio_min,M90_ratio_median,M90_ratio_max,M99_ratio_min,M99_ratio_median,M99_ratio_max, ...
    TailExcess_min,TailExcess_median,TailExcess_max);
writetable(Tsum,fullfile(outDir,'Pass5_Reproduced_comparator_summary.csv'));

TpairSum=table(n,min(PairW1),median(PairW1),max(PairW1),min(PairJS),median(PairJS),max(PairJS), ...
    'VariableNames',{'N','W1_min','W1_median','W1_max','JS_min','JS_median','JS_max'});
writetable(TpairSum,fullfile(outDir,'Pass5_Reproduced_same_moment_summary.csv'));

% Tolerance counts used in SI Table S39.
qv=[0.5,1,1.5,2,4,8,16];
Q=[]; Comparator2=strings(0,1); Cases=[]; NN=[];
for iq=1:numel(qv)
    for j=1:3
        Q(end+1,1)=qv(iq); %#ok<AGROW>
        Comparator2(end+1,1)=compNames(j); %#ok<AGROW>
        Cases(end+1,1)=sum(W1(:,j) <= qv(iq)*0.020 + 1e-15); %#ok<AGROW>
        NN(end+1,1)=n; %#ok<AGROW>
    end
end
Ttol=table(Q,Comparator2,Cases,NN,'VariableNames', ...
    {'q_relative_to_W1_0p020','Comparator','Cases_meeting_W1_tolerance','N'});
writetable(Ttol,fullfile(outDir,'Pass5_Reproduced_W1_tolerance_counts.csv'));

% Verify reproduced metrics against the sealed numerical audit.
E = readtable(fullfile(sealedDir,'Pass5_casewise_comparator_metrics.csv'),'VariableNamingRule','preserve');
Etol = readtable(fullfile(sealedDir,'Pass5_W1_tolerance_counts.csv'),'VariableNamingRule','preserve');
Esp = readtable(fullfile(sealedDir,'Pass5_same_moment_nonuniqueness.csv'),'VariableNamingRule','preserve');

% Tables use the same frozen case ordering after sortrows.
Tout=sortrows(Tout,{'StateGroup','TransferMode','EPC_wtfrac'});
E=sortrows(E,{'StateGroup','TransferMode','EPC_wtfrac'});
metricNames=Tout.Properties.VariableNames(4:end);
maxCase=0;
for j=1:numel(metricNames)
    maxCase=max(maxCase,max(abs(Tout.(metricNames{j})-E.(metricNames{j})),[],'omitnan'));
end

Tpair=sortrows(Tpair,{'StateGroup','TransferMode','EPC_wtfrac'});
Esp=sortrows(Esp,{'StateGroup','TransferMode','EPC_wtfrac'});
maxPair=max([max(abs(Tpair.W1_LOGNORMAL_vs_SCHULZ-Esp.W1_decades)), ...
             max(abs(Tpair.JS_LOGNORMAL_vs_SCHULZ_bits-Esp.JS_bits))]);

Ttol=sortrows(Ttol,{'q_relative_to_W1_0p020','Comparator'});
Etol=sortrows(Etol,{'q_relative_to_W1_0p020','Comparator'});
maxTol=max(abs(Ttol.Cases_meeting_W1_tolerance-Etol.Cases_meeting_W1_tolerance));

Check=["Primary_casewise_metrics_match_sealed"; ...
       "Same_moment_pairwise_metrics_match_sealed"; ...
       "W1_tolerance_counts_match_sealed"; ...
       "Twelve_final_cases_present"];
Pass=[maxCase<1e-12; maxPair<1e-12; maxTol==0; n==12];
MaxError=[maxCase;maxPair;maxTol;0];
Tver=table(Check,Pass,MaxError);
writetable(Tver,fullfile(outDir,'Pass5_Reproduction_verification.csv'));

fid=fopen(fullfile(outDir,'PASS5_REPRODUCTION_STATUS.txt'),'w');
if all(Pass); status='REPRODUCED AND VERIFIED'; else; status='FAILED VERIFICATION'; end
fprintf(fid,'Status: %s\n',status);
fprintf(fid,'Nature: MATLAB reproduction from frozen Stage-E curves and sealed Pass-5 comparator parameters\n');
fprintf(fid,'Reactor-model rerun: NO\n');
fprintf(fid,'Verification checks: %d/%d PASS\n',sum(Pass),numel(Pass));
fclose(fid);

fprintf('[Pass5 reproduction] %d/%d verification checks PASS.\n',sum(Pass),numel(Pass));
end

function y=normdens(y,x)
y=y./trapz(x,y);
end

function c=cdfx(y,x)
y=normdens(y,x);
c=cumtrapz(x,y);
c=c./c(end);
end

function q=quantile_mwd(y,p,M,x)
c=cdfx(y,x);
[cu,ia]=unique(c,'stable');
q=interp1(cu,M(ia),p,'linear');
end

function w=wasserstein1(a,b,x)
a=normdens(a,x); b=normdens(b,x);
ca=cumtrapz(x,a); cb=cumtrapz(x,b);
w=trapz(x,abs(ca-cb));
end

function j=jsbits(a,b,x)
a=normdens(a,x); b=normdens(b,x);
m=0.5*(a+b);
ta=zeros(size(a)); tb=zeros(size(b));
ia=a>0; ib=b>0;
ta(ia)=a(ia).*log2(a(ia)./m(ia));
tb(ib)=b(ib).*log2(b(ib)./m(ib));
j=0.5*trapz(x,ta)+0.5*trapz(x,tb);
end

function t=tail_above(y,threshold,x)
c=cdfx(y,x);
ct=interp1(x,c,log10(threshold),'linear');
t=1-ct;
end

function [j,r90,r99,w,tex]=compare_mwd(res,comp,M,x)
m90r=quantile_mwd(res,0.90,M,x);
m99r=quantile_mwd(res,0.99,M,x);
m90c=quantile_mwd(comp,0.90,M,x);
m99c=quantile_mwd(comp,0.99,M,x);
j=jsbits(res,comp,x);
w=wasserstein1(res,comp,x);
r90=m90r/m90c;
r99=m99r/m99c;
tex=tail_above(res,m90c,x)-0.10;
end
