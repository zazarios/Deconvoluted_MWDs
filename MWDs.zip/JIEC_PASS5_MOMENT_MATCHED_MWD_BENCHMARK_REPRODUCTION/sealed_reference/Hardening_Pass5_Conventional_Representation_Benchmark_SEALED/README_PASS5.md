Hardening Pass 5 — Conventional representation benchmark

Scope
-----
Post-freeze benchmark only. No A–K reactor-model state, parameter, uncertainty domain, or qualified result is changed. The benchmark reads the frozen Stage-E exported resolved MWD curves.

Primary final-MWD set
---------------------
12 resolved final distributions: six transparent reference cases and six previously qualified adverse-witness cases (DIRECT and DP, EPC 10/20/30 wt%). Source EX1 and MZCR matrix curves are additional supporting cases.

Comparators
-----------
1. LOGNORMAL_MnMw: unimodal lognormal number distribution whose induced weight distribution matches the resolved final Mn and Mw.
2. SCHULZ_ZIMM_MnMw: unimodal Schulz–Zimm/gamma family numerically adjusted on the frozen Stage-E grid to match the same Mn and Mw exactly under the benchmark quadrature.
3. PHASEWISE_SINGLE_FLORY: frozen Stage-E comparator, retained only for context.
The lognormal and Schulz–Zimm closures have the same ordinary Mn and Mw targets but different shapes; their pairwise W1 therefore directly demonstrates that moments alone do not identify the MWD shape.

Key final-case findings
-----------------------
Moment-matched lognormal: W1 = 0.028354–0.037392 decades; median 0.032917.
Moment-matched Schulz–Zimm: W1 = 0.192943–0.222838 decades; median 0.206781.
Frozen phase-wise single-Flory: W1 = 0.261665–0.300104 decades.
Lognormal vs Schulz–Zimm with identical Mn/Mw: W1 = 0.217400–0.246798 decades.

Interpretation
--------------
The benchmark does not support a blanket claim that explicit Flory populations are always necessary. A moment-matched lognormal is close to the resolved final MWD at a coarse full-distribution tolerance, whereas the equally moment-matched Schulz–Zimm closure is not. Therefore ordinary moments alone do not select a unique MWD shape. Population-resolved information is most defensible when the target/tolerance requires more than a chosen unimodal closure can guarantee, or when experimentally deconvoluted population provenance itself is part of the information being propagated. This reinforces the manuscript's target- and tolerance-dependent representation thesis.
