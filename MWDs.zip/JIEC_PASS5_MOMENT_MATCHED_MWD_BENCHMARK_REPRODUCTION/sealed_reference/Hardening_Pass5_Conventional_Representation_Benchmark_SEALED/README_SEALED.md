# Hardening Pass 5 — Sealed numerical audit

This package contains the numerical audit supporting the conventional-representation benchmark in JIEC manuscript/SI v2.5.

## Scientific question
Do exact Mn and Mw values uniquely determine a sufficiently accurate molecular-weight-distribution representation?

## Comparators
- Moment-matched lognormal distribution
- Moment-matched Schulz–Zimm distribution
- Phase-wise same-Mn single-Flory comparator (contextual legacy benchmark)

## Qualification
`Pass5_verification.csv` contains six checks. All six must pass. The benchmark is post-freeze and does not modify any A–K reactor calculation or uncertainty domain.

## Manifest convention
`MANIFEST_SHA256.csv` is non-circular: it hashes all payload files except itself. The outer ZIP and its separate `.sha256.txt` are also excluded from the internal manifest.
