% Run_JIEC_V3_StageH_TargetAwareProjection.m
% One-button certified target-aware population-projection audit.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageH');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v3.0.1 Stage H] Certified target-aware population projection audit\n');
fprintf('Release: %s\n',cfg.release);
fprintf('Evaluating all 52 partitions of five MWD populations over the qualified Stage-G joint uncertainty domain.\n');
fprintf('No new kinetics, transport law, catalyst-site identity, or probability model is introduced.\n');

result=run_stageH_target_aware_population_reduction(cfg,outdir);
V=verify_stageH_target_aware_reduction(cfg,outdir,result);
allPass=all(strcmp(V.Status,'PASS'));

% Compact scientific summary at the pre-specified MODERATE tolerance band.
O=result.OrderMap; ix=strcmp(O.ToleranceLabel,'MODERATE'); Om=O(ix,:);
fid=fopen(fullfile(outdir,'STAGE_H_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v3.0.1 Stage-H target-aware population projection audit\n');
fprintf(fid,'All executable Stage-H gates pass: %d\n',allPass);
fprintf(fid,'Population partitions evaluated: %d.\n',numel(result.Partitions));
fprintf(fid,'Oracle projection rule: group mass and reciprocal-Mn are preserved exactly; numerical labels are MWD populations, not chemical-site identities.\n');
fprintf(fid,'Uncertainty scope: full Stage-G weight simplex, both transfer modes, conservative DP alpha box, and five primary T80 scenarios.\n');
fprintf(fid,'Tolerance bands are pre-specified projection-error reporting bands, not experimental confidence limits.\n');
for r=1:height(Om)
    fprintf(fid,'MODERATE | %s | EPC %.2f | projection K in [%d,%d] | %s\n',Om.Target{r},Om.EPC_wtfrac(r),Om.K_projection_possible_lower(r),Om.K_projection_certified_sufficient(r),Om.ProjectionKstarStatus{r});
end
if allPass
    fprintf(fid,'Verdict: STAGE_H_TARGET_AWARE_POPULATION_PROJECTION_QUALIFIED__OPERATIONAL_REDUCTION_NOT_YET_ESTABLISHED\n');
else
    fprintf(fid,'Verdict: STAGE_H_FAILED__DO_NOT_USE_TARGET_ORDER_CLAIMS\n');
end
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V3_STAGE_H_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageH'},ROOT);
if ~allPass, error('Stage-H executable verification failed. Inspect StageH_verification.csv.'); end
fprintf('\n[JIEC v3.0.1 Stage H] COMPLETE\n');
fprintf('Verdict: STAGE_H_TARGET_AWARE_POPULATION_PROJECTION_QUALIFIED__OPERATIONAL_REDUCTION_NOT_YET_ESTABLISHED\n');
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
