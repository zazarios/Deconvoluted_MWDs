# Stage K v3.6 release notes

Release: `3.6-stageK-final-representation-requalification`

- Freezes qualified A–J.1 evidence.
- Expands H/H.1/H.2 from the legacy five T80 states to the final 17-state Stage-J H2/T80 union.
- Retains the previously qualified full DP alpha interval; J.1 chemistry adds no new repeat-mass support beyond this interval.
- Reuses the frozen 52 partitions, targets, metrics, transfer formulations, and tolerance bands.
- Adds independent moderate-order mirrors for H.1 and H.2.
- Produces frozen-vs-final minimax and order-change tables.
