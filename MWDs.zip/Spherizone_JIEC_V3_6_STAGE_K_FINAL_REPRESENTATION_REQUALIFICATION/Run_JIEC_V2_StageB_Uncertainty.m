% Run_JIEC_V2_StageB_Uncertainty.m
% One-button Stage-B uncertainty / identifiability ensemble.
% Run from the extracted package folder after Stage-A1 has passed.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageB');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.1 Stage B] Uncertainty / identifiability ensemble\n');
fprintf('Scientific specification: %s\n',cfg.spec_version);
fprintf('Release: %s\n',cfg.release);

% Re-run executable preflight V0-V8 in the same clean package.
preflightDir=fullfile(outdir,'Preflight'); mkdir(preflightDir);
report=verify_all(cfg,preflightDir);
writetable(report,fullfile(outdir,'StageB_preflight_verification.csv'));
required=ismember(report.Gate,{'V0','V1','V2','V3','V4','V5','V6','V7','V8'});
preflightPass=all(strcmp(report.Status(required),'PASS'));
if ~preflightPass
    error('Stage-B preflight failed. Inspect StageB_preflight_verification.csv before scientific enumeration.');
end
fprintf('Stage-A executable preflight V0-V8: PASS\n');

verdict=run_stageB_analysis(cfg,outdir);

fid=fopen(fullfile(outdir,'STAGE_B_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.1 Stage-B uncertainty / identifiability run\n');
fprintf(fid,'Preflight V0-V8 pass: %d\n',preflightPass);
fprintf(fid,'Verdict: %s\n',verdict.code);
fprintf(fid,'%s\n',verdict.summary);
fprintf(fid,'V9 external trend audit and V10 manuscript claim audit remain manual gates after this output is independently reviewed.\n');
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_B_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageB'},ROOT);

fprintf('\n[JIEC v2.1 Stage B] COMPLETE\n');
fprintf('Verdict: %s\n',verdict.code);
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
