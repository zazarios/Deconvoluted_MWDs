# Stage H.1 — T80-conditional fixed-descriptor closure

## Scientific purpose
Stage H established a target-dependent **oracle projection order**: each merged group was allowed to recompute its harmonic Mn from the hidden five-population state. H.1 removes that oracle access.

For every fixed population partition, target, EPC fraction, T80 branch and transfer formulation, H.1 assigns each merged group **one scalar Mn descriptor before the latent within-group weights and population-specific DP repeat-mass scales are known**. The descriptor is selected by a target-specific minimax rule over the inherited within-branch Stage-G support. It may not depend on the realized hidden `w_j` or `alpha_j`, but v3.1/v3.1.1 still allow dependence on the declared T80 branch and transfer formulation.

This is a stronger closure test with respect to hidden within-group weights and population-specific DP scale, but it remains conditional on the declared T80 model-form branch. It is therefore not yet one operational descriptor set across the full Stage-G epistemic domain. Group total weights also remain uncertain and no new group-weight evolution law is introduced.

## Fixed descriptor rules
For a group whose admissible Mn support is `[m_lo,m_hi]`:

- **W1 in log10 M:** geometric-center scale, giving exact worst-case `EPC * 0.5 log10(m_hi/m_lo)`.
- **final Mn relative error:** reciprocal-Mn midpoint after including the fixed matrix contribution.
- **final Mw relative error:** relative-error minimax center of the final Mw interval.
- **fixed-threshold tail mass:** descriptor whose tail probability is the midpoint of the support tail-probability interval.
- **dispersity:** target-specific fixed descriptor with an admissible single-population witness lower bound and conservative signed `Mw/Mn` ratio upper bound.

DIRECT transfer has no DP alpha interval. Under DP repeat-mass correction, the conservative Stage-G interval `alpha in [M_C2/M_C3,1]` is retained. Consequently, even singleton populations can have nonzero fixed-descriptor error when population-specific alpha is hidden.

## Interpretation
A target may return **NO_FIXED_SCALAR_CLOSURE** when even K=5 cannot satisfy the pre-specified reporting tolerance. This is a scientific outcome, not an executable failure. It means that population count alone is insufficient; at least one additional state/closure relation (for example a chemistry-dependent scale variable or matched measurement) is required.

H.1 descriptors are target-specific. A tail-optimized fixed descriptor may therefore use fewer populations than the Stage-H moment-preserving oracle projection while sacrificing fidelity in other targets. H.1 does **not** certify one universal reduced representation for all outputs.

## Pre-specified tolerances
Unchanged from Stage H:
- W1: 0.01, 0.02, 0.05 decades
- Mn/Mw/D: 1%, 2.5%, 5%
- fixed-threshold tail mass: 1, 2.5, 5 percentage points

These are reporting tolerances, not experimental confidence limits or universal engineering acceptability thresholds.

## Expected pre-execution pattern
The independent audit predicts:
- no fixed scalar closure for final Mn, Mw or D at the 1–5% bands, even at K=5, because the conservative population-specific DP scale remains hidden;
- W1 at the moderate 0.02-decade band: K=5 for EPC 10 and 20 wt%, but no K<=5 for EPC 30 wt%;
- tail metrics can require lower K because their descriptors are target-specific.

These are pre-execution expectations only. Use `Run_JIEC_V3_StageH1_FixedDescriptorClosure.m` and audit the generated verification table before using any result.

## Scope correction in v3.1.1
The v3.1 numerical calculation is retained, but the operational interpretation is narrowed. Because descriptors are allowed to depend on the T80 branch, H.1 establishes **T80-conditional fixed-descriptor closure**. A single descriptor set that is fixed before the T80 branch is known remains to be tested separately.
