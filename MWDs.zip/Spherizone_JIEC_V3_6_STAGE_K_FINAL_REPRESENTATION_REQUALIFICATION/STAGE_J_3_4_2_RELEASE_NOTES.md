# Stage J v3.4.2 release notes

Release: `3.4.2-stageJ-csv-delimiter-hotfix`

## Reason for hotfix
MATLAB R2025b auto-detected underscore (`_`) rather than comma as the delimiter for the one-row frozen Stage-G CSV `inputs/StageGQualifiedOutputs/StageG_structural_claim_closure.csv`. This split the intended header `Global_W1_certified_joint_lower_decades` into multiple table variables and stopped Stage J after its principal scientific calculations had already completed.

## Change
- Added `core/stageJ_read_csv_strict.m`.
- Frozen Stage-F and Stage-G baseline CSVs used by Stage J are now imported with `Delimiter=','`, `VariableNamingRule='preserve'`, and `TextType='string'`.
- Baseline values are still resolved by `stageJ_table_column`; no scientific value is altered.

## Scientific scope
No equations, challenge data, chemistry stress spans, H2/T80 branches, tolerances, Stage-G Jensen-envelope calculation, Stage-F composition calculations, or A-I qualified inputs were changed. This is an input-parser compatibility hotfix only.
