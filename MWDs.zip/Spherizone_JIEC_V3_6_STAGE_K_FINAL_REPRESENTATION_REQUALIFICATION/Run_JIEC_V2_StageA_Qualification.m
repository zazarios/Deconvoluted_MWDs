% Run_JIEC_V2_StageA_Qualification.m
% One-button Stage-A qualification. Run from the extracted package folder.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.0 Stage A1] Source-consistency hotfix qualification\n');
fprintf('Scientific specification: %s\n',cfg.spec_version);

report=verify_all(cfg,outdir);
write_stageA_diagnostics(cfg,outdir);

disp(report);
required=ismember(report.Gate,{'V0','V1','V2','V3','V4','V5','V6','V7','V8'});
pass=all(strcmp(report.Status(required),'PASS'));

fid=fopen(fullfile(outdir,'STAGE_A_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.0 Stage-A1 source-consistency qualification\n');
fprintf(fid,'Required executable V0-V8 pass: %d\n',pass);
sourceWarn=any(strcmp(report.Gate,'V3S') & strcmp(report.Status,'WARN'));
fprintf(fid,'Published-source consistency warning detected: %d\n',sourceWarn);
fprintf(fid,'Stage-B rule: exclude T80 scenarios marked EXCLUDE_SOURCE_INCONSISTENCY; treat clipping/missing-identity cases as stress-only.\n');
fprintf(fid,'V9 and V10 are intentionally deferred until corrected scientific results/manuscript exist.\n');
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_A1_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs'},ROOT);

if pass
    fprintf('\n[JIEC v2.0 Stage A1] V0-V8 PASSED; inspect V3S source warning before Stage B.\n');
else
    fprintf('\n[JIEC v2.0 Stage A1] QUALIFICATION FAILED. Inspect verification_report.csv.\n');
end
fprintf('Upload this file for audit:\n  %s\n',zipfile);
