# v3.1.1 Stage H.1 independent-mirror and scope hotfix

- Replaces the incorrect v3.1 independent partition/minimax mirrors with a fully independent reconstruction from the source populations, qualified T80 scenarios, Stage-F matrix moments, and Stage-E tail thresholds.
- Adds a 310-row independent group-support mirror before the partition-level checks.
- Does not change any Stage-H.1 descriptor equation, partition, tolerance, uncertainty range, or scientific numerical result.
- Corrects scope language: descriptors may depend on the declared T80 uncertainty branch, so H.1 establishes T80-conditional fixed-descriptor closure, not a single T80-global operational closure.
- Adds an executable T80-branch scope guard.
