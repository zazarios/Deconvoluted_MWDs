% Run_JIEC_V3_StageJ1_HighEPChemistryRedevelopment.m
clear;clc;ROOT=fileparts(mfilename('fullpath'));addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageJ1');if exist(outdir,'dir'),rmdir(outdir,'s');end;mkdir(outdir);cfg=stageJ1_config();
fprintf('[JIEC v3.5 Stage J.1] High-E/P chemistry-domain redevelopment\n');
fprintf('Release: %s\n',cfg.release);
fprintf('Mechanistic support source: Zhang et al. 2021 high-E/P kinetic data.\n');
fprintf('Held-out Cancelas/Botha/Wang observations are not used to set the chemistry support.\n');
fprintf('The full qualified Stage-J chemistry domain is retained as a legacy subset.\n\n');
result=run_stageJ1_highEP_chemistry_redevelopment(cfg,outdir);
V=verify_stageJ1_highEP_chemistry_redevelopment(cfg,outdir,result);allPass=all(strcmp(V.Status,'PASS'));

chem=result.UnionVOI(strcmp(result.UnionVOI.ResolvedBlock,'HIGH_EP_CHEMISTRY_MODEL_STATE'),:);
if result.AllStageHoldoutCovered && result.AllBulkHoldoutCovered
 verdict='STAGE_J1_HIGH_EP_CHEMISTRY_REDEVELOPMENT_QUALIFIED__LITERATURE_ANCHORED_DOMAIN_COVERS_HELDOUT_CHALLENGES__COMPOSITION_REMAINS_PARTIALLY_IDENTIFIED';
else
 verdict='STAGE_J1_HIGH_EP_CHEMISTRY_REDEVELOPMENT_QUALIFIED__HELDOUT_CHALLENGE_NOT_FULLY_COVERED__FURTHER_CHEMISTRY_REDEVELOPMENT_REQUIRED';
end
fid=fopen(fullfile(outdir,'STAGE_J1_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v3.5 Stage J.1 high-E/P chemistry-domain redevelopment\n');
fprintf(fid,'All executable Stage-J.1 integrity/scope gates pass: %d\n',allPass);
fprintf(fid,'Support construction source: Zhang et al. 2021 SI Tables S8-S9 at E/P=40/60 and 50/50\n');
fprintf(fid,'Held-out challenge data used to set support: NO\n');
fprintf(fid,'Matched independent Spherizone validation claimed: NO\n');
fprintf(fid,'Mechanistic kappa support: %.6g to %.6g; population contrast cap %.6g\n',cfg.StageJ1.kappa_support(1),cfg.StageJ1.kappa_support(2),cfg.StageJ1.max_population_contrast);
fprintf(fid,'High-E/P mechanistic stage-C2 interval: %.12f to %.12f\n',result.HighStageC2Min,result.HighStageC2Max);
fprintf(fid,'Final Stage-J.1 union stage-C2 interval: %.12f to %.12f\n',result.FinalStageC2Min,result.FinalStageC2Max);
fprintf(fid,'All held-out stage/proxy observations contained: %d\n',result.AllStageHoldoutCovered);
fprintf(fid,'All held-out matched-nominal-EPC Cancelas bulk points contained: %d\n',result.AllBulkHoldoutCovered);
fprintf(fid,'Union chemistry-state singleton guaranteed contraction: %.8f\n',chem.GuaranteedContractionFraction);
fprintf(fid,'All final bulk-C2 EPC intervals overlap pairwise: %d\n',all(result.Pairwise.IntervalsOverlap));
fprintf(fid,'Stage-G structural W1 rerun required because of composition chemistry alone: NO (DP repeat-mass support already spans M2/M3 to 1; Stage J already qualified H2/T80 challenge)\n');
fprintf(fid,'H/H.1/H.2 requalified over final J.1 state/model-form domain: NO\n');
fprintf(fid,'Verdict: %s\n',verdict);fclose(fid);
zipfile=fullfile(ROOT,'JIEC_V3_STAGE_J1_OUTPUTS.zip');if exist(zipfile,'file'),delete(zipfile);end;zip(zipfile,{'Outputs_StageJ1'},ROOT);
if ~allPass,error('Stage-J.1 executable verification failed. Inspect StageJ1_verification.csv.');end
fprintf('\n[JIEC v3.5 Stage J.1] COMPLETE\n');fprintf('Verdict: %s\n',verdict);fprintf('Upload: %s\n',zipfile);
