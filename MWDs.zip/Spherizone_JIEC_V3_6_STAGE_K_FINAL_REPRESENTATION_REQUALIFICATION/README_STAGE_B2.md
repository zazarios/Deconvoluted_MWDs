# Spherizone JIEC v2.3 Stage B2 — Population-weight transfer audit

## Why Stage B2 was added
Stage B1 allowed unresolved E/P chemistry to modify composition and, in the DP-corrected transfer mode, repeat-unit molecular mass. However, it retained the Alshaiban PP-derived Flory population mass fractions `w_j` as the second-stage population weights.

Zhang et al. (2021) and its SI show that active-center concentrations change strongly and non-uniformly with E/P feed ratio for a different supported Ziegler–Natta catalyst. Those numerical values cannot be transferred to the Alshaiban catalyst, but they demonstrate that unchanged population weights are not an experimentally established assumption.

Stage B2 therefore adds **U_W: population-weight transfer model-form stress** before V9/V10.

## Stress library
- `W0`: inherited PP population weights (Stage-B1 baseline).
- `W1`: ordered factor-two relative-yield stresses in both directions.
- `W2`: all unique permutations of `[0.5 0.5 1 2 2]`.

The multipliers are symmetric **stress factors only**. They are not fitted parameters, probability distributions, confidence limits, or numerical transfers from Zhang et al.

Three layers are reported:
1. `W0_INHERITED` — Stage-B1 baseline.
2. `WC_COUPLED_SAME_PATTERN_STRESS` — population yield shifts with the same qualitative pattern as the chemistry-response stress.
3. `WI_INDEPENDENT_FACTOR_TWO_STRESS` — chemistry and population yield patterns vary independently; this is the strongest structural stress test.

## Run
From the extracted package root:

```matlab
Run_JIEC_V2_StageB2_WeightTransferAudit
```

Upload `JIEC_V2_STAGE_B2_OUTPUTS.zip` for independent audit.

## Interpretation
The principal question is not whether the factor-two envelope is a true catalyst uncertainty interval. It is whether the structural multisite-vs-single-Flory conclusion is fragile to a deliberately broad, source-motivated but non-calibrated population-weight redistribution.

V9/V10 remain locked until this audit is reviewed.
