# Stage J v3.4.4 release notes

This hotfix changes only the Stage-I prerequisite verification gate.

## Root cause
The v3.4.3 verifier searched `STAGE_I_STATUS.txt` for the literal token `STAGE_I`. The frozen qualified Stage-I status file does not contain that token; it identifies the stage as `Stage I-A` and records the qualified verdict `PRIMARY_PP_DIRECTIONAL_GENERALITY_SUPPORTED__STRICT_AMPLIFICATION_MIXED__CROSS_POLYOLEFIN_UNIVERSALITY_FALSIFIED_BY_SECONDARY`. Consequently J0B failed even though Stage I was qualified.

## Fix
J0B now requires both:
1. `All executable Stage-I gates pass: 1` and the frozen Stage-I qualified verdict in `STAGE_I_STATUS.txt`; and
2. every row of the frozen `StageI_verification.csv` to have `Pass = 1` (the actual Stage-I verification schema).

No scientific equation, parameter, uncertainty domain, external challenge datum, Stage-J calculation, tolerance, or A-I frozen result is changed.
