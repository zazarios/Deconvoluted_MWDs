# Spherizone JIEC v2.5 — Stage D
## Continuous partial-identification and adversarial robustness

### Scientific purpose
Stage B2 showed that the main structural conclusions survived a **discrete factor-two** population-yield stress library. Stage D removes the dependence on those arbitrary endpoint perturbations by introducing two explicit continuous robustness coordinates.

### U_W — exact population-weight total-variation radius
For each second-stage source population vector `w0`, Stage D uses the exact uncertainty set

`TV(w,w0) = 0.5*sum(abs(w-w0)) <= delta_W`, with `w>=0` and `sum(w)=1`.

For fixed population descriptors, the quantities `1/Mn`, `Mw`, and C2 composition are linear in `w`. Their extrema over the TV ball are therefore solved **exactly** by mass transfer from low- to high-coefficient populations (or vice versa). No Optimization Toolbox is required.

The Stage-D TV table reports exact partial-identification bounds for `Mn`, `Mw`, and total C2. The reported D interval is a conservative outer interval assembled from independently optimized `Mn` and `Mw`; it is not claimed to be a jointly attained exact D extremum.

### U_C — continuous latent-chemistry amplitude
The Stage-B chemistry directions are retained only as symmetry-complete directions. Their amplitude is now continuous:

`multiplier_j(rho_C) = exp(rho_C*log(2)*z_j)`, `0 <= rho_C <= 1`.

`rho_C=0` is homogeneous population response. `rho_C=1` exactly reproduces the earlier factor-two C0/C1/C2 endpoint library. The radius is a deterministic model-form coordinate, not a probability level.


### Scope of the two continuous curves
Stage D deliberately does **not** create a probabilistic joint distribution over `U_W` and `U_C`. The `U_W` curve varies population weights continuously at homogeneous (`C0`) latent chemistry while retaining the primary temperature, sorption, and EX2-reactivity uncertainty sets. The `U_C` curve varies chemistry amplitude continuously while keeping inherited (`W0`) population weights. Stage B2 remains the joint endpoint stress test. This separation makes the critical radii interpretable and prevents an arbitrary coupling between two epistemic uncertainty coordinates.

### Regression requirements
1. `delta_W=0` must reproduce the `rho_C=0` inherited-weight homogeneous-chemistry marginal model.
2. `rho_C=1` with inherited weights must reproduce the Stage-B2 `W0_INHERITED` endpoint envelopes.
3. V0–V8 preflight must pass.

### Main outputs
- `StageD_weight_TV_partial_identification.csv`
- `StageD_chemistry_radius_partial_identification.csv`
- `StageD_old_factor_two_to_TV_mapping.csv`
- `StageD_critical_radius_brackets.csv`
- `StageD_regression_to_StageB2_W0.csv`
- `StageD_partial_identification_summary.csv`
- `STAGE_D_VERDICT.txt`

### Run
```matlab
Run_JIEC_V2_StageD_ContinuousPartialIdentification
```

Upload `JIEC_V2_STAGE_D_OUTPUTS.zip` for independent audit before Stage E is unlocked.
