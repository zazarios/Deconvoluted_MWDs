# v3.2 Stage H.2 release notes

- Adds the final H-program closure test: one target-specific scalar descriptor set must be fixed before the T80 branch, hidden within-group weights, or population-specific DP alpha are known.
- Retains all 52 population partitions, the Stage-G population-weight simplex, both declared transfer formulations, all five qualified T80 branches, and the conservative DP alpha interval.
- Allows no-K<=5 outcomes without treating them as executable failures.
- Adds 62-row independent T80-global group-support mirror, 156-row partition mirror, 90-row minimax mirror, 54-row target-order mirror, and 90-row H.1-to-H.2 penalty mirror.
- Adds explicit restriction-dominance verification: removing T80-branch access cannot improve the H.1 minimax upper error.
- Keeps dispersity as a bounded rather than exact global metric.
- Does not introduce kinetics, transport, catalyst-site identities, probability models, or experimental data.
