% Run_JIEC_V2_StageF_ValueOfInformation.m
% One-button Stage-F prospective deterministic information-value audit.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageF');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.8.1 Stage F] Prospective set-based value-of-information audit\n');
fprintf('Release: %s\n',cfg.release);
fprintf('No probability model or assumed measurement-noise distribution is used.\n');

result=run_stageF_value_of_information(cfg,outdir);
V=verify_stageF_value_of_information(cfg,outdir,result);
allPass=all(strcmp(V.Status,'PASS'));

% Compact status with target-specific conclusions only.
C=result.Singleton(strcmp(result.Singleton.Target,'StageC2_wtfrac'),:);
[bestComp,ib]=max(C.GuaranteedContractionFraction); bestCompName=C.ResolvedBlocks{ib};
Q=result.Singleton(strcmp(result.Singleton.TransferMode,'DP_REPEAT_MASS_CORRECTED') & strcmp(result.Singleton.ResolvedBlocks,'T80_TRANSFER'),:);
minMWD=min(Q.GuaranteedContractionFraction);
fid=fopen(fullfile(outdir,'STAGE_F_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.8.1 Stage-F prospective deterministic information-value audit\n');
fprintf(fid,'All executable Stage-F gates pass: %d\n',allPass);
fprintf(fid,'Primary ensemble dimensions: [%s] = %d states.\n',num2str(result.Dims),prod(result.Dims));
fprintf(fid,'Bulk stage-C2 baseline width: %.10g wt-fraction units.\n',result.Baseline.Width(strcmp(result.Baseline.Target,'StageC2_wtfrac')));
fprintf(fid,'Strongest composition singleton block: %s; guaranteed contraction %.6f.\n',bestCompName,bestComp);
fprintf(fid,'Minimum DP-MWD T80 singleton contraction across Mn/Mw/D and EPC levels: %.6f.\n',minMWD);
fprintf(fid,'Second-RCP ideal design: min normalized determinant %.6g; max normalized condition number %.6g.\n', ...
    result.ReactSummary.MinNormalizedDeterminant,result.ReactSummary.MaxNormalizedConditionNumber);
fprintf(fid,'Interpretation: block-resolution contractions are oracle upper bounds for real finite-precision measurements, not expected values of information.\n');
fprintf(fid,'Direct output measurements are calibration/validation and are not counted as transferable identification.\n');
if allPass
    fprintf(fid,'Verdict: STAGE_F_PROSPECTIVE_SET_BASED_INFORMATION_AUDIT_QUALIFIED__TARGET_SPECIFIC_DATA_PRIORITIES_IDENTIFIED\n');
else
    fprintf(fid,'Verdict: STAGE_F_FAILED__DO_NOT_USE_DATA_PRIORITY_CLAIMS\n');
end
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_F_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageF'},ROOT);
if ~allPass, error('Stage-F executable verification failed. Inspect StageF_verification.csv.'); end
fprintf('\n[JIEC v2.8.1 Stage F] COMPLETE\n');
fprintf('Verdict: STAGE_F_PROSPECTIVE_SET_BASED_INFORMATION_AUDIT_QUALIFIED__TARGET_SPECIFIC_DATA_PRIORITIES_IDENTIFIED\n');
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
