function T = verify_stageE1_continuous_full_mwd_bounds(cfg,outdir,result)
%VERIFY_STAGEE1_CONTINUOUS_FULL_MWD_BOUNDS Executable Stage-E.1 gates.
checks={}; status={}; detail={};
root=fileparts(fileparts(mfilename('fullpath')));

% E1.0 executed Stage-E prerequisite.
f=fullfile(root,'inputs','StageEQualifiedOutputs','STAGE_E_STATUS.txt');
ok=exist(f,'file')==2;
if ok
    txt=fileread(f);
    ok=~isempty(strfind(txt,'STAGE_E_EXECUTABLE_QUALIFIED__INDEPENDENT_MAGNITUDE_AUDIT_REQUIRED_BEFORE_STAGE_F')); %#ok<STREMP>
end
add('E1_0_STAGE_E_PREREQUISITE',ok,'Embedded executed Stage-E status must be qualified.');

% E1.1 matrix W1 regression to independent precheck.
Ed=readtable(fullfile(root,'Independent_Audit','StageE1_expected_diagnostics.csv'));
diffM=abs(result.matrixW1-Ed.Matrix_W1_decades(1));
add('E1_1_MATRIX_W1_REGRESSION',diffM<1e-5,sprintf('Matrix W1 absolute difference %.3g.',diffM));

% E1.2 exact C0 DP alpha-range reconstruction.
da=max(abs([result.alphaRange.alpha_min-Ed.C0_DP_alpha_min(1),result.alphaRange.alpha_max-Ed.C0_DP_alpha_max(1)]));
ok=da<1e-10 && result.alphaRange.max_population_ratio_spread<1e-12;
add('E1_2_C0_DP_COMMON_SCALE_RANGE',ok,sprintf('Max alpha endpoint difference %.3g; population-scale spread %.3g.',da,result.alphaRange.max_population_ratio_spread));

% E1.3 U_W certified lower bounds must be positive and below attainable vertex upper bounds.
U=result.Summary(strcmp(result.Summary.Coordinate,'U_W'),:);
ok=all(U.W1_certified_lower_decades>cfg.StageE1.w1_positive_tol) && ...
   all(U.W1_certified_lower_decades<=U.W1_attainable_upper_on_global_min_decades+1e-12);
add('E1_3_UW_FULL_SIMPLEX_POSITIVE_BOUND',ok,sprintf('Minimum U_W lower bound %.6g decades.',min(U.W1_certified_lower_decades)));

% E1.4 U_C bounds: DIRECT exact invariance and DP conservative superset.
C=result.Summary(strcmp(result.Summary.Coordinate,'U_C'),:);
ok=all(C.W1_certified_lower_decades>cfg.StageE1.w1_positive_tol) && ...
   all(C.W1_certified_lower_decades<=C.W1_attainable_upper_on_global_min_decades+1e-12);
add('E1_4_UC_POSITIVE_BOUND',ok,sprintf('Minimum U_C lower bound %.6g decades.',min(C.W1_certified_lower_decades)));

% E1.5 repeat-mass superset semantics.
a0=cfg.StageE1.M2_gmol/cfg.StageE1.M3_gmol;
ok=a0>0 && a0<1 && abs(a0-Ed.UC_DP_independent_alpha_min(1))<1e-12;
add('E1_5_UC_DP_SUPERSET_SEMANTICS',ok,sprintf('Independent DP scale lower limit M2/M3 = %.10g.',a0));

% E1.6 metric-scope guard must prohibit global quantile/tail-minimum claims.
S=result.MetricScope;
q={'M90_ratio','M99_ratio','TailExcessAboveCollapsedM90'}; ok=true;
for k=1:numel(q)
    j=find(strcmp(S.Metric,q{k}),1);
    ok=ok && ~isempty(j) && strcmp(S.Status{j},'MAGNITUDE_ONLY_NOT_GLOBAL_BOUND');
end
add('E1_6_NO_FALSE_QUANTILE_TAIL_CERTIFICATION',ok,'Quantile/tail metrics remain magnitude diagnostics, not certified continuous minima.');

% E1.7 independent mirror of all 60 by-T bounds and all 12 global minima.
% The v2.7 pre-execution summary table was replaced after the first executed
% run exposed an inconsistency in that auxiliary mirror. The core MATLAB
% bounds were independently reconstructed in Python from the packaged source
% population data and Stage-E matrix curve. v2.7.1 checks the complete by-T
% table first, then the global summary, so an incorrect T-scenario reduction
% cannot hide behind a matching final minimum.
Eb=readtable(fullfile(root,'Independent_Audit','StageE1_expected_byT_W1_bounds.csv'));
maxDiffByT=0; okByT=true;
for i=1:height(Eb)
    if strcmp(Eb.Coordinate{i},'U_W'), T=result.UWByT; else, T=result.UCByT; end
    j=find(strcmp(T.TransferMode,Eb.TransferMode{i}) & strcmp(T.TScenario,Eb.TScenario{i}) & ...
        abs(T.EPC_wtfrac-Eb.EPC_wtfrac(i))<1e-12,1);
    if isempty(j), okByT=false; continue; end
    d=abs(T.W1_certified_lower_decades(j)-Eb.Expected_W1_lower_decades(i));
    maxDiffByT=max(maxDiffByT,d); okByT=okByT && d<cfg.StageE1.regression_abs_tol;
end
E=readtable(fullfile(root,'Independent_Audit','StageE1_expected_continuous_W1_lower_bounds.csv'));
maxDiffSummary=0; okSummary=true;
for i=1:height(E)
    j=find(strcmp(result.Summary.Coordinate,E.Coordinate{i}) & strcmp(result.Summary.TransferMode,E.TransferMode{i}) & ...
        abs(result.Summary.EPC_wtfrac-E.EPC_wtfrac(i))<1e-12,1);
    if isempty(j), okSummary=false; continue; end
    d=abs(result.Summary.W1_certified_lower_decades(j)-E.Expected_W1_lower_decades(i));
    maxDiffSummary=max(maxDiffSummary,d); okSummary=okSummary && d<cfg.StageE1.regression_abs_tol;
end
ok=okByT && okSummary;
add('E1_7_INDEPENDENT_W1_BOUND_MIRROR',ok,sprintf(['Independent mirror: max by-T difference %.3g decades across %d rows; ' ...
    'max global-summary difference %.3g decades across %d rows (tol %.3g).'], ...
    maxDiffByT,height(Eb),maxDiffSummary,height(E),cfg.StageE1.regression_abs_tol));

% E1.8 finite-grid CDF pad audit on the complete relevant Mn span.
mins=[]; maxs=[];
ctx=stageD1_build_context(cfg); a0=cfg.StageE1.M2_gmol/cfg.StageE1.M3_gmol;
for it=1:numel(ctx.Tp)
    v=ctx.Tp(it).Mn_gmol; v=v(isfinite(v)&v>0); mins(end+1)=min(v); maxs(end+1)=max(v); %#ok<AGROW>
end
mnlo=a0*min(mins); mnhi=max(maxs); testMn=logspace(log10(mnlo),log10(mnhi),121);
M=cfg.StageE.metric_M_grid(:)'; maxErr=0;
for k=1:numel(testMn)
    q=flory_logweight_pdf(M,testMn(k)); Fn=stageE1_numerical_cdf(M,q); Fe=stageE1_flory_weight_cdf_exact(M,testMn(k));
    maxErr=max(maxErr,max(abs(Fn-Fe)));
end
ok=maxErr<cfg.StageE1.finite_grid_cdf_pad;
add('E1_8_FINITE_GRID_CDF_PAD_AUDIT',ok,sprintf('Max sampled exact-vs-grid CDF difference %.3g; pad %.3g.',maxErr,cfg.StageE1.finite_grid_cdf_pad));

% E1.9 derived JS floors must be positive whenever W1 lower bound is positive.
ok=all(result.Summary.JS_certified_lower_bits>0) && all(isfinite(result.Summary.JS_certified_lower_bits));
add('E1_9_DERIVED_JS_FLOOR',ok,sprintf('Minimum derived JS floor %.6g bits.',min(result.Summary.JS_certified_lower_bits)));

% E1.10 Stage-E magnitude context must be carried forward, not reclassified.
ok=height(result.MagnitudeContext)==1 && result.MagnitudeContext.StageE_min_W1_decades>0 && ...
    all(strcmp(result.MetricScope.Status(3:5),'MAGNITUDE_ONLY_NOT_GLOBAL_BOUND'));
add('E1_10_STAGEE_MAGNITUDE_CONTEXT_PRESERVED',ok,'Stage-E adverse-witness magnitudes are retained only as contextual evidence.');

T=table(checks,status,detail,'VariableNames',{'Gate','Status','Detail'});
writetable(T,fullfile(outdir,'StageE1_verification.csv'));

    function add(name,cond,msg)
        checks{end+1,1}=name; %#ok<AGROW>
        if cond, status{end+1,1}='PASS'; else, status{end+1,1}='FAIL'; end %#ok<AGROW>
        detail{end+1,1}=msg; %#ok<AGROW>
    end
end
