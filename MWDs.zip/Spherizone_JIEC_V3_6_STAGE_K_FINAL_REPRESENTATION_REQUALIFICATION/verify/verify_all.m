function report = verify_all(cfg, outdir)
%VERIFY_ALL Execute Stage-A V0-V8 qualification checks.
if nargin<2, outdir='Outputs'; end
if ~exist(outdir,'dir'), mkdir(outdir); end
rows={};

% V0 code/data determinism
try
 d1=data_flory_populations(); d2=data_flory_populations();
 ok=isequaln(d1,d2) && numel(d1)==16;
 rows(end+1,:)={'V0',PASSFAIL(ok),'16-record deterministic source load',sprintf('n=%d',numel(d1))}; %#ok<AGROW>
catch ME
 rows(end+1,:)={'V0','FAIL','code/data integrity',ME.message};
end

% V1 + V6 through synthetic PFR mass balance
try
 par=synthetic_par(cfg,201,1e-8,1e-11);
 z=mzcr_zone_pfr(par);
 dC3=z.F_C3_mols(1)-z.F_C3_mols(end); dC2=z.F_C2_mols(1)-z.F_C2_mols(end); dH2=z.F_H2_mols(1)-z.F_H2_mols(end);
 % Independent integrated source check from output q and local compositions.
 polymer=z.polymer_out_gps;
 massClosure=abs(polymer-trapz(z.z_m,z.qpoly_gps_per_m))/max(polymer,eps);
 speciesNonneg=min([z.F_C3_mols;z.F_C2_mols;z.F_H2_mols])>=-1e-12;
 ok=massClosure<=cfg.mass_balance_tol && speciesNonneg && dC3>=0 && dC2>=0 && dH2>=0;
 rows(end+1,:)={'V1',PASSFAIL(ok),'unit/source-term sanity',sprintf('polymer closure %.3g; consumptions C3 %.3g C2 %.3g H2 %.3g mol/s',massClosure,dC3,dC2,dH2)};
 rows(end+1,:)={'V6',PASSFAIL(ok),'synthetic PFR mass-balance closure',sprintf('relative polymer source closure %.3g',massClosure)};
catch ME
 rows(end+1,:)={'V1','FAIL','unit/source-term sanity',ME.message};
 rows(end+1,:)={'V6','FAIL','synthetic PFR mass-balance closure',ME.message};
end

% V2/V3 source distribution reconstruction
try
 data=data_flory_populations(); n=numel(data); maxNorm=0; maxMoment=0;
 recon=cell(n,8);
 for k=1:n
   m=mix_flory_populations(data(k).w,data(k).Mn_gmol,cfg.M_grid);
   normerr=abs(trapz(log10(m.M_gmol),m.dW_dlog10M)-1);
   eMn=abs(m.Mn_numerical_gmol-m.Mn_analytical_gmol)/m.Mn_analytical_gmol;
   eMw=abs(m.Mw_numerical_gmol-m.Mw_analytical_gmol)/m.Mw_analytical_gmol;
   maxNorm=max(maxNorm,normerr); maxMoment=max([maxMoment,eMn,eMw]);
   recon(k,:)={data(k).id,data(k).T_C,data(k).H2_psi,data(k).DoTi,m.Mn_analytical_gmol,m.Mw_analytical_gmol,m.D_analytical,normerr};
 end
 Trec=cell2table(recon,'VariableNames',{'SourceID','T_C','H2_psi','DoTi','Mn_gmol','Mw_gmol','D','NormAbsErr'});
 writetable(Trec,fullfile(outdir,'V3_source_reconstruction.csv'));
 ok2=maxNorm<=cfg.norm_tol; ok3=maxMoment<=cfg.moment_rel_tol;
 rows(end+1,:)={'V2',PASSFAIL(ok2),'MWD normalization',sprintf('max abs integral error %.3g',maxNorm)};
 rows(end+1,:)={'V3',PASSFAIL(ok3),'analytical/numerical source-implied moments',sprintf('max relative moment error %.3g',maxMoment)};
catch ME
 rows(end+1,:)={'V2','FAIL','MWD normalization',ME.message}; rows(end+1,:)={'V3','FAIL','source reconstruction',ME.message};
end

% V3S published-source fidelity diagnostic. This is intentionally a WARN
% when the published deconvolution descriptors do not reproduce the whole-
% polymer GPC moments printed in the same source; no source value is edited.
try
 SC=source_consistency_diagnostic(cfg.M_grid);
 writetable(SC,fullfile(outdir,'StageA1_source_consistency.csv'));
 severe=sum(SC.SevereSourceFlag);
 maxMw=max(abs(SC.Mw_relerr)); maxD=max(abs(SC.D_relerr));
 if severe>0
   st='WARN';
 else
   st='PASS';
 end
 rows(end+1,:)={'V3S',st,'published whole-polymer/source-component consistency', ...
     sprintf('severe source flags %d; max |Mw relerr| %.3g; max |D relerr| %.3g',severe,maxMw,maxD)};
catch ME
 rows(end+1,:)={'V3S','FAIL','published source consistency',ME.message};
end

% V4 interpolation endpoints + out-of-domain + LOO diagnostic
try
 ids={'60_D','60_DH','70_D','70_DH'}; data=data_flory_populations(); maxE=0;
 for k=1:numel(ids)
   s=data(strcmp({data.id},ids{k})); p=population_transfer(s.T_C,s.H2_psi,s.DoTi);
   ew=max(abs(p.w-s.w)); mask=s.w>0; em=max(abs(log(p.Mn_gmol(mask)./s.Mn_gmol(mask)))); maxE=max([maxE,ew,em]);
 end
 threw=false; try, population_transfer(80,8,1.4); catch ME2, threw=strcmp(ME2.identifier,'population_transfer:OutOfPrimaryDomain'); end
 LOO=diagnostic_loo_surrogate(cfg.M_grid); writetable(LOO,fullfile(outdir,'V4_LOO_diagnostic.csv'));
 ok=maxE<1e-12 && threw && all(isfinite(LOO.MWD_IAE));
 rows(end+1,:)={'V4',PASSFAIL(ok),'bracket endpoints / no hidden extrapolation / LOO diagnostic',sprintf('endpoint max error %.3g; outdomain_error=%d; median LOO IAE %.3g',maxE,threw,median(LOO.MWD_IAE))};
catch ME
 rows(end+1,:)={'V4','FAIL','interpolation audit',ME.message};
end

% V5 numerical convergence
try
 p1=synthetic_par(cfg,101,1e-7,1e-10); p2=synthetic_par(cfg,401,1e-9,1e-12);
 z1=mzcr_zone_pfr(p1); z2=mzcr_zone_pfr(p2);
 v1=[z1.F_C3_mols(end),z1.F_C2_mols(end),z1.F_H2_mols(end),z1.polymer_out_gps];
 v2=[z2.F_C3_mols(end),z2.F_C2_mols(end),z2.F_H2_mols(end),z2.polymer_out_gps];
 rel=max(abs(v1-v2)./max(abs(v2),1e-12)); ok=rel<=cfg.convergence_rel_tol;
 rows(end+1,:)={'V5',PASSFAIL(ok),'PFR numerical convergence',sprintf('max outlet relative difference %.3g',rel)};
catch ME
 rows(end+1,:)={'V5','FAIL','PFR numerical convergence',ME.message};
end

% V7 legacy-bug guards using a synthetic imposed H2 gradient
try
 z=linspace(0,1,101)'; q=1+z; ph=2+10*z;
 fake=struct(); fake.z_m=z; fake.qpoly_gps_per_m=q; fake.H2_psi=ph; fake.xC3=0.9*ones(size(z)); fake.xC2=zeros(size(z)); fake.xH2=0.01*ones(size(z)); fake.xInert=0.09*ones(size(z));
 fake.par=struct('T_C',65,'DoTi',1.4);
 integ=integrate_zone_properties(fake,cfg.M_grid);
 pout=population_transfer(65,12,1.4); gout=mix_flory_populations(pout.w,pout.Mn_gmol,cfg.M_grid);
 iae=trapz(log10(cfg.M_grid),abs(integ.dW_dlog10M-gout.dW_dlog10M));
 fake2=fake; fake2.qpoly_gps_per_m=0.2*q; r=integrate_zone_properties(fake2,cfg.M_grid); comb=combine_mzcr_zones(r,integ);
 ok=iae>1e-3 && comb.riser_fraction>0 && comb.downer_fraction>0;
 rows(end+1,:)={'V7',PASSFAIL(ok),'legacy bug guards',sprintf('cumulative-vs-outlet MWD IAE %.3g; riser fraction %.3g',iae,comb.riser_fraction)};
catch ME
 rows(end+1,:)={'V7','FAIL','legacy bug guards',ME.message};
end

% V8 conditioning mathematics
try
 ex1=condition_ex1_h2(cfg); e1=abs(ex1.MWD.Mw_analytical_gmol-cfg.EX1.target_Mw_gmol)/cfg.EX1.target_Mw_gmol;
 rc=reactivity_feasible_set(cfg.EX2.f1_sorbed_qualification,cfg.EX2.target_C2_wtfrac,cfg.EX2.r1_bounds_screen,cfg.EX2.r2_bounds_screen,cfg.EX2.n_curve);
 if isempty(rc), error('No EX2 feasible pairs inside screening bounds.'); end
 e2=max(abs(rc.C2_wtfrac-cfg.EX2.target_C2_wtfrac)); writetable(rc,fullfile(outdir,'V8_EX2_reactivity_feasible_curve.csv'));
 ok=e1<1e-6 && e2<1e-10;
 rows(end+1,:)={'V8',PASSFAIL(ok),'EX1 conditioning / EX2 feasible manifold',sprintf('EX1 H2 %.6g psi, Mw relerr %.3g; EX2 n=%d max target err %.3g',ex1.H2_psi,e1,height(rc),e2)};
catch ME
 rows(end+1,:)={'V8','FAIL','conditioning checks',ME.message};
end

rows(end+1,:)={'V9','DEFERRED','external trend checks','Requires regenerated scientific scenarios and literature comparison; no automatic pass in Stage A.'};
rows(end+1,:)={'V10','DEFERRED','claim traceability','Requires final regenerated tables/figures and manuscript claims.'};

report=cell2table(rows,'VariableNames',{'Gate','Status','Test','Details'});
% Replace symbolic PASSFAIL strings
for i=1:height(report)
 if startsWith(report.Status{i},'PASSFAIL(')
     report.Status{i}='FAIL'; % should never remain; compatibility fallback
 end
end
writetable(report,fullfile(outdir,'verification_report.csv'));
end

function par=synthetic_par(cfg,n_eval,relTol,absTol) %#ok<INUSD>
par=struct('T_C',cfg.synthetic.T_C,'P_bar',cfg.synthetic.P_bar,'DoTi',cfg.synthetic.DoTi, ...
    'L_m',cfg.synthetic.L_m,'A_m2',cfg.synthetic.A_m2,'u_g_m_s',cfg.synthetic.u_g_m_s, ...
    'rho_cat_bed_g_m3',cfg.synthetic.rho_cat_bed_g_m3,'Rp_sp_g_gcat_h',cfg.synthetic.Rp_sp_g_gcat_h, ...
    'gas_in',cfg.synthetic.gas,'mode','copolymer','r1',3.0,'r2',0.5,'n_eval',n_eval,'RelTol',relTol,'AbsTol',absTol);
end

function s=PASSFAIL(tf)
if tf, s='PASS'; else, s='FAIL'; end
end
