function write_stageA_diagnostics(cfg,outdir)
%WRITE_STAGEA_DIAGNOSTICS Export interpretable Stage-A diagnostic tables.
if ~exist(outdir,'dir'), mkdir(outdir); end

% Published whole-polymer vs deconvolution-component source consistency
SC=source_consistency_diagnostic(cfg.M_grid);
writetable(SC,fullfile(outdir,'StageA1_source_consistency.csv'));

% EX1 conditioning and MWD
ex1=condition_ex1_h2(cfg);
T=table(ex1.MWD.M_gmol(:),ex1.MWD.dW_dlog10M(:),'VariableNames',{'M_gmol','dW_dlog10M'});
writetable(T,fullfile(outdir,'StageA_EX1_conditioned_MWD.csv'));
S=table(ex1.H2_psi,ex1.MWD.Mn_analytical_gmol,ex1.MWD.Mw_analytical_gmol,ex1.MWD.D_analytical, ...
    'VariableNames',{'H2_psi','Mn_gmol','Mw_gmol','D'});
writetable(S,fullfile(outdir,'StageA_EX1_conditioning_summary.csv'));

% T80 envelope at FBR H2
E=population_T80_envelope(cfg.FBR.H2_psi,cfg.MZCR.DoTi);
rows=cell(numel(E),1+5+5+2+3);
for k=1:numel(E)
 rows{k,1}=E(k).name;
 for j=1:5, rows{k,1+j}=E(k).w(j); rows{k,6+j}=E(k).Mn_gmol(j); end
 rows{k,12}=E(k).truncated_weights; rows{k,13}=E(k).mn_delta_missing;
 rows{k,14}=E(k).source_pair; rows{k,15}=E(k).admissibility; rows{k,16}=E(k).admissibility_reason;
end
vars=[{'Scenario'},arrayfun(@(j)sprintf('w%d',j),1:5,'UniformOutput',false),arrayfun(@(j)sprintf('Mn%d_gmol',j),1:5,'UniformOutput',false),{'WeightTruncation','MissingMnDelta','SourcePair','Admissibility','AdmissibilityReason'}];
writetable(cell2table(rows,'VariableNames',vars),fullfile(outdir,'StageA_T80_population_envelope.csv'));

% FBR sorption scenarios
SS=thermo_fbr_scenarios(cfg.FBR.gas);
Ts=table({SS.name}',[SS.f1_sorbed]',[SS.selectivity]','VariableNames',{'Scenario','f1_sorbed','C3_over_C2_selectivity'});
writetable(Ts,fullfile(outdir,'StageA_FBR_sorption_scenarios.csv'));

% Site-response scenario library
C=site_response_scenarios(5,cfg.site_response.odds_span);
R=cell(numel(C),7);
for k=1:numel(C), R{k,1}=C(k).name; R{k,2}=C(k).class; for j=1:5,R{k,2+j}=C(k).ethylene_odds_multiplier(j);end,end
writetable(cell2table(R,'VariableNames',{'Scenario','Class','m1','m2','m3','m4','m5'}),fullfile(outdir,'StageA_site_response_scenarios.csv'));

% Two-zone normalized MZCR structural demonstration
D=run_normalized_mzcr_demo(cfg);
Tm=table(D.matrix.M_gmol(:),D.riser_product.dW_dlog10M(:),D.downer_product.dW_dlog10M(:),D.matrix.dW_dlog10M(:), ...
    'VariableNames',{'M_gmol','Riser_dW_dlog10M','Downer_dW_dlog10M','MZCR_dW_dlog10M'});
writetable(Tm,fullfile(outdir,'StageA_MZCR_two_zone_MWD_demo.csv'));
Ts2=table(D.matrix.riser_fraction,D.matrix.downer_fraction,D.matrix.Mn_gmol,D.matrix.Mw_gmol,D.matrix.D, ...
    'VariableNames',{'RiserMassFraction','DownerMassFraction','Mn_gmol','Mw_gmol','D'});
writetable(Ts2,fullfile(outdir,'StageA_MZCR_two_zone_summary.csv'));
end
