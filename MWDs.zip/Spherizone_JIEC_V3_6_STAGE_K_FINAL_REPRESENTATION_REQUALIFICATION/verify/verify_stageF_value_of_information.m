function T = verify_stageF_value_of_information(cfg,outdir,result)
%VERIFY_STAGEF_VALUE_OF_INFORMATION Executable Stage-F qualification gates.
checks={}; status={}; detail={};
root=fileparts(fileparts(mfilename('fullpath')));

% F0. Re-qualify the executed Stage-E.1 bounds against the corrected 60-row
% independent mirror. This bypasses the known stale v2.7 E1_7 auxiliary table
% without weakening any scientific gate.
E=readtable(fullfile(root,'Independent_Audit','StageE1_expected_byT_W1_bounds.csv'));
UW=readtable(fullfile(root,'inputs','StageE1QualifiedAudit','StageE1_UW_fullsimplex_W1_bounds_by_T.csv'));
UC=readtable(fullfile(root,'inputs','StageE1QualifiedAudit','StageE1_UC_continuous_W1_bounds_by_T.csv'));
maxd=0; ok=true;
for i=1:height(E)
    if strcmp(E.Coordinate{i},'U_W'), Q=UW; else, Q=UC; end
    j=find(strcmp(Q.TransferMode,E.TransferMode{i}) & strcmp(Q.TScenario,E.TScenario{i}) & abs(Q.EPC_wtfrac-E.EPC_wtfrac(i))<1e-12,1);
    if isempty(j), ok=false; continue; end
    d=abs(Q.W1_certified_lower_decades(j)-E.Expected_W1_lower_decades(i)); maxd=max(maxd,d); ok=ok && d<cfg.StageF.regression_abs_tol;
end
add('F0_STAGE_E1_CORRECTED_MIRROR_PREREQUISITE',ok,sprintf('Executed Stage-E.1: max corrected 60-row mirror difference %.3g decades.',maxd));

% F1. Ensemble dimensions are fixed and auditable.
expected=[5 2 33 11 301]; ok=isequal(result.Dims,expected);
add('F1_PRIMARY_ENSEMBLE_DIMENSIONS',ok,sprintf('Dimensions [%s], total states %d.',num2str(result.Dims),prod(result.Dims)));

% F1A. Stage-F matrix moments must use the Stage-E analytical/high-resolution
% reference, while the legacy Stage-B1 compact-grid moments remain audit-only.
M=result.MatrixMomentAudit;
ok=height(M)==1 && M.UsesStageEAnalyticalReference(1)==1 && ...
   abs(M.StageF_Mn_gmol(1)-M.StageE_Analytical_Mn_gmol(1))<1e-9 && ...
   abs(M.StageF_Mw_gmol(1)-M.StageE_Analytical_Mw_gmol(1))<1e-9 && ...
   M.LegacyCompactGrid_Mn_relative_bias(1)>0.004 && M.LegacyCompactGrid_Mn_relative_bias(1)<0.005;
add('F1A_MATRIX_MOMENT_CONSISTENCY_HOTFIX',ok,sprintf('Stage-E analytical Mn %.12g, Mw %.12g; legacy compact-grid Mn bias %.6g.', ...
    M.StageF_Mn_gmol(1),M.StageF_Mw_gmol(1),M.LegacyCompactGrid_Mn_relative_bias(1)));

% F2. Baseline target ranges reproduce the independent moment-consistent mirror and the Stage-B1 L3 composition extrema.
Eb=readtable(fullfile(root,'Independent_Audit','StageF_expected_baseline_ranges.csv'));
[maxBase,okBase]=compare_baseline(result.Baseline,Eb,cfg.StageF.regression_abs_tol);
comp=result.Baseline(strcmp(result.Baseline.Target,'StageC2_wtfrac'),:);
okL3=height(comp)==1 && abs(comp.Min-0.0199933642116365)<1e-12 && abs(comp.Max-0.0692859506374108)<1e-12;
add('F2_BASELINE_RANGE_REGRESSION',okBase && okL3,sprintf('Max moment-consistent baseline range difference %.3g; Stage-B1 L3 C2 regression %d.',maxBase,okL3));

% F3. All 95 singleton guaranteed contractions match independent calculation.
Es=readtable(fullfile(root,'Independent_Audit','StageF_expected_singleton_contractions.csv'));
[maxS,okS]=compare_subset_rows(result.Singleton,Es,cfg.StageF.regression_abs_tol);
add('F3_SINGLETON_VALUE_MIRROR',okS,sprintf('Max singleton metric difference %.3g across %d rows.',maxS,height(Es)));

% F4. Best subset at every cardinality matches independent calculation.
Eg=readtable(fullfile(root,'Independent_Audit','StageF_expected_best_subsets_by_cardinality.csv'));
[maxG,okG]=compare_subset_rows(result.Best,Eg,cfg.StageF.regression_abs_tol);
add('F4_CARDINALITY_FRONTIER_MIRROR',okG,sprintf('Max cardinality-frontier metric difference %.3g across %d rows.',maxG,height(Eg)));

% F5. Exact-identification subsets match independent finite-ensemble audit.
Em=readtable(fullfile(root,'Independent_Audit','StageF_expected_minimum_exact_sets.csv'));
okM=compare_minsets(result.MinSets,Em);
add('F5_MINIMUM_EXACT_SET_MIRROR',okM,sprintf('Minimum-exact-set rows MATLAB=%d mirror=%d.',height(result.MinSets),height(Em)));

% F6. Composition information hierarchy: latent chemistry is the strongest
% singleton; the reactivity coordinate alone has no guaranteed value while
% EX2 sorbed-f1 plus that coordinate has positive value.
C=result.Singleton(strcmp(result.Singleton.Target,'StageC2_wtfrac'),:);
[bestv,ib]=max(C.GuaranteedContractionFraction); bestName=C.ResolvedBlocks{ib};
curve=C.GuaranteedContractionFraction(strcmp(C.ResolvedBlocks,'REACTIVITY_CURVE_COORD'));
pair=result.Dependency.EX2f1PlusReactivityGuaranteedContraction(1);
ok=strcmp(bestName,'LATENT_CHEMISTRY') && bestv>0.29 && curve<1e-12 && pair>0.11;
add('F6_COMPOSITION_INFORMATION_HIERARCHY',ok,sprintf('Best singleton %s=%.6g; curve alone %.3g; EX2-f1+curve %.6g.',bestName,bestv,curve,pair));

% F7. Quantitative MWD moments are dominated by T80 population-transfer information.
Q=result.Singleton(strcmp(result.Singleton.TransferMode,'DP_REPEAT_MASS_CORRECTED') & ...
    (strcmp(result.Singleton.Target,'Final_Mn_gmol') | strcmp(result.Singleton.Target,'Final_Mw_gmol') | strcmp(result.Singleton.Target,'Final_D')),:);
ok=true; minT=inf; maxOther=-inf;
for ie=1:numel(cfg.StageF.EPC)
    for p={'Final_Mn_gmol','Final_Mw_gmol','Final_D'}
        q=Q(abs(Q.EPC_wtfrac-cfg.StageF.EPC(ie))<1e-12 & strcmp(Q.Target,p{1}),:);
        t=q.GuaranteedContractionFraction(strcmp(q.ResolvedBlocks,'T80_TRANSFER'));
        o=q.GuaranteedContractionFraction(~strcmp(q.ResolvedBlocks,'T80_TRANSFER'));
        minT=min(minT,t); maxOther=max(maxOther,max(o)); ok=ok && t>0.90 && all(o<0.05);
    end
end
D=result.Singleton(strcmp(result.Singleton.TransferMode,'DIRECT_MN_TRANSFER'),:);
tRows=D(strcmp(D.ResolvedBlocks,'T80_TRANSFER'),:); ok=ok && all(abs(tRows.GuaranteedContractionFraction-1)<1e-12);
add('F7_MWD_TARGET_SPECIFIC_INFORMATION_HIERARCHY',ok,sprintf('DP minimum T80 contraction %.6g; maximum non-T singleton %.6g; DIRECT T80 contraction = 1.',minT,maxOther));

% F8. Ideal second-RCP reactivity design must be uniquely solvable but its
% conditioning is reported, not hidden.
Er=readtable(fullfile(root,'Independent_Audit','StageF_expected_reactivity_design_summary.csv'));
S=result.ReactSummary;
d=max(abs([S.MinNormalizedDeterminant-Er.MinNormalizedDeterminant, ...
    S.MaxNormalizedConditionNumber-Er.MaxNormalizedConditionNumber, ...
    S.FractionOptimalAtLowerEndpoint-Er.FractionOptimalAtLowerEndpoint, ...
    S.FractionOptimalAtUpperEndpoint-Er.FractionOptimalAtUpperEndpoint]));
ok=d<cfg.StageF.regression_abs_tol && S.FractionOptimalAtEitherEndpoint>1-1e-12 && ...
    S.MinNormalizedDeterminant>0.04 && S.MaxNormalizedConditionNumber<50 && S.MaxRelativeExactRecoveryError<1e-10;
add('F8_SECOND_RCP_IDENTIFIABILITY_AND_CONDITIONING',ok,sprintf('Mirror diff %.3g; min determinant %.5g; max cond %.5g; max exact recovery error %.3g.', ...
    d,S.MinNormalizedDeterminant,S.MaxNormalizedConditionNumber,S.MaxRelativeExactRecoveryError));

% F9. Scope guard: no probability, expected utility, or measurement precision is claimed.
allowed={'DETERMINISTIC_MINIMAX','DETERMINISTIC_OUTCOME_RANGE','FINITE_ENSEMBLE_ORACLE_BLOCK_RESOLUTION', ...
    'SENSITIVITY_DIAGNOSTIC_ONLY','CALIBRATION_OR_VALIDATION_NOT_TRANSFERABLE_IDENTIFICATION'};
ok=all(ismember(result.Scope.Status,allowed));
add('F9_NO_FALSE_PROBABILISTIC_VOI',ok,'Stage-F metrics are deterministic set contractions / oracle block-resolution bounds, not expected value of information.');

% F10. Reactivity-coordinate measurement dependency is explicit in the interpretation table.
j=find(strcmp(result.Roles.BlockID,'REACTIVITY_CURVE_COORD'),1);
ok=~isempty(j) && contains(lower(result.Roles.MeasurementProxy{j}),'only after ex2') && contains(lower(result.Roles.Caveat{j}),'no measurement-noise');
add('F10_REACTIVITY_MEASUREMENT_DEPENDENCY_EXPLICIT',ok,'Second RCP datum is conditional on EX2 sorbed-f1 resolution and exact-readout scope is explicit.');

% F11. Stage-E.1 structural result remains separate from Stage-F quantitative identification targets.
ok=result.E1Context.Min_UW_W1_lower_decades(1)>0.17 && result.E1Context.Min_UC_W1_lower_decades(1)>0.23 && ...
   strcmp(result.E1Context.RoleInStageF{1},'STRUCTURAL_FULL_MWD_RETENTION_ALREADY_BOUNDED_AWAY_FROM_ZERO');
add('F11_STRUCTURAL_MWD_CLAIM_PRESERVED_SEPARATELY',ok,sprintf('Embedded E1 minima: U_W %.6g, U_C %.6g decades.', ...
    result.E1Context.Min_UW_W1_lower_decades(1),result.E1Context.Min_UC_W1_lower_decades(1)));

T=table(checks,status,detail,'VariableNames',{'Gate','Status','Detail'});
writetable(T,fullfile(outdir,'StageF_verification.csv'));

    function add(name,cond,msg)
        checks{end+1,1}=name; %#ok<AGROW>
        if cond, status{end+1,1}='PASS'; else, status{end+1,1}='FAIL'; end %#ok<AGROW>
        detail{end+1,1}=msg; %#ok<AGROW>
    end
end

function [maxd,ok]=compare_baseline(A,E,tol)
maxd=0; ok=true;
for i=1:height(E)
    j=find(strcmp(A.Target,E.Target{i}) & strcmp(A.TransferMode,E.TransferMode{i}) & epc_match(A.EPC_wtfrac,E.EPC_wtfrac(i)),1);
    if isempty(j), ok=false; continue; end
    d=max(abs([A.Min(j)-E.Min(i),A.Max(j)-E.Max(i),A.Width(j)-E.Width(i)])); maxd=max(maxd,d); ok=ok && d<tol*max(1,abs(E.Max(i)));
end
end

function [maxd,ok]=compare_subset_rows(A,E,tol)
maxd=0; ok=true;
for i=1:height(E)
    j=find(strcmp(A.Target,E.Target{i}) & strcmp(A.TransferMode,E.TransferMode{i}) & epc_match(A.EPC_wtfrac,E.EPC_wtfrac(i)) & ...
        strcmp(A.ResolvedBlocks,E.ResolvedBlocks{i}) & A.Cardinality==E.Cardinality(i),1);
    if isempty(j), ok=false; continue; end
    valsA=[A.BaselineWidth(j),A.WorstResidualWidth(j),A.BestResidualWidth(j),A.GuaranteedContractionFraction(j),A.BestCaseContractionFraction(j)];
    valsE=[E.BaselineWidth(i),E.WorstResidualWidth(i),E.BestResidualWidth(i),E.GuaranteedContractionFraction(i),E.BestCaseContractionFraction(i)];
    d=max(abs(valsA-valsE)); maxd=max(maxd,d); ok=ok && d<tol*max(1,max(abs(valsE)));
end
end

function ok=compare_minsets(A,E)
ok=height(A)==height(E); if ~ok, return; end
for i=1:height(E)
    j=find(strcmp(A.Target,E.Target{i}) & strcmp(A.TransferMode,E.TransferMode{i}) & epc_match(A.EPC_wtfrac,E.EPC_wtfrac(i)) & ...
        A.MinExactCardinality==E.MinExactCardinality(i) & strcmp(A.ResolvedBlocks,E.ResolvedBlocks{i}),1);
    if isempty(j), ok=false; return; end
end
end

function tf=epc_match(v,x)
if isnan(x), tf=isnan(v); else, tf=abs(v-x)<1e-12; end
end
