function T = verify_stageG_joint_uncertainty_closure(cfg,outdir,result)
%VERIFY_STAGEG_JOINT_UNCERTAINTY_CLOSURE Executable final Stage-G gates.
checks={}; status={}; detail={};
root=fileparts(fileparts(mfilename('fullpath')));

% G0. Executed Stage-F prerequisite must be qualified.
fstat=fileread(fullfile(root,'inputs','StageFQualifiedOutputs','STAGE_F_STATUS.txt'));
ok=contains(fstat,'STAGE_F_PROSPECTIVE_SET_BASED_INFORMATION_AUDIT_QUALIFIED');
add('G0_STAGE_F_PREREQUISITE',ok,'Embedded executed Stage-F status must be qualified.');

% G1. Matrix full-MWD distance is unchanged from qualified Stage E/E.1.
Ed=readtable(fullfile(root,'Independent_Audit','StageG_expected_diagnostics.csv'));
d=abs(result.matrixW1-Ed.Matrix_W1_decades(1));
ok=d<cfg.StageG.regression_abs_tol;
add('G1_MATRIX_W1_REGRESSION',ok,sprintf('Matrix W1 absolute difference %.3g decades.',d));

% G2. Analytic Jensen-envelope primitive matches independent test intervals.
J=readtable(fullfile(root,'Independent_Audit','StageG_expected_Jensen_selftest.csv'));
maxJ=0; ok=true;
for i=1:height(J)
    R=stageG_jensen_gap_u_interval(J.u_min(i),J.u_max(i),cfg.StageG.root_tol,cfg.StageG.max_bisection_iter);
    dd=max(abs([R.hmin-J.Expected_hmin(i),R.hmax-J.Expected_hmax(i)]));
    maxJ=max(maxJ,dd); ok=ok && dd<1e-10;
end
add('G2_JENSEN_ENVELOPE_ANALYTIC_SELFTEST',ok,sprintf('Max independent Jensen-extrema difference %.3g.',maxJ));

% G3. Qualified primary T80 ensemble x 2 modes x 3 EPC levels is complete.
expectedRows=5*2*3;
ok=height(result.ByT)==expectedRows && result.Diagnostics.Primary_T80_scenario_count(1)==5 && ...
    result.Diagnostics.Transfer_mode_count(1)==2 && result.Diagnostics.EPC_count(1)==3;
add('G3_JOINT_DOMAIN_DIMENSIONS',ok,sprintf('By-T rows %d; expected %d.',height(result.ByT),expectedRows));

% G4. Every by-T certified lower bound and support interval matches the independent mirror.
E=readtable(fullfile(root,'Independent_Audit','StageG_expected_joint_W1_bounds_by_T.csv'));
maxD=0; ok=true;
for i=1:height(E)
    j=find(strcmp(result.ByT.TransferMode,E.TransferMode{i}) & strcmp(result.ByT.TScenario,E.TScenario{i}) & ...
        abs(result.ByT.EPC_wtfrac-E.EPC_wtfrac(i))<1e-12,1);
    if isempty(j), ok=false; continue; end
    vals=[result.ByT.W1_certified_joint_lower_decades(j)-E.Expected_W1_lower_decades(i), ...
        result.ByT.W1_attainable_vertex_upper_decades(j)-E.Expected_W1_attainable_upper_decades(i), ...
        result.ByT.ReciprocalMnSupport_min_per_gmol(j)-E.Expected_s_min_per_gmol(i), ...
        result.ByT.ReciprocalMnSupport_max_per_gmol(j)-E.Expected_s_max_per_gmol(i)];
    dd=max(abs(vals)); maxD=max(maxD,dd); ok=ok && dd<cfg.StageG.regression_abs_tol;
end
add('G4_INDEPENDENT_JOINT_BOUND_MIRROR',ok,sprintf('Maximum by-T mirror difference %.3g.',maxD));

% G5. The structural W1 lower bound is strictly positive everywhere in the enlarged joint domain.
minLB=min(result.ByT.W1_certified_joint_lower_decades);
ok=minLB>cfg.StageG.w1_positive_tol;
add('G5_POSITIVE_JOINT_STRUCTURAL_BOUND',ok,sprintf('Minimum certified joint W1 lower bound %.9g decades.',minLB));

% G6. Summary across T80 scenarios matches independent aggregation.
S=readtable(fullfile(root,'Independent_Audit','StageG_expected_joint_W1_bounds_summary.csv'));
maxS=0; ok=true;
for i=1:height(S)
    j=find(strcmp(result.Summary.TransferMode,S.TransferMode{i}) & abs(result.Summary.EPC_wtfrac-S.EPC_wtfrac(i))<1e-12,1);
    if isempty(j), ok=false; continue; end
    dd=max(abs([result.Summary.W1_certified_joint_lower_decades(j)-S.Expected_W1_lower_decades(i), ...
        result.Summary.W1_attainable_vertex_upper_decades(j)-S.Expected_W1_attainable_upper_decades(i), ...
        result.Summary.W1_joint_min_bracket_width_decades(j)-S.Expected_bracket_width_decades(i)]));
    maxS=max(maxS,dd); ok=ok && dd<cfg.StageG.regression_abs_tol;
end
add('G6_T80_GLOBAL_SUMMARY_MIRROR',ok,sprintf('Maximum summary mirror difference %.3g decades.',maxS));

% G7. Domain enlargement is conservative by construction.
a0=cfg.StageG.M2_gmol/cfg.StageG.M3_gmol;
D=result.ByT(strcmp(result.ByT.TransferMode,'DIRECT_MN_TRANSFER'),:);
P=result.ByT(strcmp(result.ByT.TransferMode,'DP_REPEAT_MASS_CORRECTED'),:);
ok=all(abs(D.Alpha_min-1)<1e-15) && all(abs(P.Alpha_min-a0)<1e-15) && ...
    all(P.ReciprocalMnSupport_max_per_gmol>=P.ReciprocalMnSupport_min_per_gmol) && ...
    all(contains(D.DomainStatement,'continuous interval')) && all(contains(P.DomainStatement,'independent alpha_j'));
add('G7_CONSERVATIVE_JOINT_SUPERSET_SEMANTICS',ok,sprintf('DP alpha lower limit M2/M3 = %.10g; full simplex/support-interval enlargement explicit.',a0));

% G8. One-population simplex vertices are exact admissible witnesses: second-stage Jensen gap is zero.
% Therefore final W1=(1-EPC)*matrix W1 is an attainable upper bound on the global minimum.
ok=true; maxU=0;
for i=1:height(result.ByT)
    target=(1-result.ByT.EPC_wtfrac(i))*result.matrixW1;
    dd=abs(result.ByT.W1_attainable_vertex_upper_decades(i)-target); maxU=max(maxU,dd);
    ok=ok && dd<1e-12 && result.ByT.W1_certified_joint_lower_decades(i)<=target+1e-12;
end
add('G8_ATTAINABLE_VERTEX_BRACKET',ok,sprintf('Max vertex-upper regression difference %.3g decades.',maxU));

% G9. Finite-grid compatibility pad is retained and nonzero.
ok=abs(result.Diagnostics.FiniteGrid_CDF_pad_per_CDF(1)-cfg.StageG.finite_grid_cdf_pad)<1e-15 && cfg.StageG.finite_grid_cdf_pad>=1e-5;
add('G9_FINITE_GRID_CDF_PAD_RETAINED',ok,sprintf('CDF pad per CDF %.3g.',cfg.StageG.finite_grid_cdf_pad));

% G10. Scope guard: only W1 and a derived JS floor are jointly certified.
q=result.MetricScope;
ok=strcmp(q.Status{strcmp(q.Metric,'W1_log10M')},'CERTIFIED_JOINT_LOWER_BOUND') && ...
    strcmp(q.Status{strcmp(q.Metric,'JS_divergence_bits')},'DERIVED_CONSERVATIVE_LOWER_BOUND_FROM_W1') && ...
    all(strcmp(q.Status(ismember(q.Metric,{'M90_ratio','M99_ratio','TailExcessAboveCollapsedM90'})),'NOT_JOINTLY_CERTIFIED')) && ...
    all(strcmp(q.Status(ismember(q.Metric,{'StageC2_wtfrac','Grade_Mn_Mw_D'})),'NOT_A_STAGE_G_TARGET'));
add('G10_NO_FALSE_JOINT_CLAIMS',ok,'No joint certification is assigned to composition, grade moments, quantiles, or tail metrics.');

% G11. Final closure must retain a materially positive worst-case bound and identify the expected limiting case.
c=result.Closure;
ok=height(c)==1 && c.Global_W1_certified_joint_lower_decades(1)>0.19 && ...
    strcmp(c.WorstTransferMode{1},'DP_REPEAT_MASS_CORRECTED') && abs(c.WorstEPC_wtfrac(1)-0.30)<1e-12 && ...
    contains(c.ClaimStatus{1},'CERTIFIED_POSITIVE_OVER_CONSERVATIVE_JOINT_SUPERSET');
add('G11_FINAL_STRUCTURAL_CLAIM_CLOSURE',ok,sprintf('Global joint W1 lower %.9g; upper %.9g decades.', ...
    c.Global_W1_certified_joint_lower_decades(1),c.Global_W1_attainable_vertex_upper_decades(1)));

T=table(checks,status,detail,'VariableNames',{'Gate','Status','Detail'});
writetable(T,fullfile(outdir,'StageG_verification.csv'));

    function add(name,cond,msg)
        checks{end+1,1}=name; %#ok<AGROW>
        if cond, status{end+1,1}='PASS'; else, status{end+1,1}='FAIL'; end %#ok<AGROW>
        detail{end+1,1}=msg; %#ok<AGROW>
    end
end
