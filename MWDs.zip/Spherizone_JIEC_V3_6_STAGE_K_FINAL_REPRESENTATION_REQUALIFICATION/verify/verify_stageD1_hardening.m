function T = verify_stageD1_hardening(cfg,outdir,R)
%VERIFY_STAGED1_HARDENING Executable D.1 qualification checks.
checks={}; status={}; detail={};
% H1: exactly the genuine Stage-D coarse crossings are refined.
nExpected=sum(strcmp(readtable(fullfile(outdir,'StageD_critical_radius_brackets.csv')).Status,'CRITICAL_RADIUS_BRACKETED'));
checks{end+1,1}='H1_GENUINE_CROSSINGS_ONLY';
status{end+1,1}=ternary_D1(sum(R.RefinementApplied)==nExpected,'PASS','FAIL');
detail{end+1,1}=sprintf('%d of %d rows refined; expected %d coarse bracketed crossings.',sum(R.RefinementApplied),height(R),nExpected);
% H2: every refined bracket is within tolerance and preserves sign orientation.
idx=find(R.RefinementApplied);
ok=true;
for k=idx'
    ok=ok && R.RefinedBracketWidth(k)<=cfg.StageD1.critical_radius_tol*(1+1e-9) && ...
        R.MarginAtRefinedLastSeparated(k)>cfg.StageD1.margin_tol && R.MarginAtRefinedFirstOverlap(k)<=cfg.StageD1.margin_tol;
end
checks{end+1,1}='H2_BISECTION_SIGN_AND_WIDTH'; status{end+1,1}=ternary_D1(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('Tolerance %.3g; refined rows %d.',cfg.StageD1.critical_radius_tol,numel(idx));
% H3: U_W composition invariance is explicitly structural under C0.
S=readtable(fullfile(outdir,'StageD1_coordinate_semantics.csv'));
i=find(strcmp(S.Diagnostic,'U_W_C2_C0'),1);
if isempty(i)
    ok=false; v1=NaN; v2=NaN;
else
    v1=S.Value1(i); v2=S.Value2(i); ok=v1<=1e-12 && v2<=1e-12;
end
checks{end+1,1}='H3_UW_C2_STRUCTURAL_INVARIANCE'; status{end+1,1}=ternary_D1(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('Max coefficient spread %.3g; max curve change %.3g.',v1,v2);
% H4: rho=1 semantics are 0.5..2 per population and 4 max/min when span=2.
i=find(strcmp(S.Diagnostic,'U_C_RHO_1'),1);
if isempty(i)
    ok=false; v1=NaN; v2=NaN; v3=NaN;
else
    v1=S.Value1(i); v2=S.Value2(i); v3=S.Value3(i);
    ok=abs(v1-0.5)<1e-12 && abs(v2-2)<1e-12 && abs(v3-4)<1e-12;
end
checks{end+1,1}='H4_RHO1_MULTIPLIER_SEMANTICS'; status{end+1,1}=ternary_D1(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('rho=1 multiplier min %.6g, max %.6g, max/min %.6g.',v1,v2,v3);
% H5: generated refined crossings agree with the independent equation mirror.
ROOT=fileparts(fileparts(mfilename('fullpath')));
E=readtable(fullfile(ROOT,'Independent_Audit','StageD1_expected_refined_crossings.csv'));
ok=true; maxMidDiff=0;
for j=1:height(E)
    u=string(E.UncertaintyCoordinate(j)); m=string(E.TransferMode(j)); p=string(E.Property(j));
    hit=find(string(R.UncertaintyCoordinate)==u & ...
        string(R.TransferMode)==m & string(R.Property)==p & ...
        abs(R.EPC_low-E.EPC_low(j))<1e-12 & abs(R.EPC_high-E.EPC_high(j))<1e-12,1);
    if isempty(hit) || ~R.RefinementApplied(hit)
        ok=false; continue;
    end
    d=abs(R.RefinedMidpointRadius(hit)-E.RefinedMidpointRadius(j));
    maxMidDiff=max(maxMidDiff,d);
    ok=ok && d<=cfg.StageD1.critical_radius_tol;
end
checks{end+1,1}='H5_INDEPENDENT_MIRROR_AGREEMENT'; status{end+1,1}=ternary_D1(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('Maximum refined-midpoint difference from independent mirror %.3g.',maxMidDiff);
T=table(checks,status,detail,'VariableNames',{'Gate','Status','Detail'});
writetable(T,fullfile(outdir,'StageD1_hardening_verification.csv'));
end
function s=ternary_D1(cond,a,b)
if cond, s=a; else, s=b; end
end
