function T = verify_stageD_tv_solver()
%VERIFY_STAGED_TV_SOLVER Analytical unit test for exact TV linear bounds.
w0=[0.2 0.3 0.5]; c=[1 2 4]; d=[0 0.1 0.4 1.0];
[vmin,vmax]=tv_linear_bounds_curve(w0,c,d);
expectedMin=[2.8 2.5 1.6 1.0];
expectedMax=[2.8 3.1 3.8 4.0];
err=max([abs(vmin-expectedMin),abs(vmax-expectedMax)]);
T=table(err,err<1e-12,'VariableNames',{'MaxAbsError','Pass'});
end
