function T = verify_stageE_distribution_retention(cfg,outdir,result)
%VERIFY_STAGEE_DISTRIBUTION_RETENTION Executable Stage-E numerical/scope gates.
checks={}; status={}; detail={};
root=fileparts(fileparts(mfilename('fullpath')));

% E0: executed D.1 prerequisite must be embedded and qualified.
f=fullfile(root,'inputs','StageD1QualifiedOutputs','STAGE_D1_STATUS.txt');
ok=exist(f,'file')==2;
if ok
    txt=fileread(f);
    ok=~isempty(strfind(txt,'STAGE_D1_HARDENING_QUALIFIED__PROCEED_TO_STAGE_E')); %#ok<STREMP>
end
checks{end+1,1}='E0_STAGE_D1_PREREQUISITE'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}='Embedded executed Stage-D.1 status must authorize Stage E.';

% E1: detailed and collapsed distributions reproduce analytical Mn/Mw.
Tabs={result.SourceTable,result.ReferenceTable,result.WorstMetrics};
maxRel=0; maxNorm=0;
for it=1:numel(Tabs)
    A=Tabs{it};
    for i=1:height(A)
        valsA=[A.Mn_analytical_gmol(i),A.Mw_analytical_gmol(i),A.Mn_collapsed_analytical_gmol(i),A.Mw_collapsed_analytical_gmol(i)];
        valsN=[A.Mn_detailed_numerical_gmol(i),A.Mw_detailed_numerical_gmol(i),A.Mn_collapsed_numerical_gmol(i),A.Mw_collapsed_numerical_gmol(i)];
        maxRel=max(maxRel,max(abs(valsN-valsA)./max(abs(valsA),1)));
    end
end
ok=maxRel<cfg.StageE.metric_moment_rel_tol;
checks{end+1,1}='E1_FULL_MWD_MOMENT_RECONSTRUCTION'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('Maximum numerical-vs-analytical Mn/Mw relative difference %.3g (tol %.3g).',maxRel,cfg.StageE.metric_moment_rel_tol);

% E2: phase-wise information collapse must preserve final Mn analytically.
A=[result.ReferenceTable; align_worst_E(result.WorstMetrics,result.ReferenceTable.Properties.VariableNames)];
mnerr=max(abs(A.Mn_analytical_gmol-A.Mn_collapsed_analytical_gmol)./max(abs(A.Mn_analytical_gmol),1));
ok=mnerr<1e-12;
checks{end+1,1}='E2_COMPARATOR_PRESERVES_FINAL_MN'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('Maximum analytical final-Mn mismatch %.3g.',mnerr);

% E3: adverse witness search must reproduce Stage-B2 structural minima.
ok=all(result.WitnessRegression.Pass);
maxB2=max(result.WitnessRegression.RelativeDifference);
checks{end+1,1}='E3_B2_WITNESS_REGRESSION'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('Maximum relative difference from Stage-B2 minimum DeltaD %.3g.',maxB2);

% E4: full-distribution information distance remains nonzero at every B2
% adverse witness. This is a numerical identity test, not a materiality cutoff.
W=result.WorstMetrics;
minW1=min(W.W1_log10M_decades); minJS=min(W.JS_divergence_bits);
ok=minW1>cfg.StageE.distance_tol && minJS>cfg.StageE.distance_tol;
checks{end+1,1}='E4_NONZERO_FULL_DISTRIBUTION_SIGNAL_AT_B2_ADVERSE_WITNESSES'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('Minimum W1 %.6g decades; minimum JS %.6g bits. Magnitude interpretation is deferred to audit.',minW1,minJS);

% E5: source -> MZCR resolved-vs-collapsed signal remains finite and nonzero.
ok=isfinite(result.sourceW1) && isfinite(result.matrixW1) && result.sourceW1>cfg.StageE.distance_tol && result.matrixW1>cfg.StageE.distance_tol;
checks{end+1,1}='E5_SOURCE_TO_MZCR_INFORMATION_RETENTION'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('EX1-source W1 %.6g; MZCR-matrix W1 %.6g; ratio %.6g.',result.sourceW1,result.matrixW1,result.matrixW1/result.sourceW1);

% E6: source-supported H2 challenge moves all four MWD quantiles downward.
H=result.H2Trend;
qdown=all(diff(H.M10_gmol)<0) && all(diff(H.M50_gmol)<0) && all(diff(H.M90_gmol)<0) && all(diff(H.M99_gmol)<0);
checks{end+1,1}='E6_H2_FULL_MWD_DIRECTIONAL_CHALLENGE'; status{end+1,1}=ternary_E(qdown,'PASS','FAIL');
detail{end+1,1}=sprintf('All M10/M50/M90/M99 decrease over H2 = %s psi.',mat2str(H.H2_psi'));

% E7: external challenge table must explicitly prohibit invalid validation mappings.
X=result.ExternalChallenge;
y4=find(strcmp(X.ChallengeID,'Y4_FBR_ETHYLENE_RATIO'),1); y5=find(strcmp(X.ChallengeID,'Y5_STAGEE_RETENTION_METRIC'),1);
ok=~isempty(y4) && ~isempty(y5) && strcmp(X.Status{y4},'NOT_DIRECTLY_TESTABLE') && strcmp(X.Status{y5},'NO_DIRECT_YANG_EQUIVALENT');
checks{end+1,1}='E7_EXTERNAL_CHALLENGE_SCOPE_DISCIPLINE'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}='Yang FBR-ethylene and Stage-E W1/JS retention are not allowed as direct validation claims.';

% E8: the adverse witnesses must remain the pre-specified B2 minimum-DeltaD
% cases rather than cases chosen post hoc by W1/JS.
ok=all(strcmp(result.WorstMetrics.State,'B2_MIN_DELTA_D_WITNESS'));
checks{end+1,1}='E8_NO_STAGEE_METRIC_CHERRY_PICKING'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}='Full-MWD metrics are evaluated at witnesses selected by the prior Stage-B2 DeltaD objective.';

% E9: independent equation-mirror precheck bundled before MATLAB execution.
Ew=readtable(fullfile(root,'Independent_Audit','StageE_expected_B2_witnesses.csv'));
Es=readtable(fullfile(root,'Independent_Audit','StageE_expected_EX1_source_metrics.csv'));
maxMirror=0; ok=true;
for i=1:height(Ew)
    j=find(strcmp(result.WitnessTable.TransferMode,Ew.TransferMode{i}) & abs(result.WitnessTable.EPC_wtfrac-Ew.EPC_wtfrac(i))<1e-12,1);
    if isempty(j), ok=false; continue; end
    rel=abs(result.WitnessTable.MinDeltaD_vs_phasewise_singleFlory(j)-Ew.MinDeltaD(i))/max(abs(Ew.MinDeltaD(i)),1);
    maxMirror=max(maxMirror,rel); ok=ok && rel<1e-10;
end
jsrc=find(strcmp(result.SourceTable.State,'EX1_CONDITIONED_SOURCE'),1);
if isempty(jsrc), ok=false; srcdiff=inf; else, srcdiff=abs(result.SourceTable.W1_log10M_decades(jsrc)-Es.W1_log10M_decades(1)); ok=ok && srcdiff<1e-6; end
checks{end+1,1}='E9_INDEPENDENT_EQUATION_MIRROR'; status{end+1,1}=ternary_E(ok,'PASS','FAIL');
detail{end+1,1}=sprintf('Max witness relative difference %.3g; EX1-source W1 absolute difference %.3g.',maxMirror,srcdiff);

T=table(checks,status,detail,'VariableNames',{'Gate','Status','Detail'});
writetable(T,fullfile(outdir,'StageE_verification.csv'));
end

function Tout=align_worst_E(W,names)
% Select only the common metric fields so vertical concatenation is valid.
Tout=W(:,names);
end

function s=ternary_E(cond,a,b)
if cond, s=a; else, s=b; end
end
