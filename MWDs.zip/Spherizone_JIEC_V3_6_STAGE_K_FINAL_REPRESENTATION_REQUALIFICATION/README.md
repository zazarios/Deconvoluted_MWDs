# Spherizone JIEC v3.4.2 — Stage J table-header hotfix

Run:

`Run_JIEC_V3_StageJ_ExternalPhysicalConsistencyChallenge.m`

The launcher creates `JIEC_V3_STAGE_J_OUTPUTS.zip`.

Stage J uses independent industrial/pilot/controlled hiPP evidence only as a held-out physical-consistency challenge. It does not fit external ICP data and does not claim matched Spherizone validation.

See `README_STAGE_J.md`, `STAGE_J_3_4_RELEASE_NOTES.md`, and `STAGE_J_3_4_1_RELEASE_NOTES.md`.

## Stage-J v3.4.3 verification hotfix
Stage J v3.4.3 fixes only the semantic column naming/resolution of the in-memory claim-scope tables used by verification gates J13-J17 and routes Stage-J independent mirror CSVs through the strict comma reader. Scientific calculations and A-I frozen inputs are unchanged. See `STAGE_J_3_4_3_RELEASE_NOTES.md`.

---

## Stage J.1 extension (v3.5)
The current extension is documented in `README_STAGE_J1.md`. Run `Run_JIEC_V3_StageJ1_HighEPChemistryRedevelopment.m`. Stage J and all prior stages remain frozen upstream evidence.

## Stage K v3.6
The current development head is Stage K final representation-order requalification. Run `Run_JIEC_V3_StageK_FinalRepresentationRequalification.m`. Stage K freezes A–J.1 and requalifies H/H.1/H.2 over the final 17-state H2/T80 support without changing the representation rules or tolerance bands.
