# Stage K — Final representation-order requalification

Stage K freezes A–J.1 and re-runs the scientific questions originally asked in Stages H, H.1, and H.2 over the finalized downstream state/model-form domain.

## What changes
Only the admissible H2/T80 state support changes. The legacy five-state Stage-G/H support is replaced by the qualified Stage-J union:
- 6 no-added-H2 boundary states,
- 6 controlled 2 mol% H2 stress states,
- 5 legacy 5 mol% H2 states.

Total: 17 T80/H2 states.

## What does not change
- five source MWD populations,
- all 52 set partitions,
- harmonic-Mn oracle projection rule,
- H.1 target-specific fixed-scalar descriptor definition,
- H.2 T80-global fixed-scalar descriptor definition,
- DIRECT and DP transfer formulations,
- EPC = 0.10, 0.20, 0.30,
- W1/scalar/tail targets,
- TIGHT/MODERATE/COARSE tolerance bands.

J.1 high-E/P chemistry does not require an additional molecular-weight scale enumeration because H/H.1/H.2 already used the full independent DP repeat-mass scale interval alpha_j in [M(C2)/M(C3), 1]. This interval contains every physically possible E/P repeat-mass scaling and therefore every J.1 composition realization.

## Scientific questions
1. Does target-dependent oracle population order survive the final state domain?
2. Does H.1 branch-conditional fixed-descriptor closure survive, and where does it become harder?
3. Does the H.2 T80-global state/model-form closure barrier survive?
4. Which H/H.1/H.2 order claims change when the externally challenged H2/T80 support is included?

Stage K is a requalification stage. It does not redesign the representation or fit external ICP data.
