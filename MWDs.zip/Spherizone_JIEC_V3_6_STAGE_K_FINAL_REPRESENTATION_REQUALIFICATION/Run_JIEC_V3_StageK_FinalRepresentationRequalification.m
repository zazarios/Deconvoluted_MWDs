clear; clc;
ROOT=fileparts(mfilename('fullpath'));addpath(genpath(ROOT));
cfg=stageK_config();outdir=fullfile(ROOT,'Outputs_StageK');if exist(outdir,'dir'),rmdir(outdir,'s');end;mkdir(outdir);
fprintf('[JIEC v3.6 Stage K] Final representation-order requalification\n');
fprintf('Release: %s\n',cfg.release);
fprintf('A-J.1 are frozen. Only the H/H.1/H.2 admissible H2/T80 state support is expanded to the final 17-state union.\n');
result=run_stageK_final_representation_requalification(cfg,outdir);
V=verify_stageK_final_representation_requalification(cfg,outdir,result);
allPass=all(strcmp(V.Status,'PASS'));
statusfile=fullfile(outdir,'STAGE_K_STATUS.txt');fid=fopen(statusfile,'w');
fprintf(fid,'Stage K final representation-order requalification\n');fprintf(fid,'Release: %s\n',cfg.release);
fprintf(fid,'All executable Stage-K gates pass: %d\n',allPass);
if allPass
 verdict='STAGE_K_FINAL_REPRESENTATION_REQUALIFICATION_QUALIFIED';
else
 verdict='STAGE_K_EXECUTABLE_VERIFICATION_FAILED';
end
fprintf(fid,'Verdict: %s\n',verdict);fclose(fid);
zipfile=fullfile(ROOT,'JIEC_V3_STAGE_K_OUTPUTS.zip');if exist(zipfile,'file'),delete(zipfile);end
files=dir(fullfile(outdir,'*'));files=files(~[files.isdir]);names=fullfile(outdir,{files.name});zip(zipfile,names);
if ~allPass,error('Stage-K executable verification failed. Inspect StageK_verification.csv.');end
fprintf('[JIEC v3.6 Stage K] QUALIFIED. Output archive: %s\n',zipfile);
