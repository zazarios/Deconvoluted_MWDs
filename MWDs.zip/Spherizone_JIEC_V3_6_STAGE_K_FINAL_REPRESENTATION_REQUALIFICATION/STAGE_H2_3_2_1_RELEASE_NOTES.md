# Stage H.2 v3.2.1 containment-tolerance hotfix

This is a verification-only hotfix to v3.2. No model equations, uncertainty domains, descriptors, partitions, target metrics, tolerances, or scientific outputs are changed.

## Root cause
Gate H2_4 compared H.2 supports recomputed in memory with H.1 branch supports reloaded from CSV using an absolute tolerance of 1e-9 g/mol. The independent H.2 support mirror itself shows numerical/serialization differences up to 3.03e-9 g/mol, so the containment gate was tighter than the established numerical round-trip scale.

## Fix
- Add `cfg.StageH2.containment_abs_tol_gmol = 1e-8`.
- H2_4 now reports row count, missing keys, and maximum lower/upper containment violations.
- The tolerance is only a numerical containment tolerance. It does not change any scientific support interval.

At the exported-result level from the failed v3.2 run, all 310 H.1 branch supports are contained in the corresponding H.2 global supports with zero positive violation after serialization.
