# Stage H v3.0.1 release notes

**Release:** `3.0.1-stageH-independent-mirror-hotfix`

## Reason
Stage H v3.0 completed the full target-aware projection calculation, but gates H6 and H13 failed because the packaged independent pre-execution summary/order reference was inconsistent with the final Stage-H equations.

## Independent audit
A fresh independent reconstruction reproduced:
- 300 pair-witness rows to <= 7.8e-16 absolute error;
- 300 support-bound rows to <= 7.8e-16;
- 156 partition-level rows to <= 5.6e-16;
- 90 minimax summary rows to <= 4.8e-16;
- all 54 target-order decisions exactly.

## Changes
- replaced `StageH_expected_target_minimax_summary.csv`;
- replaced `StageH_expected_target_order_map.csv`;
- added independent pair-witness, support-bound, and partition-bound reference tables;
- added gates H6A and H6B for low-level independent verification;
- updated release/status text.

## No scientific changes
No equation, population partition, uncertainty set, tolerance band, target metric, or Stage-H result has been changed.
