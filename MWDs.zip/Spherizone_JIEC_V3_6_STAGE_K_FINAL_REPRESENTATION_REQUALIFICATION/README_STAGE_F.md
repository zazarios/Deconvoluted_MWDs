# Stage F — prospective deterministic set-based information audit

## Question
Which unresolved information would most reduce the remaining partial-identification width, and does the answer differ for bulk composition versus quantitative MWD moments?

Stage F does **not** assume a prior probability distribution, expected utility, posterior distribution, or measurement-noise model. For each candidate epistemic block, it asks an oracle question: if that block were known exactly, what is the largest target width that could remain after all unresolved blocks are still allowed to vary? The reported `GuaranteedContractionFraction` is therefore a deterministic minimax contraction and an **upper bound on the information value of a real finite-precision measurement**.

## Five information blocks
1. `T80_TRANSFER`: population-weight/Mn transfer from the source domain to the FBR-relevant 80 °C representation.
2. `FBR_SORPTION`: high-E/P sorbed propylene/ethylene composition at the FBR condition.
3. `LATENT_CHEMISTRY`: population-dependent comonomer response represented by the Stage-B endpoint library.
4. `EX2_SORBED_F1`: unresolved sorbed propylene fraction in the EX2 conditioning experiment.
5. `REACTIVITY_CURVE_COORD`: remaining coordinate along the EX2-conditioned effective Mayo–Lewis reactivity curve. This is **conditional information**: experimentally, one additional RCP composition datum can address this coordinate only after EX2 sorbed `f1` is characterized and the second condition has an independently known sorbed composition.

The primary finite ensemble is exactly the refined Stage-B1 L3 construction: 5 T80 scenarios × 2 FBR sorption scenarios × 33 latent-chemistry scenarios × 11 EX2 `f1` anchors × 301 reactivity-curve coordinates = 1,092,630 states.

## Targets
- bulk second-stage C2 wt fraction;
- final `Mn`, `Mw`, and dispersity for EPC = 10, 20, and 30 wt%;
- both `DIRECT_MN_TRANSFER` and `DP_REPEAT_MASS_CORRECTED` MWD interpretations.

The Stage-E/E1 full-MWD structural-retention result is carried only as context. Stage F does not re-open that already-qualified structural claim.

## Second-RCP design diagnostic
After EX2 sorbed `f1` is known, the existing EX2 composition provides one linear equation in the effective `(r1,r2)` pair. Stage F scans a second independently known sorbed `f1` across the source-supported anchor interval and chooses the condition maximizing the normalized angle between the two Mayo–Lewis equations. Exact recovery is checked, and the 2×2 condition number is exported. A finite determinant establishes ideal structural identifiability only; it does not establish robustness to experimental error.

## Outputs
- `StageF_baseline_target_ranges.csv`
- `StageF_all_block_subsets.csv`
- `StageF_single_block_value.csv`
- `StageF_best_subsets_by_cardinality.csv`
- `StageF_minimum_exact_sets.csv`
- `StageF_composition_cardinality_frontier.csv`
- `StageF_reactivity_dependency.csv`
- `StageF_second_RCP_design_detail.csv`
- `StageF_second_RCP_design_summary.csv`
- `StageF_measurement_roles.csv`
- `StageF_StageE1_context.csv`
- `StageF_scope.csv`
- `StageF_verification.csv`
- `STAGE_F_STATUS.txt`

## Run
```matlab
Run_JIEC_V2_StageF_ValueOfInformation
```

Upload `JIEC_V2_STAGE_F_OUTPUTS.zip` for independent audit before using Stage-F rankings in the manuscript.


## v2.8.1 matrix-moment consistency hotfix
The original v2.8 executable inherited matrix `Mn`/`Mw` from the compact Stage-B1 export grid (`M_output_grid`). This introduces a small numerical truncation bias, most visibly in matrix `Mn` (~0.443%). Stage E later reconstructed the same matrix on the full-distribution framework and exported analytical/high-resolution moments. Stage F.1 now uses those qualified Stage-E analytical matrix moments for all final `Mn`, `Mw`, and dispersity targets. The legacy compact-grid values are exported only in `StageF_matrix_moment_consistency.csv` for regression/audit.

This correction does not change the Stage-F epistemic ensemble, composition calculation, information blocks, subset definitions, or second-RCP design. The independent Stage-F mirror tables already correspond to the analytical moment reference, so F2–F4 should now test the intended calculation rather than the legacy grid bias.
