# JIEC v3.5 Stage J.1 release notes

**Release:** `3.5-stageJ1-high-EP-chemistry-redevelopment`

This release adds a prospective high-E/P chemistry-domain redevelopment on top of the qualified Stage-J v3.4.4 evidence. It does not alter any frozen Stage A-J numerical output.

### New model-form support
- Zhang et al. 2021 high-E/P SI kinetic evidence at E/P 40/60 and 50/50 is transcribed explicitly.
- Observed apparent `kpE/kpP`: 2.18978 to 30.15873.
- Maximum within-condition class contrast: 13.77249.
- Primary outward-rounded effective preference support: 2 to 32; population contrast cap: 16.
- Full Stage-J chemistry family is retained as a legacy subset.

### Scope
The new `kappa` coordinate is a reduced-order stress coordinate on sorbed E/P odds. It is not asserted to equal Zhang's catalyst-specific kinetics, nor `r1`/`r2` in the Mayo-Lewis equation. Held-out ICP/hiPP data are not used to choose the support.

### Qualification target
Requalify composition partial identification and deterministic VOI. Do not refit external data and do not silently requalify H-H.2.
