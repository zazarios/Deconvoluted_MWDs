# Stage H — Certified Target-Aware Population Projection Audit

## Scientific question

Stage H asks a different question from Stages E–G:

> How much of the five-population experimentally resolved MWD representation must be retained for a specified downstream target, and when is reduction scientifically safe under the already-qualified joint uncertainty domain?

The comparison is now **5 → K populations**, with K = 1,…,5, rather than only 5 versus 1.

## Fixed reduction rule

All 52 set partitions of the five numerical MWD-population labels are evaluated. No label is interpreted as a chemically unique active site.

For a merged group G,

- group mass: `W_G = sum_j w_j`,
- reciprocal group Mn: `1/Mn_G = sum_j (w_j/W_G)/Mn_j`.

Thus each group preserves its exact number contribution and every reduction preserves total stage and final Mn. No new pseudo-population Mn is fitted.

The partition is allowed to depend on the **target and retained order K**, but it is not allowed to depend on the uncertainty realization. The minimax error is evaluated first over the complete uncertainty domain, and only then is the best partition selected.

## Oracle-projection interpretation

The group mass and harmonic group Mn are recalculated from each detailed five-population uncertainty state. Stage H therefore evaluates an **optimistic state-aware projection**. It is a lower-bound test on irreducible representation complexity, not yet an operational K-population model that can be propagated without access to the hidden five-population state.

Consequently:

- failure at order K is strong: K is insufficient even with oracle aggregation;
- success at order K means **projection-sufficient**, not automatically deployable;
- an operational reduced model would require a separate group-level transfer/uncertainty closure and is outside Stage H.

## Uncertainty domain

Stage H inherits the qualified Stage-G domain without adding a new uncertainty source:

- full population-weight simplex;
- `DIRECT_MN_TRANSFER` and `DP_REPEAT_MASS_CORRECTED`;
- the five qualified primary T80 transfer scenarios;
- for DP transfer, the conservative independent repeat-mass scale box `M2/M3 <= alpha_j <= 1`.

## Target metrics

Primary order-certification targets are:

1. final Mn relative error;
2. final Mw relative error;
3. final dispersity relative error;
4. final-product W1 in log10(M), decades;
5. absolute tail-mass error above the frozen Stage-E MZCR-matrix M90 threshold;
6. absolute tail-mass error above the frozen Stage-E MZCR-matrix M99 threshold.

M50/M90/M99 quantile errors are exported only as reference-state diagnostics because Stage H does not certify their continuous-domain global extrema.

## Why the matrix no longer creates a passive-retention artifact

The full and reduced final products share exactly the same matrix distribution. Therefore

`F_final,5 - F_final,K = EPC * (F_stage,5 - F_stage,K)`

and consequently

`W1_final(5,K) = EPC * W1_stage(5,K)`.

Stage H therefore measures information lost by reducing the **second-stage population representation itself**. The broad matrix cannot create a false positive reduction-loss signal.

## Minimax bounds

For each partition and target:

- W1 and fixed-tail errors receive an **admissible pair-witness lower bound** and a **continuous-support Jensen-envelope upper bound**.
- Mw and dispersity use the exact endpoint-mixture maximum over the enlarged support. Because the relevant support endpoints are attained by population/alpha endpoints, this scalar bound is attainable for every multi-label group.
- Mn error is exactly zero by construction.

For order K,

`E_K^LB = min_partition lower_bound(partition)`

and

`E_K^UB = min_partition upper_bound(partition)`.

The true target-aware minimax error lies in `[E_K^LB, E_K^UB]`.

## Pre-specified tolerance bands

The following reporting bands are frozen before MATLAB execution. They are **not** experimental confidence limits or universal accuracy standards.

- W1: 0.01, 0.02, 0.05 decades;
- Mn/Mw/dispersity: 1%, 2.5%, 5% relative error;
- tail mass: 1, 2.5, 5 percentage points absolute mass fraction.

For each target/tolerance, Stage H reports

`K_projection_possible_lower <= K*_proj <= K_projection_certified_sufficient`.

A unique projection K* is claimed only when both bounds agree.

## Anti-cherry-picking rules

- all 52 partitions are evaluated;
- all three EPC fractions are retained;
- both transfer modes and all five primary T80 scenarios are retained;
- tolerance bands are fixed in `default_config.m` before execution;
- no partition may change with the uncertainty realization;
- quantile diagnostics cannot determine K*;
- executable PASS does not require a favorable target hierarchy.

## Independent precheck

The independent implementation predicts strong target dependence. In particular:

- Mn is lossless at K=1 by construction;
- the minimax Mw/dispersity error falls from roughly 31–61% at K=1 to roughly 0.65–2.41% at K=4 across EPC 10–30%;
- W1 at K=4 is tightly bracketed near 0.012–0.013, 0.024–0.026, and 0.0366–0.0385 decades for EPC 10, 20, and 30%, respectively;
- the W1-optimal partitions differ from the Mw-optimal partitions, which is the expected signature of target-aware representation complexity.

These are pre-execution references only. MATLAB must reproduce the independent table and pass H0–H13 before Stage H is qualified.

## Outputs

The launcher creates `JIEC_V3_STAGE_H_OUTPUTS.zip` containing:

- `StageH_all_partition_minimax_bounds.csv`
- `StageH_target_minimax_summary.csv`
- `StageH_target_order_map.csv`
- `StageH_pair_witnesses.csv`
- `StageH_support_bounds.csv`
- `StageH_reduction_invariants.csv`
- `StageH_reference_quantile_diagnostics.csv`
- `StageH_metric_scope.csv`
- `StageH_verification.csv`
- `STAGE_H_STATUS.txt`

## Claim scope

If qualified, Stage H may support a statement that the **minimum oracle-projection population resolution is target- and EPC-dependent within the prescribed uncertainty domain**. It does not establish chemical identities for the numerical populations, catalyst-general transferability, industrial validation, or a universal tolerance standard.


## v3.0.1 verification hotfix

The original v3.0 MATLAB scientific calculation completed, but H6 and H13 failed because the frozen pre-execution minimax/order mirror did not correspond to the final Stage-H equations and Stage-G uncertainty semantics. An independent reconstruction from the source populations reproduced all 300 pair witnesses, 300 continuous-support bounds, 156 partition bounds, 90 target/K minimax rows, and 54 order decisions to floating-point precision.

v3.0.1 changes **verification only**. It does not change the projection equations, uncertainty domain, 52 partitions, target metrics, tolerance bands, or scientific results. Verification is strengthened with low-level pair/support and partition mirrors before the summary/order checks.

See `Independent_Audit/STAGE_H_V301_INDEPENDENT_RECONSTRUCTION_AUDIT.txt`.
