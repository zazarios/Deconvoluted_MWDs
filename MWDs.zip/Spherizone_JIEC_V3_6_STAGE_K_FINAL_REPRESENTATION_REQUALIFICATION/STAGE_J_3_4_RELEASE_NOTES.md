# Release 3.4 — Stage J External Physical-Consistency Challenge

- Preserves the repaired v3.2.1 Stage-H.2 implementation and outputs unchanged as upstream evidence.
- Adds no fitted kinetic, sorption, or catalyst-specific parameter.
- Adds literature-held-out FBR-H2 challenge branches at no-added H2, 2 mol% H2 stress, and the legacy 5 mol% H2 comparator.
- Adds nested latent-chemistry stress domains with maximum odds spans 2, 4, 8, 16, and 32.
- Adds external stage/rubber-rich and matched-EPC bulk-C2 challenge tables from uploaded hiPP literature.
- Recomputes finite-ensemble composition singleton VOI over the expanded H2/T80 state and nested chemistry stress domains.
- Recomputes Stage-G joint W1 lower bounds over the union of the new H2/T80 branches.
- Explicitly reclassifies Stage-D.1/F composition claims if the frozen chemistry domain undercovers external hiPP evidence.
- Does not claim matched industrial validation and does not silently requalify Stage-H/H.1/H.2 order maps over the expanded H2/T80 set.

## Packaging hardening
- Preserves the repaired Stage-H.2 `default_config.m` byte-for-byte.
- Adds Stage-J-only `stageJ_config.m` rather than modifying upstream configuration.
- Stores qualified Stage-H.2 outputs under `inputs/StageH2QualifiedOutputs/` as immutable prerequisite evidence.
