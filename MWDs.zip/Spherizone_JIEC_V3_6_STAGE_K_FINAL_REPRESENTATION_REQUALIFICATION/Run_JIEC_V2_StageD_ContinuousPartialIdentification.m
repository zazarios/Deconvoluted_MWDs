% Run_JIEC_V2_StageD_ContinuousPartialIdentification.m
% One-button Stage-D continuous partial-identification and adversarial robustness audit.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageD');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.5 Stage D] Continuous partial-identification / adversarial robustness\n');
fprintf('Scientific specification: %s\n',cfg.spec_version);
fprintf('Release: %s\n',cfg.release);

% Re-run executable preflight V0-V8.
preflightDir=fullfile(outdir,'Preflight'); mkdir(preflightDir);
report=verify_all(cfg,preflightDir);
writetable(report,fullfile(outdir,'StageD_preflight_verification.csv'));
required=ismember(report.Gate,{'V0','V1','V2','V3','V4','V5','V6','V7','V8'});
preflightPass=all(strcmp(report.Status(required),'PASS'));
if ~preflightPass
    error('Stage-D preflight failed. Inspect StageD_preflight_verification.csv.');
end

% Stage-D exact-TV solver unit test.
tvtest=verify_stageD_tv_solver();
writetable(tvtest,fullfile(outdir,'StageD_TV_solver_unit_test.csv'));
if ~tvtest.Pass(1), error('Stage-D exact TV solver unit test failed.'); end

% Confirm Stage C had already passed with scope restrictions.
stageCStatus=fullfile(ROOT,'inputs','StageCOutputs','STAGE_C_STATUS.txt');
if ~exist(stageCStatus,'file'), error('Embedded Stage-C status file is missing.'); end
stageCText=fileread(stageCStatus);
if isempty(strfind(stageCText,'V9_PASS_WITH_SCOPE_RESTRICTIONS')) || ...
        isempty(strfind(stageCText,'GO_FOR_JIEC_RECONSTRUCTION_WITH_NARROW_STRUCTURAL_AND_IDENTIFIABILITY_CLAIMS')) %#ok<STREMP>
    error('Embedded Stage-C qualification is not the expected passed-with-restrictions state.');
end

verdict=run_stageD_continuous_partial_identification(cfg,outdir);
if ~verdict.RegressionPass
    error('Stage-D regression to Stage-B2 W0 evidence failed.');
end

fid=fopen(fullfile(outdir,'STAGE_D_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.5 Stage-D continuous partial-identification / adversarial robustness\n');
fprintf(fid,'Preflight V0-V8 pass: %d\n',preflightPass);
fprintf(fid,'Stage-D endpoint regression pass: %d\n',verdict.RegressionPass);
fprintf(fid,'Verdict: %s\n',verdict.code);
fprintf(fid,'%s\n',verdict.summary);
fprintf(fid,'Stage E remains locked until independent audit of Stage-D outputs.\n');
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_D_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageD'},ROOT);

fprintf('\n[JIEC v2.5 Stage D] COMPLETE\n');
fprintf('Verdict: %s\n',verdict.code);
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
