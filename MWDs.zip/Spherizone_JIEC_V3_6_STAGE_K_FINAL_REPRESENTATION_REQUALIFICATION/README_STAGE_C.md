# Spherizone JIEC v2.4 — Stage C (V9/V10)

## Purpose
Stage C does **not** add new fitted physics. It audits whether the surviving Stage-B2 findings are consistent with the available literature **within comparable scope**, and then freezes the exact manuscript claims that are supportable.

### V9 — external literature-consistency audit
V9 distinguishes:
- directly comparable directional checks;
- structural consistency checks;
- comparator-only evidence;
- limitations that must not be misrepresented as validation.

A literature result is **not** forced into a pass/fail comparison when the manipulated variable differs from the conditional variable in this reduced-order framework. In particular, Yang et al. (2026) varies FBR ethylene feed ratio through a detailed kinetic model, whereas the present framework conditions on second-stage EPC fraction. That comparison is therefore explicitly `NOT_DIRECTLY_COMPARABLE`.

### V10 — claim traceability
V10 writes:
- permitted claims;
- exact model evidence;
- external evidence/context;
- prohibited claims and reasons.

The intended final decision is either:
- `GO_FOR_JIEC_RECONSTRUCTION_WITH_NARROW_STRUCTURAL_AND_IDENTIFIABILITY_CLAIMS`, or
- `HOLD_BEFORE_MANUSCRIPT_RECONSTRUCTION`.

## Run
```matlab
Run_JIEC_V2_StageC_V9V10
```

Upload:
`Outputs_StageC/JIEC_V2_STAGE_C_OUTPUTS.zip`

## Binding interpretation
Stage C must **not** claim:
- industrial validation;
- a unique site-to-EPR/PE mapping;
- reliable 80 °C catalyst-population extrapolation;
- RTD robustness;
- first complete Spherizone ICP model;
- universally fewer assumptions than detailed kinetic models.

The defensible methodological comparison is a **reduction in site-specific kinetic-parameter estimation burden**, achieved by transferring experimentally resolved MWD-population information while explicitly exposing model-form uncertainty.

## Important V9 interpretation for hydrogen sensitivity
At 70 °C and Do/Ti=1.4, the Alshaiban-anchored population model predicts decreasing `Mn` and `Mw` with increasing H2, consistent with Yang et al. (2026), but **decreasing dispersity**, whereas Yang et al. report a slight dispersity increase for their industrial four-site catalyst/model. Stage C therefore records this as a **catalyst-dependent trend divergence**, not a validation failure and not a universal trend. The manuscript must not claim a universal H2→dispersity direction.
