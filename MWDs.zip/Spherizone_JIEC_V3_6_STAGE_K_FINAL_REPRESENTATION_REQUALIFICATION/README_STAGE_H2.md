# Stage H.2 — T80-global operational fixed-descriptor closure

## Scientific purpose
Stage H established target-dependent oracle projection order. Stage H.1 removed access to hidden within-group weights and population-specific DP alpha, but still allowed each fixed descriptor to depend on the selected T80 population-transfer branch.

Stage H.2 removes that remaining access. For each fixed population partition, target, EPC fraction, and declared transfer formulation, every group receives **one scalar Mn descriptor before the T80 branch, within-group weights, or DP alpha realization are known**.

This is the strongest fixed-scalar closure test in the H program. It asks whether population count alone can support a target when the retained model-form uncertainty is unresolved.

## What remains declared rather than latent
DIRECT_MN_TRANSFER and DP_REPEAT_MASS_CORRECTED remain alternative model formulations. H.2 does not force one descriptor set to serve both formulations. Similarly, descriptors remain target-specific and EPC-specific. H.2 does not claim one universal reduced model for all outputs.

## T80-global support
For every nonempty population group, the support is the set of all population Mn values across the five qualified T80 branches. Under DP repeat-mass correction, each population additionally retains the conservative alpha interval

`M_C2/M_C3 <= alpha_j <= 1`.

The scalar metrics used in H.2 attain their extrema at the global support endpoints, so W1, final Mn, final Mw, and fixed-threshold tail-mass minimax errors are exact for this fixed-scalar closure problem. Dispersity remains nonseparable and is reported as an admissible witness lower bound plus conservative signed-ratio upper bound.

## Reporting tolerances
Unchanged from Stage H/H.1:
- W1: 0.01, 0.02, 0.05 decades
- Mn/Mw/D: 1%, 2.5%, 5%
- fixed-threshold tail mass: 1, 2.5, 5 percentage points

These are pre-specified model-reduction reporting bands, not experimental confidence intervals or universal engineering acceptability criteria.

## Independent pre-execution expectation
The independent audit predicts that, at the MODERATE bands, no K<=5 provides T80-global fixed-scalar closure for final Mn, final Mw, dispersity, full-MWD W1, or tail mass above the matrix M90 threshold at EPC 10, 20, or 30 wt%. The very-far-tail matrix-M99 threshold remains target-specifically closable with K=1 at the moderate band.

Failure at K=5 is a scientific outcome, not an executable failure. It means that increasing population count cannot substitute for unresolved descriptor/state/model-form information.

## Interpretation if qualified
Stage H.2 should be interpreted together with H and H.1:
1. **H:** population resolution needed under optimistic oracle projection;
2. **H.1:** fixed-descriptor closure after removing hidden weight/alpha access, conditional on T80 branch;
3. **H.2:** fixed-descriptor closure before T80 model-form uncertainty is resolved.

The sequence separates representation resolution from latent-state and model-form closure. It does not establish industrial ICP validation, group-weight dynamics, population-specific chemistry identification, or one universal reduced model.


## v3.2.1 verification hotfix
See `STAGE_H2_3_2_1_RELEASE_NOTES.md`. Scientific calculations are unchanged.
