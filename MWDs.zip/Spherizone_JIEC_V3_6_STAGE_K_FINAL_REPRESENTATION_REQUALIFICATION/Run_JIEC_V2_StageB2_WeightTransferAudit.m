% Run_JIEC_V2_StageB2_WeightTransferAudit.m
% One-button Stage-B2 audit of unresolved second-stage population-weight transfer.
% Scientific reason: the Alshaiban w_j values are PP-derived polymer-population
% mass fractions. Zhang et al. (2021) demonstrates E/P-dependent active-center
% redistribution in another Ziegler-Natta catalyst, so direct transfer of w_j
% into the E/P stage must be stress-tested before V9/V10.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageB2');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.3 Stage B2] Population-weight transfer audit\n');
fprintf('Scientific specification: %s\n',cfg.spec_version);

% Re-run executable preflight V0-V8.
preflightDir=fullfile(outdir,'Preflight'); mkdir(preflightDir);
report=verify_all(cfg,preflightDir);
writetable(report,fullfile(outdir,'StageB2_preflight_verification.csv'));
required=ismember(report.Gate,{'V0','V1','V2','V3','V4','V5','V6','V7','V8'});
preflightPass=all(strcmp(report.Status(required),'PASS'));
if ~preflightPass
    error('Stage-B2 preflight failed. Inspect StageB2_preflight_verification.csv.');
end

verdict=run_stageB2_weight_transfer_audit(cfg,outdir);
if ~verdict.RegressionPass
    error('Stage-B2 W0 regression against Stage B1 failed.');
end

fid=fopen(fullfile(outdir,'STAGE_B2_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.3 Stage-B2 population-weight transfer audit\n');
fprintf(fid,'Preflight V0-V8 pass: %d\n',preflightPass);
fprintf(fid,'B1 regression pass: %d\n',verdict.RegressionPass);
fprintf(fid,'Verdict: %s\n',verdict.code);
fprintf(fid,'%s\n',verdict.summary);
fprintf(fid,'V9 external literature-trend audit and V10 claim traceability remain locked until independent Stage-B2 review.\n');
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_B2_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageB2'},ROOT);

fprintf('\n[JIEC v2.3 Stage B2] COMPLETE\n');
fprintf('Verdict: %s\n',verdict.code);
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
