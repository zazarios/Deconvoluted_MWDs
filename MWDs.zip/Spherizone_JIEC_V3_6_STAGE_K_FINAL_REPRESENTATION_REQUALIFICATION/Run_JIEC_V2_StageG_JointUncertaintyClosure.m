% Run_JIEC_V2_StageG_JointUncertaintyClosure.m
% One-button final joint-uncertainty structural-claim closure.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageG');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.9 Stage G] Joint-uncertainty structural-claim closure\n');
fprintf('Release: %s\n',cfg.release);
fprintf('No new physics or probability model is introduced.\n');
fprintf('Certifying simultaneous U_W x U_C full-MWD retention over the primary T80 envelope.\n');

result=run_stageG_joint_uncertainty_closure(cfg,outdir);
V=verify_stageG_joint_uncertainty_closure(cfg,outdir,result);
allPass=all(strcmp(V.Status,'PASS'));

c=result.Closure;
fid=fopen(fullfile(outdir,'STAGE_G_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.9 Stage-G joint-uncertainty structural-claim closure\n');
fprintf(fid,'All executable Stage-G gates pass: %d\n',allPass);
fprintf(fid,'Global certified joint W1 lower bound: %.12g decades.\n',c.Global_W1_certified_joint_lower_decades(1));
fprintf(fid,'Attainable vertex upper bound on the joint global minimum: %.12g decades.\n',c.Global_W1_attainable_vertex_upper_decades(1));
fprintf(fid,'Worst transfer mode: %s; EPC %.3f; T80 scenario: %s.\n',c.WorstTransferMode{1},c.WorstEPC_wtfrac(1),c.WorstTScenario{1});
fprintf(fid,'Interpretation: the bound is deterministic and conservative over an enlarged joint uncertainty superset, not a confidence interval.\n');
fprintf(fid,'Scope: structural full-MWD separation only; composition, grade-level Mn/Mw/D, quantile minima, and industrial validation are not jointly certified here.\n');
if allPass
    fprintf(fid,'Verdict: STAGE_G_JOINT_UNCERTAINTY_STRUCTURAL_CLAIM_CLOSURE_QUALIFIED__MODEL_DEVELOPMENT_FREEZE_CANDIDATE\n');
else
    fprintf(fid,'Verdict: STAGE_G_FAILED__DO_NOT_CLAIM_JOINT_STRUCTURAL_ROBUSTNESS\n');
end
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_G_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageG'},ROOT);
if ~allPass, error('Stage-G executable verification failed. Inspect StageG_verification.csv.'); end
fprintf('\n[JIEC v2.9 Stage G] COMPLETE\n');
fprintf('Verdict: STAGE_G_JOINT_UNCERTAINTY_STRUCTURAL_CLAIM_CLOSURE_QUALIFIED__MODEL_DEVELOPMENT_FREEZE_CANDIDATE\n');
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
