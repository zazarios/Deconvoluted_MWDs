# Release 3.4.1 — Stage J table-header compatibility hotfix

## Scope
This hotfix repairs a MATLAB `readtable` column-name compatibility failure encountered after the Stage-J scientific calculations had completed.

## Observed failure
MATLAB R2025b reported:
`Unrecognized table variable name 'Global_W1_certified_joint_lower_decades'`
when Stage J read the frozen Stage-G claim-closure CSV for the baseline-regression audit.

## Repair
- Added `core/stageJ_table_column.m`, which resolves a required column from current `VariableNames`, saved `VariableDescriptions`, or `matlab.lang.makeValidName`.
- Replaced direct dot-reference to the frozen Stage-G W1 column with the robust resolver.
- No scientific equations, uncertainty domains, external evidence, challenge scenarios, tolerances, Stage-G/H/H.1/H.2/I inputs, or expected results were changed.

## Evidence from failed v3.4 run
The failed run had already generated all main Stage-J scientific tables before entering the baseline-regression block. Those partial outputs matched the independent pre-MATLAB expectations for:
- chemistry-span coverage thresholds (8/16/32),
- composition ranges across H2 branches,
- joint W1 bounds, and
- positive structural-survival result with global union lower bound 0.197018411053648 decades.

## Required action
Run `Run_JIEC_V3_StageJ_ExternalPhysicalConsistencyChallenge.m` again from this v3.4.1 package and upload the resulting `JIEC_V3_STAGE_J_OUTPUTS.zip` for final qualification.
