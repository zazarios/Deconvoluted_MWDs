# Stage G — Joint-Uncertainty Structural-Claim Closure

## Purpose

Stage G is the planned final model-development test. It asks one narrow question:

> Does the full molecular-weight-distribution separation between the experimentally resolved multi-population representation and the phase-wise same-Mn Flory collapse remain bounded away from zero when the prescribed population-weight and latent-chemistry uncertainties act simultaneously, with the primary T80 population-transfer envelope retained?

No new physical parameter, kinetic law, sorption model, population identity, phase assignment, or probability distribution is introduced.

## Joint uncertainty domain

The exact Stage-D coordinates are enlarged conservatively.

- **Weight uncertainty U_W:** the maximal total-variation domain is the full active-population simplex.
- **Chemistry U_C, DIRECT_MN_TRANSFER:** chemistry changes composition but not population Mn; therefore MWD is chemistry-invariant.
- **Chemistry U_C, DP_REPEAT_MASS_CORRECTED:** every population repeat-mass scale satisfies

  `M2/M3 <= alpha_j <= 1`,

  where M2 = 28.05 and M3 = 42.08 g/mol. Stage G permits the alpha_j values to vary independently, which is a superset of the exact Stage-D chemistry manifold.
- **T80 transfer:** all five primary Stage-B/Stage-D T80 scenarios are retained: the 70 °C boundary hold plus four admissible empirical 10 °C slope stresses.

Stage G then enlarges the available reciprocal-Mn values to the enclosing continuous interval. A positive lower bound over this larger set is conservative for the exact joint uncertainty product.

## Jensen-gap formulation

For a Flory most-probable weight distribution,

`Q_M(s) = 1 - exp(-M s) (1 + M s)`, with `s = 1/Mn`.

For any second-stage population mixture,

- resolved CDF = `E[Q_M(S)]`,
- same-Mn collapsed CDF = `Q_M(E[S])`.

Therefore the second-stage resolved-minus-collapsed CDF is the Jensen gap

`h(M) = E[Q_M(S)] - Q_M(E[S])`.

`Q_M` is convex for `M s < 1` and concave for `M s > 1`. Stage G uses the exact lower convex and upper concave envelopes of this single-inflection function on the enclosing support interval to obtain pointwise bounds on h(M). These bounds are then combined with the fixed MZCR matrix CDF difference and integrated in log10(M) to obtain a certified Wasserstein-1 lower bound.

A finite-grid CDF compatibility pad of 1e-5 per CDF is retained from Stage E.1.

## Attainable upper bound on the global minimum

A one-population simplex vertex is an admissible weight state. For a one-population second stage, the resolved and same-Mn collapsed second-stage MWDs are identical, so the second-stage Jensen gap is exactly zero. Hence

`W1_global_min <= (1-EPC) * W1_matrix`.

Stage G reports both the certified lower bound and this attainable upper bound, giving a deterministic bracket on the unknown joint global minimum.

## Independent pre-execution mirror

The independent calculation predicts the worst certified joint lower bound at:

- transfer mode: `DP_REPEAT_MASS_CORRECTED`
- EPC = 0.30
- T80 scenario: `T80_empiricalSlope_55_0505_to_65_0505`
- W1 lower bound ≈ **0.197018411 decades**
- attainable vertex upper bound ≈ **0.214823035 decades**

Thus the expected worst-case bracket is approximately

`0.19702 <= W1_joint_min <= 0.21482 decades`.

These values are pre-execution references only. The MATLAB run must reproduce the independent mirror and pass every Stage-G gate before the result is qualified.

## Claim scope after qualification

If Stage G passes, the permitted structural statement is:

> Across a conservative joint uncertainty superset covering the prescribed population-weight redistribution, latent chemistry, and primary T80 transfer scenarios, the propagated multi-population MWD remains separated from the phase-wise same-Mn Flory collapse by a positive certified Wasserstein-1 lower bound.

Stage G does **not** establish:

- unique ICP composition or EPR/PE partitioning;
- unique EPC-grade Mn, Mw, or dispersity;
- continuous global lower bounds for M90, M99, or tail excess;
- industrial or pilot-plant validation;
- catalyst-general transferability outside the source-supported population representation.

Those restrictions remain governed by Stages C, E/E.1, and F.

## Outputs

Running the one-button launcher creates `JIEC_V2_STAGE_G_OUTPUTS.zip` containing:

- `StageG_joint_W1_bounds_by_T.csv`
- `StageG_joint_W1_bounds_summary.csv`
- `StageG_structural_claim_closure.csv`
- `StageG_metric_scope.csv`
- `StageG_numerical_diagnostics.csv`
- `StageG_verification.csv`
- `STAGE_G_STATUS.txt`
