clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(ROOT); addpath(fullfile(ROOT,'core')); addpath(fullfile(ROOT,'data')); addpath(fullfile(ROOT,'verify'));
outdir=fullfile(ROOT,'Outputs_StageC');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
verdict=run_stageC_v9v10(outdir);
fprintf('\n[Stage C] %s\n',verdict);
fprintf('[Stage C] Upload: %s\n',fullfile(outdir,'JIEC_V2_STAGE_C_OUTPUTS.zip'));
