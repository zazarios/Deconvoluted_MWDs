% Run_JIEC_V3_StageH2_T80GlobalOperationalClosure.m
clear;clc;ROOT=fileparts(mfilename('fullpath'));addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageH2');if exist(outdir,'dir'),rmdir(outdir,'s');end;mkdir(outdir);cfg=default_config();
fprintf('[JIEC v3.2.1 Stage H.2] T80-global operational fixed-descriptor closure audit\n');
fprintf('Release: %s\n',cfg.release);
fprintf('One target-specific group descriptor set is fixed before the T80 branch, hidden within-group weights, or population-specific DP alpha are known.\n');
result=run_stageH2_t80_global_operational_closure(cfg,outdir);V=verify_stageH2_t80_global_operational_closure(cfg,outdir,result);allPass=all(strcmp(V.Status,'PASS'));
O=result.OrderMap;Om=O(strcmp(O.ToleranceLabel,'MODERATE'),:);fid=fopen(fullfile(outdir,'STAGE_H2_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v3.2.1 Stage-H.2 T80-global operational fixed-descriptor closure audit\nAll executable Stage-H.2 gates pass: %d\n',allPass);
fprintf(fid,'Scientific scope: descriptors are fixed before T80 branch, hidden weights and DP alpha, conditional on target/EPC and the declared transfer formulation. No universal cross-target or cross-formulation reduced model is claimed.\n');
for r=1:height(Om)
 if isnan(Om.K_global_certified_sufficient(r)),ks='NO_K_LE_5';else,ks=sprintf('%d',Om.K_global_certified_sufficient(r));end
 fprintf(fid,'MODERATE | %s | EPC %.2f | certified T80-global fixed-scalar K = %s | %s\n',Om.Target{r},Om.EPC_wtfrac(r),ks,Om.GlobalClosureStatus{r});
end
if allPass,fprintf(fid,'Verdict: STAGE_H2_T80_GLOBAL_FIXED_DESCRIPTOR_CLOSURE_QUALIFIED__POPULATION_ORDER_AND_STATE_MODEL_FORM_CLOSURE_SEPARATED\n');else,fprintf(fid,'Verdict: STAGE_H2_FAILED__DO_NOT_USE_T80_GLOBAL_CLOSURE_CLAIMS\n');end
fclose(fid);
zipfile=fullfile(ROOT,'JIEC_V3_STAGE_H2_OUTPUTS.zip');if exist(zipfile,'file'),delete(zipfile);end;zip(zipfile,{'Outputs_StageH2'},ROOT);
if ~allPass,error('Stage-H.2 executable verification failed. Inspect StageH2_verification.csv.');end
fprintf('\n[JIEC v3.2.1 Stage H.2] COMPLETE\nUpload: %s\n',zipfile);
