% Run_JIEC_V2_StageB1_CoupledAudit.m
% One-button Stage-B1 coupled-property / identifiability audit.
% This stage refines Stage B after independent review:
%   (1) EX2 sorption anchor fixed to the actual 70 C conditioning temperature
%       and the documented propylene/propane validity ratio is enforced.
%   (2) gas-composition sorption is stress-only; source-motivated C3/C2
%       selectivity 4-5 defines the primary high-E/P sorption envelope.
%   (3) composition uncertainty is coupled back to MWD through an explicit
%       degree-of-polymerization (DP) transfer interpretation in addition to
%       direct-Mn transfer.
%   (4) RTD is labelled structurally inactive in fixed-EPC conditional mode,
%       not claimed as a demonstrated robustness result.
%   (5) verdict language distinguishes structural MWD broadening from
%       quantitative grade separation.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageB1');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.2 Stage B1] Coupled-property / identifiability audit\n');
fprintf('Scientific specification: %s\n',cfg.spec_version);
fprintf('Base release: %s\n',cfg.release);

% Re-run executable preflight V0-V8.
preflightDir=fullfile(outdir,'Preflight'); mkdir(preflightDir);
report=verify_all(cfg,preflightDir);
writetable(report,fullfile(outdir,'StageB1_preflight_verification.csv'));
required=ismember(report.Gate,{'V0','V1','V2','V3','V4','V5','V6','V7','V8'});
preflightPass=all(strcmp(report.Status(required),'PASS'));
if ~preflightPass
    error('Stage-B1 preflight failed. Inspect StageB1_preflight_verification.csv.');
end

verdict=run_stageB1_coupled_audit(cfg,outdir);

fid=fopen(fullfile(outdir,'STAGE_B1_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.2 Stage-B1 coupled-property / identifiability audit\n');
fprintf(fid,'Preflight V0-V8 pass: %d\n',preflightPass);
fprintf(fid,'Verdict: %s\n',verdict.code);
fprintf(fid,'%s\n',verdict.summary);
fprintf(fid,'V9 external literature-trend audit and V10 claim traceability remain subsequent gates.\n');
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_B1_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageB1'},ROOT);

fprintf('\n[JIEC v2.2 Stage B1] COMPLETE\n');
fprintf('Verdict: %s\n',verdict.code);
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
