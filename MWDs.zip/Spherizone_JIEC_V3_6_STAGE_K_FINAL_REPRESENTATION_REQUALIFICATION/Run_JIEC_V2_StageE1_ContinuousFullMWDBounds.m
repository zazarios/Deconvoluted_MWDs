% Run_JIEC_V2_StageE1_ContinuousFullMWDBounds.m
% One-button Stage-E.1 continuous full-MWD robustness-bound qualification.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageE1');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.7.1 Stage E.1] Continuous full-MWD retention bounds\n');
fprintf('Release: %s\n',cfg.release);

result=run_stageE1_continuous_full_mwd_bounds(cfg,outdir);
V=verify_stageE1_continuous_full_mwd_bounds(cfg,outdir,result);
allPass=all(strcmp(V.Status,'PASS'));

S=result.Summary;
minUW=min(S.W1_certified_lower_decades(strcmp(S.Coordinate,'U_W')));
minUC=min(S.W1_certified_lower_decades(strcmp(S.Coordinate,'U_C')));
fid=fopen(fullfile(outdir,'STAGE_E1_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.7.1 Stage-E.1 continuous full-MWD retention bounds\n');
fprintf(fid,'All executable Stage-E.1 gates pass: %d\n',allPass);
fprintf(fid,'Minimum certified U_W W1 lower bound: %.10g decades\n',minUW);
fprintf(fid,'Minimum certified U_C W1 lower bound: %.10g decades\n',minUC);
fprintf(fid,'Important scope: U_W and U_C are marginal uncertainty coordinates, matching Stage D; no joint U_W x U_C claim is made.\n');
fprintf(fid,'U_W uses the full population simplex, which contains every Stage-D TV ball up to delta_W=1.\n');
fprintf(fid,'DP U_C uses an independent repeat-mass scale box as a conservative superset of the exact Stage-D chemistry manifold.\n');
fprintf(fid,'Only W1 has a primary certified continuous lower bound; the JS floor is mathematically derived and loose. Quantile/tail values remain magnitude diagnostics.\n');
if allPass
    fprintf(fid,'Verdict: STAGE_E1_CONTINUOUS_FULL_MWD_BOUNDS_QUALIFIED__INDEPENDENT_MAGNITUDE_AUDIT_REQUIRED_BEFORE_STAGE_F\n');
else
    fprintf(fid,'Verdict: STAGE_E1_CONTINUOUS_FULL_MWD_BOUNDS_FAILED__DO_NOT_PROCEED\n');
end
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_E1_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageE1'},ROOT);

if ~allPass, error('Stage-E.1 executable verification failed. Inspect StageE1_verification.csv.'); end
fprintf('\n[JIEC v2.7.1 Stage E.1] COMPLETE\n');
fprintf('Verdict: STAGE_E1_CONTINUOUS_FULL_MWD_BOUNDS_QUALIFIED__INDEPENDENT_MAGNITUDE_AUDIT_REQUIRED_BEFORE_STAGE_F\n');
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
