function S = thermo_fbr_scenarios(gas)
%THERMO_FBR_SCENARIOS Explicit high-E/P sorbed-composition model-form scenarios.
% No high-E/P catalyst-specific equilibrium correlation is asserted.
% Selectivity stress cases use propylene/ethylene solubility ratios of 4 and 5,
% motivated by literature context; they are NOT fitted equilibrium constants.

x3=gas.C3H6; x2=gas.C2H4;
if x3<=0 || x2<=0, error('FBR sorption scenarios require positive C3 and C2.'); end
sels=[1 4 5]; names={'gas_composition_baseline','selectivity_C3_over_C2_4','selectivity_C3_over_C2_5'};
S=repmat(struct('name','','f1_sorbed',NaN,'selectivity',NaN,'status','model_form'),1,numel(sels));
for k=1:numel(sels)
    a=sels(k);
    S(k).name=names{k}; S(k).selectivity=a;
    S(k).f1_sorbed=(a*x3)/(a*x3+x2);
end
end
