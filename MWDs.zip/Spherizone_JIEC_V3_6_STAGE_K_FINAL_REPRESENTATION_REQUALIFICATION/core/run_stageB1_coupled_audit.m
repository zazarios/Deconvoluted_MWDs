function verdict = run_stageB1_coupled_audit(cfg,outdir)
%RUN_STAGEB1_COUPLED_AUDIT Refined audit after independent Stage-B review.
if ~exist(outdir,'dir'), mkdir(outdir); end

% A. Corrected 70 C EX2 source-domain anchor.
anchor=ex2_sorption_anchor_envelope_B1(cfg);
A=table(anchor.f1_min,anchor.f1_max,anchor.argmin(1),anchor.argmin(2),anchor.argmin(3),anchor.argmin(4),anchor.argmin(5),anchor.argmin(6), ...
    anchor.argmax(1),anchor.argmax(2),anchor.argmax(3),anchor.argmax(4),anchor.argmax(5),anchor.argmax(6), ...
    'VariableNames',{'f1_min','f1_max','min_T_C','min_xC2_reactive','min_PC3_bar','min_PC2_bar','min_Ppropane_bar','min_C3_in_C3_plus_propane', ...
    'max_T_C','max_xC2_reactive','max_PC3_bar','max_PC2_bar','max_Ppropane_bar','max_C3_in_C3_plus_propane'});
writetable(A,fullfile(outdir,'StageB1_EX2_sorption_anchor_70C.csv'));

primarySurface=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac, ...
    cfg.EX2.primary_r1_bounds,cfg.EX2.primary_r2_bounds,cfg.EX2.primary_n_r2,'PRIMARY_SCREEN_70C_ANCHOR');
expandedSurface=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac, ...
    [0.05 50],[0.05 50],401,'EXPANDED_STRESS_70C_ANCHOR');
writetable(primarySurface,fullfile(outdir,'StageB1_EX2_primary_feasible_surface.csv'));
writetable(expandedSurface,fullfile(outdir,'StageB1_EX2_expanded_stress_surface.csv'));

Lit=table({'Yang_Lei_Luo_2026';'Zhang_et_al_2025';'Tian_group_A_2013';'Tian_group_B_2013'}, ...
    [10;0.07441;4.30;37.0],[0.10;31.87;0.27;1.62], ...
    {'effective model exemplar; not transferred';'industrial fitted effective-model exemplar; not transferred'; ...
     'experimentally fitted group-A exemplar; different catalyst/process';'experimentally fitted group-B exemplar; different catalyst/process'}, ...
    'VariableNames',{'Source','r_propylene','r_ethylene','Role'});
writetable(Lit,fullfile(outdir,'StageB1_external_reactivity_ratio_exemplars.csv'));

% B. Model-form objects.
mz=run_normalized_mzcr_demo(cfg); matrix=mz.matrix;
Tall=population_T80_envelope(cfg.FBR.H2_psi,cfg.MZCR.DoTi);
Tprimary=selectT(Tall,cfg.StageB.primary_T_classes);
Tboundary=Tprimary(strcmp({Tprimary.name},'T80_boundary_hold_70C'));
sorb=thermo_fbr_scenarios(cfg.FBR.gas);
S4=sorb(strcmp({sorb.name},'selectivity_C3_over_C2_4'));
S5=sorb(strcmp({sorb.name},'selectivity_C3_over_C2_5'));
Sgas=sorb(strcmp({sorb.name},'gas_composition_baseline'));
Sprimary=[S4 S5];
resp=site_response_scenarios(5,cfg.site_response.odds_span);
C0=resp(strcmp({resp.name},'C0_homogeneous'));
EPC=cfg.StageB.primary_EPC;

% C. Layered composition-identifiability decomposition.
layers={ ...
    'L0_minimal_boundary_sel4_C0',Tboundary,S4,C0; ...
    'L1_add_sorption_sel4_sel5',Tboundary,Sprimary,C0; ...
    'L2_add_latent_chemistry',Tboundary,Sprimary,resp; ...
    'L3_add_temperature_model_form',Tprimary,Sprimary,resp; ...
    'L4_stress_add_gas_composition_baseline',Tprimary,[Sprimary Sgas],resp};
LR=cell(0,10);
for il=1:size(layers,1)
    lname=layers{il,1}; Ts=layers{il,2}; Ss=layers{il,3}; Cs=layers{il,4};
    [cmin,cmax]=composition_extrema(Ts,Ss,Cs,primarySurface);
    for ie=1:numel(EPC)
        LR(end+1,:)={lname,EPC(ie),cmin,cmax,EPC(ie)*cmin,EPC(ie)*cmax,NaN,NaN,false,false}; %#ok<AGROW>
    end
    idx=(size(LR,1)-numel(EPC)+1):size(LR,1);
    for j=1:numel(EPC)-1
        gap=LR{idx(j+1),5}-LR{idx(j),6};
        LR{idx(j),7}=gap; LR{idx(j),9}=gap>0;
    end
end
LayerT=cell2table(LR,'VariableNames',{'Layer','EPC_wtfrac','StageC2_min','StageC2_max','TotalC2_min','TotalC2_max','Gap_to_next_EPC','Unused','Separated_from_next_EPC','Unused2'});
LayerT.Unused=[]; LayerT.Unused2=[];
writetable(LayerT,fullfile(outdir,'StageB1_composition_barrier_layers.csv'));

% D. Coupled MWD-property envelope under the primary admissible ensemble.
% Primary sorption excludes the unsupported selectivity=1 gas-composition
% baseline; that baseline remains a stress layer above.
modes={'DIRECT_MN_TRANSFER','DP_REPEAT_MASS_CORRECTED'};
rows=cell(0,11);
structuralAll=true;
for im=1:numel(modes)
    mode=modes{im};
    mnmin=inf(1,numel(EPC)); mnmax=-inf(1,numel(EPC));
    mwmin=inf(1,numel(EPC)); mwmax=-inf(1,numel(EPC));
    dmin=inf(1,numel(EPC)); dmax=-inf(1,numel(EPC));
    mindeltaD=inf(1,numel(EPC));
    for it=1:numel(Tprimary)
        pop=Tprimary(it);
        for is=1:numel(Sprimary)
            for ic=1:numel(resp)
                P=stage_properties_vectorized_B1(pop,Sprimary(is).f1_sorbed,primarySurface.r1,primarySurface.r2,resp(ic),mode);
                for ie=1:numel(EPC)
                    e=EPC(ie);
                    Bmn=1./((1-e)/matrix.Mn_gmol + e./P.Mn_gmol);
                    Bmw=(1-e)*matrix.Mw_gmol + e.*P.Mw_gmol;
                    Bd=Bmw./Bmn;
                    % Same-final-Mn structural comparator: replace both matrix
                    % and second-stage population mixtures by single Flory MPDs.
                    Smw=(1-e)*(2*matrix.Mn_gmol) + e.*(2*P.Mn_gmol);
                    Sd=Smw./Bmn;
                    delta=Bd-Sd;
                    mnmin(ie)=min(mnmin(ie),min(Bmn)); mnmax(ie)=max(mnmax(ie),max(Bmn));
                    mwmin(ie)=min(mwmin(ie),min(Bmw)); mwmax(ie)=max(mwmax(ie),max(Bmw));
                    dmin(ie)=min(dmin(ie),min(Bd)); dmax(ie)=max(dmax(ie),max(Bd));
                    mindeltaD(ie)=min(mindeltaD(ie),min(delta));
                end
            end
        end
    end
    structuralAll=structuralAll && all(mindeltaD>0);
    for ie=1:numel(EPC)
        rows(end+1,:)={mode,EPC(ie),mnmin(ie),mnmax(ie),mwmin(ie),mwmax(ie),dmin(ie),dmax(ie),mindeltaD(ie),NaN,NaN}; %#ok<AGROW>
    end
    baseidx=(size(rows,1)-numel(EPC)+1):size(rows,1);
    for j=1:numel(EPC)-1
        gapMn=mnmax(j+1)-mnmin(j); % negative => separated decreasing envelopes
        gapMw=mwmax(j+1)-mwmin(j);
        rows{baseidx(j),10}=gapMn; rows{baseidx(j),11}=gapMw;
    end
end
MWD=cell2table(rows,'VariableNames',{'TransferMode','EPC_wtfrac','Mn_min','Mn_max','Mw_min','Mw_max','D_min','D_max','MinDeltaD_vs_sameMn_singleFlory','MnGap_to_next_EPC','MwGap_to_next_EPC'});
writetable(MWD,fullfile(outdir,'StageB1_coupled_MWD_envelopes.csv'));

% E. Explicit RTD scope statement: fixed EPC + no age-dependent kinetic law
% makes RTD structurally inactive. This is not presented as robustness.
RTD=table({'CSTR_N1';'TIS_N2';'TIS_N5';'PFR_limit'},[1;2;5;Inf],false(4,1), ...
    repmat("NOT_ACTIVE_IN_FIXED_EPC_CONDITIONAL_MODEL",4,1), ...
    repmat("No residence-time-dependent yield/chain-growth/deactivation law is identified; RTD cannot be tested quantitatively without adding kinetics. Literature comparison remains V9.",4,1), ...
    'VariableNames',{'RTDScenario','N_tanks','QuantitativelyEvaluated','Status','Reason'});
writetable(RTD,fullfile(outdir,'StageB1_RTD_scope.csv'));

% F. Compact verdict.
% Primary composition barrier is judged at L3 (source-motivated sorption 4-5,
% all latent chemistry and admissible T model-form cases), not by the
% selectivity=1 gas-composition stress case L4.
L3=LayerT(strcmp(LayerT.Layer,'L3_add_temperature_model_form'),:);
compSeparated=true;
for j=1:height(L3)-1
    if ~L3.Separated_from_next_EPC(j), compSeparated=false; end
end
% Quantitative MWD grade separation requires both Mn and Mw envelopes to be
% separated for both adjacent EPC changes in both transfer interpretations.
mwdSeparated=true;
for im=1:numel(modes)
    sub=MWD(strcmp(MWD.TransferMode,modes{im}),:);
    for j=1:height(sub)-1
        if ~(sub.MnGap_to_next_EPC(j)<0 && sub.MwGap_to_next_EPC(j)<0)
            mwdSeparated=false;
        end
    end
end
if structuralAll && ~compSeparated && ~mwdSeparated
    code='STRUCTURAL_MWD_HETEROGENEITY_ROBUST__QUANTITATIVE_GRADE_SEPARATION_PARTIAL__COMPOSITION_IDENTIFIABILITY_BARRIER';
    summary=['Proceed scientifically with a narrower claim: multisite structural broadening survives direct-Mn and DP-repeat-mass transfer interpretations, ' ...
        'but quantitative EPC-to-MWD grade separation is not uniformly resolved and total ethylene composition becomes non-identifiable once admissible sorption/site-response uncertainty is included.'];
elseif structuralAll && ~compSeparated && mwdSeparated
    code='STRUCTURAL_AND_QUANTITATIVE_MWD_SUPPORTED__COMPOSITION_IDENTIFIABILITY_BARRIER';
    summary='Proceed: structural and quantitative MWD separation survive, while composition remains non-identifiable.';
elseif structuralAll && compSeparated
    code='STRUCTURAL_MWD_AND_COMPOSITION_SEPARATION_SUPPORTED';
    summary='Proceed: structural MWD broadening and composition separation survive the refined primary ensemble.';
else
    code='STOP_OR_REPOSITION_STRUCTURAL_MWD_NOT_ROBUST';
    summary='Do not proceed with the proposed structural MWD claim; it fails under the coupled transfer audit.';
end
verdict=struct('code',code,'summary',summary,'StructuralBroadeningAllModes',structuralAll,'QuantitativeMWDSeparatedAll',mwdSeparated,'CompositionSeparatedL3',compSeparated, ...
    'EX2Anchor_f1_min',anchor.f1_min,'EX2Anchor_f1_max',anchor.f1_max);

fid=fopen(fullfile(outdir,'STAGE_B1_VERDICT.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.2 Stage-B1 refined verdict\n');
fprintf(fid,'Verdict: %s\n',code);
fprintf(fid,'%s\n',summary);
fprintf(fid,'Corrected EX2 70 C source-domain anchor f1: %.8f to %.8f\n',anchor.f1_min,anchor.f1_max);
fprintf(fid,'Structural multisite broadening positive in both transfer modes: %d\n',structuralAll);
fprintf(fid,'Quantitative Mn+Mw EPC envelope separation for all adjacent EPC levels and both transfer modes: %d\n',mwdSeparated);
fprintf(fid,'Total-C2 EPC envelope separation in refined primary L3 ensemble: %d\n',compSeparated);
fprintf(fid,'Gas-composition sorption baseline is stress-only, not part of the refined primary envelope.\n');
fprintf(fid,'RTD is not claimed as tested robustness because it is structurally inactive in fixed-EPC conditional mode.\n');
fprintf(fid,'All ranges are deterministic epistemic/model-form envelopes, not statistical confidence intervals.\n');
fclose(fid);
end

function Tsel=selectT(Tall,classes)
keep=false(1,numel(Tall));
for k=1:numel(Tall), keep(k)=any(strcmp(Tall(k).admissibility,classes)); end
Tsel=Tall(keep);
end

function [cmin,cmax]=composition_extrema(Ts,Ss,Cs,surf)
cmin=inf; cmax=-inf;
for it=1:numel(Ts)
    for is=1:numel(Ss)
        for ic=1:numel(Cs)
            c=stage_c2_vectorized(Ts(it),Ss(is).f1_sorbed,surf.r1,surf.r2,Cs(ic));
            cmin=min(cmin,min(c)); cmax=max(cmax,max(c));
        end
    end
end
end
