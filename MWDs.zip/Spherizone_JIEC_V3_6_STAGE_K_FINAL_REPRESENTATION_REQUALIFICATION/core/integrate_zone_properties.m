function out = integrate_zone_properties(zone, M_grid, varargin)
%INTEGRATE_ZONE_PROPERTIES Production-weighted axial MWD/composition integral.
% Optional Name/Value: 'r1','r2','composition_mode' ('none'|'gas_baseline').

p=inputParser; addParameter(p,'r1',NaN); addParameter(p,'r2',NaN); addParameter(p,'composition_mode','none'); parse(p,varargin{:});
r1=p.Results.r1; r2=p.Results.r2; mode=p.Results.composition_mode;
z=zone.z_m(:); q=zone.qpoly_gps_per_m(:);
if all(q<=0), error('No positive polymer-production weight in zone.'); end
M=M_grid(:)'; nx=numel(M); nz=numel(z);
G=zeros(nz,nx); c2wt=nan(nz,1);
for i=1:nz
    pop=population_transfer(zone.par.T_C,zone.H2_psi(i),zone.par.DoTi);
    mix=mix_flory_populations(pop.w,pop.Mn_gmol,M);
    G(i,:)=mix.dW_dlog10M;
    if strcmpi(mode,'gas_baseline')
        xr=zone.xC3(i)+zone.xC2(i);
        if xr<=0, error('No reactive monomer for composition calculation.'); end
        f1=zone.xC3(i)/xr;
        F1=mayo_lewis_propylene_fraction(f1,r1,r2);
        c2wt(i)=ethylene_weight_fraction(F1);
    end
end
mass=trapz(z,q);
Gcum=trapz(z,G.*q,1)/mass;
x=log10(M); Gcum=Gcum/trapz(x,Gcum);
Mn=1/trapz(x,Gcum./M); Mw=trapz(x,Gcum.*M);
out=struct('M_gmol',M,'dW_dlog10M',Gcum,'mass_rel',mass,'Mn_gmol',Mn,'Mw_gmol',Mw,'D',Mw/Mn);
if strcmpi(mode,'gas_baseline')
    out.C2_wtfrac=trapz(z,c2wt.*q)/mass;
    out.local_C2_wtfrac=c2wt;
else
    out.C2_wtfrac=NaN; out.local_C2_wtfrac=c2wt;
end
out.local_MWD=G;
end
