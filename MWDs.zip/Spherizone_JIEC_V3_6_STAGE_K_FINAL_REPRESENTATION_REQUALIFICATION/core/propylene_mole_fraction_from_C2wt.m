function F1 = propylene_mole_fraction_from_C2wt(wC2)
%PROPYLENE_MOLE_FRACTION_FROM_C2WT Inverse of ethylene_weight_fraction.
M3=42.08; M2=28.05;
if any(wC2<=0 | wC2>=1), error('wC2 must be between 0 and 1.'); end
F1 = M2.*(1-wC2) ./ (M2.*(1-wC2) + wC2.*M3);
end
