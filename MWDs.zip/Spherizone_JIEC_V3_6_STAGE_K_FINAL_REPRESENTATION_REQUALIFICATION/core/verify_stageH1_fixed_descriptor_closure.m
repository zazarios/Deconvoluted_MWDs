function V=verify_stageH1_fixed_descriptor_closure(cfg,outdir,result)
%VERIFY_STAGEH1_FIXED_DESCRIPTOR_CLOSURE Executable qualification gates.
ROOT=fileparts(fileparts(mfilename('fullpath')));Gate={};Status={};Detail={};
add('H1_0_STAGE_H_PREREQUISITE',gateH(),'Qualified Stage-H output is present.');
add('H1_1_PARTITION_AND_TARGET_COMPLETENESS',height(result.PartTable)==156 && height(result.Summary)==90 && height(result.OrderMap)==54,'Expected 52 partitions x 3 EPC; 6 targets x 3 EPC x 5 K; 54 tolerance rows.');
vars=result.Descriptors.Properties.VariableNames;
add('H1_2_NO_HIDDEN_STATE_DESCRIPTOR_INPUT',~any(ismember(vars,{'PopulationWeight','Alpha_j','HiddenWeights','HiddenAlpha'})) && all(strcmp(result.Descriptors.HiddenStateAccess,'NONE')),'Fixed descriptors contain no latent w_j or population-specific alpha_j input.');
% K=5 DIRECT singletons must be exact before DP chemistry uncertainty is admitted.
D=result.Descriptors; ix=D.K==5 & strcmp(D.TransferMode,'DIRECT_MN_TRANSFER');
add('H1_3_K5_DIRECT_IDENTITY',max(D.GroupUpper(ix))<1e-12,'All singleton DIRECT descriptors collapse to exact population Mn.');
% K=5 DP must retain a nonzero fixed-closure penalty because alpha is hidden.
ix=D.K==5 & strcmp(D.TransferMode,'DP_REPEAT_MASS_CORRECTED') & strcmp(D.Target,'FINAL_W1_LOG10M');
add('H1_4_HIDDEN_CHEMISTRY_PENALTY_EXPOSED',max(D.GroupUpper(ix))>1e-6,'A fixed scalar cannot remove the conservative DP alpha uncertainty even at K=5.');
[okG,detG]=mirrorGroupSupport();add('H1_5A_INDEPENDENT_GROUP_SUPPORT_MIRROR',okG,detG);
[okP,detP]=mirrorPartition();add('H1_5_INDEPENDENT_PARTITION_MIRROR',okP,detP);
[okS,detS]=mirrorSummary();add('H1_6_INDEPENDENT_MINIMAX_MIRROR',okS,detS);
add('H1_7_BOUND_ORDER',max(result.PartTable.DRel_lower-result.PartTable.DRel_upper)<=1e-12,'D witness lower bounds do not exceed conservative upper bounds.');
add('H1_8_MONOTONE_WITH_K',monotoneSummary(),'Best fixed-closure error is nonincreasing with K.');
[okO,detO]=mirrorOrder();add('H1_9_INDEPENDENT_ORDER_MAP_MIRROR',okO,detO);
% No-K states must stay NaN rather than being coerced to K=5.
O=result.OrderMap; no=contains(O.FixedClosureStatus,'NO_FIXED');
add('H1_10_NO_FORCED_K_WHEN_CLOSURE_FAILS',all(isnan(O.K_fixed_certified_sufficient(no))),'No failed fixed-scalar closure is silently relabeled K=5.');
G=result.GapTable;
add('H1_11_ORACLE_COMPARISON_EXPORTED',height(G)==54,'Stage-H moment-preserving oracle order and H.1 target-specific fixed order are compared without assuming either must dominate; a target-specific fixed descriptor may sacrifice other targets.');
q=strcmp(result.MetricScope.Metric,'FINAL_D_REL');
add('H1_12_D_SCOPE_GUARD',any(q) && contains(result.MetricScope.Status{find(q,1)},'CONSERVATIVE'),'D is explicitly bracketed rather than mislabeled exact.');
add('H1_13_OPERATIONAL_SCOPE_GUARD',true,'H.1 closes scalar group descriptors only; it does not claim a validated group-weight dynamic law or industrial deployment.');
q=strcmp(result.ClaimScope.Claim,'T80_GLOBAL_FIXED_DESCRIPTOR_CLOSURE');
add('H1_14_T80_BRANCH_SCOPE_GUARD',any(q) && strcmp(result.ClaimScope.ClaimStatus{find(q,1)},'NOT_ESTABLISHED'),'Descriptors are conditional on the declared T80 branch; one T80-global fixed descriptor is not established in H.1.');
V=table(Gate',Status',Detail','VariableNames',{'Gate','Status','Detail'});writetable(V,fullfile(outdir,'StageH1_verification.csv'));
 function add(n,ok,d),Gate{end+1}=n;if ok,Status{end+1}='PASS';else,Status{end+1}='FAIL';end;Detail{end+1}=d;end
 function ok=gateH()
  f=fullfile(ROOT,'inputs','StageHQualifiedOutputs','STAGE_H_STATUS.txt');ok=exist(f,'file')==2 && contains(fileread(f),'QUALIFIED');
 end

 function [ok,detail]=mirrorGroupSupport()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH1_expected_group_supports_v311.csv'));D=result.Descriptors;d=[];bad=0;
  for r=1:height(E)
   ix=strcmp(D.GroupCode,E.GroupCode{r}) & strcmp(D.TScenario,E.TScenario{r}) & strcmp(D.TransferMode,E.TransferMode{r});
   if ~any(ix),bad=bad+1;continue;end
   d(end+1)=max(abs(D.Support_Mlo_gmol(ix)-E.ExpectedSupport_Mlo_gmol(r))); %#ok<AGROW>
   d(end+1)=max(abs(D.Support_Mhi_gmol(ix)-E.ExpectedSupport_Mhi_gmol(r))); %#ok<AGROW>
  end
  md=max(d);ok=bad==0 && md<=cfg.StageH1.mirror_abs_tol;detail=sprintf('310 group/T/transfer supports; missing=%d; max independent discrepancy=%.6g g/mol',bad,md);
 end
 function [ok,detail]=mirrorPartition()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH1_expected_partition_bounds.csv'));P=result.PartTable;d=[];
  fields={{'MnRel_lower','MnRel_lower'},{'MnRel_upper','MnRel_upper'},{'MwRel_lower','MwRel_lower'},{'MwRel_upper','MwRel_upper'},{'DRel_lower','DRel_lower'},{'DRel_upper','DRel_upper'},{'W1_lower_decades','W1_lower_decades'},{'W1_upper_decades','W1_upper_decades'},{'Tail90_lower_abs','Tail90_lower_abs'},{'Tail90_upper_abs','Tail90_upper_abs'},{'Tail99_lower_abs','Tail99_lower_abs'},{'Tail99_upper_abs','Tail99_upper_abs'}};
  for r=1:height(E)
   ix=strcmp(P.PartitionCode,E.PartitionCode{r}) & P.K==E.K(r) & abs(P.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12;if sum(ix)~=1,d(end+1)=Inf;continue;end %#ok<AGROW>
   for k=1:numel(fields),d(end+1)=abs(P.(fields{k}{1})(ix)-E.(fields{k}{2})(r));end %#ok<AGROW>
  end
  md=max(d);ok=md<=cfg.StageH1.mirror_abs_tol;detail=sprintf('156 partition rows; max independent discrepancy=%.6g',md);
 end
 function [ok,detail]=mirrorSummary()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH1_expected_target_minimax_summary.csv'));S=result.Summary;d=[];bad=0;
  for r=1:height(E)
   ix=strcmp(S.Target,E.Target{r}) & abs(S.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12 & S.K==E.K(r);if sum(ix)~=1,bad=bad+1;continue;end
   d(end+1)=abs(S.MinimaxLower(ix)-E.ExpectedMinimaxLower(r));d(end+1)=abs(S.MinimaxUpper(ix)-E.ExpectedMinimaxUpper(r)); %#ok<AGROW>
  end
  md=max(d);ok=bad==0 && md<=cfg.StageH1.mirror_abs_tol;detail=sprintf('90 summary rows; mismatches=%d; max discrepancy=%.6g',bad,md);
 end
 function ok=monotoneSummary()
  S=result.Summary;ok=true;tg=unique(S.Target,'stable');ep=unique(S.EPC_wtfrac);
  for a=1:numel(tg),for b=1:numel(ep),ix=strcmp(S.Target,tg{a}) & abs(S.EPC_wtfrac-ep(b))<1e-12;X=S(ix,:);[~,o]=sort(X.K);X=X(o,:);ok=ok&&all(diff(X.MinimaxLower)<=1e-10)&&all(diff(X.MinimaxUpper)<=1e-10);end,end
 end
 function [ok,detail]=mirrorOrder()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH1_expected_target_order_map.csv'));O=result.OrderMap;bad=0;
  for r=1:height(E)
   ix=strcmp(O.Target,E.Target{r}) & abs(O.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12 & strcmp(O.ToleranceLabel,E.ToleranceLabel{r});if sum(ix)~=1,bad=bad+1;continue;end
   a=O.K_fixed_possible_lower(ix);b=E.Expected_K_fixed_possible_lower(r); if ~(isnan(a)&&isnan(b)) && a~=b,bad=bad+1;end
   a=O.K_fixed_certified_sufficient(ix);b=E.Expected_K_fixed_certified_sufficient(r); if ~(isnan(a)&&isnan(b)) && a~=b,bad=bad+1;end
   if ~strcmp(O.FixedClosureStatus{find(ix,1)},E.ExpectedStatus{r}),bad=bad+1;end
  end
  ok=bad==0;detail=sprintf('54 order rows; field/status mismatches=%d',bad);
 end
end
