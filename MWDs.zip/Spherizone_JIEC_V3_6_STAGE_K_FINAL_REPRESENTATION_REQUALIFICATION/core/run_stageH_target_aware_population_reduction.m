function result = run_stageH_target_aware_population_reduction(cfg,outdir)
%RUN_STAGEH_TARGET_AWARE_POPULATION_REDUCTION Certified target-aware reduction.
% The five experimentally resolved MWD populations are reduced through all 52
% set partitions. No partition may depend on the uncertainty realization.
if ~exist(outdir,'dir'), mkdir(outdir); end
ROOT=fileparts(fileparts(mfilename('fullpath')));
M=cfg.StageH.metric_M_grid(:)'; x=log10(M); %#ok<NASGU>
ctx=stageD1_build_context(cfg);
P=stageH_generate_partitions(5);
if numel(P)~=52, error('StageH:PartitionCount','Expected 52 five-label set partitions.'); end
modes=ctx.modes; ne=numel(cfg.StageH.EPC); nt=numel(ctx.Tp); nm=numel(modes);
if nt~=5, error('StageH:TScenarioCount','Stage H requires the five qualified Stage-G primary T80 scenarios.'); end

% High-resolution matrix moments frozen in Stage F.
Tm=readtable(fullfile(ROOT,'inputs','StageFQualifiedOutputs','StageF_matrix_moment_consistency.csv'));
matrixMn=Tm.StageF_Mn_gmol(1); matrixMw=Tm.StageF_Mw_gmol(1);
% Frozen tail thresholds from the qualified Stage-E MZCR matrix.
Te=readtable(fullfile(ROOT,'inputs','StageEQualifiedOutputs','StageE_source_to_MZCR_distribution_retention.csv'));
ir=find(strcmp(Te.State,'MZCR_MATRIX'),1); if isempty(ir), error('StageH:MatrixThreshold','MZCR matrix row missing.'); end
Mtail90=Te.M90_detailed_gmol(ir); Mtail99=Te.M99_detailed_gmol(ir);
a0=cfg.StageH.M2_gmol/cfg.StageH.M3_gmol;

% Pair-witness caches. Dimensions: T, mode, i, j [, EPC].
pW=zeros(nt,nm,5,5); pT90=zeros(nt,nm,5,5); pT99=zeros(nt,nm,5,5); pMw=zeros(nt,nm,5,5,ne);
PairRows=struct([]);
for it=1:nt
    Mn=ctx.Tp(it).Mn_gmol;
    for im=1:nm
        mode=modes{im};
        for i=1:4
            for j=i+1:5
                if strcmpi(mode,'DIRECT_MN_TRANSFER')
                    A=[1 1];
                else
                    A=[a0 a0; a0 1; 1 a0; 1 1];
                end
                bestW=-Inf;best90=-Inf;best99=-Inf;aw=[NaN NaN];a90=aw;a99=aw;tw=NaN;t90=NaN;t99=NaN;
                bestMw=-Inf(1,ne); amw=nan(ne,2); tmw=nan(1,ne);
                for ia=1:size(A,1)
                    ai=A(ia,1);aj=A(ia,2);s1=1/(ai*Mn(i));s2=1/(aj*Mn(j));
                    sh=stageH_pair_shape_witness(s1,s2,M,Mtail90,Mtail99,cfg);
                    if sh.StageW1_witness_decades>bestW, bestW=sh.StageW1_witness_decades;aw=A(ia,:);tw=sh.t_W1;end
                    if sh.StageTail90_witness_abs>best90,best90=sh.StageTail90_witness_abs;a90=A(ia,:);t90=sh.t_Tail90;end
                    if sh.StageTail99_witness_abs>best99,best99=sh.StageTail99_witness_abs;a99=A(ia,:);t99=sh.t_Tail99;end
                    for ie=1:ne
                        e=cfg.StageH.EPC(ie); [vv,tt]=stageH_max_pair_mw_rel(s1,s2,e,matrixMw,cfg);
                        if vv>bestMw(ie),bestMw(ie)=vv;amw(ie,:)=A(ia,:);tmw(ie)=tt;end
                    end
                end
                pW(it,im,i,j)=bestW;pT90(it,im,i,j)=best90;pT99(it,im,i,j)=best99;
                for ie=1:ne,pMw(it,im,i,j,ie)=bestMw(ie);end
                for ie=1:ne
                    e=cfg.StageH.EPC(ie);
                    rr=struct('TScenario',ctx.Tp(it).name,'TransferMode',mode,'Population_i',i,'Population_j',j,'EPC_wtfrac',e, ...
                        'W1_pair_witness_final_decades',e*bestW,'W1_alpha_i',aw(1),'W1_alpha_j',aw(2),'W1_t',tw, ...
                        'MwRel_pair_witness',bestMw(ie),'Mw_alpha_i',amw(ie,1),'Mw_alpha_j',amw(ie,2),'Mw_t',tmw(ie), ...
                        'Tail90_pair_witness_final_abs',e*best90,'Tail90_alpha_i',a90(1),'Tail90_alpha_j',a90(2),'Tail90_t',t90, ...
                        'Tail99_pair_witness_final_abs',e*best99,'Tail99_alpha_i',a99(1),'Tail99_alpha_j',a99(2),'Tail99_t',t99);
                    PairRows=append_H(PairRows,rr); %#ok<AGROW>
                end
            end
        end
    end
end
PairTable=struct2table(PairRows);writetable(PairTable,fullfile(outdir,'StageH_pair_witnesses.csv'));

% Continuous-support upper caches indexed by extreme labels i<j.
rW=zeros(nt,nm,5,5);rT90=zeros(nt,nm,5,5);rT99=zeros(nt,nm,5,5);rMw=zeros(nt,nm,5,5,ne);
RangeRows=struct([]);
for it=1:nt
    Mn=ctx.Tp(it).Mn_gmol;
    for im=1:nm
        mode=modes{im};
        for i=1:4
            for j=i+1:5
                members=[i j];
                for ie=1:ne
                    e=cfg.StageH.EPC(ie);
                    b=stageH_group_support_bounds(Mn,members,mode,e,matrixMw,M,Mtail90,Mtail99,cfg);
                    if ie==1
                        rW(it,im,i,j)=b.W1_upper_final_decades/e;
                        rT90(it,im,i,j)=b.Tail90_upper_final_abs/e;
                        rT99(it,im,i,j)=b.Tail99_upper_final_abs/e;
                    end
                    rMw(it,im,i,j,ie)=b.MwRel_exact;
                    rr=struct('TScenario',ctx.Tp(it).name,'TransferMode',mode,'ExtremePopulation_i',i,'ExtremePopulation_j',j, ...
                        'EPC_wtfrac',e,'W1_support_upper_final_decades',e*rW(it,im,i,j), ...
                        'MwRel_support_exact',b.MwRel_exact,'DRel_support_exact',b.DRel_exact, ...
                        'Tail90_support_upper_final_abs',e*rT90(it,im,i,j),'Tail99_support_upper_final_abs',e*rT99(it,im,i,j), ...
                        'ReciprocalMn_sLo',b.sLo,'ReciprocalMn_sHi',b.sHi,'Mw_t',b.t_Mw);
                    RangeRows=append_H(RangeRows,rr); %#ok<AGROW>
                end
            end
        end
    end
end
RangeTable=struct2table(RangeRows);writetable(RangeTable,fullfile(outdir,'StageH_support_bounds.csv'));

% Evaluate every partition. A partition is target-specific only after its
% minimax error has been computed across the entire uncertainty domain.
PartRows=struct([]); InvRows=struct([]);
for ip=1:numel(P)
    part=P(ip);
    for ie=1:ne
        e=cfg.StageH.EPC(ie);
        Wlb=0;Wub=0;Mwr=0;T90lb=0;T90ub=0;T99lb=0;T99ub=0;
        for it=1:nt
            for im=1:nm
                for ig=1:numel(part.Groups)
                    g=part.Groups{ig};
                    if numel(g)<=1, continue; end
                    gi=min(g);gj=max(g);
                    Wub=max(Wub,e*rW(it,im,gi,gj));
                    T90ub=max(T90ub,e*rT90(it,im,gi,gj));
                    T99ub=max(T99ub,e*rT99(it,im,gi,gj));
                    Mwr=max(Mwr,rMw(it,im,gi,gj,ie));
                    for pp=1:size(nchoosek(g,2),1) %#ok<FXSET>
                        prs=nchoosek(g,2); ii=prs(pp,1);jj=prs(pp,2);
                        Wlb=max(Wlb,e*pW(it,im,ii,jj));
                        T90lb=max(T90lb,e*pT90(it,im,ii,jj));
                        T99lb=max(T99lb,e*pT99(it,im,ii,jj));
                    end
                end
            end
        end
        Wub=max(Wub,Wlb);T90ub=max(T90ub,T90lb);T99ub=max(T99ub,T99lb);
        rr=struct('PartitionCode',part.Code,'K',part.K,'EPC_wtfrac',e, ...
            'MnRel_lower',0,'MnRel_upper',0,'MwRel_lower',Mwr,'MwRel_upper',Mwr,'DRel_lower',Mwr,'DRel_upper',Mwr, ...
            'W1_lower_decades',Wlb,'W1_upper_decades',Wub, ...
            'Tail90_lower_abs',T90lb,'Tail90_upper_abs',T90ub,'Tail99_lower_abs',T99lb,'Tail99_upper_abs',T99ub);
        PartRows=append_H(PartRows,rr); %#ok<AGROW>
    end
end
PartTable=struct2table(PartRows);writetable(PartTable,fullfile(outdir,'StageH_all_partition_minimax_bounds.csv'));

% Invariant audit at transparent reference states: every reduction preserves Mn.
for im=1:nm
    ref=stageE_reference_state(cfg,ctx,modes{im});
    for ip=1:numel(P)
        red=stageH_reduce_partition(ref.stage_w,ref.stage_Mn_population_gmol,P(ip).Groups);
        InvRows=append_H(InvRows,struct('TransferMode',modes{im},'PartitionCode',P(ip).Code,'K',P(ip).K, ...
            'Original_stage_Mn_gmol',red.Mn_original_gmol,'Reduced_stage_Mn_gmol',red.Mn_reduced_gmol, ...
            'Relative_difference',abs(red.Mn_reduced_gmol/red.Mn_original_gmol-1))); %#ok<AGROW>
    end
end
Inv=struct2table(InvRows);writetable(Inv,fullfile(outdir,'StageH_reduction_invariants.csv'));

% Minimax-optimal error bounds by K and target.
Targets={'FINAL_Mn_REL','FINAL_Mw_REL','FINAL_D_REL','FINAL_W1_LOG10M','TAIL_MASS_AT_MATRIX_M90_ABS','TAIL_MASS_AT_MATRIX_M99_ABS'};
Cols={{'MnRel_lower','MnRel_upper'},{'MwRel_lower','MwRel_upper'},{'DRel_lower','DRel_upper'}, ...
      {'W1_lower_decades','W1_upper_decades'},{'Tail90_lower_abs','Tail90_upper_abs'},{'Tail99_lower_abs','Tail99_upper_abs'}};
SumRows=struct([]);
for ie=1:ne
    e=cfg.StageH.EPC(ie);
    for iy=1:numel(Targets)
        for K=1:5
            ix=PartTable.K==K & abs(PartTable.EPC_wtfrac-e)<1e-12;
            lo=PartTable.(Cols{iy}{1})(ix);up=PartTable.(Cols{iy}{2})(ix);idx=find(ix);
            [vlo,il]=min(lo);[vup,iu]=min(up);
            rr=struct('Target',Targets{iy},'EPC_wtfrac',e,'K',K,'MinimaxLower',vlo,'MinimaxUpper',vup, ...
                'BestPartitionLower',PartTable.PartitionCode{idx(il)},'BestPartitionUpper',PartTable.PartitionCode{idx(iu)}, ...
                'BoundWidth',max(0,vup-vlo));
            SumRows=append_H(SumRows,rr); %#ok<AGROW>
        end
    end
end
Summary=struct2table(SumRows);writetable(Summary,fullfile(outdir,'StageH_target_minimax_summary.csv'));

% Pre-specified tolerance map and K* brackets.
OrderRows=struct([]);
for ie=1:ne
    e=cfg.StageH.EPC(ie);
    for iy=1:numel(Targets)
        [tols,labels,unit]=tolset_H(Targets{iy},cfg);
        for itol=1:numel(tols)
            tol=tols(itol); ix=strcmp(Summary.Target,Targets{iy}) & abs(Summary.EPC_wtfrac-e)<1e-12;
            S=Summary(ix,:);[~,ord]=sort(S.K);S=S(ord,:);
            kp=find(S.MinimaxLower<=tol+1e-15,1,'first'); ks=find(S.MinimaxUpper<=tol+1e-15,1,'first');
            if isempty(kp),kp=5;end;if isempty(ks),ks=5;end
            if kp==ks,status='CERTIFIED_UNIQUE_PROJECTION_KSTAR';else,status='PROJECTION_KSTAR_BRACKETED_BY_BOUNDS';end
            rr=struct('Target',Targets{iy},'EPC_wtfrac',e,'ToleranceLabel',labels{itol},'Tolerance',tol,'ToleranceUnit',unit, ...
                'K_projection_possible_lower',kp,'K_projection_certified_sufficient',ks,'ProjectionKstarStatus',status);
            OrderRows=append_H(OrderRows,rr); %#ok<AGROW>
        end
    end
end
OrderMap=struct2table(OrderRows);writetable(OrderMap,fullfile(outdir,'StageH_target_order_map.csv'));

% Reference-state quantile diagnostics for the W1-upper-optimal partition at each K.
% These are not used to select partitions or K* and are not continuous-domain bounds.
cfgM=cfg;cfgM.M_output_grid=M; mz=run_normalized_mzcr_demo(cfgM); matrix=mz.matrix;
QRows=struct([]);
for im=1:nm
    ref=stageE_reference_state(cfg,ctx,modes{im});
    fullStage=mix_flory_populations(ref.stage_w,ref.stage_Mn_population_gmol,M);
    for ie=1:ne
        e=cfg.StageH.EPC(ie);
        for K=1:5
            ix=strcmp(Summary.Target,'FINAL_W1_LOG10M') & abs(Summary.EPC_wtfrac-e)<1e-12 & Summary.K==K;
            code=Summary.BestPartitionUpper{find(ix,1)}; ip=find(strcmp({P.Code},code),1);
            red=stageH_reduce_partition(ref.stage_w,ref.stage_Mn_population_gmol,P(ip).Groups);
            redStage=mix_flory_populations(red.w,red.Mn_gmol,M);
            mp=matrix.dW_dlog10M(:)';mp=mp/trapz(log10(M),mp);
            pf=(1-e)*mp+e*fullStage.dW_dlog10M;pr=(1-e)*mp+e*redStage.dW_dlog10M;
            met=stageE_distribution_metrics(M,pf,pr);
            rr=struct('TransferMode',modes{im},'EPC_wtfrac',e,'K',K,'PartitionCode',code, ...
                'W1_reference_decades',met.W1_log10M_decades, ...
                'M50_full_gmol',met.M50_detailed,'M50_reduced_gmol',met.M50_collapsed,'M50_relative_error',abs(met.M50_collapsed/met.M50_detailed-1), ...
                'M90_full_gmol',met.M90_detailed,'M90_reduced_gmol',met.M90_collapsed,'M90_relative_error',abs(met.M90_collapsed/met.M90_detailed-1), ...
                'M99_full_gmol',met.M99_detailed,'M99_reduced_gmol',met.M99_collapsed,'M99_relative_error',abs(met.M99_collapsed/met.M99_detailed-1), ...
                'Scope','REFERENCE_DIAGNOSTIC_ONLY__NOT_A_CONTINUOUS_MINIMAX_BOUND');
            QRows=append_H(QRows,rr); %#ok<AGROW>
        end
    end
end
Qdiag=struct2table(QRows);writetable(Qdiag,fullfile(outdir,'StageH_reference_quantile_diagnostics.csv'));

% Metric/claim scope.
Metric={'FINAL_Mn_REL';'FINAL_Mw_REL';'FINAL_D_REL';'FINAL_W1_LOG10M';'TAIL_MASS_AT_MATRIX_M90_ABS';'TAIL_MASS_AT_MATRIX_M99_ABS';'M50_M90_M99_QUANTILES'};
Status={'EXACT_ZERO_BY_CONSTRUCTION';'EXACT_MINIMAX_WITHIN_ENLARGED_SUPPORT';'EXACT_MINIMAX_WITHIN_ENLARGED_SUPPORT'; ...
    'MINIMAX_BRACKET_WITNESS_TO_CERTIFIED_UPPER';'MINIMAX_BRACKET_WITNESS_TO_CERTIFIED_UPPER';'MINIMAX_BRACKET_WITNESS_TO_CERTIFIED_UPPER';'REFERENCE_DIAGNOSTIC_ONLY'};
Meaning={'All merges preserve total reciprocal-Mn exactly.';'Target-aware final-product Mw relative loss.';'Same relative loss as Mw because Mn is preserved.'; ...
    'Final-product W1 reduction loss; matrix cancels exactly and loss equals EPC times second-stage loss.'; ...
    'Absolute tail-mass error above frozen Stage-E MZCR-matrix M90 threshold.';'Absolute tail-mass error above frozen Stage-E MZCR-matrix M99 threshold.'; ...
    'Used for interpretability only; no continuous-domain K* claim.'};
Scope=table(Metric,Status,Meaning);writetable(Scope,fullfile(outdir,'StageH_metric_scope.csv'));

result=struct('Partitions',P,'PairTable',PairTable,'RangeTable',RangeTable,'PartTable',PartTable,'Summary',Summary,'OrderMap',OrderMap, ...
    'Invariants',Inv,'QuantileDiagnostics',Qdiag,'MetricScope',Scope,'matrixMn',matrixMn,'matrixMw',matrixMw,'Mtail90',Mtail90,'Mtail99',Mtail99,'ctx',ctx);
end

function A=append_H(A,r)
if isempty(A),A=r;return;end
if ~isequal(fieldnames(A),fieldnames(r)),error('StageH:StructSchemaMismatch','Stage-H record schema mismatch.');end
A(end+1)=r;
end

function [tols,labels,unit]=tolset_H(target,cfg)
labels=cfg.StageH.tolerance_labels;
if strcmp(target,'FINAL_W1_LOG10M')
    tols=cfg.StageH.W1_tolerances_decades;unit='decades';
elseif contains(target,'TAIL_MASS')
    tols=cfg.StageH.tail_mass_abs_tolerances;unit='absolute_mass_fraction';
else
    tols=cfg.StageH.scalar_rel_tolerances;unit='relative_fraction';
end
end
