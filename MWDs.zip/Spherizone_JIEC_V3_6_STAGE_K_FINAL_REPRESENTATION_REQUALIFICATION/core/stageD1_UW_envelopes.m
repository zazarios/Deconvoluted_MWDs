function B = stageD1_UW_envelopes(ctx,delta,transferMode,EPC)
%STAGED1_UW_ENVELOPES Exact U_W envelopes at one arbitrary TV radius.
% U_W is evaluated at homogeneous C0 latent chemistry exactly as in Stage D.
if delta<0 || delta>1, error('delta must lie in [0,1].'); end
EPC=EPC(:)'; ne=numel(EPC);
MnLo=inf(1,ne); MnHi=-inf(1,ne); MwLo=inf(1,ne); MwHi=-inf(1,ne);
C2Lo=inf(1,ne); C2Hi=-inf(1,ne);
for it=1:numel(ctx.Tp)
    pop=ctx.Tp(it); active=pop.w>0 & isfinite(pop.Mn_gmol);
    w0=pop.w(active); w0=w0/sum(w0);
    for is=1:numel(ctx.Sp)
        stC=stage_population_state(pop,ctx.Sp(is).f1_sorbed,ctx.surf.r1,ctx.surf.r2,ctx.C0,'DIRECT_MN_TRANSFER');
        [c2min,c2max]=tv_linear_bounds_curve(w0,stC.C2J(:,active),delta);
        for ie=1:ne
            e=EPC(ie);
            C2Lo(ie)=min(C2Lo(ie),e*min(c2min(:)));
            C2Hi(ie)=max(C2Hi(ie),e*max(c2max(:)));
        end
        st=stage_population_state(pop,ctx.Sp(is).f1_sorbed,ctx.surf.r1,ctx.surf.r2,ctx.C0,transferMode);
        MnJ=st.MnJ(:,active);
        if strcmpi(transferMode,'DIRECT_MN_TRANSFER'), MnJ=MnJ(1,:); end
        [invmin,invmax]=tv_linear_bounds_curve(w0,1./MnJ,delta);
        [mwmin,mwmax]=tv_linear_bounds_curve(w0,2.*MnJ,delta);
        for ie=1:ne
            e=EPC(ie);
            mnlo=1/((1-e)/ctx.matrix.Mn_gmol + e*max(invmax(:)));
            mnhi=1/((1-e)/ctx.matrix.Mn_gmol + e*min(invmin(:)));
            mwlo=(1-e)*ctx.matrix.Mw_gmol + e*min(mwmin(:));
            mwhi=(1-e)*ctx.matrix.Mw_gmol + e*max(mwmax(:));
            MnLo(ie)=min(MnLo(ie),mnlo); MnHi(ie)=max(MnHi(ie),mnhi);
            MwLo(ie)=min(MwLo(ie),mwlo); MwHi(ie)=max(MwHi(ie),mwhi);
        end
    end
end
B=struct('Mn_min',MnLo,'Mn_max',MnHi,'Mw_min',MwLo,'Mw_max',MwHi,'C2_min',C2Lo,'C2_max',C2Hi);
end
