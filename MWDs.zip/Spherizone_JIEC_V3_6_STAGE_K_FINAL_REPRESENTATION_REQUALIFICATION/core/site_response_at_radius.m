function S = site_response_at_radius(direction,rho,span)
%SITE_RESPONSE_AT_RADIUS Continuous chemistry-response amplitude.
% multiplier_j = exp(rho*log(span)*z_j), rho in [0,1].
if nargin<3, span=2; end
if rho<0 || rho>1, error('rho must lie in [0,1].'); end
if span<=1, error('span must exceed one.'); end
S=struct();
S.name=sprintf('%s_rho_%0.4f',direction.name,rho);
S.class=direction.class;
S.rho=rho;
S.ethylene_odds_multiplier=exp(rho*log(span).*direction.z(:)');
end
