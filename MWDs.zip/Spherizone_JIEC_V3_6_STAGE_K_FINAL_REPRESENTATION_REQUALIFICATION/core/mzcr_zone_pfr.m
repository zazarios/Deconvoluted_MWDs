function zone = mzcr_zone_pfr(par)
%MZCR_ZONE_PFR Generic unit-consistent PFR-zone gas-depletion diagnostic.
% Catalyst density is per BED volume. Therefore no additional (1-epsilon)
% factor appears in the source term.
%
% Required par fields: T_C,P_bar,DoTi,L_m,A_m2,u_g_m_s,rho_cat_bed_g_m3,
% Rp_sp_g_gcat_h,gas_in,mode ('homo'|'copolymer'),r1,r2,n_eval.

R=8.314462618; T_K=par.T_C+273.15; P_Pa=par.P_bar*1e5;
fields={'C3H6','C2H4','H2','C3H8'};
for k=1:numel(fields), if ~isfield(par.gas_in,fields{k}), error('Missing gas field.'); end, end
x=[par.gas_in.C3H6 par.gas_in.C2H4 par.gas_in.H2 par.gas_in.C3H8];
if abs(sum(x)-1)>1e-8, error('Gas inlet must sum to one.'); end
Ftot=par.u_g_m_s*par.A_m2*P_Pa/(R*T_K); % mol/s, ideal-gas diagnostic
F0=Ftot*x;
y0=[F0(1);F0(2);F0(3);0]; % C3,C2,H2, polymer mass flow generated g/s
if isfield(par,'RelTol'), relTol=par.RelTol; else, relTol=1e-8; end
if isfield(par,'AbsTol'), absTol=par.AbsTol; else, absTol=1e-11; end
opts=odeset('RelTol',relTol,'AbsTol',absTol,'NonNegative',1:3);
zspan=linspace(0,par.L_m,par.n_eval);
[z,y]=ode15s(@rhs,zspan,y0,opts);
zone=struct(); zone.z_m=z; zone.F_C3_mols=y(:,1); zone.F_C2_mols=y(:,2); zone.F_H2_mols=y(:,3);
zone.F_inert_mols=F0(4); zone.polymer_gps=y(:,4); zone.par=par;
zone.qpoly_gps_per_m=zeros(size(z));
zone.H2_psi=zeros(size(z)); zone.xC3=zeros(size(z)); zone.xC2=zeros(size(z)); zone.xH2=zeros(size(z)); zone.xInert=zeros(size(z));
for i=1:numel(z)
    [~,diag]=local_rates(y(i,1:3)',par,F0(4));
    zone.qpoly_gps_per_m(i)=diag.qpoly_gps_per_m;
    zone.H2_psi(i)=diag.H2_psi;
    zone.xC3(i)=diag.xC3; zone.xC2(i)=diag.xC2; zone.xH2(i)=diag.xH2; zone.xInert(i)=diag.xInert;
end
zone.gas_out=build_gas_struct(zone.xC3(end),zone.xC2(end),zone.xH2(end),zone.xInert(end));
zone.polymer_out_gps=zone.polymer_gps(end);
zone.mass_rel=trapz(zone.z_m,zone.qpoly_gps_per_m);

    function dy=rhs(~,yy)
        [rates,~]=local_rates(yy(1:3),par,F0(4));
        dy=[-rates.C3_mols_m; -rates.C2_mols_m; -rates.H2_mols_m; rates.qpoly_gps_m];
    end
end

function [rates,diag]=local_rates(Freact,par,Finert)
FC3=max(Freact(1),0); FC2=max(Freact(2),0); FH2=max(Freact(3),0);
Fsum=FC3+FC2+FH2+Finert;
x3=FC3/Fsum; x2=FC2/Fsum; xh=FH2/Fsum; xi=Finert/Fsum;
H2psi=xh*par.P_bar*14.5037738;
pop=population_transfer(par.T_C,H2psi,par.DoTi);
mix=mix_flory_populations(pop.w,pop.Mn_gmol,logspace(1,8,401));
Mn=mix.Mn_analytical_gmol;
Rp_bed_g_m3_h=par.Rp_sp_g_gcat_h*par.rho_cat_bed_g_m3;
qpoly=Rp_bed_g_m3_h*par.A_m2/3600; % g/s per m
if strcmpi(par.mode,'homo') || FC2<=0
    F1poly=1;
elseif strcmpi(par.mode,'copolymer')
    f1=x3/(x3+x2); % explicit gas-composition baseline for diagnostic
    F1poly=mayo_lewis_propylene_fraction(f1,par.r1,par.r2);
else
    error('Unknown par.mode.');
end
Mavg=F1poly*42.08 + (1-F1poly)*28.05; % g/mol repeat units
molmon=Rp_bed_g_m3_h/Mavg/3600; % mol/m3/s
RC3=F1poly*molmon; RC2=(1-F1poly)*molmon;
RH2=par.Rp_sp_g_gcat_h/Mn*par.rho_cat_bed_g_m3/3600; % mol/m3/s
rates=struct('C3_mols_m',RC3*par.A_m2,'C2_mols_m',RC2*par.A_m2, ...
    'H2_mols_m',RH2*par.A_m2,'qpoly_gps_m',qpoly);
diag=struct('qpoly_gps_per_m',qpoly,'H2_psi',H2psi,'xC3',x3,'xC2',x2,'xH2',xh,'xInert',xi,'F1poly',F1poly,'Mn_gmol',Mn);
end
