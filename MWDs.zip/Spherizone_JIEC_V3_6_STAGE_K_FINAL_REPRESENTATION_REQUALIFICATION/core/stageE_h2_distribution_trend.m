function T = stageE_h2_distribution_trend(cfg,M_grid)
%STAGEE_H2_DISTRIBUTION_TREND Source-supported 70 C H2 distribution-shift challenge.
% This uses only the bracketed Alshaiban population-transfer surface at
% Do/Ti=1.4. It is a qualitative external-trend challenge against Yang 2026,
% not numerical validation across catalysts.

H=cfg.StageE.H2_trend_psi(:)'; M=M_grid(:)'; x=log10(M);
rows=cell(numel(H),13);
for k=1:numel(H)
    pop=population_transfer(cfg.StageE.H2_trend_T_C,H(k),cfg.StageE.H2_trend_DoTi);
    mix=mix_flory_populations(pop.w,pop.Mn_gmol,M);
    ps=population_moments(pop);
    gc=flory_logweight_pdf(M,ps.Mn_gmol); gc=gc/trapz(x,gc);
    met=stageE_distribution_metrics(M,mix.dW_dlog10M,gc);
    rows(k,:)={H(k),ps.Mn_gmol,ps.Mw_gmol,ps.D,met.M10_detailed,met.M50_detailed,met.M90_detailed,met.M99_detailed, ...
        met.M90_over_M10_detailed,met.TailMassAboveCollapsedM90_detailed,met.W1_log10M_decades,met.JS_divergence_bits,pop.domain_flag};
end
T=cell2table(rows,'VariableNames',{'H2_psi','Mn_gmol','Mw_gmol','D','M10_gmol','M50_gmol','M90_gmol','M99_gmol', ...
    'M90_over_M10','TailMassAboveSameMnSingleFloryM90','W1_vs_sameMn_singleFlory_decades','JS_vs_sameMn_singleFlory_bits','DomainFlag'});
end
