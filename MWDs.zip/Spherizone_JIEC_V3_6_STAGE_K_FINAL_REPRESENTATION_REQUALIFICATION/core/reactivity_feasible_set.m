function T = reactivity_feasible_set(f1, target_C2_wtfrac, r1_bounds, r2_bounds, npts)
%REACTIVITY_FEASIBLE_SET Exact r1-r2 curve satisfying one composition constraint.
% No unique optimum is selected.

if nargin<5, npts=301; end
if f1<=0 || f1>=1, error('f1 must be in (0,1).'); end
Ftarget=propylene_mole_fraction_from_C2wt(target_C2_wtfrac);
r2=linspace(r2_bounds(1),r2_bounds(2),npts)';
q=1-f1;
num=f1*q*(1-2*Ftarget) - Ftarget.*r2.*q.^2;
den=f1^2*(Ftarget-1);
r1=num./den;
keep=isfinite(r1) & r1>=r1_bounds(1) & r1<=r1_bounds(2);
r1=r1(keep); r2=r2(keep);
Fcalc=mayo_lewis_propylene_fraction(f1,r1,r2);
C2=ethylene_weight_fraction(Fcalc);
T=table(r1,r2,C2,repmat(f1,numel(r1),1), ...
    'VariableNames',{'r1','r2','C2_wtfrac','f1_sorbed'});
end
