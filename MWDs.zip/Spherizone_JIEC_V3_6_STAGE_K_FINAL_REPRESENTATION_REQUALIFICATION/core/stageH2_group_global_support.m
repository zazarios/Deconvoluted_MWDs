function s = stageH2_group_global_support(ctx,members,mode,cfg)
%STAGEH2_GROUP_GLOBAL_SUPPORT T80-global population-Mn support for one group.
% The T80 branch is treated as unknown. DIRECT uses the five qualified T80
% population Mn values. DP_REPEAT_MASS_CORRECTED additionally retains the
% conservative population-specific repeat-mass scale alpha in [M2/M3,1].
a0=cfg.StageH2.M2_gmol/cfg.StageH2.M3_gmol;
vals=[]; tnames={}; pop=[];
for it=1:numel(ctx.Tp)
    Mn=ctx.Tp(it).Mn_gmol;
    for jj=members
        if strcmpi(mode,'DIRECT_MN_TRANSFER')
            vv=Mn(jj);
        elseif strcmpi(mode,'DP_REPEAT_MASS_CORRECTED')
            vv=[a0*Mn(jj),Mn(jj)];
        else
            error('StageH2:Mode','Unknown transfer mode %s.',mode);
        end
        vals=[vals vv]; %#ok<AGROW>
        for q=1:numel(vv)
            tnames{end+1}=ctx.Tp(it).name; %#ok<AGROW>
            pop(end+1)=jj; %#ok<AGROW>
        end
    end
end
[mlo,il]=min(vals);[mhi,ih]=max(vals);
s=struct('Mlo_gmol',mlo,'Mhi_gmol',mhi,'T_at_Mlo',tnames{il},'T_at_Mhi',tnames{ih}, ...
    'Population_at_Mlo',pop(il),'Population_at_Mhi',pop(ih),'AlphaMin',a0,'AlphaMax',1);
end
