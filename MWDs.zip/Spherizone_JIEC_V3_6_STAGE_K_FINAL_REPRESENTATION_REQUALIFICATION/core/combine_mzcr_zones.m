function out = combine_mzcr_zones(riser, downer)
%COMBINE_MZCR_ZONES Mass-weighted product combination of two solved zones.
if numel(riser.M_gmol)~=numel(downer.M_gmol) || any(abs(riser.M_gmol-downer.M_gmol)>0)
    error('Riser/downer M grids differ.');
end
mR=riser.mass_rel; mD=downer.mass_rel;
if mR<=0 || mD<=0, error('Both zone contributions must be positive.'); end
M=riser.M_gmol; G=(mR*riser.dW_dlog10M+mD*downer.dW_dlog10M)/(mR+mD);
x=log10(M); G=G/trapz(x,G);
Mn=1/trapz(x,G./M); Mw=trapz(x,G.*M);
out=struct('M_gmol',M,'dW_dlog10M',G,'mass_R_rel',mR,'mass_D_rel',mD, ...
    'riser_fraction',mR/(mR+mD),'downer_fraction',mD/(mR+mD),'Mn_gmol',Mn,'Mw_gmol',Mw,'D',Mw/Mn);
if isfinite(riser.C2_wtfrac) && isfinite(downer.C2_wtfrac)
    out.C2_wtfrac=(mR*riser.C2_wtfrac+mD*downer.C2_wtfrac)/(mR+mD);
else
    out.C2_wtfrac=NaN;
end
end
