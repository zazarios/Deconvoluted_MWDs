function out = ex2_sorption_anchor_envelope(cfg)
%EX2_SORPTION_ANCHOR_ENVELOPE Source-domain anchor for EX2 conditioning.
% The 5 mol%% EX2 recipe is outside the exact RCP correlation composition
% window. Therefore this function does NOT extrapolate the correlation to
% EX2. It scans only the documented correlation validity region and returns
% the corresponding sorbed propylene-fraction range as an epistemic anchor.
%
% Source domain used here (Kulajanpeng/Kulanjanpeng RCP correlations):
%   T = 70-85 C
%   reactive ethylene mole fraction = 0.08-0.09
%   ethylene partial pressure <= 10 bar
%   propylene partial pressure <= 20 bar
%
% This is an anchor envelope, not an EX2 sorption prediction.

A=cfg.EX2.anchor;
Ts=linspace(A.T_C(1),A.T_C(2),A.nT);
xs=linspace(A.xC2_reactive(1),A.xC2_reactive(2),A.nx);
P3s=linspace(A.PC3_bar(1),A.PC3_bar(2),A.nP);

fvals=[]; meta=[];
for i=1:numel(Ts)
    T_C=Ts(i); TK=T_C+273.15;
    for j=1:numel(xs)
        x2=xs(j); x3=1-x2;
        for k=1:numel(P3s)
            P3=P3s(k); P2=P3*x2/x3;
            if P2>10, continue; end
            C3=(0.00010875*TK^2 - 0.072807*TK + 12.0)*P3^2 + (-0.5656*TK + 233.3)*P3;
            C2=(-0.0010838*TK^2 + 0.76655*TK - 135.6)*P2^2 + (-2.9744*TK + 1099.1)*P2;
            if C3<=0 || C2<=0, continue; end
            f=C3/(C3+C2);
            fvals(end+1,1)=f; %#ok<AGROW>
            meta(end+1,:)=[T_C,x2,P3,P2,C3,C2,f]; %#ok<AGROW>
        end
    end
end
if isempty(fvals), error('No valid points found in EX2 anchor scan.'); end
[fmin,imin]=min(fvals); [fmax,imax]=max(fvals);
out=struct();
out.f1_min=fmin; out.f1_max=fmax;
out.f1_grid=linspace(fmin,fmax,A.n_f1)';
out.argmin=meta(imin,:); out.argmax=meta(imax,:);
out.scan_table=array2table(meta,'VariableNames',{'T_C','xC2_reactive','PC3_bar','PC2_bar','C3_corr','C2_corr','f1_sorbed'});
out.note=['Source-domain anchor only. The 5 mol% EX2 condition is not evaluated ' ...
    'with the simple RCP correlations because it lies outside their stated ' ...
    'reactive-composition window.'];
end
