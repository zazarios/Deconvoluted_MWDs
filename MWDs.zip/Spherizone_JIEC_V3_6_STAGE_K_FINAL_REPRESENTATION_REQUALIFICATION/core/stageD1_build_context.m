function ctx = stageD1_build_context(cfg)
%STAGED1_BUILD_CONTEXT Rebuild the exact Stage-D deterministic context.
% No Stage-D physical or epistemic assumptions are changed.
anchor=ex2_sorption_anchor_envelope_B1(cfg);
surf=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac, ...
    cfg.EX2.primary_r1_bounds,cfg.EX2.primary_r2_bounds,cfg.EX2.primary_n_r2,'PRIMARY_SCREEN_70C_ANCHOR');
mz=run_normalized_mzcr_demo(cfg);
Tall=population_T80_envelope(cfg.FBR.H2_psi,cfg.MZCR.DoTi);
keepT=false(1,numel(Tall));
for k=1:numel(Tall), keepT(k)=any(strcmp(Tall(k).admissibility,cfg.StageB.primary_T_classes)); end
Tp=Tall(keepT);
sorbAll=thermo_fbr_scenarios(cfg.FBR.gas);
keepS=false(1,numel(sorbAll));
for k=1:numel(sorbAll), keepS(k)=any(strcmp(sorbAll(k).name,cfg.StageD.primary_sorption_names)); end
Sp=sorbAll(keepS);
if numel(Sp)~=numel(cfg.StageD.primary_sorption_names), error('Stage-D.1 primary sorption scenario mismatch.'); end
Cend=site_response_scenarios(5,cfg.site_response.odds_span);
C0=Cend(strcmp({Cend.name},'C0_homogeneous'));
if numel(C0)~=1, error('C0 homogeneous chemistry scenario is missing.'); end
ctx=struct('anchor',anchor,'surf',surf,'matrix',mz.matrix,'Tp',Tp,'Sp',Sp,'C0',C0, ...
    'Dirs',continuous_chemistry_directions(5),'EPC',cfg.StageB.primary_EPC, ...
    'modes',{{'DIRECT_MN_TRANSFER','DP_REPEAT_MASS_CORRECTED'}});
end
