function out = ex2_sorption_anchor_envelope_B1(cfg)
%EX2_SORPTION_ANCHOR_ENVELOPE_B1 Source-domain EX2 sorption anchor at 70 C.
% The EX2 recipe itself lies outside the documented 8-9 mol% reactive-C2
% correlation window, so this remains an epistemic source-domain anchor,
% not a prediction at the EX2 recipe.
%
% Unlike Stage B, this audit does not scan 70-85 C because EX2 conditioning
% occurs at 70 C. It also explicitly enforces the documented propylene /
% propane ratio of 77:23 to 80:20 for use of the propylene correlation.
A=cfg.EX2.anchor;
T_C=cfg.EX1.T_C; % EX2 retained at the same 70 C matrix-stage temperature.
TK=T_C+273.15;
xs=linspace(A.xC2_reactive(1),A.xC2_reactive(2),A.nx);
P3s=linspace(A.PC3_bar(1),A.PC3_bar(2),A.nP);
ratios=linspace(0.77,0.80,4); % xC3/(xC3+xC3H8)

fvals=[]; meta=[];
for jr=1:numel(ratios)
    r3=ratios(jr);
    for j=1:numel(xs)
        x2=xs(j); x3=1-x2;
        for k=1:numel(P3s)
            P3=P3s(k);
            Ppropane=P3*(1-r3)/r3;
            if Ppropane>10, continue; end
            P2=P3*x2/x3;
            if P2>10, continue; end
            C3=(0.00010875*TK^2 - 0.072807*TK + 12.0)*P3^2 + (-0.5656*TK + 233.3)*P3;
            C2=(-0.0010838*TK^2 + 0.76655*TK - 135.6)*P2^2 + (-2.9744*TK + 1099.1)*P2;
            if C3<=0 || C2<=0, continue; end
            f=C3/(C3+C2);
            fvals(end+1,1)=f; %#ok<AGROW>
            meta(end+1,:)=[T_C,x2,P3,P2,Ppropane,r3,C3,C2,f]; %#ok<AGROW>
        end
    end
end
if isempty(fvals), error('No valid points found in corrected EX2 anchor scan.'); end
[fmin,imin]=min(fvals); [fmax,imax]=max(fvals);
out=struct();
out.f1_min=fmin; out.f1_max=fmax;
out.f1_grid=linspace(fmin,fmax,A.n_f1)';
out.argmin=meta(imin,:); out.argmax=meta(imax,:);
out.scan_table=array2table(meta,'VariableNames',{'T_C','xC2_reactive','PC3_bar','PC2_bar','Ppropane_bar','C3_in_C3_plus_propane','C3_corr','C2_corr','f1_sorbed'});
out.note=['Source-domain anchor at 70 C only; propylene/propane validity ratio explicitly enforced. ' ...
    'The 5 mol% EX2 recipe is not evaluated with the low-C2 correlation.'];
end
