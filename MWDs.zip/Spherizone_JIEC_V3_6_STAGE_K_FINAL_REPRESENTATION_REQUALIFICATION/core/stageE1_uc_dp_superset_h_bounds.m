function B = stageE1_uc_dp_superset_h_bounds(M_gmol,w,Mn_population_gmol,alphaMin,cdfPad)
%STAGEE1_UC_DP_SUPERSET_H_BOUNDS Conservative U_C pointwise bounds.
% Exact DP repeat-mass scaling satisfies alpha_j in [M2/M3,1]. E.1 allows
% each alpha_j to vary independently over that interval, a strict superset
% of the Stage-D chemistry manifold. Therefore the resulting W1 lower bound
% is conservative for every exact U_C realization.
M=M_gmol(:)'; w=w(:)'; Mn=Mn_population_gmol(:)';
active=w>0 & isfinite(Mn) & Mn>0; w=w(active); Mn=Mn(active); w=w/sum(w);
if ~(alphaMin>0 && alphaMin<=1), error('StageE1:AlphaRange','Invalid alphaMin.'); end
Lmin=zeros(size(M)); Lmax=zeros(size(M));
for j=1:numel(w)
    Lmin=Lmin+w(j).*stageE1_flory_weight_cdf_exact(M,Mn(j));
    Lmax=Lmax+w(j).*stageE1_flory_weight_cdf_exact(M,alphaMin*Mn(j));
end
Mn0=1/sum(w./Mn);
Qmin=stageE1_flory_weight_cdf_exact(M,Mn0);
Qmax=stageE1_flory_weight_cdf_exact(M,alphaMin*Mn0);
numPad=2*cdfPad;
hmin=Lmin-Qmax-numPad;
hmax=Lmax-Qmin+numPad;
hmin=max(-1,hmin); hmax=min(1,hmax);
B=struct('hmin',hmin,'hmax',hmax,'alpha_min',alphaMin,'Mn_inherited_gmol',Mn0, ...
    'cdf_pad_total',numPad);
end
