function [ByT,Summary,Closure] = stageJ_joint_w1_H2_challenge(cfg,Tset)
%STAGEJ_JOINT_W1_H2_CHALLENGE Re-evaluate Stage-G W1 closure over H2 branches.
% The Stage-G chemistry support is retained unchanged: under DP transfer it
% already uses the full independent repeat-mass scale interval M2/M3..1, so
% high-E/P composition widening cannot enlarge that physical repeat-mass bound.

M=cfg.StageE.metric_M_grid(:)'; x=log10(M); xdiam=x(end)-x(1);
cfgH=cfg; cfgH.M_output_grid=M;
mz=run_normalized_mzcr_demo(cfgH); matrix=mz.matrix;
MC=stageE1_matrix_cdf_difference(matrix,M);
a0=cfg.StageG.M2_gmol/cfg.StageG.M3_gmol;
modes={'DIRECT_MN_TRANSFER','DP_REPEAT_MASS_CORRECTED'};
Rows=struct([]);
for it=1:numel(Tset)
    pop=Tset(it); active=pop.w>0 & isfinite(pop.Mn_gmol) & pop.Mn_gmol>0;
    if ~any(active), error('StageJ:NoActivePopulations','No active T80 populations.'); end
    Mn=pop.Mn_gmol(active); sLo=min(1./Mn);
    for im=1:numel(modes)
        mode=modes{im};
        if strcmp(mode,'DIRECT_MN_TRANSFER')
            sHi=max(1./Mn); alphaMin=1;
        else
            sHi=max(1./(a0.*Mn)); alphaMin=a0;
        end
        HB=stageG_jensen_support_bounds(M,sLo,sHi,cfg.StageG.finite_grid_cdf_pad,cfg.StageG.root_tol,cfg.StageG.max_bisection_iter);
        for ie=1:numel(cfg.StageJ.EPC)
            e=cfg.StageJ.EPC(ie);
            W=stageE1_w1_lower_from_h_bounds(M,MC.A,HB.hmin,HB.hmax,e);
            rr=struct(); rr.H2Branch=pop.H2Branch; rr.H2Role=pop.H2Role; rr.H2_molfrac=pop.H2_molfrac; rr.H2_psi=pop.H2_psi;
            rr.TransferMode=mode; rr.EPC_wtfrac=e; rr.TScenario=pop.name; rr.TBaseScenario=pop.base_name; rr.TAdmissibility=pop.admissibility;
            rr.W1_certified_joint_lower_decades=W.W1_lower_decades;
            rr.W1_attainable_vertex_upper_decades=(1-e)*MC.W1_decades;
            rr.W1_joint_min_bracket_width_decades=rr.W1_attainable_vertex_upper_decades-rr.W1_certified_joint_lower_decades;
            rr.JS_certified_joint_lower_bits=stageE1_js_lower_from_w1(W.W1_lower_decades,xdiam);
            rr.ReciprocalMnSupport_min_per_gmol=sLo; rr.ReciprocalMnSupport_max_per_gmol=sHi;
            rr.Alpha_min=alphaMin; rr.Alpha_max=1; rr.CDF_pad_total=HB.cdf_pad_total;
            Rows=appendJ(Rows,rr); %#ok<AGROW>
        end
    end
end
ByT=struct2table(Rows);

branches=unique(ByT.H2Branch,'stable'); scopes=[branches; {'UNION_ALL_H2_BRANCHES'}];
S=struct([]);
for ib=1:numel(scopes)
    scope=scopes{ib};
    for im=1:numel(modes)
        for ie=1:numel(cfg.StageJ.EPC)
            e=cfg.StageJ.EPC(ie);
            if strcmp(scope,'UNION_ALL_H2_BRANCHES')
                ix=strcmp(ByT.TransferMode,modes{im}) & abs(ByT.EPC_wtfrac-e)<1e-12;
            else
                ix=strcmp(ByT.H2Branch,scope) & strcmp(ByT.TransferMode,modes{im}) & abs(ByT.EPC_wtfrac-e)<1e-12;
            end
            [lo,kr]=min(ByT.W1_certified_joint_lower_decades(ix)); ids=find(ix); k=ids(kr);
            up=min(ByT.W1_attainable_vertex_upper_decades(ix));
            rr=struct('H2BranchScope',scope,'TransferMode',modes{im},'EPC_wtfrac',e, ...
                'W1_certified_joint_lower_decades',lo,'W1_attainable_vertex_upper_decades',up, ...
                'W1_joint_min_bracket_width_decades',up-lo,'JS_certified_joint_lower_bits',stageE1_js_lower_from_w1(lo,xdiam), ...
                'WorstTScenario',ByT.TScenario{k},'WorstH2Branch',ByT.H2Branch{k},'WorstH2_molfrac',ByT.H2_molfrac(k));
            S=appendJ(S,rr); %#ok<AGROW>
        end
    end
end
Summary=struct2table(S);

C=cell(0,8);
for ib=1:numel(scopes)
    scope=scopes{ib}; q=strcmp(Summary.H2BranchScope,scope);
    [lo,krel]=min(Summary.W1_certified_joint_lower_decades(q)); ids=find(q); k=ids(krel);
    up=Summary.W1_attainable_vertex_upper_decades(k);
    if lo>cfg.StageJ.w1_positive_tol, status='CERTIFIED_POSITIVE_STRUCTURAL_SEPARATION'; else, status='STRUCTURAL_SEPARATION_NOT_CERTIFIED_POSITIVE'; end
    C(end+1,:)={scope,lo,up,up-lo,Summary.TransferMode{k},Summary.EPC_wtfrac(k),Summary.WorstTScenario{k},status}; %#ok<AGROW>
end
Closure=cell2table(C,'VariableNames',{'H2BranchScope','Global_W1_certified_joint_lower_decades','Global_W1_attainable_vertex_upper_decades', ...
    'Global_bracket_width_decades','WorstTransferMode','WorstEPC_wtfrac','WorstTScenario','StructuralStatus'});
end

function A=appendJ(A,r)
if isempty(A), A=r; return; end
if ~isequal(fieldnames(A),fieldnames(r)), error('StageJ:StructSchemaMismatch','Stage-J record schema mismatch.'); end
A(end+1)=r;
end
