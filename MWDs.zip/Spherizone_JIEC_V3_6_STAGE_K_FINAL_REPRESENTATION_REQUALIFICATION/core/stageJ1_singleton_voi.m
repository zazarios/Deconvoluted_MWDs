function T = stageJ1_singleton_voi(A,blockNames,label)
%STAGEJ1_SINGLETON_VOI Deterministic singleton oracle contractions.
nb=numel(blockNames); sz=size(A); if numel(sz)<nb, sz(end+1:nb)=1; end
if numel(sz)~=nb, error('StageJ1:TensorDimensionMismatch','One tensor dimension per block is required.'); end
base=max(A(:))-min(A(:)); rows=cell(nb,9);
for d=1:nb
 perm=[d setdiff(1:nb,d,'stable')]; B=permute(A,perm); B=reshape(B,[sz(d) prod(sz(setdiff(1:nb,d,'stable')))]);
 widths=max(B,[],2)-min(B,[],2); worst=max(widths); best=min(widths);
 if base>0, g=1-worst/base; gb=1-best/base; else, g=NaN; gb=NaN; end
 rows(d,:)={label,blockNames{d},d,base,worst,best,g,gb,sz(d)};
end
T=cell2table(rows,'VariableNames',{'Domain','ResolvedBlock','BlockIndex','BaselineWidth','WorstResidualWidth','BestResidualWidth','GuaranteedContractionFraction','BestCaseContractionFraction','BlockStateCount'});
end
