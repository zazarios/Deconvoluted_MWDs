function V = verify_stageJ_external_physical_consistency(cfg,outdir,result)
%VERIFY_STAGEJ_EXTERNAL_PHYSICAL_CONSISTENCY Executable Stage-J qualification.
% Scientific challenge failure is an admissible outcome. Gates test integrity,
% scope, and arithmetic, not whether external data agree with the model.
ROOT=fileparts(fileparts(mfilename('fullpath'))); Gate={};Status={};Detail={};
add('J0_STAGE_H2_PREREQUISITE',gateH2(),'Repaired/qualified Stage-H.2 status is present.');
add('J0B_STAGE_I_PREREQUISITE',gateI(),'Qualified Stage-I external-generality output is present as frozen upstream evidence.');
add('J1_EXTERNAL_EVIDENCE_REGISTRY',evidenceGate(),'Required Yang/Cancelas/Botha/Wang/Zhang/Urdampilleta/Khare evidence rows and key quantitative challenge values are present.');
add('J2_H2_BRANCH_COMPLETENESS',branchGate(),sprintf('%d declared H2 challenge branches are represented.',numel(cfg.StageJ.H2_branch_names)));
add('J3_T80_WEIGHT_NORMALIZATION',max(abs(result.T80Audit.WeightSum-1))<=1e-12,'Every retained T80 population vector is normalized.');
B=result.BaselineRegression;
add('J4_FROZEN_STAGEF_COMPOSITION_REPRODUCTION',B.C2MinAbsDiff<=cfg.StageJ.baseline_reproduction_abs_tol && B.C2MaxAbsDiff<=cfg.StageJ.baseline_reproduction_abs_tol, ...
    sprintf('Legacy Stage-J composition branch reproduces Stage F; min/max abs diff %.3g/%.3g.',B.C2MinAbsDiff,B.C2MaxAbsDiff));
add('J5_FROZEN_STAGEG_W1_REPRODUCTION',B.W1AbsDiff<=cfg.StageJ.baseline_reproduction_abs_tol, ...
    sprintf('Legacy Stage-J structural branch reproduces Stage G; abs diff %.3g decades.',B.W1AbsDiff));
[okNest,detNest]=nestedRangeGate();add('J6_NESTED_CHEMISTRY_STRESS_DOMAIN',okNest,detNest);
[okCov,detCov]=coverageArithmeticGate();add('J7_EXTERNAL_STAGE_COVERAGE_ARITHMETIC',okCov,detCov);
[okBulk,detBulk]=bulkArithmeticGate();add('J8_BULK_C2_CHALLENGE_ARITHMETIC',okBulk,detBulk);
[okV,detV]=voiRangeGate();add('J9_COMPOSITION_VOI_RANGE_REPRODUCTION',okV,detV);
add('J10_VOI_FRACTION_BOUNDS',all(result.VOISingleton.GuaranteedContractionFraction>=-1e-10 & result.VOISingleton.GuaranteedContractionFraction<=1+1e-10), ...
    'All deterministic singleton guaranteed contractions lie in [0,1] within tolerance.');
[okW,detW]=w1UnionGate();add('J11_W1_UNION_MINIMUM_ARITHMETIC',okW,detW);
add('J12_SCIENTIFIC_FAILURE_PERMITTED',ismember(result.W1Closure.StructuralStatus(strcmp(result.W1Closure.H2BranchScope,'UNION_ALL_H2_BRANCHES')), ...
    {'CERTIFIED_POSITIVE_STRUCTURAL_SEPARATION','STRUCTURAL_SEPARATION_NOT_CERTIFIED_POSITIVE'}), ...
    'Positive or non-positive external structural challenge is a permitted scientific outcome.');
add('J13_NO_MATCHED_VALIDATION_OVERCLAIM',scopeIs('CANCELAS_BULK_POINTS_ARE_MATCHED_VALIDATION','NOT_ESTABLISHED') && scopeIs('RUBBER_RICH_C2_EQUALS_ALL_SECOND_STAGE_POLYMER_C2','NOT_ESTABLISHED'), ...
    'External hiPP data remain challenge/proxy evidence, not matched validation.');
add('J14_NO_ADDED_H2_SCOPE_GUARD',scopeIs('NO_ADDED_H2_EQUALS_ZERO_RESIDUAL_H2','NOT_ESTABLISHED'), ...
    'No-added-H2 literature evidence is not relabeled as proof of zero residual H2.');
add('J15_EXTERNAL_DATA_NOT_FITTED',scopeIs('EXTERNAL_DATA_USED_FOR_PARAMETER_FITTING','PROHIBITED_AND_NOT_DONE'), ...
    'Stage J does not fit external observations.');
add('J16_H_TO_H2_NOT_SILENTLY_REQUALIFIED',legacyStatus('StageH_to_H2_orders_under_expanded_H2','NOT_REQUALIFIED_IN_STAGE_J__REQUIRES_EXPANDED_T80_SUPPORT_RERUN'), ...
    'Existing H/H.1/H.2 order claims are not silently extended to the new H2/T80 branch set.');
add('J17_DP_REPEAT_MASS_DOMAIN_SCOPE',scopeIs('STAGEG_DP_REPEAT_MASS_SUPPORT_COVERS_ANY_EP_REPEAT_MASS','ESTABLISHED_BY_CONSTRUCTION'), ...
    'Stage-G DP alpha support remains the full ethylene-to-propylene repeat-mass interval.');
[okIM,detIM]=independentCompositionMirror();add('J18_INDEPENDENT_COMPOSITION_MIRROR',okIM,detIM);
[okIW,detIW]=independentW1Mirror();add('J19_INDEPENDENT_W1_MIRROR',okIW,detIW);
[okIT,detIT]=independentThresholdMirror();add('J20_INDEPENDENT_THRESHOLD_MIRROR',okIT,detIT);
V=table(Gate',Status',Detail','VariableNames',{'Gate','Status','Detail'});writetable(V,fullfile(outdir,'StageJ_verification.csv'));

 function add(n,ok,d),Gate{end+1}=n;if ok,Status{end+1}='PASS';else,Status{end+1}='FAIL';end;Detail{end+1}=d;end
 function ok=gateH2()
  f=fullfile(ROOT,'inputs','StageH2QualifiedOutputs','STAGE_H2_STATUS.txt');
  ok=exist(f,'file')==2 && contains(fileread(f),'STAGE_H2_T80_GLOBAL_FIXED_DESCRIPTOR_CLOSURE_QUALIFIED');
 end
 function ok=gateI()
  f=fullfile(ROOT,'inputs','StageIQualifiedOutputs','STAGE_I_STATUS.txt');
  if exist(f,'file')~=2, ok=false; return; end
  txt=fileread(f);
  verdict='PRIMARY_PP_DIRECTIONAL_GENERALITY_SUPPORTED__STRICT_AMPLIFICATION_MIXED__CROSS_POLYOLEFIN_UNIVERSALITY_FALSIFIED_BY_SECONDARY';
  ok=contains(txt,'All executable Stage-I gates pass: 1') && contains(txt,verdict);
  vf=fullfile(ROOT,'inputs','StageIQualifiedOutputs','StageI_verification.csv');
  if ok && exist(vf,'file')==2
      try
          Tv=stageJ_read_csv_strict(vf);
          pv=stageJ_table_column(Tv,'Pass');
          ok=~isempty(pv) && all(double(pv)==1);
      catch
          ok=false;
      end
  else
      ok=false;
  end
 end
 function ok=evidenceGate()
  E=result.Evidence; ids={'JYANG_H2','JCAN_H2','JCAN10_BULK','JCAN20_BULK','JCAN30_BULK','JBOTHA150','JBOTHA360','JWANG_PP2_STAGE','JZHANG_CHEM','JURD_RTD','JKHARE_PLANT'};
  ok=all(ismember(ids,E.ID));
  if ok
   q=strcmp(E.ID,'JCAN10_BULK');ok=ok&&abs(E.ValueLo(q)-0.051)<1e-12;
   q=strcmp(E.ID,'JBOTHA360');ok=ok&&abs(E.ValueLo(q)-0.378)<1e-12;
  end
 end
 function ok=branchGate()
  A=unique(result.T80Audit.H2Branch,'stable');ok=numel(A)==numel(cfg.StageJ.H2_branch_names)&&all(ismember(cfg.StageJ.H2_branch_names,A));
  for z=1:numel(cfg.StageJ.H2_branch_names),ok=ok&&any(strcmp(result.T80Audit.H2Branch,cfg.StageJ.H2_branch_names{z}));end
 end
 function [ok,detail]=nestedRangeGate()
  R=result.Ranges(strcmp(result.Ranges.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);[~,o]=sort(R.ChemistryOddsSpan);R=R(o,:);ok=true;mx=0;
  for z=2:height(R)
   v1=max(0,R.StageC2Min(z)-R.StageC2Min(z-1));v2=max(0,R.StageC2Max(z-1)-R.StageC2Max(z));mx=max([mx v1 v2]);ok=ok&&v1<=1e-12&&v2<=1e-12;
  end
  detail=sprintf('Nested union envelope maximum containment violation %.3g.',mx);
 end
 function [ok,detail]=coverageArithmeticGate()
  C=result.StageCoverage;bad=0;
  for z=1:height(C)
   ov=(C.ModelStageC2Max(z)>=C.ExternalLo(z)&&C.ModelStageC2Min(z)<=C.ExternalHi(z));ct=(C.ModelStageC2Min(z)<=C.ExternalLo(z)&&C.ModelStageC2Max(z)>=C.ExternalHi(z));
   bad=bad+(ov~=C.AnyOverlap(z))+(ct~=C.ContainsExternalDatumOrRange(z));
  end
  ok=bad==0;detail=sprintf('%d stage/proxy coverage rows; arithmetic mismatches=%d.',height(C),bad);
 end
 function [ok,detail]=bulkArithmeticGate()
  C=result.BulkCoverage;bad=0;md=0;
  for z=1:height(C)
   r=result.Ranges(result.Ranges.ChemistryOddsSpan==C.ChemistryOddsSpan(z)&strcmp(result.Ranges.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);
   dlo=abs(C.ModelBulkC2Min(z)-C.EPC_wtfrac(z)*r.StageC2Min);dhi=abs(C.ModelBulkC2Max(z)-C.EPC_wtfrac(z)*r.StageC2Max);md=max([md dlo dhi]);
   cv=C.ExternalBulkC2(z)>=C.ModelBulkC2Min(z)&&C.ExternalBulkC2(z)<=C.ModelBulkC2Max(z);bad=bad+(cv~=C.ExternalPointCovered(z));
  end
  ok=bad==0&&md<=1e-12;detail=sprintf('%d matched-EPC bulk rows; coverage mismatches=%d; max product arithmetic discrepancy %.3g.',height(C),bad,md);
 end
 function [ok,detail]=voiRangeGate()
  A=result.VOIBase;R=result.Ranges(strcmp(result.Ranges.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);d=[];bad=0;
  for z=1:height(A)
   q=R.ChemistryOddsSpan==A.ChemistryOddsSpan(z);if sum(q)~=1,bad=bad+1;continue;end
   d(end+1)=abs(A.StageC2Min(z)-R.StageC2Min(q));d(end+1)=abs(A.StageC2Max(z)-R.StageC2Max(q)); %#ok<AGROW>
  end
  if isempty(d),md=Inf;else,md=max(d);end
  ok=bad==0&&md<=cfg.StageJ.regression_abs_tol;detail=sprintf('Span baselines compared=%d; missing=%d; max discrepancy %.3g.',height(A),bad,md);
 end
 function [ok,detail]=w1UnionGate()
  S=result.W1Summary;U=S(strcmp(S.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);branches=cfg.StageJ.H2_branch_names;d=[];bad=0;
  for z=1:height(U)
   vals=[];
   for b=1:numel(branches)
    q=strcmp(S.H2BranchScope,branches{b})&strcmp(S.TransferMode,U.TransferMode{z})&abs(S.EPC_wtfrac-U.EPC_wtfrac(z))<1e-12;
    if sum(q)~=1,bad=bad+1;else,vals(end+1)=S.W1_certified_joint_lower_decades(q);end %#ok<AGROW>
   end
   if ~isempty(vals),d(end+1)=abs(U.W1_certified_joint_lower_decades(z)-min(vals));end %#ok<AGROW>
  end
  if isempty(d),md=Inf;else,md=max(d);end
  ok=bad==0&&md<=1e-12;detail=sprintf('%d union W1 rows; missing=%d; max minimum discrepancy %.3g.',height(U),bad,md);
 end
 function [ok,detail]=independentCompositionMirror()
  E=stageJ_read_csv_strict(fullfile(ROOT,'Independent_Audit','StageJ_expected_composition_ranges.csv'));R=result.Ranges;d=[];bad=0;
  for z=1:height(E)
   q=R.ChemistryOddsSpan==E.ChemistryOddsSpan(z) & (string(R.H2BranchScope)==string(E.H2BranchScope(z)));
   if sum(q)~=1,bad=bad+1;continue;end
   d(end+1)=abs(R.StageC2Min(q)-E.ExpectedStageC2Min(z));d(end+1)=abs(R.StageC2Max(q)-E.ExpectedStageC2Max(z)); %#ok<AGROW>
  end
  if isempty(d),md=Inf;else,md=max(d);end
  ok=bad==0&&md<=cfg.StageJ.regression_abs_tol;detail=sprintf('%d independent composition rows; missing=%d; max discrepancy %.3g.',height(E),bad,md);
 end
 function [ok,detail]=independentW1Mirror()
  E=stageJ_read_csv_strict(fullfile(ROOT,'Independent_Audit','StageJ_expected_W1_summary.csv'));S=result.W1Summary;d=[];bad=0;
  for z=1:height(E)
   q=(string(S.H2BranchScope)==string(E.H2BranchScope(z))) & (string(S.TransferMode)==string(E.TransferMode(z))) & abs(S.EPC_wtfrac-E.EPC_wtfrac(z))<1e-12;
   if sum(q)~=1,bad=bad+1;continue;end
   d(end+1)=abs(S.W1_certified_joint_lower_decades(q)-E.ExpectedW1Lower(z));d(end+1)=abs(S.W1_attainable_vertex_upper_decades(q)-E.ExpectedVertexUpper(z)); %#ok<AGROW>
  end
  if isempty(d),md=Inf;else,md=max(d);end
  ok=bad==0&&md<=cfg.StageJ.regression_abs_tol;detail=sprintf('%d independent W1 rows; missing=%d; max discrepancy %.3g decades.',height(E),bad,md);
 end
 function [ok,detail]=independentThresholdMirror()
  E=stageJ_read_csv_strict(fullfile(ROOT,'Independent_Audit','StageJ_expected_thresholds.csv'));T=result.Thresholds;
  vals=[T.MinimumSpanForAnyExternalStageOverlap T.MinimumSpanForFullExternalStageEnvelopeContainment T.MinimumSpanCoveringAllCancelasBulkPoints];
  expv=[E.MinimumSpanForAnyExternalStageOverlap E.MinimumSpanForFullExternalStageEnvelopeContainment E.MinimumSpanCoveringAllCancelasBulkPoints];
  ok=all((isnan(vals)&isnan(expv))|abs(vals-expv)<1e-12);detail=sprintf('Observed thresholds [%g %g %g], independent expected [%g %g %g].',vals,expv);
 end
 function ok=scopeIs(claim,status)
  claims=string(stageJ_table_column(result.ClaimScope,'Claim'));
  statuses=string(stageJ_table_column(result.ClaimScope,'Status'));
  q=(claims==string(claim));idx=find(q,1);ok=sum(q)==1 && ~isempty(idx) && statuses(idx)==string(status);
 end
 function ok=legacyStatus(claim,status)
  claims=string(stageJ_table_column(result.LegacyClaims,'Claim'));
  statuses=string(stageJ_table_column(result.LegacyClaims,'Status'));
  q=(claims==string(claim));idx=find(q,1);ok=sum(q)==1 && ~isempty(idx) && statuses(idx)==string(status);
 end
end
