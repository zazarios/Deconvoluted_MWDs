function out = fbr_conditional_property(matrix, stage_pop, EPC_wtfrac, f1_sorbed, r1, r2, response, M_grid)
%FBR_CONDITIONAL_PROPERTY Conditional second-stage composition and final MWD.
% The primary model predicts total second-stage EP-copolymer contribution.
% No deterministic EPR/PE phase split is constructed.

if EPC_wtfrac<=0 || EPC_wtfrac>=1, error('EPC_wtfrac must be in (0,1).'); end
w=stage_pop.w(:)'; Mn=stage_pop.Mn_gmol(:)'; active=w>0; w=w/sum(w);
mult=response.ethylene_odds_multiplier(:)';
if numel(mult)~=numel(w), error('Response multiplier length mismatch.'); end
odds=(1-f1_sorbed)/f1_sorbed;
f1j=1 ./ (1 + mult.*odds);
F1j=mayo_lewis_propylene_fraction(f1j,r1,r2);
C2j=ethylene_weight_fraction(F1j);
stage_C2=sum(w(active).*C2j(active));
stage_mix=mix_flory_populations(w,Mn,M_grid);

M=matrix.M_gmol;
if numel(M)~=numel(stage_mix.M_gmol) || any(abs(M-stage_mix.M_gmol)>0), error('M grids differ.'); end
G=(1-EPC_wtfrac)*matrix.dW_dlog10M + EPC_wtfrac*stage_mix.dW_dlog10M;
x=log10(M); G=G/trapz(x,G);
MnF=1/trapz(x,G./M); MwF=trapz(x,G.*M);
if isfield(matrix,'C2_wtfrac') && isfinite(matrix.C2_wtfrac), matrixC2=matrix.C2_wtfrac; else, matrixC2=0; end
out=struct();
out.M_gmol=M; out.dW_dlog10M=G; out.Mn_gmol=MnF; out.Mw_gmol=MwF; out.D=MwF/MnF;
out.EPC_wtfrac=EPC_wtfrac; out.stage_C2_wtfrac=stage_C2; out.total_C2_wtfrac=(1-EPC_wtfrac)*matrixC2+EPC_wtfrac*stage_C2;
out.population_f1_sorbed=f1j; out.population_C2_wtfrac=C2j; out.response_name=response.name;
end
