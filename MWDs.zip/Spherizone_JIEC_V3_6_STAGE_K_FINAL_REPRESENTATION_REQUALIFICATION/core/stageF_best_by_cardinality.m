function B = stageF_best_by_cardinality(T)
%STAGEF_BEST_BY_CARDINALITY Best guaranteed contraction for each subset size.
e=T.EPC_wtfrac; e(isnan(e))=-1;
keys=cell(height(T),1);
for i=1:height(T)
    keys{i}=sprintf('%s|%s|%.12g|%d',T.Target{i},T.TransferMode{i},e(i),T.Cardinality(i));
end
[uk,~,~]=unique(keys,'stable'); %#ok<ASGLU>
keep=zeros(numel(uk),1);
for k=1:numel(uk)
    idx=find(strcmp(keys,uk{k}));
    [~,j]=max(T.GuaranteedContractionFraction(idx));
    keep(k)=idx(j);
end
B=T(keep,:);
end
