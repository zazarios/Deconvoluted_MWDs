function D = continuous_chemistry_directions(npop)
%CONTINUOUS_CHEMISTRY_DIRECTIONS Symmetry-complete log-odds directions.
% At rho=1 with span=2, these reproduce the Stage-B C0/C1/C2 endpoint
% library. At rho=0 every direction collapses to homogeneous response.
if nargin<1, npop=5; end
if npop~=5, error('Current direction library is defined for five populations.'); end
D=struct('name',{},'class',{},'z',{});
D(end+1)=struct('name','C0_homogeneous','class','C0','z',zeros(1,5));
z=linspace(-1,1,5);
D(end+1)=struct('name','C1_order_lowMW_to_highMW','class','C1','z',z);
D(end+1)=struct('name','C1_order_highMW_to_lowMW','class','C1','z',fliplr(z));
P=unique(perms([-1 -1 0 1 1]),'rows');
for k=1:size(P,1)
    D(end+1)=struct('name',sprintf('C2_mixed_%02d',k),'class','C2','z',P(k,:)); %#ok<AGROW>
end
end
