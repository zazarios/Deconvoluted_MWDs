function result = run_stageF_value_of_information(cfg,outdir)
%RUN_STAGEF_VALUE_OF_INFORMATION Prospective set-based value-of-information audit.
% No probability distribution, expected utility, or assumed measurement noise
% is introduced. Information value is the guaranteed contraction of a
% deterministic partial-identification width after an epistemic block is
% treated as exactly resolved (an oracle upper bound for a real measurement).
if ~exist(outdir,'dir'), mkdir(outdir); end
ctx=stageD1_build_context(cfg);
Tp=ctx.Tp; Sp=ctx.Sp; surf=ctx.surf;
% Stage F uses the qualified Stage-E analytical matrix moments rather than
% the legacy compact-export-grid moments inherited from Stage B1. The latter
% carry a small numerical truncation bias (principally in Mn) and are retained
% only as an audit comparator, not as epistemic uncertainty.
[matrix,MatrixMomentAudit]=stageF_matrix_moment_reference(ctx.matrix);
Cs=site_response_scenarios(5,cfg.site_response.odds_span);
blockNames=cfg.StageF.block_names;

% Verify rectangular EX2 feasible-surface factorization: f1 anchor x r2 coordinate.
fA=unique(surf.f1_EX2,'stable'); r2u=unique(surf.r2,'stable');
nT=numel(Tp); nS=numel(Sp); nC=numel(Cs); nA=numel(fA); nK=numel(r2u);
if height(surf)~=nA*nK, error('StageF:NonRectangularSurface','EX2 feasible surface is not rectangular.'); end
for ia=1:nA
    q=surf(abs(surf.f1_EX2-fA(ia))<1e-12,:);
    if height(q)~=nK || max(abs(q.r2-r2u))>1e-12, error('StageF:SurfaceOrdering','EX2 r2 grid mismatch across f1 anchors.'); end
end

% Primary L3 finite ensemble: T80 model form x FBR sorption x latent chemistry
% x EX2 sorbed-f1 anchor x reactivity-curve coordinate.
sz=[nT nS nC nA nK];
C2=zeros(sz); MnDP=zeros(sz); MwDP=zeros(sz);
for it=1:nT
    for is=1:nS
        for ic=1:nC
            P=stage_properties_vectorized_B1(Tp(it),Sp(is).f1_sorbed,surf.r1,surf.r2,Cs(ic),'DP_REPEAT_MASS_CORRECTED');
            gC=reshape(P.C2_wtfrac,[nK nA])';
            gN=reshape(P.Mn_gmol,[nK nA])';
            gW=reshape(P.Mw_gmol,[nK nA])';
            C2(it,is,ic,:,:)=reshape(gC,[1 1 1 nA nK]);
            MnDP(it,is,ic,:,:)=reshape(gN,[1 1 1 nA nK]);
            MwDP(it,is,ic,:,:)=reshape(gW,[1 1 1 nA nK]);
        end
    end
end

% Direct-transfer stage moments depend only on T80 population transfer.
MnDir=zeros(nT,1); MwDir=zeros(nT,1);
for it=1:nT
    p=population_moments(Tp(it)); MnDir(it)=p.Mn_gmol; MwDir(it)=p.Mw_gmol;
end

All=stageF_minimax_subset_table(C2,blockNames,'StageC2_wtfrac','COMPOSITION',NaN);
baseRows=cell(0,7);
baseRows(end+1,:)={'StageC2_wtfrac','COMPOSITION',NaN,min(C2(:)),max(C2(:)),max(C2(:))-min(C2(:)),'wt fraction'}; %#ok<AGROW>

for ie=1:numel(cfg.StageF.EPC)
    e=cfg.StageF.EPC(ie);
    % DIRECT_MN_TRANSFER
    FmnD=1./((1-e)/matrix.Mn_gmol + e./reshape(MnDir,[nT 1 1 1 1]));
    FmwD=(1-e)*matrix.Mw_gmol + e.*reshape(MwDir,[nT 1 1 1 1]);
    FmnD=repmat(FmnD,[1 nS nC nA nK]); FmwD=repmat(FmwD,[1 nS nC nA nK]); FD=FmwD./FmnD;
    All=[All; stageF_minimax_subset_table(FmnD,blockNames,'Final_Mn_gmol','DIRECT_MN_TRANSFER',e)]; %#ok<AGROW>
    All=[All; stageF_minimax_subset_table(FmwD,blockNames,'Final_Mw_gmol','DIRECT_MN_TRANSFER',e)]; %#ok<AGROW>
    All=[All; stageF_minimax_subset_table(FD,blockNames,'Final_D','DIRECT_MN_TRANSFER',e)]; %#ok<AGROW>
    baseRows(end+1,:)={'Final_Mn_gmol','DIRECT_MN_TRANSFER',e,min(FmnD(:)),max(FmnD(:)),max(FmnD(:))-min(FmnD(:)),'g/mol'}; %#ok<AGROW>
    baseRows(end+1,:)={'Final_Mw_gmol','DIRECT_MN_TRANSFER',e,min(FmwD(:)),max(FmwD(:)),max(FmwD(:))-min(FmwD(:)),'g/mol'}; %#ok<AGROW>
    baseRows(end+1,:)={'Final_D','DIRECT_MN_TRANSFER',e,min(FD(:)),max(FD(:)),max(FD(:))-min(FD(:)),'dimensionless'}; %#ok<AGROW>

    % DP_REPEAT_MASS_CORRECTED
    Fmn=1./((1-e)/matrix.Mn_gmol + e./MnDP);
    Fmw=(1-e)*matrix.Mw_gmol + e.*MwDP; Fd=Fmw./Fmn;
    All=[All; stageF_minimax_subset_table(Fmn,blockNames,'Final_Mn_gmol','DP_REPEAT_MASS_CORRECTED',e)]; %#ok<AGROW>
    All=[All; stageF_minimax_subset_table(Fmw,blockNames,'Final_Mw_gmol','DP_REPEAT_MASS_CORRECTED',e)]; %#ok<AGROW>
    All=[All; stageF_minimax_subset_table(Fd,blockNames,'Final_D','DP_REPEAT_MASS_CORRECTED',e)]; %#ok<AGROW>
    baseRows(end+1,:)={'Final_Mn_gmol','DP_REPEAT_MASS_CORRECTED',e,min(Fmn(:)),max(Fmn(:)),max(Fmn(:))-min(Fmn(:)),'g/mol'}; %#ok<AGROW>
    baseRows(end+1,:)={'Final_Mw_gmol','DP_REPEAT_MASS_CORRECTED',e,min(Fmw(:)),max(Fmw(:)),max(Fmw(:))-min(Fmw(:)),'g/mol'}; %#ok<AGROW>
    baseRows(end+1,:)={'Final_D','DP_REPEAT_MASS_CORRECTED',e,min(Fd(:)),max(Fd(:)),max(Fd(:))-min(Fd(:)),'dimensionless'}; %#ok<AGROW>
end

Baseline=cell2table(baseRows,'VariableNames',{'Target','TransferMode','EPC_wtfrac','Min','Max','Width','Units'});
Singleton=All(All.Cardinality==1,:);
Best=stageF_best_by_cardinality(All);
MinSets=stageF_minimum_exact_sets(All,cfg.StageF.exact_rel_tol,cfg.StageF.exact_abs_tol);
[ReactDetail,ReactSummary]=stageF_reactivity_pair_design(cfg,surf);
Roles=stageF_measurement_roles();

% Composition-specific cardinality frontier and key dependency rows.
CompBest=Best(strcmp(Best.Target,'StageC2_wtfrac'),:);
idxCurve=find(strcmp(All.Target,'StageC2_wtfrac') & strcmp(All.ResolvedBlocks,'REACTIVITY_CURVE_COORD'),1);
idxPair=find(strcmp(All.Target,'StageC2_wtfrac') & strcmp(All.ResolvedBlocks,'EX2_SORBED_F1+REACTIVITY_CURVE_COORD'),1);
Dependency=table(All.GuaranteedContractionFraction(idxCurve),All.GuaranteedContractionFraction(idxPair), ...
    'VariableNames',{'ReactivityCoordinateAloneGuaranteedContraction','EX2f1PlusReactivityGuaranteedContraction'});

% Context: Stage-E.1 structural retention is already robust; Stage F targets
% the unresolved quantitative composition/MWD-moment claims.
e1=readtable(fullfile(fileparts(fileparts(mfilename('fullpath'))),'inputs','StageE1QualifiedAudit','StageE1_continuous_W1_bounds_summary.csv'));
E1Context=table(min(e1.W1_certified_lower_decades(strcmp(e1.Coordinate,'U_W'))), ...
    min(e1.W1_certified_lower_decades(strcmp(e1.Coordinate,'U_C'))), ...
    {'STRUCTURAL_FULL_MWD_RETENTION_ALREADY_BOUNDED_AWAY_FROM_ZERO'}, ...
    'VariableNames',{'Min_UW_W1_lower_decades','Min_UC_W1_lower_decades','RoleInStageF'});

Scope=table({'GuaranteedContractionFraction';'BestCaseContractionFraction';'MinimumExactSubset';'ReactivityPairConditionNumber';'DirectOutputMeasurement'}, ...
    {'DETERMINISTIC_MINIMAX';'DETERMINISTIC_OUTCOME_RANGE';'FINITE_ENSEMBLE_ORACLE_BLOCK_RESOLUTION';'SENSITIVITY_DIAGNOSTIC_ONLY';'CALIBRATION_OR_VALIDATION_NOT_TRANSFERABLE_IDENTIFICATION'}, ...
    {'No probability or expected utility.';'No probability assigned to outcomes.';'Exact block resolution is an upper bound on a real measurement with finite precision.'; ...
    'No assumed measurement noise; uniqueness is not precision.';'A measured target can collapse its local output but cannot be counted as independent validation if fitted.'}, ...
    'VariableNames',{'Quantity','Status','Interpretation'});

writetable(Baseline,fullfile(outdir,'StageF_baseline_target_ranges.csv'));
writetable(All,fullfile(outdir,'StageF_all_block_subsets.csv'));
writetable(Singleton,fullfile(outdir,'StageF_single_block_value.csv'));
writetable(Best,fullfile(outdir,'StageF_best_subsets_by_cardinality.csv'));
writetable(MinSets,fullfile(outdir,'StageF_minimum_exact_sets.csv'));
writetable(CompBest,fullfile(outdir,'StageF_composition_cardinality_frontier.csv'));
writetable(Dependency,fullfile(outdir,'StageF_reactivity_dependency.csv'));
writetable(ReactDetail,fullfile(outdir,'StageF_second_RCP_design_detail.csv'));
writetable(ReactSummary,fullfile(outdir,'StageF_second_RCP_design_summary.csv'));
writetable(Roles,fullfile(outdir,'StageF_measurement_roles.csv'));
writetable(E1Context,fullfile(outdir,'StageF_StageE1_context.csv'));
writetable(Scope,fullfile(outdir,'StageF_scope.csv'));
writetable(MatrixMomentAudit,fullfile(outdir,'StageF_matrix_moment_consistency.csv'));

result=struct('Baseline',Baseline,'AllSubsets',All,'Singleton',Singleton,'Best',Best,'MinSets',MinSets, ...
    'CompBest',CompBest,'Dependency',Dependency,'ReactDetail',ReactDetail,'ReactSummary',ReactSummary, ...
    'Roles',Roles,'E1Context',E1Context,'Scope',Scope,'MatrixMomentAudit',MatrixMomentAudit,'Dims',[nT nS nC nA nK]);
end
