function R = refine_stageD_critical_radii_D1(cfg,outdir)
%REFINE_STAGED_CRITICAL_RADII_D1 Bisection hardening of genuine Stage-D crossings.
% Only rows already bracketed by Stage D are refined. Zero-radius overlap and
% full-domain survival rows are not converted into artificial thresholds.
coarse=readtable(fullfile(outdir,'StageD_critical_radius_brackets.csv'));
ctx=stageD1_build_context(cfg);
n=height(coarse);
refApplied=false(n,1); rLo=coarse.LastSeparatedRadius; rHi=coarse.FirstOverlapRadius;
rMid=nan(n,1); width=nan(n,1); mLo=nan(n,1); mHi=nan(n,1); nIter=zeros(n,1);
interp=strings(n,1);
for i=1:n
    coord=string(coarse.UncertaintyCoordinate(i)); mode=string(coarse.TransferMode(i)); prop=string(coarse.Property(i));
    status=string(coarse.Status(i));
    if coord=="U_W_TV" && prop=="C2"
        interp(i)="STRUCTURAL_UW_C2_INVARIANCE_UNDER_C0__NOT_EMPIRICAL_ROBUSTNESS";
    elseif coord=="U_C_LOG_ODDS" && mode=="DIRECT_MN_TRANSFER" && (prop=="Mn" || prop=="Mw")
        interp(i)="DIRECT_TRANSFER_MWD_IS_STRUCTURALLY_INVARIANT_TO_UC__IDENTIFIABILITY_STATUS_STILL_APPLIES";
    elseif status=="OVERLAP_ALREADY_AT_ZERO_RADIUS"
        interp(i)="NO_POSITIVE_CRITICAL_RADIUS__OVERLAP_EXISTS_AT_ZERO";
    elseif status=="SEPARATION_SURVIVES_FULL_SCANNED_RADIUS"
        interp(i)="NO_CROSSING_WITHIN_ADMISSIBLE_RADIUS_0_TO_1";
    else
        interp(i)="REFINED_NONZERO_CRITICAL_RADIUS";
    end
    if status~="CRITICAL_RADIUS_BRACKETED", continue; end
    lo=coarse.LastSeparatedRadius(i); hi=coarse.FirstOverlapRadius(i);
    flo=stageD1_margin_at_radius(ctx,cfg,coord,mode,prop,coarse.EPC_low(i),coarse.EPC_high(i),lo);
    fhi=stageD1_margin_at_radius(ctx,cfg,coord,mode,prop,coarse.EPC_low(i),coarse.EPC_high(i),hi);
    if ~(flo>cfg.StageD1.margin_tol && fhi<=cfg.StageD1.margin_tol)
        error('Stage-D.1 invalid starting bracket at row %d: margins %.17g, %.17g.',i,flo,fhi);
    end
    it=0;
    while (hi-lo)>cfg.StageD1.critical_radius_tol && it<cfg.StageD1.max_bisection_iter
        mid=0.5*(lo+hi);
        fm=stageD1_margin_at_radius(ctx,cfg,coord,mode,prop,coarse.EPC_low(i),coarse.EPC_high(i),mid);
        if fm>cfg.StageD1.margin_tol
            lo=mid; flo=fm;
        else
            hi=mid; fhi=fm;
        end
        it=it+1;
    end
    if (hi-lo)>cfg.StageD1.critical_radius_tol, error('Stage-D.1 bisection failed to reach radius tolerance.'); end
    refApplied(i)=true; rLo(i)=lo; rHi(i)=hi; rMid(i)=0.5*(lo+hi); width(i)=hi-lo; mLo(i)=flo; mHi(i)=fhi; nIter(i)=it;
end
R=coarse;
R.RefinementApplied=refApplied;
R.RefinedLastSeparatedRadius=rLo;
R.RefinedFirstOverlapRadius=rHi;
R.RefinedMidpointRadius=rMid;
R.RefinedBracketWidth=width;
R.MarginAtRefinedLastSeparated=mLo;
R.MarginAtRefinedFirstOverlap=mHi;
R.RefinementIterations=nIter;
R.InterpretationCode=interp;
writetable(R,fullfile(outdir,'StageD1_critical_radius_refined.csv'));

% Semantic diagnostics: explicitly distinguish structural invariance from evidence.
W=readtable(fullfile(outdir,'StageD_weight_TV_partial_identification.csv'));
maxChange=0;
for mode=unique(string(W.TransferMode),'stable')'
    for e=unique(W.EPC_wtfrac,'stable')'
        s=W(string(W.TransferMode)==mode & abs(W.EPC_wtfrac-e)<1e-12,:);
        maxChange=max(maxChange,max(s.TotalC2_max)-min(s.TotalC2_max));
        maxChange=max(maxChange,max(s.TotalC2_min)-min(s.TotalC2_min));
    end
end
% Direct coefficient check at representative states; C0 makes columns identical analytically.
maxCoeffSpread=0;
for it=1:numel(ctx.Tp)
    for is=1:numel(ctx.Sp)
        st=stage_population_state(ctx.Tp(it),ctx.Sp(is).f1_sorbed,ctx.surf.r1,ctx.surf.r2,ctx.C0,'DIRECT_MN_TRANSFER');
        active=ctx.Tp(it).w>0 & isfinite(ctx.Tp(it).Mn_gmol);
        X=st.C2J(:,active);
        maxCoeffSpread=max(maxCoeffSpread,max(max(X,[],2)-min(X,[],2)));
    end
end
span=cfg.site_response.odds_span;
Sem=table( ...
    ["U_W_C2_C0";"U_C_RHO_1";"U_C_RHO_0"], ...
    [maxCoeffSpread;1/span;1], ...
    [maxChange;span;1], ...
    [NaN;span^2;1], ...
    ["C0 assigns identical C2 response coefficients to all active populations; changing population weights cannot change total C2. This is structural by construction, not empirical robustness."; ...
     "At rho_C=1, each population multiplier lies from 1/span to span (0.5 to 2 when span=2); the maximum-to-minimum contrast is span^2=4."; ...
     "At rho_C=0, all population multipliers equal 1 and chemistry is homogeneous."], ...
    'VariableNames',{'Diagnostic','Value1','Value2','Value3','Interpretation'});
writetable(Sem,fullfile(outdir,'StageD1_coordinate_semantics.csv'));
end
