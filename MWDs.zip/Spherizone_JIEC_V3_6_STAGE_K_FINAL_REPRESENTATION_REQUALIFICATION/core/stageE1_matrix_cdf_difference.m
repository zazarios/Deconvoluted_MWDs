function out = stageE1_matrix_cdf_difference(matrix,M_gmol)
%STAGEE1_MATRIX_CDF_DIFFERENCE Matrix resolved-minus-collapsed CDF difference.
M=M_gmol(:)'; x=log10(M);
if numel(matrix.M_gmol)~=numel(M) || any(abs(log10(matrix.M_gmol(:)')-x)>1e-12)
    error('StageE1:MatrixGridMismatch','Matrix distribution is not on the Stage-E.1 metric grid.');
end
p=matrix.dW_dlog10M(:)';
q=flory_logweight_pdf(M,matrix.Mn_gmol);
Fp=stageE1_numerical_cdf(M,p);
Fq=stageE1_numerical_cdf(M,q);
A=Fp-Fq;
out=struct('F_resolved',Fp,'F_collapsed',Fq,'A',A,'W1_decades',trapz(x,abs(A)));
end
