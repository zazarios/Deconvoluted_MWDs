function verdict = run_stageB_analysis(cfg,outdir)
%RUN_STAGEB_ANALYSIS Full deterministic Stage-B uncertainty/identifiability audit.
% All epistemic/model-form dimensions are enumerated deterministically.
% Large Cartesian products are evaluated but only scientifically useful
% summaries/extreme provenance are exported; no probability interpretation.

if ~exist(outdir,'dir'), mkdir(outdir); end

% -------------------------------------------------------------------------
% A. Source-domain EX2 sorption anchor and set-valued reactivity conditioning
% -------------------------------------------------------------------------
anchor=ex2_sorption_anchor_envelope(cfg);
A=table(anchor.f1_min,anchor.f1_max,anchor.argmin(1),anchor.argmin(2),anchor.argmin(3),anchor.argmin(4), ...
    anchor.argmax(1),anchor.argmax(2),anchor.argmax(3),anchor.argmax(4), ...
    'VariableNames',{'f1_min','f1_max','min_T_C','min_xC2_reactive','min_PC3_bar','min_PC2_bar', ...
    'max_T_C','max_xC2_reactive','max_PC3_bar','max_PC2_bar'});
writetable(A,fullfile(outdir,'StageB_EX2_sorption_anchor_summary.csv'));

primarySurface=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac, ...
    cfg.EX2.primary_r1_bounds,cfg.EX2.primary_r2_bounds,cfg.EX2.primary_n_r2,'PRIMARY_SCREEN');
expandedSurface=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac, ...
    cfg.EX2.expanded_r1_bounds,cfg.EX2.expanded_r2_bounds,cfg.EX2.expanded_n_r2,'EXPANDED_STRESS_SCREEN');
writetable(primarySurface,fullfile(outdir,'StageB_EX2_primary_feasible_surface.csv'));
writetable(expandedSurface,fullfile(outdir,'StageB_EX2_expanded_stress_surface.csv'));

% External effective-model ratio exemplars used only to document why the
% expanded stress screen is deliberately wide. These are NOT transferred as
% catalyst-specific constants.
Lit=table({'Yang_Lei_Luo_2026';'Zhang_et_al_2025'},[10;0.07441],[0.1;31.87], ...
    {'effective kinetic-model exemplar; not transferred';'industrial fitted effective-model exemplar; not transferred'}, ...
    'VariableNames',{'Source','r_propylene','r_ethylene','Role'});
writetable(Lit,fullfile(outdir,'StageB_external_reactivity_ratio_exemplars.csv'));

% Exact target check.
maxTargetErr=max(abs(primarySurface.C2_wtfrac-cfg.EX2.target_C2_wtfrac));

% -------------------------------------------------------------------------
% B. Corrected MZCR matrix and T80 population scenarios
% -------------------------------------------------------------------------
mz=run_normalized_mzcr_demo(cfg);
matrix=mz.matrix;
Tall=population_T80_envelope(cfg.FBR.H2_psi,cfg.MZCR.DoTi);
Tprimary=select_T(Tall,cfg.StageB.primary_T_classes);
Tstress=select_T(Tall,cfg.StageB.stress_T_classes);

sorb=thermo_fbr_scenarios(cfg.FBR.gas);
resp=site_response_scenarios(5,cfg.site_response.odds_span);
rtd=rtd_ensemble(cfg);

% Export T scenario metadata.
Tm=cell(numel(Tall),6);
for k=1:numel(Tall)
    Tm(k,:)={Tall(k).name,Tall(k).source_pair,Tall(k).admissibility,Tall(k).admissibility_reason, ...
        Tall(k).truncated_weights,Tall(k).mn_delta_missing};
end
writetable(cell2table(Tm,'VariableNames',{'Scenario','SourcePair','Admissibility','Reason','WeightTruncation','MissingMnDelta'}), ...
    fullfile(outdir,'StageB_T80_scenario_classification.csv'));

% -------------------------------------------------------------------------
% C. Primary MWD envelope (depends on U_T and U_EPC in conditional mode)
% -------------------------------------------------------------------------
mwdRows={}; nm=0;
M=matrix.M_gmol; x=log10(M);
for it=1:numel(Tprimary)
    ps=population_moments(Tprimary(it));
    stagemix=mix_flory_populations(Tprimary(it).w,Tprimary(it).Mn_gmol,M);
    for ie=1:numel(cfg.StageB.primary_EPC)
        epc=cfg.StageB.primary_EPC(ie);
        fb=final_blend_moments(matrix.Mn_gmol,matrix.Mw_gmol,ps.Mn_gmol,ps.Mw_gmol,epc);
        G=(1-epc)*matrix.dW_dlog10M + epc*stagemix.dW_dlog10M;
        G=G/trapz(x,G);
        nm=nm+1;
        mwdRows(nm,:)={Tprimary(it).name,epc,ps.Mn_gmol,ps.Mw_gmol,ps.D,fb.Mn_gmol,fb.Mw_gmol,fb.D}; %#ok<AGROW>
        if it==1 && ie==1
            Gcube=zeros(numel(Tprimary),numel(cfg.StageB.primary_EPC),numel(M));
        end
        Gcube(it,ie,:)=G;
    end
end
MWDT=cell2table(mwdRows,'VariableNames',{'TScenario','EPC_wtfrac','Stage_Mn_gmol','Stage_Mw_gmol','Stage_D','ICP_Mn_gmol','ICP_Mw_gmol','ICP_D'});
writetable(MWDT,fullfile(outdir,'StageB_primary_MWD_scenarios.csv'));

% MWD density envelopes for direct plotting.
for ie=1:numel(cfg.StageB.primary_EPC)
    Gs=squeeze(Gcube(:,ie,:));
    Gmin=min(Gs,[],1)'; Gmax=max(Gs,[],1)'; Gref=squeeze(Gcube(1,ie,:));
    Tout=table(M(:),Gmin,Gref(:),Gmax,'VariableNames',{'M_gmol','dW_min','dW_boundary_hold','dW_max'});
    writetable(Tout,fullfile(outdir,sprintf('StageB_MWD_envelope_EPC_%02dwtpct.csv',round(100*cfg.StageB.primary_EPC(ie)))));
end

% -------------------------------------------------------------------------
% D. Primary composition envelope: evaluate every point in the set-valued
% EX2 surface for every T/sorption/chemistry state. EPC simply scales total
% C2 because the matrix is HPP in the primary ICP case.
% -------------------------------------------------------------------------
r1v=primarySurface.r1; r2v=primarySurface.r2;
compRows={}; nc=0;
EPC=cfg.StageB.primary_EPC;
fullMin=inf(size(EPC)); fullMax=-inf(size(EPC));
minProv=cell(size(EPC)); maxProv=cell(size(EPC));
for it=1:numel(Tprimary)
    pop=Tprimary(it);
    for is=1:numel(sorb)
        for ic=1:numel(resp)
            c2=stage_c2_vectorized(pop,sorb(is).f1_sorbed,r1v,r2v,resp(ic));
            [cmin,imin]=min(c2); [cmax,imax]=max(c2);
            nc=nc+1;
            compRows(nc,:)={pop.name,sorb(is).name,resp(ic).name,cmin,cmax, ...
                r1v(imin),r2v(imin),primarySurface.f1_EX2(imin), ...
                r1v(imax),r2v(imax),primarySurface.f1_EX2(imax)}; %#ok<AGROW>
            for ie=1:numel(EPC)
                lo=EPC(ie)*cmin; hi=EPC(ie)*cmax;
                if lo<fullMin(ie)
                    fullMin(ie)=lo;
                    minProv{ie}=provstr(pop.name,sorb(is).name,resp(ic).name,r1v(imin),r2v(imin),primarySurface.f1_EX2(imin));
                end
                if hi>fullMax(ie)
                    fullMax(ie)=hi;
                    maxProv{ie}=provstr(pop.name,sorb(is).name,resp(ic).name,r1v(imax),r2v(imax),primarySurface.f1_EX2(imax));
                end
            end
        end
    end
end
CompT=cell2table(compRows,'VariableNames',{'TScenario','SorptionScenario','ChemistryScenario','Stage_C2_min','Stage_C2_max', ...
    'Min_r1','Min_r2','Min_f1_EX2','Max_r1','Max_r2','Max_f1_EX2'});
writetable(CompT,fullfile(outdir,'StageB_primary_stageC2_extrema_by_model_state.csv'));

% MWD property envelope per EPC + composition envelope.
envRows={};
for ie=1:numel(EPC)
    sub=MWDT(abs(MWDT.EPC_wtfrac-EPC(ie))<1e-12,:);
    envRows(ie,:)={EPC(ie),min(sub.ICP_Mn_gmol),max(sub.ICP_Mn_gmol), ...
        min(sub.ICP_Mw_gmol),max(sub.ICP_Mw_gmol),min(sub.ICP_D),max(sub.ICP_D), ...
        fullMin(ie),fullMax(ie),minProv{ie},maxProv{ie}}; %#ok<AGROW>
end
Envelope=cell2table(envRows,'VariableNames',{'EPC_wtfrac','Mn_min_gmol','Mn_max_gmol','Mw_min_gmol','Mw_max_gmol','D_min','D_max', ...
    'TotalC2_min_wtfrac','TotalC2_max_wtfrac','TotalC2_min_provenance','TotalC2_max_provenance'});
writetable(Envelope,fullfile(outdir,'StageB_primary_output_envelopes.csv'));

% -------------------------------------------------------------------------
% E. Transparent reference scenario and one-factor envelope contributions
% -------------------------------------------------------------------------
ref=make_reference(cfg,anchor,primarySurface,Tprimary,sorb,resp,matrix);
writetable(struct2table(ref),fullfile(outdir,'StageB_reference_scenario.csv'));
OF=onefactor(cfg,ref,anchor,primarySurface,Tprimary,sorb,resp,matrix,fullMin,fullMax,MWDT);
writetable(OF,fullfile(outdir,'StageB_onefactor_spread.csv'));

% -------------------------------------------------------------------------
% F. Structural multisite-vs-single-Flory comparator (H1)
% -------------------------------------------------------------------------
cr={}; nr=0; allHigher=true;
for it=1:numel(Tprimary)
    ps=population_moments(Tprimary(it));
    for ie=1:numel(EPC)
        epc=EPC(ie);
        multi=final_blend_moments(matrix.Mn_gmol,matrix.Mw_gmol,ps.Mn_gmol,ps.Mw_gmol,epc);
        single=final_blend_moments(matrix.Mn_gmol,2*matrix.Mn_gmol,ps.Mn_gmol,2*ps.Mn_gmol,epc);
        nr=nr+1;
        cr(nr,:)={Tprimary(it).name,epc,multi.Mn_gmol,multi.Mw_gmol,multi.D,single.Mn_gmol,single.Mw_gmol,single.D,multi.D-single.D}; %#ok<AGROW>
        allHigher=allHigher && multi.D>single.D;
    end
end
CT=cell2table(cr,'VariableNames',{'TScenario','EPC_wtfrac','Multi_Mn','Multi_Mw','Multi_D','Single_Mn','Single_Mw','Single_D','Delta_D'});
writetable(CT,fullfile(outdir,'StageB_multisite_vs_singleFlory.csv'));

% -------------------------------------------------------------------------
% G. RTD invariance is an explicit result in conditional-property mode.
% -------------------------------------------------------------------------
RT=cell(numel(rtd),4);
for k=1:numel(rtd)
    RT(k,:)={rtd(k).name,rtd(k).N,rtd(k).normalized_property_multiplier,rtd(k).note};
end
writetable(cell2table(RT,'VariableNames',{'RTDScenario','N_tanks','NormalizedPropertyMultiplier','Interpretation'}), ...
    fullfile(outdir,'StageB_RTD_conditional_invariance.csv'));

% -------------------------------------------------------------------------
% H. Expanded stress envelope: wider r-screen + T extrapolation-failure
% cases, excluding only the documented source-inconsistent 60_D slope.
% -------------------------------------------------------------------------
Stress=stress_envelope(cfg,Tstress,expandedSurface,sorb,resp,matrix);
writetable(Stress,fullfile(outdir,'StageB_extended_stress_envelopes.csv'));

% -------------------------------------------------------------------------
% I. Trend / identifiability tests and stop-condition verdict
% -------------------------------------------------------------------------
Trend=trend_checks(EPC,Envelope,MWDT,CompT,allHigher);
writetable(Trend,fullfile(outdir,'StageB_trend_and_identifiability_checks.csv'));

primaryCount=numel(Tprimary)*height(primarySurface)*numel(sorb)*numel(resp)*numel(EPC);
stressCount=numel(Tstress)*height(expandedSurface)*numel(sorb)*numel(resp)*(numel(EPC)+1);
verdict=stageB_verdict(Trend,Envelope,allHigher,primaryCount,stressCount,maxTargetErr,anchor);
write_verdict(verdict,outdir);

% Compact machine-readable status.
S=table(primaryCount,stressCount,height(primarySurface),height(expandedSurface),numel(Tprimary),numel(Tstress), ...
    anchor.f1_min,anchor.f1_max,maxTargetErr,string(verdict.code), ...
    'VariableNames',{'PrimaryScenarioEvaluations','StressScenarioEvaluations','PrimaryEX2SetPoints','ExpandedEX2SetPoints', ...
    'PrimaryTScenarios','StressTScenarios','EX2Anchor_f1_min','EX2Anchor_f1_max','EX2TargetMaxAbsErr','Verdict'});
writetable(S,fullfile(outdir,'StageB_status.csv'));
end

% =========================================================================
function Tsel=select_T(Tall,classes)
keep=false(1,numel(Tall));
for k=1:numel(Tall), keep(k)=any(strcmp(Tall(k).admissibility,classes)); end
Tsel=Tall(keep);
end

function s=provstr(t,so,c,r1,r2,f1)
s=sprintf('T=%s | sorb=%s | chemistry=%s | r1=%.8g | r2=%.8g | f1_EX2=%.8g',t,so,c,r1,r2,f1);
end

function ref=make_reference(cfg,anchor,surf,Tp,sorb,resp,matrix)
% Computational reference only; not a posterior mean/best fit.
tname=cfg.StageB.reference.TScenario;
it=find(strcmp({Tp.name},tname),1); if isempty(it), error('Reference T scenario missing.'); end
is=find(strcmp({sorb.name},cfg.StageB.reference.FBR_sorption),1); if isempty(is), error('Reference sorption missing.'); end
ic=find(strcmp({resp.name},cfg.StageB.reference.chemistry),1); if isempty(ic), error('Reference chemistry missing.'); end
fmid=0.5*(anchor.f1_min+anchor.f1_max);
r2target=cfg.EX2.primary_r2_bounds(1)+cfg.StageB.reference.r2_fraction_of_screen*diff(cfg.EX2.primary_r2_bounds);
d=((surf.f1_EX2-fmid)/(anchor.f1_max-anchor.f1_min)).^2 + ((surf.r2-r2target)/diff(cfg.EX2.primary_r2_bounds)).^2;
[~,ir]=min(d);
ps=population_moments(Tp(it));
epc=cfg.StageB.reference.EPC_wtfrac;
fb=final_blend_moments(matrix.Mn_gmol,matrix.Mw_gmol,ps.Mn_gmol,ps.Mw_gmol,epc);
c2=stage_c2_from_scenario(Tp(it),sorb(is).f1_sorbed,surf.r1(ir),surf.r2(ir),resp(ic));
ref=struct();
ref.TScenario=string(Tp(it).name); ref.EX2_f1_anchor=surf.f1_EX2(ir); ref.r1=surf.r1(ir); ref.r2=surf.r2(ir);
ref.FBRSorption=string(sorb(is).name); ref.FBR_f1_sorbed=sorb(is).f1_sorbed; ref.Chemistry=string(resp(ic).name);
ref.EPC_wtfrac=epc; ref.Mn_gmol=fb.Mn_gmol; ref.Mw_gmol=fb.Mw_gmol; ref.D=fb.D;
ref.Stage_C2_wtfrac=c2; ref.Total_C2_wtfrac=epc*c2;
ref.Note="Transparent computational reference only; no best-estimate/probability interpretation.";
end

function T=onefactor(cfg,ref,anchor,surf,Tp,sorb,resp,matrix,fullMin,fullMax,MWDT) %#ok<INUSD>
% One-factor-at-a-time ranges around the transparent reference.
factors={'U_T','U_r_and_EX2_anchor','U_sorb','U_C','U_EPC','U_RTD'};
rows=cell(numel(factors),10);
% locate reference objects/conditioning point
it=find(strcmp({Tp.name},char(ref.TScenario)),1);
is=find(strcmp({sorb.name},char(ref.FBRSorption)),1);
ic=find(strcmp({resp.name},char(ref.Chemistry)),1);
[~,ir]=min((surf.r1-ref.r1).^2+(surf.r2-ref.r2).^2+(surf.f1_EX2-ref.EX2_f1_anchor).^2);
epc=ref.EPC_wtfrac;
% helper baseline
base=[ref.Mn_gmol ref.Mw_gmol ref.D ref.Total_C2_wtfrac];

% U_T
vals=[];
for k=1:numel(Tp)
 ps=population_moments(Tp(k)); fb=final_blend_moments(matrix.Mn_gmol,matrix.Mw_gmol,ps.Mn_gmol,ps.Mw_gmol,epc);
 c2=stage_c2_from_scenario(Tp(k),sorb(is).f1_sorbed,ref.r1,ref.r2,resp(ic));
 vals(end+1,:)=[fb.Mn_gmol fb.Mw_gmol fb.D epc*c2]; %#ok<AGROW>
end
rows(1,:)=factorrow(factors{1},vals,base);
% U_r + EX2 anchor feasible surface
c2=stage_c2_vectorized(Tp(it),sorb(is).f1_sorbed,surf.r1,surf.r2,resp(ic));
vals=[repmat(base(1:3),numel(c2),1),epc*c2]; rows(2,:)=factorrow(factors{2},vals,base);
% U_sorb
vals=[];
for k=1:numel(sorb)
 c2=stage_c2_from_scenario(Tp(it),sorb(k).f1_sorbed,ref.r1,ref.r2,resp(ic));
 vals(end+1,:)=[base(1:3) epc*c2]; %#ok<AGROW>
end
rows(3,:)=factorrow(factors{3},vals,base);
% U_C
vals=[];
for k=1:numel(resp)
 c2=stage_c2_from_scenario(Tp(it),sorb(is).f1_sorbed,ref.r1,ref.r2,resp(k));
 vals(end+1,:)=[base(1:3) epc*c2]; %#ok<AGROW>
end
rows(4,:)=factorrow(factors{4},vals,base);
% U_EPC
vals=[]; ps=population_moments(Tp(it)); c2=stage_c2_from_scenario(Tp(it),sorb(is).f1_sorbed,ref.r1,ref.r2,resp(ic));
for k=1:numel(cfg.StageB.primary_EPC)
 e=cfg.StageB.primary_EPC(k); fb=final_blend_moments(matrix.Mn_gmol,matrix.Mw_gmol,ps.Mn_gmol,ps.Mw_gmol,e);
 vals(end+1,:)=[fb.Mn_gmol fb.Mw_gmol fb.D e*c2]; %#ok<AGROW>
end
rows(5,:)=factorrow(factors{5},vals,base);
% U_RTD is exactly invariant in current conditional-property mode
vals=repmat(base,numel(cfg.RTD.names),1); rows(6,:)=factorrow(factors{6},vals,base);
T=cell2table(rows,'VariableNames',{'Factor','Mn_min','Mn_max','Mw_min','Mw_max','D_min','D_max','TotalC2_min','TotalC2_max','Interpretation'});
end

function r=factorrow(name,vals,base)
mn=min(vals,[],1); mx=max(vals,[],1);
r={name,mn(1),mx(1),mn(2),mx(2),mn(3),mx(3),mn(4),mx(4), ...
    sprintf('OAT range around reference; no probability. Baseline=[Mn %.4g, Mw %.4g, D %.4g, C2 %.4g].',base(1),base(2),base(3),base(4))};
end

function Stress=stress_envelope(cfg,Tstress,surf,sorb,resp,matrix)
E=[cfg.StageB.primary_EPC cfg.StageB.stress_EPC];
r1=surf.r1; r2=surf.r2;
rows=cell(numel(E),9);
for ie=1:numel(E)
 epc=E(ie); mnmin=inf; mnmax=-inf; mwmin=inf; mwmax=-inf; dmin=inf; dmax=-inf; cmin=inf; cmax=-inf;
 for it=1:numel(Tstress)
  ps=population_moments(Tstress(it)); fb=final_blend_moments(matrix.Mn_gmol,matrix.Mw_gmol,ps.Mn_gmol,ps.Mw_gmol,epc);
  mnmin=min(mnmin,fb.Mn_gmol); mnmax=max(mnmax,fb.Mn_gmol); mwmin=min(mwmin,fb.Mw_gmol); mwmax=max(mwmax,fb.Mw_gmol); dmin=min(dmin,fb.D); dmax=max(dmax,fb.D);
  for is=1:numel(sorb)
   for ic=1:numel(resp)
    c=stage_c2_vectorized(Tstress(it),sorb(is).f1_sorbed,r1,r2,resp(ic));
    cmin=min(cmin,epc*min(c)); cmax=max(cmax,epc*max(c));
   end
  end
 end
 rows(ie,:)={epc,mnmin,mnmax,mwmin,mwmax,dmin,dmax,cmin,cmax};
end
Stress=cell2table(rows,'VariableNames',{'EPC_wtfrac','Mn_min_gmol','Mn_max_gmol','Mw_min_gmol','Mw_max_gmol','D_min','D_max','TotalC2_min_wtfrac','TotalC2_max_wtfrac'});
end

function T=trend_checks(EPC,Envelope,MWDT,CompT,allHigher) %#ok<INUSD>
rows={}; n=0;
% Adjacent envelope separation.
for i=1:numel(EPC)-1
 n=n+1; gapC=Envelope.TotalC2_min_wtfrac(i+1)-Envelope.TotalC2_max_wtfrac(i);
 rows(n,:)={sprintf('TotalC2 envelope separation %.0f->%.0f wt%% EPC',100*EPC(i),100*EPC(i+1)),gapC>0,gapC, ...
     'Positive gap means adjacent design envelopes are quantitatively separated.'}; %#ok<AGROW>
 n=n+1; gapMn=Envelope.Mn_max_gmol(i+1)-Envelope.Mn_min_gmol(i); % decreasing output: separation if high-EPC max < low-EPC min -> gap negative
 rows(n,:)={sprintf('Mn decreasing-envelope separation %.0f->%.0f wt%% EPC',100*EPC(i),100*EPC(i+1)),gapMn<0,gapMn, ...
     'Negative gap means higher-EPC Mn envelope lies entirely below lower-EPC envelope.'}; %#ok<AGROW>
 n=n+1; gapMw=Envelope.Mw_max_gmol(i+1)-Envelope.Mw_min_gmol(i);
 rows(n,:)={sprintf('Mw decreasing-envelope separation %.0f->%.0f wt%% EPC',100*EPC(i),100*EPC(i+1)),gapMw<0,gapMw, ...
     'Negative gap means higher-EPC Mw envelope lies entirely below lower-EPC envelope.'}; %#ok<AGROW>
end
% Per-T monotonic MWD trends.
Ts=unique(MWDT.TScenario,'stable'); monoMn=true; monoMw=true; monoD=true;
for k=1:numel(Ts)
 sub=MWDT(strcmp(MWDT.TScenario,Ts{k}),:); [~,ord]=sort(sub.EPC_wtfrac); sub=sub(ord,:);
 monoMn=monoMn && all(diff(sub.ICP_Mn_gmol)<0);
 monoMw=monoMw && all(diff(sub.ICP_Mw_gmol)<0);
 monoD=monoD && (all(diff(sub.ICP_D)>=-1e-10) || all(diff(sub.ICP_D)<=1e-10));
end
n=n+1; rows(n,:)={'Mn monotonic with EPC in every primary T scenario',monoMn,double(monoMn),'Expected direction: decreasing.'};
n=n+1; rows(n,:)={'Mw monotonic with EPC in every primary T scenario',monoMw,double(monoMw),'Expected direction: decreasing.'};
n=n+1; rows(n,:)={'D has a consistent monotonic direction within every primary T scenario',monoD,double(monoD),'Direction may differ weakly near flat cases; this is a strict check.'};
n=n+1; rows(n,:)={'Multisite final D exceeds same-Mn single-Flory comparator in all primary scenarios',allHigher,double(allHigher),'Direct test of H1 structural broadening.'};
T=cell2table(rows,'VariableNames',{'Check','Pass','Metric','Interpretation'});
end

function v=stageB_verdict(Trend,Envelope,allHigher,primaryCount,stressCount,maxTargetErr,anchor)
sep=Trend(contains(Trend.Check,'TotalC2 envelope separation'),:);
quantC2=all(sep.Pass);
robustMWD=allHigher && any(Trend.Pass(contains(Trend.Check,'Mn monotonic')|contains(Trend.Check,'Mw monotonic')));
% Composition is considered quantitatively non-identifiable when adjacent EPC
% envelopes overlap. This does NOT fail the paper; it triggers the barrier
% interpretation required by the frozen specification.
if robustMWD && ~quantC2
    code='MWD_ROBUST_COMPOSITION_IDENTIFIABILITY_BARRIER';
    summary=['Proceed scientifically, but reposition composition as a demonstrated identifiability barrier. ' ...
        'MWD heterogeneity/trends survive the admissible ensemble, whereas total-C2 design envelopes overlap.'];
elseif robustMWD && quantC2
    code='REDUCED_ORDER_ROBUST_TRENDS_SUPPORTED';
    summary='Proceed: both MWD and composition design envelopes retain quantitative separation under the admissible ensemble.';
else
    code='STOP_OR_REPOSITION_GLOBAL_IDENTIFIABILITY_BARRIER';
    summary='Do not proceed with a property-prediction framing; even the primary MWD claim is not robust under the admissible ensemble.';
end
v=struct('code',code,'summary',summary,'PrimaryScenarioEvaluations',primaryCount,'StressScenarioEvaluations',stressCount, ...
    'EX2TargetMaxAbsErr',maxTargetErr,'EX2Anchor_f1_min',anchor.f1_min,'EX2Anchor_f1_max',anchor.f1_max,'QuantitativeC2EnvelopeSeparation',quantC2,'RobustMWDStructuralClaim',robustMWD);
end

function write_verdict(v,outdir)
fid=fopen(fullfile(outdir,'STAGE_B_VERDICT.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.1 Stage-B uncertainty / identifiability verdict\n');
fprintf(fid,'Verdict: %s\n',v.code);
fprintf(fid,'%s\n',v.summary);
fprintf(fid,'Primary scenario evaluations: %d\n',v.PrimaryScenarioEvaluations);
fprintf(fid,'Expanded stress scenario evaluations: %d\n',v.StressScenarioEvaluations);
fprintf(fid,'EX2 source-domain sorption-anchor f1 range: %.8f to %.8f\n',v.EX2Anchor_f1_min,v.EX2Anchor_f1_max);
fprintf(fid,'Maximum EX2 conditioning target absolute error: %.3g\n',v.EX2TargetMaxAbsErr);
fprintf(fid,'Robust multisite/MWD structural claim: %d\n',v.RobustMWDStructuralClaim);
fprintf(fid,'Quantitatively separated total-C2 EPC envelopes: %d\n',v.QuantitativeC2EnvelopeSeparation);
fprintf(fid,'Important: all ranges are deterministic epistemic/model-form envelopes, not statistical confidence intervals.\n');
fclose(fid);
end
