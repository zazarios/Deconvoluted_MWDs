function B = stageG_jensen_support_bounds(M_gmol,sMin,sMax,cdfPad,rootTol,maxIter)
%STAGEG_JENSEN_SUPPORT_BOUNDS Pointwise second-stage CDF-difference bounds.
% Any admissible joint Stage-G state is enlarged to an arbitrary probability
% distribution of S=1/Mn over [sMin,sMax]. For each M,
% detailed CDF = E[Q_M(S)] and same-Mn collapsed CDF = Q_M(E[S]).
% stageG_jensen_gap_u_interval provides exact Jensen-gap extrema on the
% enclosing interval. The optional CDF pad preserves Stage-E finite-grid
% compatibility and is applied to both CDFs.
M=M_gmol(:)';
if ~(isscalar(sMin)&&isscalar(sMax)&&isfinite(sMin)&&isfinite(sMax)&&sMin>0&&sMax>=sMin)
    error('StageG:SupportRange','Invalid reciprocal-Mn support interval.');
end
if nargin<4 || isempty(cdfPad), cdfPad=0; end
if nargin<5 || isempty(rootTol), rootTol=1e-13; end
if nargin<6 || isempty(maxIter), maxIter=90; end
hmin=zeros(size(M)); hmax=zeros(size(M));
caseMin=cell(size(M)); caseMax=cell(size(M));
for k=1:numel(M)
    R=stageG_jensen_gap_u_interval(M(k)*sMin,M(k)*sMax,rootTol,maxIter);
    hmin(k)=R.hmin; hmax(k)=R.hmax; caseMin{k}=R.case_hmin; caseMax{k}=R.case_hmax;
end
numPad=2*cdfPad;
hmin=max(-1,hmin-numPad); hmax=min(1,hmax+numPad);
B=struct('hmin',hmin,'hmax',hmax,'s_min',sMin,'s_max',sMax, ...
    'cdf_pad_total',numPad,'max_abs_hmin',max(abs(hmin)),'max_abs_hmax',max(abs(hmax)), ...
    'case_hmin',{caseMin},'case_hmax',{caseMax});
end
