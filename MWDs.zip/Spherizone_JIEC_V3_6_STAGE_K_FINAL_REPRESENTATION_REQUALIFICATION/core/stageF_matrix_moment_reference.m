function [matrix,audit] = stageF_matrix_moment_reference(legacyMatrix)
%STAGEF_MATRIX_MOMENT_REFERENCE Use qualified Stage-E analytical matrix moments.
% Stage B1 computed MZCR matrix moments on the compact export M grid. That
% finite-grid numerical integration is adequate for graphics but carries a
% small truncation bias, especially in Mn. Stage E later exported analytical /
% high-resolution moments for the same qualified MZCR matrix. Stage F uses
% the Stage-E values so value-of-information results are not contaminated by
% an avoidable numerical-grid artifact.
root=fileparts(fileparts(mfilename('fullpath')));
f=fullfile(root,'inputs','StageEQualifiedOutputs','StageE_source_to_MZCR_distribution_retention.csv');
T=readtable(f);
j=find(strcmp(T.State,'MZCR_MATRIX'),1);
if isempty(j), error('StageF:MissingStageEMatrix','MZCR_MATRIX row missing from qualified Stage-E output.'); end
MnE=T.Mn_analytical_gmol(j); MwE=T.Mw_analytical_gmol(j);
if ~(isfinite(MnE) && MnE>0 && isfinite(MwE) && MwE>MnE)
    error('StageF:InvalidStageEMatrixMoments','Qualified Stage-E analytical matrix moments are invalid.');
end
matrix=legacyMatrix;
matrix.Mn_gmol=MnE; matrix.Mw_gmol=MwE; matrix.D=MwE/MnE;
mnBias=(legacyMatrix.Mn_gmol-MnE)/MnE;
mwBias=(legacyMatrix.Mw_gmol-MwE)/MwE;
audit=table(legacyMatrix.Mn_gmol,legacyMatrix.Mw_gmol,MnE,MwE,matrix.Mn_gmol,matrix.Mw_gmol,mnBias,mwBias,true, ...
    'VariableNames',{'LegacyCompactGrid_Mn_gmol','LegacyCompactGrid_Mw_gmol','StageE_Analytical_Mn_gmol','StageE_Analytical_Mw_gmol', ...
    'StageF_Mn_gmol','StageF_Mw_gmol','LegacyCompactGrid_Mn_relative_bias','LegacyCompactGrid_Mw_relative_bias','UsesStageEAnalyticalReference'});
end
