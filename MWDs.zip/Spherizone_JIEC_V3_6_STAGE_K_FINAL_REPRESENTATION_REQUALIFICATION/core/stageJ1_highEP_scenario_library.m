function S = stageJ1_highEP_scenario_library(cfg,P)
%STAGEJ1_HIGHEP_SCENARIO_LIBRARY Combine reference level and pattern.
levels=cfg.StageJ1.kappa_reference_levels;
rows=cell(0,12); n=0;
for il=1:numel(levels)
 L=levels(il); ell=log2(L);
 for ip=1:height(P)
  d=[P.d1(ip) P.d2(ip) P.d3(ip) P.d4(ip) P.d5(ip)];
  e=min(max(ell+d,log2(cfg.StageJ1.kappa_support(1))),log2(cfg.StageJ1.kappa_support(2)));
  kappa=2.^e; n=n+1;
  rows(n,:)={il,L,ip,P.PatternID{ip},P.PatternClass{ip},kappa(1),kappa(2),kappa(3),kappa(4),kappa(5),max(kappa)/min(kappa),'HIGH_EP_MECHANISTIC_STRESS'}; %#ok<AGROW>
 end
end
S=cell2table(rows,'VariableNames',{'LevelIndex','ReferenceKappa','PatternIndex','PatternID','PatternClass','kappa1','kappa2','kappa3','kappa4','kappa5','RealizedContrast','Status'});
end
