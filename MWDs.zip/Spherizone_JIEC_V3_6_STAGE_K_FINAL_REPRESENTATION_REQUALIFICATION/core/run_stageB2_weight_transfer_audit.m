function verdict = run_stageB2_weight_transfer_audit(cfg,outdir)
%RUN_STAGEB2_WEIGHT_TRANSFER_AUDIT Test transfer of PP-derived population weights to E/P stage.
% Stage B1 demonstrated robustness to composition-coupled Mn transfer but held
% second-stage population mass fractions equal to the transferred PP-derived
% Flory weights. Stage B2 explicitly stress-tests that assumption.

if ~exist(outdir,'dir'), mkdir(outdir); end

% Recreate refined Stage-B1 scientific objects.
anchor=ex2_sorption_anchor_envelope_B1(cfg);
primarySurface=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac, ...
    cfg.EX2.primary_r1_bounds,cfg.EX2.primary_r2_bounds,cfg.EX2.primary_n_r2,'PRIMARY_SCREEN_70C_ANCHOR');

mz=run_normalized_mzcr_demo(cfg); matrix=mz.matrix;
Tall=population_T80_envelope(cfg.FBR.H2_psi,cfg.MZCR.DoTi);
Tprimary=selectT_B2(Tall,cfg.StageB.primary_T_classes);
sorb=thermo_fbr_scenarios(cfg.FBR.gas);
S4=sorb(strcmp({sorb.name},'selectivity_C3_over_C2_4'));
S5=sorb(strcmp({sorb.name},'selectivity_C3_over_C2_5'));
Sprimary=[S4 S5];
C=site_response_scenarios(5,cfg.site_response.odds_span);
W=population_weight_transfer_scenarios(5,cfg.site_response.odds_span);
EPC=cfg.StageB.primary_EPC;
modes={'DIRECT_MN_TRANSFER','DP_REPEAT_MASS_CORRECTED'};

% Export the stress library explicitly.
WR=cell(numel(W),9);
for iw=1:numel(W)
    WR(iw,:)={W(iw).name,W(iw).class,W(iw).status,W(iw).yield_multiplier(1),W(iw).yield_multiplier(2), ...
        W(iw).yield_multiplier(3),W(iw).yield_multiplier(4),W(iw).yield_multiplier(5), ...
        max(W(iw).yield_multiplier)/min(W(iw).yield_multiplier)};
end
WT=cell2table(WR,'VariableNames',{'Scenario','Class','Status','m1','m2','m3','m4','m5','MaxToMinMultiplierRatio'});
writetable(WT,fullfile(outdir,'StageB2_weight_transfer_scenarios.csv'));

% Literature provenance: evidence motivates testing weight transfer but does
% not supply numerical multipliers for the Alshaiban catalyst.
Ev=table({'Zhang_et_al_2021_SI_CHMDMS';'Zhang_et_al_2021_SI_DCPDMS'}, ...
    {'E/P 0/100 to 50/50 changes active-center concentrations differently among C8-sol, C7-sol and C7-insol fractions.'; ...
     'E/P 0/100 to 50/50 changes active-center concentrations differently among C8-sol, C7-sol and C7-insol fractions.'}, ...
    {'Qualitative/model-form evidence only; different catalyst. No numerical transfer to Alshaiban populations.'; ...
     'Qualitative/model-form evidence only; different catalyst. No numerical transfer to Alshaiban populations.'}, ...
    'VariableNames',{'Source','ObservedPattern','PermittedUse'});
writetable(Ev,fullfile(outdir,'StageB2_external_weight_transfer_evidence.csv'));

% Three layers:
% W0 = B1 inherited population weights.
% WC = chemistry-response multiplier reused as a same-pattern weight stress.
% WI = weight-response pattern varies independently of chemistry-response pattern.
layers={'W0_INHERITED','WC_COUPLED_SAME_PATTERN_STRESS','WI_INDEPENDENT_FACTOR_TWO_STRESS'};
rows=cell(0,13);
compRows=cell(0,8);
structuralIndependent=true;

for il=1:numel(layers)
    lname=layers{il};
    for im=1:numel(modes)
        mode=modes{im};
        mnmin=inf(1,numel(EPC)); mnmax=-inf(1,numel(EPC));
        mwmin=inf(1,numel(EPC)); mwmax=-inf(1,numel(EPC));
        dmin=inf(1,numel(EPC)); dmax=-inf(1,numel(EPC));
        mindelta=inf(1,numel(EPC));
        cmin=inf; cmax=-inf;
        for it=1:numel(Tprimary)
            pop=Tprimary(it);
            for is=1:numel(Sprimary)
                for ic=1:numel(C)
                    switch lname
                        case 'W0_INHERITED'
                            Wuse=W(1);
                        case 'WC_COUPLED_SAME_PATTERN_STRESS'
                            Wuse=make_single_weight_B2(C(ic).ethylene_odds_multiplier,'WC_same_pattern');
                        case 'WI_INDEPENDENT_FACTOR_TWO_STRESS'
                            Wuse=W;
                        otherwise
                            error('Unknown B2 layer.');
                    end
                    P=stage_properties_weight_ensemble_B2(pop,Sprimary(is).f1_sorbed,primarySurface.r1,primarySurface.r2,C(ic),mode,Wuse);
                    cmin=min(cmin,min(P.C2_wtfrac(:))); cmax=max(cmax,max(P.C2_wtfrac(:)));
                    for ie=1:numel(EPC)
                        e=EPC(ie);
                        Bmn=1./((1-e)/matrix.Mn_gmol + e./P.Mn_gmol);
                        Bmw=(1-e)*matrix.Mw_gmol + e.*P.Mw_gmol;
                        Bd=Bmw./Bmn;
                        % Comparator has same phase Mn and final Mn, but each
                        % phase is replaced by a single Flory MPD (Mw=2Mn).
                        Smw=(1-e)*(2*matrix.Mn_gmol) + e.*(2*P.Mn_gmol);
                        Sd=Smw./Bmn;
                        delta=Bd-Sd;
                        mnmin(ie)=min(mnmin(ie),min(Bmn(:))); mnmax(ie)=max(mnmax(ie),max(Bmn(:)));
                        mwmin(ie)=min(mwmin(ie),min(Bmw(:))); mwmax(ie)=max(mwmax(ie),max(Bmw(:)));
                        dmin(ie)=min(dmin(ie),min(Bd(:))); dmax(ie)=max(dmax(ie),max(Bd(:)));
                        mindelta(ie)=min(mindelta(ie),min(delta(:)));
                    end
                end
            end
        end
        if strcmp(lname,'WI_INDEPENDENT_FACTOR_TWO_STRESS')
            structuralIndependent=structuralIndependent && all(mindelta>0);
        end
        start=size(rows,1)+1;
        for ie=1:numel(EPC)
            rows(end+1,:)={lname,mode,EPC(ie),mnmin(ie),mnmax(ie),mwmin(ie),mwmax(ie),dmin(ie),dmax(ie),mindelta(ie),NaN,NaN,NaN}; %#ok<AGROW>
        end
        idx=start:(start+numel(EPC)-1);
        for j=1:numel(EPC)-1
            rows{idx(j),11}=mnmax(j+1)-mnmin(j); % <0 means separated decreasing envelopes
            rows{idx(j),12}=mwmax(j+1)-mwmin(j); % <0 means separated decreasing envelopes
            rows{idx(j),13}=(mnmax(j+1)<mnmin(j)) && (mwmax(j+1)<mwmin(j));
        end
        % Composition does not depend on transferMode; export once per layer.
        if im==1
            for ie=1:numel(EPC)
                gap=NaN; sep=false;
                if ie<numel(EPC)
                    gap=EPC(ie+1)*cmin - EPC(ie)*cmax;
                    sep=gap>0;
                end
                compRows(end+1,:)={lname,EPC(ie),cmin,cmax,EPC(ie)*cmin,EPC(ie)*cmax,gap,sep}; %#ok<AGROW>
            end
        end
    end
end

MWD=cell2table(rows,'VariableNames',{'WeightTransferLayer','TransferMode','EPC_wtfrac','Mn_min','Mn_max','Mw_min','Mw_max','D_min','D_max', ...
    'MinDeltaD_vs_sameMn_singleFlory','MnGap_to_next_EPC','MwGap_to_next_EPC','Mn_and_Mw_Separated_from_next_EPC'});
writetable(MWD,fullfile(outdir,'StageB2_MWD_weight_transfer_envelopes.csv'));
Comp=cell2table(compRows,'VariableNames',{'WeightTransferLayer','EPC_wtfrac','StageC2_min','StageC2_max','TotalC2_min','TotalC2_max','Gap_to_next_EPC','Separated_from_next_EPC'});
writetable(Comp,fullfile(outdir,'StageB2_composition_weight_transfer_layers.csv'));

% Regression: W0 must reproduce Stage-B1 refined primary envelopes.
B1dir=fullfile(outdir,'B1Regression');
if ~exist(B1dir,'dir'), mkdir(B1dir); end
b1=run_stageB1_coupled_audit(cfg,B1dir);
B1M=readtable(fullfile(B1dir,'StageB1_coupled_MWD_envelopes.csv'));
W0=MWD(strcmp(MWD.WeightTransferLayer,'W0_INHERITED'),:);
regErr=0;
for i=1:height(B1M)
    modeB=string(B1M.TransferMode(i));
    j=find(string(W0.TransferMode)==modeB & abs(W0.EPC_wtfrac-B1M.EPC_wtfrac(i))<1e-12,1);
    if isempty(j), error('Stage-B2 regression row missing.'); end
    valsB=[B1M.Mn_min(i),B1M.Mn_max(i),B1M.Mw_min(i),B1M.Mw_max(i),B1M.D_min(i),B1M.D_max(i),B1M.MinDeltaD_vs_sameMn_singleFlory(i)];
    vals2=[W0.Mn_min(j),W0.Mn_max(j),W0.Mw_min(j),W0.Mw_max(j),W0.D_min(j),W0.D_max(j),W0.MinDeltaD_vs_sameMn_singleFlory(j)];
    regErr=max(regErr,max(abs(valsB-vals2)./max(abs(valsB),1)));
end
Reg=table(regErr,regErr<1e-10,'VariableNames',{'MaxRelativeDifference_B2W0_vs_B1','Pass'});
writetable(Reg,fullfile(outdir,'StageB2_B1_regression.csv'));

% Final verdict based on the independent factor-two weight-transfer stress.
WI=MWD(strcmp(MWD.WeightTransferLayer,'WI_INDEPENDENT_FACTOR_TWO_STRESS'),:);
quantSeparated=true;
for im=1:numel(modes)
    sub=WI(strcmp(WI.TransferMode,modes{im}),:);
    for j=1:height(sub)-1
        if ~sub.Mn_and_Mw_Separated_from_next_EPC(j), quantSeparated=false; end
    end
end
CI=Comp(strcmp(Comp.WeightTransferLayer,'WI_INDEPENDENT_FACTOR_TWO_STRESS'),:);
compSeparated=true;
for j=1:height(CI)-1
    if ~CI.Separated_from_next_EPC(j), compSeparated=false; end
end

if structuralIndependent && ~quantSeparated && ~compSeparated
    code='STRUCTURAL_MWD_HETEROGENEITY_SURVIVES_POPULATION_WEIGHT_TRANSFER_STRESS__QUANTITATIVE_GRADE_SEPARATION_NOT_IDENTIFIABLE__COMPOSITION_BARRIER_PERSISTS';
    summary=['Proceed to external trend/claim audit with a narrower structural claim. The multisite-vs-single-Flory broadening survives an independent factor-two relative population-yield stress, ' ...
        'but quantitative EPC-to-MWD grade separation and total-C2 separation do not survive this additional unresolved population-weight transfer.'];
elseif structuralIndependent
    code='STRUCTURAL_MWD_HETEROGENEITY_SURVIVES_POPULATION_WEIGHT_TRANSFER_STRESS';
    summary='Structural broadening survives the additional population-weight transfer stress; inspect quantitative separation tables before claim drafting.';
else
    code='STOP_OR_REPOSITION_STRUCTURAL_MWD_FAILS_POPULATION_WEIGHT_TRANSFER_STRESS';
    summary='The core structural MWD claim is not robust to unresolved second-stage population-weight transfer; do not proceed to manuscript reconstruction.';
end

verdict=struct('code',code,'summary',summary,'StructuralIndependentWeightStress',structuralIndependent, ...
    'QuantitativeMWDSeparatedIndependent',quantSeparated,'CompositionSeparatedIndependent',compSeparated,'RegressionPass',Reg.Pass(1));

fid=fopen(fullfile(outdir,'STAGE_B2_VERDICT.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.3 Stage-B2 population-weight transfer audit\n');
fprintf(fid,'Verdict: %s\n',code);
fprintf(fid,'%s\n',summary);
fprintf(fid,'B1 W0 regression pass: %d (max relative difference %.3g)\n',Reg.Pass(1),regErr);
fprintf(fid,'Structural broadening positive under independent factor-two weight stress: %d\n',structuralIndependent);
fprintf(fid,'Quantitative Mn+Mw EPC separation survives independent weight stress: %d\n',quantSeparated);
fprintf(fid,'Total-C2 EPC separation survives independent weight stress: %d\n',compSeparated);
fprintf(fid,'The factor-two yield multipliers are deliberate symmetric model-form stresses, not source-estimated catalyst parameters or confidence bounds.\n');
fprintf(fid,'Zhang et al. 2021 is used only to establish that E/P-dependent active-center redistribution exists; its numerical values are not transferred to the Alshaiban catalyst.\n');
fclose(fid);
end

function Tsel=selectT_B2(Tall,classes)
keep=false(1,numel(Tall));
for k=1:numel(Tall), keep(k)=any(strcmp(Tall(k).admissibility,classes)); end
Tsel=Tall(keep);
end

function W=make_single_weight_B2(mult,name)
W=struct('name',name,'class','WC','yield_multiplier',mult(:)', ...
    'status','SAME_PATTERN_COUPLED_MODEL_FORM_STRESS');
end
