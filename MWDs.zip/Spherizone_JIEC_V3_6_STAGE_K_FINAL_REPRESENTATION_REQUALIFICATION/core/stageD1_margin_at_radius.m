function margin = stageD1_margin_at_radius(ctx,cfg,coord,transferMode,property,EPC_low,EPC_high,radius)
%STAGED1_MARGIN_AT_RADIUS Adjacent-grade separation margin at arbitrary radius.
% Positive => separated under the Stage-D orientation; <= tolerance => overlap.
E=[EPC_low EPC_high];
switch char(coord)
    case 'U_W_TV'
        B=stageD1_UW_envelopes(ctx,radius,transferMode,E);
    case 'U_C_LOG_ODDS'
        B=stageD1_UC_envelopes(ctx,radius,transferMode,E,cfg.site_response.odds_span);
    otherwise
        error('Unknown uncertainty coordinate: %s',char(coord));
end
switch char(property)
    case 'Mn'
        margin=B.Mn_min(1)-B.Mn_max(2);
    case 'Mw'
        margin=B.Mw_min(1)-B.Mw_max(2);
    case 'C2'
        margin=B.C2_min(2)-B.C2_max(1);
    otherwise
        error('Unknown property: %s',char(property));
end
end
