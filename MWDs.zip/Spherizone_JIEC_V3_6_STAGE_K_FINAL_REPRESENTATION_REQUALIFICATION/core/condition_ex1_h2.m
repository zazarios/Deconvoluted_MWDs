function out = condition_ex1_h2(cfg)
%CONDITION_EX1_H2 Select H2 in the bracketed domain to match EX1 Mw target.
fun=@(h) ex1_mw_at_h2(h,cfg) - cfg.EX1.target_Mw_gmol;
h=fzero(fun,cfg.EX1.H2_search_psi);
pop=population_transfer(cfg.EX1.T_C,h,cfg.EX1.DoTi);
mix=mix_flory_populations(pop.w,pop.Mn_gmol,cfg.M_grid);
out=struct('H2_psi',h,'population',pop,'MWD',mix,'target_Mw_gmol',cfg.EX1.target_Mw_gmol);
end

function Mw = ex1_mw_at_h2(h,cfg)
pop=population_transfer(cfg.EX1.T_C,h,cfg.EX1.DoTi);
mix=mix_flory_populations(pop.w,pop.Mn_gmol,cfg.M_grid);
Mw=mix.Mw_analytical_gmol;
end
