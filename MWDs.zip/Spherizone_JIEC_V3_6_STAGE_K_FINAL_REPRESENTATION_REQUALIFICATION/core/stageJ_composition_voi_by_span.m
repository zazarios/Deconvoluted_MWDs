function [Baseline,Singleton] = stageJ_composition_voi_by_span(cfg,Tset,Sp,surf)
%STAGEJ_COMPOSITION_VOI_BY_SPAN Requalify composition singleton VOI by span.
% The first block combines the externally challenged FBR-H2 branch with the
% inherited T80 transfer scenario. Results remain finite-ensemble deterministic
% minimax contractions, not expected information gain.

fA=unique(surf.f1_EX2,'stable'); r2u=unique(surf.r2,'stable');
nT=numel(Tset); nS=numel(Sp); nA=numel(fA); nK=numel(r2u);
if height(surf)~=nA*nK, error('StageJ:NonRectangularSurface','EX2 feasible surface is not rectangular.'); end
blockNames={'FBR_H2_AND_T80_STATE','FBR_SORPTION','LATENT_CHEMISTRY','EX2_SORBED_F1','REACTIVITY_CURVE_COORD'};
baseRows=cell(0,5); oneRows=cell(0,10);
for ispan=1:numel(cfg.StageJ.chemistry_odds_spans)
    span=cfg.StageJ.chemistry_odds_spans(ispan);
    Cs=stageJ_nested_chemistry_scenarios(cfg,span); nC=numel(Cs);
    C2=zeros(nT,nS,nC,nA,nK);
    for it=1:nT
        for is=1:nS
            for ic=1:nC
                c=stage_c2_vectorized(Tset(it),Sp(is).f1_sorbed,surf.r1,surf.r2,Cs(ic));
                g=reshape(c,[nK nA])';
                C2(it,is,ic,:,:)=reshape(g,[1 1 1 nA nK]);
            end
        end
    end
    bmin=min(C2(:)); bmax=max(C2(:)); bw=bmax-bmin;
    baseRows(end+1,:)={span,bmin,bmax,bw,'SECOND_STAGE_C2_WTFRAC'}; %#ok<AGROW>
    sz=size(C2);
    for d=1:5
        perm=[d setdiff(1:5,d,'stable')];
        B=permute(C2,perm);
        B=reshape(B,[sz(d) prod(sz(setdiff(1:5,d,'stable')))]);
        widths=max(B,[],2)-min(B,[],2);
        worst=max(widths); best=min(widths);
        if bw>0, g=1-worst/bw; gb=1-best/bw; else, g=NaN; gb=NaN; end
        oneRows(end+1,:)={span,blockNames{d},d,bw,worst,best,g,gb,sz(d),'FINITE_ENSEMBLE_ORACLE_BLOCK_RESOLUTION'}; %#ok<AGROW>
    end
    clear C2
end
Baseline=cell2table(baseRows,'VariableNames',{'ChemistryOddsSpan','StageC2Min','StageC2Max','BaselineWidth','Quantity'});
Singleton=cell2table(oneRows,'VariableNames',{'ChemistryOddsSpan','ResolvedBlock','BlockIndex','BaselineWidth','WorstResidualWidth','BestResidualWidth', ...
    'GuaranteedContractionFraction','BestCaseContractionFraction','BlockStateCount','Status'});
end
