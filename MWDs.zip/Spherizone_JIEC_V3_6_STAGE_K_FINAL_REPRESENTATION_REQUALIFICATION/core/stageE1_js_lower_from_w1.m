function jsBits = stageE1_js_lower_from_w1(W1_decades,xDiameter_decades)
%STAGEE1_JS_LOWER_FROM_W1 Conservative JS lower bound on finite log-M support.
% W1 <= diameter*TV and Pinsker imply JS_bits >= TV^2/(2 ln 2).
if W1_decades<0 || xDiameter_decades<=0, error('StageE1:JSBoundInput','Invalid W1/diameter.'); end
TVlb=W1_decades/xDiameter_decades;
jsBits=(TVlb.^2)/(2*log(2));
end
