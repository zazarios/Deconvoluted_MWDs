function d = stageH1_group_minimax_descriptor(target,Mn0,members,mode,e,matrixMn,matrixMw,Mtail90,Mtail99,cfg)
%STAGEH1_GROUP_MINIMAX_DESCRIPTOR Best fixed scalar group descriptor.
% The descriptor is selected before hidden within-group weights and DP alpha
% values are known. It may depend only on target, EPC, T80 branch, transfer
% formulation, and fixed group membership.
vals=Mn0(members); a0=cfg.StageH1.M2_gmol/cfg.StageH1.M3_gmol;
if strcmpi(mode,'DIRECT_MN_TRANSFER')
    mlo=min(vals); mhi=max(vals);
else
    mlo=a0*min(vals); mhi=max(vals);
end
A=(1-e)/matrixMn; B=(1-e)*matrixMw;
lo=0; up=0; mhat=NaN; note='';
switch target
    case 'FINAL_W1_LOG10M'
        mhat=sqrt(mlo*mhi);
        up=e*0.5*log10(mhi/mlo); lo=up;
        note='Exact minimax over scale-family W1 support.';
    case 'FINAL_Mn_REL'
        Slo=A+e/mhi; Shi=A+e/mlo; Sh=0.5*(Slo+Shi);
        mhat=e/(Sh-A);
        up=(Shi-Slo)/(Shi+Slo); lo=up;
        note='Exact fractional-linear simplex minimax.';
    case 'FINAL_Mw_REL'
        Vlo=B+2*e*mlo; Vhi=B+2*e*mhi; H=2*Vlo*Vhi/(Vlo+Vhi);
        mhat=(H-B)/(2*e);
        up=(Vhi-Vlo)/(Vhi+Vlo); lo=up;
        note='Exact fractional-linear simplex minimax.';
    case {'TAIL_MASS_AT_MATRIX_M90_ABS','TAIL_MASS_AT_MATRIX_M99_ABS'}
        if strcmp(target,'TAIL_MASS_AT_MATRIX_M90_ABS'), Mt=Mtail90; else, Mt=Mtail99; end
        plo=tail_H1(Mt,mlo); phi=tail_H1(Mt,mhi); ph=0.5*(plo+phi);
        mhat=invert_tail_H1(Mt,ph,mlo,mhi,cfg);
        up=e*0.5*(phi-plo); lo=up;
        note='Exact minimax for linear fixed-threshold tail mass.';
    case 'FINAL_D_REL'
        [mhat,dmin,dmax]=descriptor_D_H1(mlo,mhi,e,A,B);
        Dhat=Dsingle_H1(mhat,e,A,B);
        % Admissible lower witness: each population alone, with its exact DP
        % alpha interval.  The final partition-level upper bound is assembled
        % separately from signed Mw/Mn ratio extrema.
        for jj=members
            if strcmpi(mode,'DIRECT_MN_TRANSFER')
                l=Mn0(jj); h=Mn0(jj);
            else
                l=a0*Mn0(jj); h=Mn0(jj);
            end
            ms=sqrt(B/(2*A)); ms=min(max(ms,l),h);
            cand=[l h ms];
            for q=1:numel(cand), lo=max(lo,abs(Dhat/Dsingle_H1(cand(q),e,A,B)-1)); end
        end
        up=max(abs(Dhat/dmin-1),abs(Dhat/dmax-1));
        note='Lower: admissible single-population chemistry witness; group support upper is conservative.';
    otherwise
        error('StageH1:Target','Unknown target %s',target);
end
d=struct('Mhat_gmol',mhat,'Mlo_gmol',mlo,'Mhi_gmol',mhi,'GroupLower',lo,'GroupUpper',up,'Note',note);
end

function p=tail_H1(Mt,m)
u=Mt/m;
if u>745, p=0; else, p=exp(-u)*(1+u); end
end
function m=invert_tail_H1(Mt,p,lo,hi,cfg)
if p<=tail_H1(Mt,lo)+1e-16, m=lo; return; end
if p>=tail_H1(Mt,hi)-1e-16, m=hi; return; end
for k=1:cfg.StageH1.max_bisection_iter
    mid=sqrt(lo*hi); pm=tail_H1(Mt,mid);
    if pm<p, lo=mid; else, hi=mid; end
    if abs(log(hi/lo))<cfg.StageH1.root_tol, break; end
end
m=sqrt(lo*hi);
end
function D=Dsingle_H1(m,e,A,B)
D=(B+2*e*m)*(A+e/m);
end
function [mhat,dmin,dmax]=descriptor_D_H1(mlo,mhi,e,A,B)
ms=sqrt(B/(2*A)); ms=min(max(ms,mlo),mhi);
dmin=Dsingle_H1(ms,e,A,B);
% Maximum over endpoint mixtures. D(t) is concave quadratic because
% (mlo-mhi)*(1/mlo-1/mhi)<0.
v0=B+2*e*mhi; v1=2*e*(mlo-mhi);
s0=A+e/mhi; s1=e*(1/mlo-1/mhi);
c0=v0*s0; c1=v0*s1+v1*s0; c2=v1*s1;
if c2<0, tv=min(max(-c1/(2*c2),0),1); else, tv=0; end
dmax=max([c0,c0+c1+c2,c0+c1*tv+c2*tv^2]);
ideal=2*dmin*dmax/(dmin+dmax);
dslo=Dsingle_H1(mlo,e,A,B); dshi=Dsingle_H1(mhi,e,A,B); dsmax=max(dslo,dshi);
target=min(max(ideal,dmin),dsmax);
% Solve 2eA*m^2 + (AB+2e^2-target)m + Be = 0.
aa=2*e*A; bb=A*B+2*e^2-target; cc=B*e;
disc=max(0,bb^2-4*aa*cc); roots=[(-bb-sqrt(disc))/(2*aa),(-bb+sqrt(disc))/(2*aa)];
valid=roots(roots>=mlo*(1-1e-10) & roots<=mhi*(1+1e-10));
if isempty(valid)
    cand=[mlo mhi ms]; [~,ix]=min(abs(arrayfun(@(z)Dsingle_H1(z,e,A,B),cand)-target)); mhat=cand(ix);
else
    gc=sqrt(mlo*mhi); [~,ix]=min(abs(log(valid/gc))); mhat=valid(ix);
end
end
