function A = stageE1_c0_dp_alpha_range(ctx)
%STAGEE1_C0_DP_ALPHA_RANGE Exact Stage-D C0 common repeat-mass scale range.
pop=ctx.Tp(1); active=find(pop.w>0 & isfinite(pop.Mn_gmol));
if isempty(active), error('StageE1:NoActivePopulations','No active T80 populations.'); end
vals=[]; spreadMax=0;
for is=1:numel(ctx.Sp)
    st=stage_population_state(pop,ctx.Sp(is).f1_sorbed,ctx.surf.r1,ctx.surf.r2,ctx.C0,'DP_REPEAT_MASS_CORRECTED');
    ratios=bsxfun(@rdivide,st.MnJ(:,active),pop.Mn_gmol(active));
    spread=max(ratios,[],2)-min(ratios,[],2);
    spreadMax=max(spreadMax,max(abs(spread)));
    vals=[vals; ratios(:,1)]; %#ok<AGROW>
end
if spreadMax>1e-12
    error('StageE1:C0ScaleNotCommon','C0 DP repeat-mass correction is not common across populations.');
end
A=struct('alpha_min',min(vals),'alpha_max',max(vals),'n_exact_states',numel(vals), ...
    'max_population_ratio_spread',spreadMax);
end
