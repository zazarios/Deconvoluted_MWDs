function result = run_stageG_joint_uncertainty_closure(cfg,outdir)
%RUN_STAGEG_JOINT_UNCERTAINTY_CLOSURE Final structural robustness closure.
% No new physical model is introduced. Stage G simultaneously enlarges the
% Stage-D U_W and U_C domains and retains every qualified primary T80
% population-transfer scenario. The resulting support interval is a
% conservative superset of the exact joint domain.
if ~exist(outdir,'dir'), mkdir(outdir); end
M=cfg.StageE.metric_M_grid(:)'; x=log10(M); xdiam=x(end)-x(1);
cfgH=cfg; cfgH.M_output_grid=M;
mz=run_normalized_mzcr_demo(cfgH); matrix=mz.matrix;
MC=stageE1_matrix_cdf_difference(matrix,M);
ctx=stageD1_build_context(cfg);
a0=cfg.StageG.M2_gmol/cfg.StageG.M3_gmol;

Rows=struct([]);
for it=1:numel(ctx.Tp)
    pop=ctx.Tp(it);
    active=pop.w>0 & isfinite(pop.Mn_gmol) & pop.Mn_gmol>0;
    if ~any(active), error('StageG:NoActivePopulations','No active T80 populations.'); end
    Mn=pop.Mn_gmol(active);
    sLo=min(1./Mn);
    for im=1:numel(ctx.modes)
        mode=ctx.modes{im};
        if strcmpi(mode,'DIRECT_MN_TRANSFER')
            sHi=max(1./Mn);
            alphaMin=1;
            domain='Full active-population simplex; chemistry is MWD-invariant; discrete reciprocal-Mn support enlarged to its enclosing continuous interval.';
            note='Conservative continuous-support superset of exact DIRECT joint U_W x U_C domain.';
        else
            sHi=max(1./(a0.*Mn));
            alphaMin=a0;
            domain=sprintf('Full active-population simplex; independent alpha_j in [%.10g,1]; reciprocal-Mn support enlarged to its enclosing continuous interval.',a0);
            note='Conservative superset of exact DP joint U_W x U_C chemistry manifold and weight domain.';
        end
        HB=stageG_jensen_support_bounds(M,sLo,sHi,cfg.StageG.finite_grid_cdf_pad,cfg.StageG.root_tol,cfg.StageG.max_bisection_iter);
        for ie=1:numel(cfg.StageG.EPC)
            e=cfg.StageG.EPC(ie);
            W=stageE1_w1_lower_from_h_bounds(M,MC.A,HB.hmin,HB.hmax,e);
            rr=struct();
            rr.TransferMode=mode; rr.EPC_wtfrac=e; rr.TScenario=pop.name; rr.TAdmissibility=pop.admissibility;
            rr.W1_certified_joint_lower_decades=W.W1_lower_decades;
            rr.W1_attainable_vertex_upper_decades=(1-e)*MC.W1_decades;
            rr.W1_joint_min_bracket_width_decades=rr.W1_attainable_vertex_upper_decades-rr.W1_certified_joint_lower_decades;
            rr.JS_certified_joint_lower_bits=stageE1_js_lower_from_w1(W.W1_lower_decades,xdiam);
            rr.ReciprocalMnSupport_min_per_gmol=sLo; rr.ReciprocalMnSupport_max_per_gmol=sHi;
            rr.Alpha_min=alphaMin; rr.Alpha_max=1; rr.CDF_pad_total=HB.cdf_pad_total;
            rr.DomainStatement=domain; rr.Note=note;
            Rows=append_G(Rows,rr); %#ok<AGROW>
        end
    end
end
ByT=struct2table(Rows);
writetable(ByT,fullfile(outdir,'StageG_joint_W1_bounds_by_T.csv'));

% Summary across the entire qualified primary T80 ensemble.
Sum=struct([]);
for im=1:numel(ctx.modes)
    mode=ctx.modes{im};
    for ie=1:numel(cfg.StageG.EPC)
        e=cfg.StageG.EPC(ie);
        ix=strcmp(ByT.TransferMode,mode) & abs(ByT.EPC_wtfrac-e)<1e-12;
        [lo,krel]=min(ByT.W1_certified_joint_lower_decades(ix));
        idx=find(ix); k=idx(krel);
        up=min(ByT.W1_attainable_vertex_upper_decades(ix));
        rr=struct('TransferMode',mode,'EPC_wtfrac',e,'W1_certified_joint_lower_decades',lo, ...
            'W1_attainable_vertex_upper_decades',up,'W1_joint_min_bracket_width_decades',up-lo, ...
            'JS_certified_joint_lower_bits',stageE1_js_lower_from_w1(lo,xdiam), ...
            'WorstTScenario',ByT.TScenario{k},'WorstTAdmissibility',ByT.TAdmissibility{k});
        Sum=append_G(Sum,rr); %#ok<AGROW>
    end
end
Summary=struct2table(Sum);
writetable(Summary,fullfile(outdir,'StageG_joint_W1_bounds_summary.csv'));

[globalLo,ig]=min(Summary.W1_certified_joint_lower_decades);
globalUp=Summary.W1_attainable_vertex_upper_decades(ig);
Closure=table(globalLo,globalUp,globalUp-globalLo,Summary.TransferMode(ig),Summary.EPC_wtfrac(ig),Summary.WorstTScenario(ig), ...
    {['CERTIFIED_POSITIVE_OVER_CONSERVATIVE_JOINT_SUPERSET: full weight simplex x chemistry support x primary T80 ensemble. ' ...
      'This closes the structural full-MWD retention claim only; it does not identify composition or grade-level moments.']}, ...
    'VariableNames',{'Global_W1_certified_joint_lower_decades','Global_W1_attainable_vertex_upper_decades', ...
    'Global_bracket_width_decades','WorstTransferMode','WorstEPC_wtfrac','WorstTScenario','ClaimStatus'});
writetable(Closure,fullfile(outdir,'StageG_structural_claim_closure.csv'));

Metric={'W1_log10M';'JS_divergence_bits';'M90_ratio';'M99_ratio';'TailExcessAboveCollapsedM90';'StageC2_wtfrac';'Grade_Mn_Mw_D'};
Status={'CERTIFIED_JOINT_LOWER_BOUND';'DERIVED_CONSERVATIVE_LOWER_BOUND_FROM_W1'; ...
    'NOT_JOINTLY_CERTIFIED';'NOT_JOINTLY_CERTIFIED';'NOT_JOINTLY_CERTIFIED'; ...
    'NOT_A_STAGE_G_TARGET';'NOT_A_STAGE_G_TARGET'};
Meaning={'Primary Stage-G structural-closure metric.';'Pinsker/support-diameter consequence; intentionally loose.'; ...
    'Retain Stage-E adverse-witness magnitude only.';'Retain Stage-E adverse-witness magnitude only.'; ...
    'Retain Stage-E adverse-witness magnitude only.';'Stage F remains the composition-identifiability result.'; ...
    'Stage F remains the quantitative-moment identifiability result.'};
Scope=table(Metric,Status,Meaning); writetable(Scope,fullfile(outdir,'StageG_metric_scope.csv'));

Diag=table(MC.W1_decades,a0,numel(ctx.Tp),numel(ctx.modes),numel(cfg.StageG.EPC),cfg.StageG.finite_grid_cdf_pad, ...
    min(ByT.W1_certified_joint_lower_decades),max(ByT.W1_joint_min_bracket_width_decades), ...
    'VariableNames',{'Matrix_W1_decades','DP_alpha_min','Primary_T80_scenario_count','Transfer_mode_count','EPC_count', ...
    'FiniteGrid_CDF_pad_per_CDF','Minimum_joint_W1_lower_decades','Maximum_joint_bracket_width_decades'});
writetable(Diag,fullfile(outdir,'StageG_numerical_diagnostics.csv'));

result=struct('ByT',ByT,'Summary',Summary,'Closure',Closure,'MetricScope',Scope,'Diagnostics',Diag, ...
    'matrixW1',MC.W1_decades,'matrix',matrix,'ctx',ctx);
end

function A=append_G(A,r)
if isempty(A), A=r; return; end
if ~isequal(fieldnames(A),fieldnames(r)), error('StageG:StructSchemaMismatch','Stage-G record schema mismatch.'); end
A(end+1)=r;
end
