function V = verify_stageK_final_representation_requalification(cfg,outdir,result)
%VERIFY_STAGEK_FINAL_REPRESENTATION_REQUALIFICATION Executable K gates.
ROOT=fileparts(fileparts(mfilename('fullpath')));
G={};S={};D={};
add=@(g,s,d) assignin('caller','_stageK_gate_tmp',{g,s,d}); %#ok<NASGU>

% local gate append helper implemented explicitly for MATLAB compatibility.
[G,S,D]=gate(G,S,D,'K0_STAGE_J1_PREREQUISITE',gateJ1(ROOT), ...
    'Qualified Stage J.1 with all J1_0-J1_21 gates PASS is frozen upstream.');

branches=cfg.StageK.expected_branch_names; counts=zeros(size(branches));
for i=1:numel(branches),counts(i)=sum(strcmp(result.StateAudit.H2Branch,branches{i}));end
ok=height(result.StateAudit)==cfg.StageK.expected_T_state_count && isequal(counts,cfg.StageK.expected_branch_counts);
[G,S,D]=gate(G,S,D,'K1_FINAL_STATE_SUPPORT',ok,sprintf('states=%d; branch counts=[%s]',height(result.StateAudit),num2str(counts)));

% Frozen Stage-H five T80 states must be an exact subset of the final legacy branch.
OH=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageHQualifiedOutputs','StageH_pair_witnesses.csv'));
oldT=unique(string(OH.TScenario),'stable');
q=strcmp(result.StateAudit.H2Branch,'LEGACY_5MOL_H2');newBase=string(result.StateAudit.TBaseScenario(q));
missing=setdiff(oldT,newBase);
[G,S,D]=gate(G,S,D,'K2_FROZEN_H_DOMAIN_SUBSET',isempty(missing),sprintf('old states=%d; final legacy states=%d; missing=%d',numel(oldT),numel(newBase),numel(missing)));

alpha0=cfg.StageH.M2_gmol/cfg.StageH.M3_gmol;
ok=result.AlphaAudit.J1ContainedByFrozenRepeatMassSupport(1)==1 && abs(result.AlphaAudit.FrozenAlphaMin(1)-alpha0)<1e-14 && abs(result.AlphaAudit.FrozenAlphaMax(1)-1)<1e-14;
[G,S,D]=gate(G,S,D,'K3_J1_CHEMISTRY_CONTAINED_BY_FROZEN_ALPHA',ok,sprintf('alpha=[%.12g,1]; J1 C2=[%.6g,%.6g]',alpha0,result.AlphaAudit.J1_StageC2Min(1),result.AlphaAudit.J1_StageC2Max(1)));

[G,S,D]=gate(G,S,D,'K4_H_EXPANDED_DOMAIN_MONOTONIC',all(result.CmpH.ExpandedDomainNotBetterGuard),sprintf('%d/%d rows satisfy final lower/upper >= frozen.',sum(result.CmpH.ExpandedDomainNotBetterGuard),height(result.CmpH)));
[G,S,D]=gate(G,S,D,'K5_H1_EXPANDED_DOMAIN_MONOTONIC',all(result.CmpH1.ExpandedDomainNotBetterGuard),sprintf('%d/%d rows satisfy final lower/upper >= frozen.',sum(result.CmpH1.ExpandedDomainNotBetterGuard),height(result.CmpH1)));
[G,S,D]=gate(G,S,D,'K6_H2_EXPANDED_DOMAIN_MONOTONIC',all(result.CmpH2.ExpandedDomainNotBetterGuard),sprintf('%d/%d rows satisfy final lower/upper >= frozen.',sum(result.CmpH2.ExpandedDomainNotBetterGuard),height(result.CmpH2)));

[ok,detail]=mirrorModerate(fullfile(ROOT,'Independent_Audit','StageK_expected_H_moderate_order.csv'),result.H.OrderMap,'H');
[G,S,D]=gate(G,S,D,'K7_H_ORACLE_MODERATE_INDEPENDENT_MIRROR',ok,detail);
[ok,detail]=mirrorModerate(fullfile(ROOT,'Independent_Audit','StageK_expected_H1_moderate_order.csv'),result.H1.OrderMap,'H1');
[G,S,D]=gate(G,S,D,'K8_H1_MODERATE_INDEPENDENT_MIRROR',ok,detail);
[ok,detail]=mirrorModerate(fullfile(ROOT,'Independent_Audit','StageK_expected_H2_moderate_order.csv'),result.H2.OrderMap,'H2');
[G,S,D]=gate(G,S,D,'K9_H2_MODERATE_INDEPENDENT_MIRROR',ok,detail);

[G,S,D]=gate(G,S,D,'K10_H_ORDER_NO_INVALID_IMPROVEMENT',~any(result.OrderH.InvalidImprovement),sprintf('invalid improvements=%d',sum(result.OrderH.InvalidImprovement)));
[G,S,D]=gate(G,S,D,'K11_H1_ORDER_NO_INVALID_IMPROVEMENT',~any(result.OrderH1.InvalidImprovement),sprintf('invalid improvements=%d',sum(result.OrderH1.InvalidImprovement)));
[G,S,D]=gate(G,S,D,'K12_H2_ORDER_NO_INVALID_IMPROVEMENT',~any(result.OrderH2.InvalidImprovement),sprintf('invalid improvements=%d',sum(result.OrderH2.InvalidImprovement)));

% H2 global minimax cannot beat H1 T80-conditional minimax over the same final set.
P=result.H2.PenaltyTable;
[G,S,D]=gate(G,S,D,'K13_GLOBALIZATION_NOT_BETTER_THAN_CONDITIONAL',all(P.GlobalNotBetterGuard),sprintf('%d/%d rows satisfy H2 upper >= H1 upper.',sum(P.GlobalNotBetterGuard),height(P)));

% Oracle Mn remains exactly preserved by the harmonic-Mn reduction construction.
q=strcmp(result.H.OrderMap.Target,'FINAL_Mn_REL');
ok=all(result.H.OrderMap.K_projection_certified_sufficient(q)==1);
[G,S,D]=gate(G,S,D,'K14_ORACLE_MN_INVARIANT',ok,sprintf('%d Mn tolerance rows; K*=1 rows=%d',sum(q),sum(result.H.OrderMap.K_projection_certified_sufficient(q)==1)));

% Target dependence must survive in the oracle moderate map at every EPC.
Om=result.H.OrderMap(strcmp(result.H.OrderMap.ToleranceLabel,'MODERATE'),:);ok=true;det={};
for e=cfg.StageH.EPC
 k=Om.K_projection_certified_sufficient(abs(Om.EPC_wtfrac-e)<1e-12);u=unique(k(isfinite(k)));ok=ok&&numel(u)>=2;det{end+1}=sprintf('EPC %.1f: %s',e,num2str(u')); %#ok<AGROW>
end
[G,S,D]=gate(G,S,D,'K15_ORACLE_TARGET_DEPENDENCE_PERSISTS',ok,strjoin(det,'; '));

% Global fixed-descriptor closure barrier should remain substantial.
O2=result.H2.OrderMap(strcmp(result.H2.OrderMap.ToleranceLabel,'MODERATE'),:);nFail=sum(isnan(O2.K_global_certified_sufficient));
[G,S,D]=gate(G,S,D,'K16_GLOBAL_FIXED_DESCRIPTOR_BARRIER_PERSISTS',nFail>=15,sprintf('moderate no-closure rows=%d/18',nFail));

% No projection/tolerance definitions changed.
ok=isequal(cfg.StageH.W1_tolerances_decades,[0.01 0.02 0.05]) && isequal(cfg.StageH.scalar_rel_tolerances,[0.01 0.025 0.05]) && isequal(cfg.StageH.tail_mass_abs_tolerances,[0.01 0.025 0.05]);
[G,S,D]=gate(G,S,D,'K17_FROZEN_TOLERANCE_BANDS',ok,'H/H.1/H.2 TIGHT/MODERATE/COARSE bands unchanged.');

% Map cardinality and no forced K on failed fixed closures.
ok=height(result.H.OrderMap)==54 && height(result.H1.OrderMap)==54 && height(result.H2.OrderMap)==54;
[G,S,D]=gate(G,S,D,'K18_ORDER_MAP_CARDINALITY',ok,sprintf('H=%d H1=%d H2=%d',height(result.H.OrderMap),height(result.H1.OrderMap),height(result.H2.OrderMap)));
q=isnan(result.H1.OrderMap.K_fixed_certified_sufficient);ok=all(startsWith(string(result.H1.OrderMap.FixedClosureStatus(q)),'NO_'));
q2=isnan(result.H2.OrderMap.K_global_certified_sufficient);ok=ok&&all(startsWith(string(result.H2.OrderMap.GlobalClosureStatus(q2)),'NO_'));
[G,S,D]=gate(G,S,D,'K19_NO_FORCED_K_ON_FAILURE',ok,'NaN K retained wherever fixed/global closure is not certified.');

% Scope guards.
C=result.Claims;
ok=scopeIs(C,'J1_CHEMISTRY_REQUIRES_ALPHA_SUPPORT_BEYOND_FROZEN_H_RANGE','NO') && scopeIs(C,'INDUSTRIAL_ICP_VALIDATION','NOT_ESTABLISHED') && scopeIs(C,'ONE_UNIFIED_REDUCED_MODEL_FOR_ALL_TARGETS','NOT_ESTABLISHED');
[G,S,D]=gate(G,S,D,'K20_SCOPE_GUARDS',ok,'No validation, chemistry-transfer, or universal-reduced-model overclaim.');

req={'StageK_state_support.csv','StageK_J1_repeat_mass_support_audit.csv','StageK_H_target_order_map.csv','StageK_H1_target_order_map.csv','StageK_H2_target_order_map.csv','StageK_moderate_order_snapshot.csv','StageK_claim_scope.csv'};
ok=true;for i=1:numel(req),ok=ok&&exist(fullfile(outdir,req{i}),'file')==2;end
[G,S,D]=gate(G,S,D,'K21_REQUIRED_OUTPUTS_PRESENT',ok,sprintf('%d required result files checked.',numel(req)));

% Final scientific semantic gate: J.1 state/domain is represented without
% recalibrating projection rules or external data.
ok=contains(cfg.StageK.note,'changes only') || contains(cfg.StageK.note,'expands only');
[G,S,D]=gate(G,S,D,'K22_REQUALIFICATION_ONLY_SEMANTICS',ok,'Stage K changes state support only; no representation redesign or external fitting.');

V=table(G',S',D','VariableNames',{'Gate','Status','Detail'});writetable(V,fullfile(outdir,'StageK_verification.csv'));
end

function [G,S,D]=gate(G,S,D,name,ok,detail)
G{end+1}=name; if ok,S{end+1}='PASS';else,S{end+1}='FAIL';end;D{end+1}=detail;
end
function ok=gateJ1(ROOT)
f=fullfile(ROOT,'inputs','StageJ1QualifiedOutputs','STAGE_J1_STATUS.txt');v=fullfile(ROOT,'inputs','StageJ1QualifiedOutputs','StageJ1_verification.csv');
ok=exist(f,'file')==2&&contains(fileread(f),'All executable Stage-J.1 integrity/scope gates pass: 1')&&exist(v,'file')==2;
if ok,T=stageJ_read_csv_strict(v);ok=height(T)==22&&all(strcmp(string(T.Status),'PASS'));end
end
function [ok,detail]=mirrorModerate(file,O,kind)
E=stageJ_read_csv_strict(file);q=strcmp(string(O.ToleranceLabel),'MODERATE');O=O(q,:);bad=0;
for i=1:height(E)
 m=strcmp(string(O.Target),string(E.Target(i)))&abs(O.EPC_wtfrac-E.EPC_wtfrac(i))<1e-12;
 if sum(m)~=1,bad=bad+1;continue;end
 if strcmp(kind,'H'),k=O.K_projection_certified_sufficient(m);st=string(O.ProjectionKstarStatus(m));elseif strcmp(kind,'H1'),k=O.K_fixed_certified_sufficient(m);st=string(O.FixedClosureStatus(m));else,k=O.K_global_certified_sufficient(m);st=string(O.GlobalClosureStatus(m));end
 ek=E.ExpectedCertifiedK(i); if xor(isnan(k),isnan(ek)) || (~isnan(k)&&abs(k-ek)>1e-12) || st~=string(E.ExpectedStatus(i)),bad=bad+1;end
end
ok=bad==0;detail=sprintf('%d expected rows; mismatches=%d',height(E),bad);
end
function ok=scopeIs(C,claim,status)
q=strcmp(string(C.Claim),claim);ok=sum(q)==1&&strcmp(string(C.Status(q)),status);
end
