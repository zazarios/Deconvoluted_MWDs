function R = rtd_ensemble(cfg)
%RTD_ENSEMBLE RTD alternatives for the conditional steady-property model.
% With EPC fraction externally specified and local stage properties steady,
% normalized MWD/composition are RTD-invariant. The code records this rather
% than inventing a residence-time kinetic effect.
names=cfg.RTD.names; Ns=cfg.RTD.N;
R=repmat(struct('name','','N',NaN,'normalized_property_multiplier',1, ...
    'note','RTD-invariant in conditional steady-property mode; RTD affects yield only in optional kinetic/yield mode.'),1,numel(names));
for k=1:numel(names), R(k).name=names{k}; R(k).N=Ns(k); end
end
