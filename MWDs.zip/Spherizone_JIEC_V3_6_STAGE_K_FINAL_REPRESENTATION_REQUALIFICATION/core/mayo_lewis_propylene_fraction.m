function F1 = mayo_lewis_propylene_fraction(f1, r1, r2)
%MAYO_LEWIS_PROPYLENE_FRACTION Instantaneous propylene mole fraction in polymer.
q=1-f1;
den=r1.*f1.^2 + 2.*f1.*q + r2.*q.^2;
if any(den(:)<=0), error('Non-positive Mayo-Lewis denominator.'); end
F1=(r1.*f1.^2 + f1.*q)./den;
end
