function out = stageH_pair_shape_witness(s1,s2,Mgrid,Mtail90,Mtail99,cfg)
%STAGEH_PAIR_SHAPE_WITNESS Admissible pair-state lower-bound witness.
% A fixed, pre-specified t grid is used. Therefore the reported maxima are
% guaranteed attainable lower bounds on the true pair worst case; they are
% not presented as exact global maxima.
M=Mgrid(:)'; x=log10(M); q1=stageH_flory_cdf(M,s1); q2=stageH_flory_cdf(M,s2);
tg=linspace(0,1,cfg.StageH.witness_t_points);
bW=-Inf;b90=-Inf;b99=-Inf;tW=NaN;t90=NaN;t99=NaN;
q190=stageH_flory_cdf(Mtail90,s1);q290=stageH_flory_cdf(Mtail90,s2);
q199=stageH_flory_cdf(Mtail99,s1);q299=stageH_flory_cdf(Mtail99,s2);
for k=1:numel(tg)
    t=tg(k); sb=t*s1+(1-t)*s2;
    h=t.*q1+(1-t).*q2-stageH_flory_cdf(M,sb);
    v=trapz(x,abs(h));
    if v>bW, bW=v;tW=t;end
    v90=abs(t*q190+(1-t)*q290-stageH_flory_cdf(Mtail90,sb));
    if v90>b90,b90=v90;t90=t;end
    v99=abs(t*q199+(1-t)*q299-stageH_flory_cdf(Mtail99,sb));
    if v99>b99,b99=v99;t99=t;end
end
out=struct('StageW1_witness_decades',max(0,bW),'StageTail90_witness_abs',max(0,b90), ...
    'StageTail99_witness_abs',max(0,b99),'t_W1',tW,'t_Tail90',t90,'t_Tail99',t99);
end
