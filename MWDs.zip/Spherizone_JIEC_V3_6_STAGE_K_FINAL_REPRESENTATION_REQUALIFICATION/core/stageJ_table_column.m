function col = stageJ_table_column(T, requestedName)
%STAGEJ_TABLE_COLUMN Robustly resolve a CSV/table column by original header.
% Handles MATLAB readtable VariableNamingRule='modify' behavior by checking
% current VariableNames, saved VariableDescriptions, and makeValidName.
requestedName = string(requestedName);
names = string(T.Properties.VariableNames);
idx = find(names == requestedName, 1);

if isempty(idx)
    try
        desc = string(T.Properties.VariableDescriptions);
        if numel(desc) == numel(names)
            idx = find(desc == requestedName, 1);
        end
    catch
        % Older/alternate table metadata: fall through to makeValidName.
    end
end

if isempty(idx)
    validName = string(matlab.lang.makeValidName(char(requestedName)));
    idx = find(names == validName, 1);
end

if isempty(idx)
    error('StageJ:MissingTableColumn', ...
        'Required table column "%s" was not found. Available variables: %s', ...
        char(requestedName), strjoin(cellstr(names), ', '));
end

col = T{:,idx};
end
