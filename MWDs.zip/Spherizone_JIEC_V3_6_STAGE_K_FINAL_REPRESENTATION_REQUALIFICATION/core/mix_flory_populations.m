function out = mix_flory_populations(w, Mn_gmol, M_grid)
%MIX_FLORY_POPULATIONS Mixture MWD and analytical/numerical moments.

w = w(:)'; Mn_gmol = Mn_gmol(:)';
if numel(w) ~= numel(Mn_gmol), error('w and Mn_gmol lengths differ.'); end
if any(w < -1e-14) || ~isfinite(sum(w)), error('Invalid population weights.'); end
active = w > 0;
if any(~isfinite(Mn_gmol(active)) | Mn_gmol(active)<=0)
    error('Active populations require finite positive Mn.');
end
w(~active) = 0;
w = w / sum(w);

M = M_grid(:)';
g = zeros(size(M));
for j = find(active)
    g = g + w(j) .* flory_logweight_pdf(M, Mn_gmol(j));
end
x = log10(M);
Z = trapz(x,g);
if Z <= 0 || ~isfinite(Z), error('MWD normalization failed.'); end

Mn_a = 1 / sum(w(active) ./ Mn_gmol(active));
Mw_a = sum(w(active) .* (2 .* Mn_gmol(active)));
D_a = Mw_a / Mn_a;

% Numerical molecular averages from the normalized weight distribution.
gn = g ./ Z;
invMn_n = trapz(x, gn ./ M);
Mn_n = 1 / invMn_n;
Mw_n = trapz(x, gn .* M);

out.M_gmol = M;
out.dW_dlog10M = gn;
out.raw_integral = Z;
out.w = w;
out.Mn_population_gmol = Mn_gmol;
out.Mn_analytical_gmol = Mn_a;
out.Mw_analytical_gmol = Mw_a;
out.D_analytical = D_a;
out.Mn_numerical_gmol = Mn_n;
out.Mw_numerical_gmol = Mw_n;
out.D_numerical = Mw_n/Mn_n;
end
