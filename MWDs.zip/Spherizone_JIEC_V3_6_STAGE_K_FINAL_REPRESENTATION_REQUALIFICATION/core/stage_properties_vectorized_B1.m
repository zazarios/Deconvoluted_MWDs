function out = stage_properties_vectorized_B1(pop,f1_sorbed,r1vec,r2vec,response,transferMode)
%STAGE_PROPERTIES_VECTORIZED_B1 Coupled stage composition and MWD moments.
% transferMode:
%   DIRECT_MN_TRANSFER       - transfers PP-derived population Mn directly.
%   DP_REPEAT_MASS_CORRECTED - transfers population DPn=Mn_PP/M_C3 and
%                              rescales by the predicted repeat-unit molar
%                              mass of each population.
% Neither mode is a full copolymerization kinetic model. Their spread is an
% explicit MWD-transfer model-form diagnostic.
M3=42.08; M2=28.05;
w=pop.w(:)'; w=max(w,0); w=w/sum(w);
Mn0=pop.Mn_gmol(:)';
active=w>0 & isfinite(Mn0);
if ~any(active), error('No active MWD populations.'); end
mult=response.ethylene_odds_multiplier(:)';
if numel(mult)~=numel(w), error('Response multiplier length mismatch.'); end
r1=r1vec(:); r2=r2vec(:);
odds=(1-f1_sorbed)/f1_sorbed;
f1j=1./(1+mult.*odds); % sorbed propylene fraction per latent population
q=1-f1j;
den=r1.*(f1j.^2) + 2.*f1j.*q + r2.*(q.^2);
if any(den(:)<=0), error('Non-positive Mayo-Lewis denominator.'); end
F1=(r1.*(f1j.^2)+f1j.*q)./den; % polymer propylene mole fraction, n x npop
C2=(1-F1).*M2 ./ (F1.*M3 + (1-F1).*M2);
out.C2_wtfrac=C2*w';

switch upper(transferMode)
    case 'DIRECT_MN_TRANSFER'
        MnJ=repmat(Mn0,numel(r1),1);
    case 'DP_REPEAT_MASS_CORRECTED'
        repeatM=F1.*M3 + (1-F1).*M2;
        MnJ=(Mn0./M3).*repeatM;
    otherwise
        error('Unknown transferMode: %s',transferMode);
end
wa=w(active);
MnA=MnJ(:,active);
out.Mn_gmol=1./sum(wa./MnA,2);
out.Mw_gmol=2*sum(wa.*MnA,2);
out.D=out.Mw_gmol./out.Mn_gmol;
out.transferMode=transferMode;
end
