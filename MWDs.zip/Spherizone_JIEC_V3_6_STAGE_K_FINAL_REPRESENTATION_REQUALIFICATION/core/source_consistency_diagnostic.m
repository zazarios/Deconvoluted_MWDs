function T = source_consistency_diagnostic(M_grid)
%SOURCE_CONSISTENCY_DIAGNOSTIC Compare published deconvolution descriptors
% with the whole-polymer GPC moments printed in the same source papers.
% This is a source-fidelity diagnostic, not a fitting objective.

pop=data_flory_populations(); rep=data_source_whole_moments();
if numel(pop)~=numel(rep), error('Source moment record count mismatch.'); end
n=numel(pop);
R=cell(n,13);
for k=1:n
    rr=rep(strcmp({rep.id},pop(k).id));
    if isempty(rr), error('Missing whole-polymer source moments for %s.',pop(k).id); end
    m=mix_flory_populations(pop(k).w,pop(k).Mn_gmol,M_grid);
    eMn=(m.Mn_analytical_gmol-rr.Mn_reported_gmol)/rr.Mn_reported_gmol;
    eMw=(m.Mw_analytical_gmol-rr.Mw_reported_gmol)/rr.Mw_reported_gmol;
    eD=(m.D_analytical-rr.D_reported)/rr.D_reported;
    severe=abs(eMw)>0.50 || abs(eD)>0.75;
    if severe
        cls='SOURCE_INTERNAL_INCONSISTENCY';
    elseif max(abs([eMn eMw eD]))>0.25
        cls='APPROXIMATION_OR_ROUNDING_GAP';
    else
        cls='CONSISTENT_WITH_DECONVOLUTION_APPROXIMATION';
    end
    R(k,:)={pop(k).id,rr.Mn_reported_gmol,rr.Mw_reported_gmol,rr.D_reported, ...
        m.Mn_analytical_gmol,m.Mw_analytical_gmol,m.D_analytical,eMn,eMw,eD,severe,cls,pop(k).source};
end
T=cell2table(R,'VariableNames',{'SourceID','Mn_reported_gmol','Mw_reported_gmol','D_reported', ...
    'Mn_componentImplied_gmol','Mw_componentImplied_gmol','D_componentImplied', ...
    'Mn_relerr','Mw_relerr','D_relerr','SevereSourceFlag','Classification','Source'});
end
