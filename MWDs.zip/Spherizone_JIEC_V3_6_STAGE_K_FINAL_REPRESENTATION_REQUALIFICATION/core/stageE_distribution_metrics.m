function out = stageE_distribution_metrics(M_gmol, detailed_pdf, collapsed_pdf)
%STAGEE_DISTRIBUTION_METRICS Full-MWD distances and tail/quantile descriptors.
% Inputs are weight densities dW/dlog10(M) on a common positive M grid.
% W1 is the 1-D Wasserstein-1 distance in log10(M), with units of decades.
% Jensen-Shannon divergence uses log base 2 and is therefore reported in bits.

M=M_gmol(:)'; x=log10(M);
p=detailed_pdf(:)'; q=collapsed_pdf(:)';
if numel(M)~=numel(p) || numel(M)~=numel(q), error('Stage-E metric grid mismatch.'); end
if any(~isfinite(M)) || any(M<=0) || any(~isfinite(p)) || any(~isfinite(q)) || any(p<0) || any(q<0)
    error('Invalid Stage-E distribution input.');
end
Zp=trapz(x,p); Zq=trapz(x,q);
if Zp<=0 || Zq<=0, error('Non-positive Stage-E distribution normalization.'); end
p=p/Zp; q=q/Zq;
Fp=cumtrapz(x,p); Fq=cumtrapz(x,q);
Fp=Fp/Fp(end); Fq=Fq/Fq(end);

W1=trapz(x,abs(Fp-Fq));
m=0.5*(p+q);
tp=zeros(size(p)); tq=zeros(size(q));
ip=p>0 & m>0; iq=q>0 & m>0;
tp(ip)=p(ip).*log2(p(ip)./m(ip));
tq(iq)=q(iq).*log2(q(iq)./m(iq));
JS=0.5*trapz(x,tp)+0.5*trapz(x,tq);

qd=stageE_quantiles_local(M,Fp,[0.10 0.50 0.90 0.99]);
qc=stageE_quantiles_local(M,Fq,[0.10 0.50 0.90 0.99]);
Fdetail_at_collapsed_M90=interp1(x,Fp,log10(qc(3)),'linear');
Fcollapsed_at_collapsed_M90=interp1(x,Fq,log10(qc(3)),'linear');
tailD=max(0,min(1,1-Fdetail_at_collapsed_M90));
tailC=max(0,min(1,1-Fcollapsed_at_collapsed_M90));

MnD=1/trapz(x,p./M); MwD=trapz(x,p.*M); DD=MwD/MnD;
MnC=1/trapz(x,q./M); MwC=trapz(x,q.*M); DC=MwC/MnC;

out=struct();
out.W1_log10M_decades=W1;
out.JS_divergence_bits=JS;
out.M10_detailed=qd(1); out.M50_detailed=qd(2); out.M90_detailed=qd(3); out.M99_detailed=qd(4);
out.M10_collapsed=qc(1); out.M50_collapsed=qc(2); out.M90_collapsed=qc(3); out.M99_collapsed=qc(4);
out.M90_over_M10_detailed=qd(3)/qd(1); out.M90_over_M10_collapsed=qc(3)/qc(1);
out.TailMassAboveCollapsedM90_detailed=tailD;
out.TailMassAboveCollapsedM90_collapsed=tailC;
out.TailExcessAboveCollapsedM90=tailD-tailC;
out.Mn_detailed_numerical=MnD; out.Mw_detailed_numerical=MwD; out.D_detailed_numerical=DD;
out.Mn_collapsed_numerical=MnC; out.Mw_collapsed_numerical=MwC; out.D_collapsed_numerical=DC;
out.DeltaD_numerical=DD-DC;
out.DetailedNormalization=trapz(x,p); out.CollapsedNormalization=trapz(x,q);
out.detailed_pdf=p; out.collapsed_pdf=q; out.F_detailed=Fp; out.F_collapsed=Fq;
end

function vals=stageE_quantiles_local(M,F,probs)
% Remove repeated CDF ordinates before interpolation.
[Fu,ia]=unique(F,'stable'); Mu=M(ia);
if Fu(1)>0, Fu=[0 Fu]; Mu=[M(1) Mu]; end %#ok<AGROW>
if Fu(end)<1, Fu=[Fu 1]; Mu=[Mu M(end)]; end %#ok<AGROW>
vals=interp1(Fu,Mu,probs,'linear');
if any(~isfinite(vals)), error('Stage-E quantile interpolation failed.'); end
end
