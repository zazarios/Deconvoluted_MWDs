function verdict = run_stageD_continuous_partial_identification(cfg,outdir)
%RUN_STAGED_CONTINUOUS_PARTIAL_IDENTIFICATION Stage-D continuous robustness audit.
%
% D-W: exact total-variation (TV) population-weight partial-identification
%      bounds, with all other primary Stage-B2 endpoint uncertainties retained.
% D-C: continuous chemistry-response amplitude rho_C in [0,1], using the
%      symmetry-complete Stage-B direction library and inherited population
%      weights. rho_C=1 reproduces the prior factor-two endpoint chemistry set.
%
% The radii are deterministic epistemic/model-form robustness coordinates,
% NOT probability levels or confidence intervals.

if ~exist(outdir,'dir'), mkdir(outdir); end

anchor=ex2_sorption_anchor_envelope_B1(cfg);
surf=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac, ...
    cfg.EX2.primary_r1_bounds,cfg.EX2.primary_r2_bounds,cfg.EX2.primary_n_r2,'PRIMARY_SCREEN_70C_ANCHOR');
mz=run_normalized_mzcr_demo(cfg); matrix=mz.matrix;
Tall=population_T80_envelope(cfg.FBR.H2_psi,cfg.MZCR.DoTi);
Tp=selectT_D(Tall,cfg.StageB.primary_T_classes);
sorbAll=thermo_fbr_scenarios(cfg.FBR.gas);
Sp=selectS_D(sorbAll,cfg.StageD.primary_sorption_names);
Cend=site_response_scenarios(5,cfg.site_response.odds_span);
Cweight=Cend(strcmp({Cend.name},'C0_homogeneous'));
if numel(Cweight)~=1, error('C0 homogeneous chemistry scenario is missing.'); end
Dirs=continuous_chemistry_directions(5);
EPC=cfg.StageB.primary_EPC;
modes={'DIRECT_MN_TRANSFER','DP_REPEAT_MASS_CORRECTED'};

%% D-W. Exact continuous TV-ball weight bounds.
delta=cfg.StageD.weight_TV_grid(:)'; nd=numel(delta);
rowsW=cell(0,15);
% global envelopes: mode x EPC x delta
nm=numel(modes); ne=numel(EPC);
MnLo=inf(nm,ne,nd); MnHi=-inf(nm,ne,nd);
MwLo=inf(nm,ne,nd); MwHi=-inf(nm,ne,nd);
C2Lo=inf(1,ne,nd); C2Hi=-inf(1,ne,nd);

for it=1:numel(Tp)
    pop=Tp(it); active=pop.w>0 & isfinite(pop.Mn_gmol);
    w0=pop.w(active); w0=w0/sum(w0);
    for is=1:numel(Sp)
        for ic=1:numel(Cweight)
            % U_W is a marginal continuous weight-transfer audit at C0
            % homogeneous chemistry. U_C is varied separately below; Stage B2
            % remains the joint endpoint stress test.
            stC=stage_population_state(pop,Sp(is).f1_sorbed,surf.r1,surf.r2,Cweight(ic),'DIRECT_MN_TRANSFER');
            C2coef=stC.C2J(:,active);
            [c2min,c2max]=tv_linear_bounds_curve(w0,C2coef,delta);
            for ie=1:ne
                e=EPC(ie);
                lo=e*min(c2min,[],1); hi=e*max(c2max,[],1);
                tmp=squeeze(C2Lo(1,ie,:))'; tmp=min(tmp,lo); C2Lo(1,ie,:)=reshape(tmp,1,1,[]);
                tmp=squeeze(C2Hi(1,ie,:))'; tmp=max(tmp,hi); C2Hi(1,ie,:)=reshape(tmp,1,1,[]);
            end

            for im=1:nm
                st=stage_population_state(pop,Sp(is).f1_sorbed,surf.r1,surf.r2,Cweight(ic),modes{im});
                MnJ=st.MnJ(:,active);
                % DIRECT_MN_TRANSFER has identical population Mn on every
                % reactivity row; avoid thousands of duplicate TV solves.
                if strcmp(modes{im},'DIRECT_MN_TRANSFER')
                    MnJ=MnJ(1,:);
                end
                invcoef=1./MnJ; mwcoef=2.*MnJ;
                [invmin,invmax]=tv_linear_bounds_curve(w0,invcoef,delta);
                [mwmin,mwmax]=tv_linear_bounds_curve(w0,mwcoef,delta);
                for ie=1:ne
                    e=EPC(ie);
                    mnlo=1./((1-e)/matrix.Mn_gmol + e.*max(invmax,[],1));
                    mnhi=1./((1-e)/matrix.Mn_gmol + e.*min(invmin,[],1));
                    mwlo=(1-e)*matrix.Mw_gmol + e.*min(mwmin,[],1);
                    mwhi=(1-e)*matrix.Mw_gmol + e.*max(mwmax,[],1);
                    tmp=squeeze(MnLo(im,ie,:))'; tmp=min(tmp,mnlo); MnLo(im,ie,:)=reshape(tmp,1,1,[]);
                    tmp=squeeze(MnHi(im,ie,:))'; tmp=max(tmp,mnhi); MnHi(im,ie,:)=reshape(tmp,1,1,[]);
                    tmp=squeeze(MwLo(im,ie,:))'; tmp=min(tmp,mwlo); MwLo(im,ie,:)=reshape(tmp,1,1,[]);
                    tmp=squeeze(MwHi(im,ie,:))'; tmp=max(tmp,mwhi); MwHi(im,ie,:)=reshape(tmp,1,1,[]);
                end
            end
        end
    end
end

for im=1:nm
    for ie=1:ne
        for id=1:nd
            mnlo=MnLo(im,ie,id); mnhi=MnHi(im,ie,id);
            mwlo=MwLo(im,ie,id); mwhi=MwHi(im,ie,id);
            c2lo=C2Lo(1,ie,id); c2hi=C2Hi(1,ie,id);
            rowsW(end+1,:)={delta(id),modes{im},EPC(ie),mnlo,mnhi,mwlo,mwhi, ...
                mwlo/mnhi,mwhi/mnlo,c2lo,c2hi,NaN,NaN,NaN,NaN}; %#ok<AGROW>
        end
    end
end
Wcurve=cell2table(rowsW,'VariableNames',{'TV_radius','TransferMode','EPC_wtfrac','Mn_min','Mn_max','Mw_min','Mw_max', ...
    'D_outer_min','D_outer_max','TotalC2_min','TotalC2_max','Mn_margin_to_next','Mw_margin_to_next','C2_margin_to_next','All_MnMw_separated_to_next'});
Wcurve=addMargins_D(Wcurve,EPC,'TV_radius');
writetable(Wcurve,fullfile(outdir,'StageD_weight_TV_partial_identification.csv'));

%% Map the old factor-two scenario library onto the continuous TV coordinate.
Wold=population_weight_transfer_scenarios(5,cfg.site_response.odds_span);
ctx=cell(0,8);
for it=1:numel(Tp)
    w0=Tp(it).w(:)'; w0=max(w0,0); w0=w0/sum(w0);
    for iw=1:numel(Wold)
        we=w0.*Wold(iw).yield_multiplier(:)'; we=we/sum(we);
        tv=0.5*sum(abs(we-w0));
        ctx(end+1,:)={Tp(it).name,Wold(iw).name,Wold(iw).class,tv, ...
            1-max(w0),max(w0),find(w0==max(w0),1),max(Wold(iw).yield_multiplier)/min(Wold(iw).yield_multiplier)}; %#ok<AGROW>
    end
end
Ctx=cell2table(ctx,'VariableNames',{'TScenario','OldWeightScenario','OldClass','TV_radius_from_source_weights', ...
    'Exact_TV_radius_to_any_single_population','Largest_source_weight','Largest_source_population_index','OldMultiplierMaxToMin'});
writetable(Ctx,fullfile(outdir,'StageD_old_factor_two_to_TV_mapping.csv'));

%% D-C. Continuous chemistry amplitude with inherited weights.
rho=cfg.StageD.chemistry_rho_grid(:)'; nr=numel(rho);
rowsC=cell(0,15);
MnLoC=inf(nm,ne,nr); MnHiC=-inf(nm,ne,nr);
MwLoC=inf(nm,ne,nr); MwHiC=-inf(nm,ne,nr);
DLoC=inf(nm,ne,nr); DHiC=-inf(nm,ne,nr);
C2LoC=inf(1,ne,nr); C2HiC=-inf(1,ne,nr);

% DIRECT_MN_TRANSFER MWD is independent of chemistry/sorption/reactivity.
for it=1:numel(Tp)
    ps=population_moments(Tp(it));
    for ie=1:ne
        fb=final_blend_moments(matrix.Mn_gmol,matrix.Mw_gmol,ps.Mn_gmol,ps.Mw_gmol,EPC(ie));
        for irho=1:nr
            MnLoC(1,ie,irho)=min(MnLoC(1,ie,irho),fb.Mn_gmol);
            MnHiC(1,ie,irho)=max(MnHiC(1,ie,irho),fb.Mn_gmol);
            MwLoC(1,ie,irho)=min(MwLoC(1,ie,irho),fb.Mw_gmol);
            MwHiC(1,ie,irho)=max(MwHiC(1,ie,irho),fb.Mw_gmol);
            DLoC(1,ie,irho)=min(DLoC(1,ie,irho),fb.D);
            DHiC(1,ie,irho)=max(DHiC(1,ie,irho),fb.D);
        end
    end
end

for irho=1:nr
    rr=rho(irho);
    for it=1:numel(Tp)
        pop=Tp(it);
        for is=1:numel(Sp)
            for idir=1:numel(Dirs)
                resp=site_response_at_radius(Dirs(idir),rr,cfg.site_response.odds_span);
                % Composition and DP-coupled MWD in one vectorized call.
                P=stage_properties_vectorized_B1(pop,Sp(is).f1_sorbed,surf.r1,surf.r2,resp,'DP_REPEAT_MASS_CORRECTED');
                cmin=min(P.C2_wtfrac); cmax=max(P.C2_wtfrac);
                for ie=1:ne
                    e=EPC(ie);
                    C2LoC(1,ie,irho)=min(C2LoC(1,ie,irho),e*cmin);
                    C2HiC(1,ie,irho)=max(C2HiC(1,ie,irho),e*cmax);
                    Bmn=1./((1-e)/matrix.Mn_gmol + e./P.Mn_gmol);
                    Bmw=(1-e)*matrix.Mw_gmol + e.*P.Mw_gmol;
                    Bd=Bmw./Bmn;
                    MnLoC(2,ie,irho)=min(MnLoC(2,ie,irho),min(Bmn));
                    MnHiC(2,ie,irho)=max(MnHiC(2,ie,irho),max(Bmn));
                    MwLoC(2,ie,irho)=min(MwLoC(2,ie,irho),min(Bmw));
                    MwHiC(2,ie,irho)=max(MwHiC(2,ie,irho),max(Bmw));
                    DLoC(2,ie,irho)=min(DLoC(2,ie,irho),min(Bd));
                    DHiC(2,ie,irho)=max(DHiC(2,ie,irho),max(Bd));
                end
            end
        end
    end
end

% Direct-transfer composition is the same composition envelope; copy it.
for irho=1:nr
    for ie=1:ne
        for im=1:nm
            rowsC(end+1,:)={rho(irho),4^rho(irho),modes{im},EPC(ie), ...
                MnLoC(im,ie,irho),MnHiC(im,ie,irho),MwLoC(im,ie,irho),MwHiC(im,ie,irho), ...
                DLoC(im,ie,irho),DHiC(im,ie,irho),C2LoC(1,ie,irho),C2HiC(1,ie,irho),NaN,NaN,NaN}; %#ok<AGROW>
        end
    end
end
Ccurve=cell2table(rowsC,'VariableNames',{'Chemistry_radius_rho','MaxToMinOddsMultiplierRatio','TransferMode','EPC_wtfrac', ...
    'Mn_min','Mn_max','Mw_min','Mw_max','D_min','D_max','TotalC2_min','TotalC2_max','Mn_margin_to_next','Mw_margin_to_next','C2_margin_to_next'});
Ccurve=addMargins_D(Ccurve,EPC,'Chemistry_radius_rho');
writetable(Ccurve,fullfile(outdir,'StageD_chemistry_radius_partial_identification.csv'));

%% Critical-radius brackets.
Crit=critical_radius_table_D(Wcurve,Ccurve,EPC,cfg.StageD.critical_margin_tol);
writetable(Crit,fullfile(outdir,'StageD_critical_radius_brackets.csv'));

%% Regression against embedded Stage-B2 W0 endpoint evidence.
Reg=regress_stageD_to_B2_D(cfg,Wcurve,Ccurve,outdir);

%% Compact summary of continuous partial-identification findings.
Summary=summary_table_D(Wcurve,Ccurve,Ctx,Crit);
writetable(Summary,fullfile(outdir,'StageD_partial_identification_summary.csv'));

if ~Reg.Pass(1)
    code='STAGE_D_REGRESSION_FAIL';
    summary='Continuous Stage-D implementation does not reproduce the Stage-B2 W0 endpoint evidence. Do not proceed.';
else
    code='CONTINUOUS_PARTIAL_IDENTIFICATION_QUALIFIED__PROCEED_TO_STAGE_E_DISTRIBUTION_RETENTION';
    summary=['Exact continuous TV-ball bounds and continuous chemistry-amplitude curves are qualified. ' ...
        'Use the exported critical-radius brackets as robustness margins, not confidence intervals. Proceed to Stage E distribution-level information retention and external Yang-2026 challenge.'];
end
verdict=struct('code',code,'summary',summary,'RegressionPass',Reg.Pass(1));

fid=fopen(fullfile(outdir,'STAGE_D_VERDICT.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.5 Stage-D continuous partial-identification / adversarial robustness\n');
fprintf(fid,'Verdict: %s\n',code);
fprintf(fid,'%s\n',summary);
fprintf(fid,'Regression to Stage-B2 W0 endpoint: %d (max relative difference %.3g)\n',Reg.Pass(1),Reg.MaxRelativeDifference(1));
fprintf(fid,'U_W is an exact total-variation simplex ball for linear moment/composition functionals.\n');
fprintf(fid,'U_C is a continuous amplitude rho_C in [0,1] along the symmetry-complete Stage-B chemistry directions.\n');
fprintf(fid,'Neither radius is a probability level or confidence interval.\n');
fprintf(fid,'D bounds in the U_W table are conservative outer bounds from separately optimized Mn and Mw; they are not joint exact extrema.\n');
fclose(fid);
end

function Tsel=selectT_D(Tall,classes)
keep=false(1,numel(Tall));
for k=1:numel(Tall), keep(k)=any(strcmp(Tall(k).admissibility,classes)); end
Tsel=Tall(keep);
end

function Ssel=selectS_D(Sall,names)
keep=false(1,numel(Sall));
for k=1:numel(Sall), keep(k)=any(strcmp(Sall(k).name,names)); end
Ssel=Sall(keep);
if numel(Ssel)~=numel(names), error('One or more Stage-D primary sorption scenarios are missing.'); end
end

function T=addMargins_D(T,EPC,radiusVar)
% Add adjacent-EPC separation margins at each radius and transfer mode.
rv=T.(radiusVar);
modes=unique(string(T.TransferMode),'stable');
radii=unique(rv,'stable');
for im=1:numel(modes)
    for ir=1:numel(radii)
        idx=find(string(T.TransferMode)==modes(im) & abs(rv-radii(ir))<1e-12);
        [~,ord]=sort(T.EPC_wtfrac(idx)); idx=idx(ord);
        for j=1:numel(idx)-1
            a=idx(j); b=idx(j+1);
            % Mn and Mw decrease with EPC in the admitted primary model:
            % positive margin => high-EPC upper envelope is below low-EPC lower envelope.
            T.Mn_margin_to_next(a)=T.Mn_min(a)-T.Mn_max(b);
            T.Mw_margin_to_next(a)=T.Mw_min(a)-T.Mw_max(b);
            % Total C2 increases with EPC: positive margin => high-EPC lower
            % envelope is above low-EPC upper envelope.
            T.C2_margin_to_next(a)=T.TotalC2_min(b)-T.TotalC2_max(a);
            if ismember('All_MnMw_separated_to_next',T.Properties.VariableNames)
                T.All_MnMw_separated_to_next(a)=T.Mn_margin_to_next(a)>0 && T.Mw_margin_to_next(a)>0;
            end
        end
    end
end
end

function Crit=critical_radius_table_D(W,C,EPC,tol)
rows=cell(0,8);
props={'Mn','Mw','C2'};
for which=1:2
    if which==1, T=W; rname='TV_radius'; uname='U_W_TV'; else, T=C; rname='Chemistry_radius_rho'; uname='U_C_LOG_ODDS'; end
    modes=unique(string(T.TransferMode),'stable'); radii=unique(T.(rname),'stable');
    for im=1:numel(modes)
        for ip=1:numel(EPC)-1
            for jp=1:numel(props)
                p=props{jp};
                switch p
                    case 'Mn', mvar='Mn_margin_to_next';
                    case 'Mw', mvar='Mw_margin_to_next';
                    case 'C2', mvar='C2_margin_to_next';
                end
                margins=nan(size(radii));
                for ir=1:numel(radii)
                    idx=find(string(T.TransferMode)==modes(im) & abs(T.(rname)-radii(ir))<1e-12 & abs(T.EPC_wtfrac-EPC(ip))<1e-12,1);
                    margins(ir)=T.(mvar)(idx);
                end
                if margins(1)<=tol
                    status='OVERLAP_ALREADY_AT_ZERO_RADIUS'; lo=0; hi=0;
                else
                    k=find(margins<=tol,1,'first');
                    if isempty(k)
                        status='SEPARATION_SURVIVES_FULL_SCANNED_RADIUS'; lo=radii(end); hi=NaN;
                    else
                        status='CRITICAL_RADIUS_BRACKETED'; lo=radii(k-1); hi=radii(k);
                    end
                end
                rows(end+1,:)={uname,char(modes(im)),p,EPC(ip),EPC(ip+1),status,lo,hi}; %#ok<AGROW>
            end
        end
    end
end
Crit=cell2table(rows,'VariableNames',{'UncertaintyCoordinate','TransferMode','Property','EPC_low','EPC_high','Status','LastSeparatedRadius','FirstOverlapRadius'});
end

function Reg=regress_stageD_to_B2_D(cfg,Wcurve,Ccurve,outdir)
% Two regressions:
% R1: U_W delta=0 must equal U_C rho=0 (same C0/W0 marginal model).
% R2: U_C rho=1 must reproduce Stage-B2 W0 endpoint envelopes.
root=fileparts(fileparts(mfilename('fullpath')));
inB2=fullfile(root,'inputs','StageB2Outputs');
M=readtable(fullfile(inB2,'StageB2_MWD_weight_transfer_envelopes.csv'));
Q=readtable(fullfile(inB2,'StageB2_composition_weight_transfer_layers.csv'));
M=M(strcmp(M.WeightTransferLayer,'W0_INHERITED'),:);
Q=Q(strcmp(Q.WeightTransferLayer,'W0_INHERITED'),:);
maxerrInternal=0; maxerrB2=0;

modes=unique(string(Wcurve.TransferMode),'stable');
epcs=unique(Wcurve.EPC_wtfrac,'stable');
for im=1:numel(modes)
    for ie=1:numel(epcs)
        mode=modes(im); e=epcs(ie);
        iw=find(string(Wcurve.TransferMode)==mode & abs(Wcurve.EPC_wtfrac-e)<1e-12 & abs(Wcurve.TV_radius)<1e-12,1);
        ic0=find(string(Ccurve.TransferMode)==mode & abs(Ccurve.EPC_wtfrac-e)<1e-12 & abs(Ccurve.Chemistry_radius_rho)<1e-12,1);
        if isempty(iw) || isempty(ic0), error('Stage-D internal marginal-regression row missing.'); end
        a=[Wcurve.Mn_min(iw),Wcurve.Mn_max(iw),Wcurve.Mw_min(iw),Wcurve.Mw_max(iw),Wcurve.TotalC2_min(iw),Wcurve.TotalC2_max(iw)];
        b=[Ccurve.Mn_min(ic0),Ccurve.Mn_max(ic0),Ccurve.Mw_min(ic0),Ccurve.Mw_max(ic0),Ccurve.TotalC2_min(ic0),Ccurve.TotalC2_max(ic0)];
        maxerrInternal=max(maxerrInternal,max(abs(a-b)./max(abs(b),1e-12)));
    end
end

for i=1:height(M)
    mode=string(M.TransferMode(i)); e=M.EPC_wtfrac(i);
    ic=find(string(Ccurve.TransferMode)==mode & abs(Ccurve.EPC_wtfrac-e)<1e-12 & abs(Ccurve.Chemistry_radius_rho-1)<1e-12,1);
    if isempty(ic), error('Stage-D B2 endpoint regression row missing.'); end
    ref=[M.Mn_min(i),M.Mn_max(i),M.Mw_min(i),M.Mw_max(i)];
    b=[Ccurve.Mn_min(ic),Ccurve.Mn_max(ic),Ccurve.Mw_min(ic),Ccurve.Mw_max(ic)];
    maxerrB2=max(maxerrB2,max(abs(b-ref)./max(abs(ref),1)));
end
for i=1:height(Q)
    e=Q.EPC_wtfrac(i);
    ic=find(abs(Ccurve.EPC_wtfrac-e)<1e-12 & abs(Ccurve.Chemistry_radius_rho-1)<1e-12,1);
    ref=[Q.TotalC2_min(i),Q.TotalC2_max(i)];
    b=[Ccurve.TotalC2_min(ic),Ccurve.TotalC2_max(ic)];
    maxerrB2=max(maxerrB2,max(abs(b-ref)./max(abs(ref),1e-12)));
end
maxerr=max(maxerrInternal,maxerrB2);
pass=maxerr<cfg.StageD.regression_rel_tol;
Reg=table(maxerrInternal,maxerrB2,maxerr,pass,'VariableNames', ...
    {'MaxRelativeDifference_UW0_vs_UC0','MaxRelativeDifference_UC1_vs_StageB2W0','MaxRelativeDifference','Pass'});
writetable(Reg,fullfile(outdir,'StageD_regression_to_StageB2_W0.csv'));
end

function S=summary_table_D(W,C,Ctx,Crit)
rows=cell(0,3);
rows(end+1,:)={'Old_factor_two_TV_radius_range',min(Ctx.TV_radius_from_source_weights),max(Ctx.TV_radius_from_source_weights)};
rows(end+1,:)={'Exact_single_population_collapse_radius_range',min(Ctx.Exact_TV_radius_to_any_single_population),max(Ctx.Exact_TV_radius_to_any_single_population)};
% Minimum/maximum final property widths at full TV radius.
sub=W(abs(W.TV_radius-1)<1e-12,:);
rows(end+1,:)={'Full_TV_Mw_width_range_gmol',min(sub.Mw_max-sub.Mw_min),max(sub.Mw_max-sub.Mw_min)};
subc=C(abs(C.Chemistry_radius_rho-1)<1e-12,:);
rows(end+1,:)={'Full_chemistry_TotalC2_width_range',min(subc.TotalC2_max-subc.TotalC2_min),max(subc.TotalC2_max-subc.TotalC2_min)};
% Count identifiability thresholds.
rows(end+1,:)={'Critical_radius_tests_already_overlapping_at_zero',sum(strcmp(Crit.Status,'OVERLAP_ALREADY_AT_ZERO_RADIUS')),height(Crit)};
S=cell2table(rows,'VariableNames',{'Metric','Value1','Value2'});
end
