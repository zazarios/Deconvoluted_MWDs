function B = stageD1_UC_envelopes(ctx,rho,transferMode,EPC,span)
%STAGED1_UC_ENVELOPES Exact U_C envelopes at one arbitrary chemistry radius.
if nargin<5, span=2; end
if rho<0 || rho>1, error('rho must lie in [0,1].'); end
EPC=EPC(:)'; ne=numel(EPC);
MnLo=inf(1,ne); MnHi=-inf(1,ne); MwLo=inf(1,ne); MwHi=-inf(1,ne);
C2Lo=inf(1,ne); C2Hi=-inf(1,ne);

% DIRECT_MN_TRANSFER MWD is independent of U_C chemistry amplitude.
if strcmpi(transferMode,'DIRECT_MN_TRANSFER')
    for it=1:numel(ctx.Tp)
        ps=population_moments(ctx.Tp(it));
        for ie=1:ne
            fb=final_blend_moments(ctx.matrix.Mn_gmol,ctx.matrix.Mw_gmol,ps.Mn_gmol,ps.Mw_gmol,EPC(ie));
            MnLo(ie)=min(MnLo(ie),fb.Mn_gmol); MnHi(ie)=max(MnHi(ie),fb.Mn_gmol);
            MwLo(ie)=min(MwLo(ie),fb.Mw_gmol); MwHi(ie)=max(MwHi(ie),fb.Mw_gmol);
        end
    end
end

for it=1:numel(ctx.Tp)
    pop=ctx.Tp(it);
    for is=1:numel(ctx.Sp)
        for idir=1:numel(ctx.Dirs)
            resp=site_response_at_radius(ctx.Dirs(idir),rho,span);
            P=stage_properties_vectorized_B1(pop,ctx.Sp(is).f1_sorbed,ctx.surf.r1,ctx.surf.r2,resp,'DP_REPEAT_MASS_CORRECTED');
            cmin=min(P.C2_wtfrac); cmax=max(P.C2_wtfrac);
            for ie=1:ne
                e=EPC(ie);
                C2Lo(ie)=min(C2Lo(ie),e*cmin); C2Hi(ie)=max(C2Hi(ie),e*cmax);
                if strcmpi(transferMode,'DP_REPEAT_MASS_CORRECTED')
                    Bmn=1./((1-e)/ctx.matrix.Mn_gmol + e./P.Mn_gmol);
                    Bmw=(1-e)*ctx.matrix.Mw_gmol + e.*P.Mw_gmol;
                    MnLo(ie)=min(MnLo(ie),min(Bmn)); MnHi(ie)=max(MnHi(ie),max(Bmn));
                    MwLo(ie)=min(MwLo(ie),min(Bmw)); MwHi(ie)=max(MwHi(ie),max(Bmw));
                end
            end
        end
    end
end
B=struct('Mn_min',MnLo,'Mn_max',MnHi,'Mw_min',MwLo,'Mw_max',MwHi,'C2_min',C2Lo,'C2_max',C2Hi);
end
