function [Ranges,Witnesses,surf] = stageJ_composition_ranges(cfg,Tset,Sp)
%STAGEJ_COMPOSITION_RANGES Finite external-challenge composition envelopes.
% Reuses the EX2-conditioned feasible reactivity surface and primary FBR
% sorption scenarios. The only widened coordinate is the pre-specified nested
% latent-chemistry odds span. This is a stress audit, not a fitted chemistry law.

anchor=ex2_sorption_anchor_envelope_B1(cfg);
surf=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac, ...
    cfg.EX2.primary_r1_bounds,cfg.EX2.primary_r2_bounds,cfg.EX2.primary_n_r2,'PRIMARY_SCREEN_70C_ANCHOR');

branches=unique({Tset.H2Branch},'stable');
rows=cell(0,11); wrows=cell(0,11);
for ispan=1:numel(cfg.StageJ.chemistry_odds_spans)
    span=cfg.StageJ.chemistry_odds_spans(ispan);
    Cs=stageJ_nested_chemistry_scenarios(cfg,span);
    for ib=1:(numel(branches)+1)
        if ib<=numel(branches)
            bname=branches{ib}; idxT=find(strcmp({Tset.H2Branch},bname));
        else
            bname='UNION_ALL_H2_BRANCHES'; idxT=1:numel(Tset);
        end
        lo=Inf; hi=-Inf; lowit=[]; hiwit=[];
        for jt=idxT
            pop=Tset(jt);
            for js=1:numel(Sp)
                for jc=1:numel(Cs)
                    c2=stage_c2_vectorized(pop,Sp(js).f1_sorbed,surf.r1,surf.r2,Cs(jc));
                    [a,ia]=min(c2); [b,ibest]=max(c2);
                    if a<lo
                        lo=a; lowit={pop.name,Sp(js).name,Cs(jc).name,surf.f1_EX2(ia),surf.r1(ia),surf.r2(ia)};
                    end
                    if b>hi
                        hi=b; hiwit={pop.name,Sp(js).name,Cs(jc).name,surf.f1_EX2(ibest),surf.r1(ibest),surf.r2(ibest)};
                    end
                end
            end
        end
        ext=cfg.StageJ.external_stage_C2_challenge;
        overlap=(hi>=ext(1) && lo<=ext(2));
        contains=(lo<=ext(1) && hi>=ext(2));
        gap=max([ext(1)-hi,lo-ext(2),0]);
        rows(end+1,:)={span,bname,lo,hi,hi-lo,ext(1),ext(2),overlap,contains,gap,'FINITE_STRESS_ENSEMBLE_NOT_CONFIDENCE_INTERVAL'}; %#ok<AGROW>
        wrows(end+1,:)={span,bname,'MIN',lowit{1},lowit{2},lowit{3},lowit{4},lowit{5},lowit{6},lo,'SECOND_STAGE_C2_WTFRAC'}; %#ok<AGROW>
        wrows(end+1,:)={span,bname,'MAX',hiwit{1},hiwit{2},hiwit{3},hiwit{4},hiwit{5},hiwit{6},hi,'SECOND_STAGE_C2_WTFRAC'}; %#ok<AGROW>
    end
end
Ranges=cell2table(rows,'VariableNames',{'ChemistryOddsSpan','H2BranchScope','StageC2Min','StageC2Max','StageC2Width', ...
    'ExternalChallengeMin','ExternalChallengeMax','AnyOverlapWithExternalEnvelope','ContainsExternalEnvelope','GapToExternalEnvelope','Status'});
Witnesses=cell2table(wrows,'VariableNames',{'ChemistryOddsSpan','H2BranchScope','Extremum','TScenario','SorptionScenario','ChemistryScenario', ...
    'EX2_f1_sorbed','r1','r2','StageC2_wtfrac','Quantity'});
end
