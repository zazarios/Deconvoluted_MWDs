function [vmax,tbest] = stageH_max_pair_mw_rel(s1,s2,e,matrixMw,cfg)
%STAGEH_MAX_PAIR_MW_REL Exact endpoint-pair scalar reduction objective.
fun=@(t) stageH_mw_rel_local(s1,s2,t,e,matrixMw);
[vmax,tbest]=stageH_maximize_t(fun,cfg);
end
function r=stageH_mw_rel_local(s1,s2,t,e,matrixMw)
sb=t*s1+(1-t)*s2;
A=t/s1+(1-t)/s2; B=1/sb;
full=(1-e)*matrixMw+2*e*A; red=(1-e)*matrixMw+2*e*B;
r=max(0,(full-red)/full);
end
