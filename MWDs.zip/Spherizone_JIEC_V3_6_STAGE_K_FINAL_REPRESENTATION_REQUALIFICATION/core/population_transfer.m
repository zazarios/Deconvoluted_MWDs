function out = population_transfer(T_C, H2_psi, DoTi, varargin)
%POPULATION_TRANSFER Bracketed primary interpolation with explicit domain flag.
% Primary interpolation: Do/Ti=1.4, T=60..70 C, H2=0..16 psi.
% Exact source points anywhere in the 16-condition database are also returned.

p = inputParser;
addParameter(p,'tol',1e-10);
parse(p,varargin{:});
tol=p.Results.tol;
data = data_flory_populations();

% Exact source point first.
for k=1:numel(data)
    if abs(T_C-data(k).T_C)<tol && abs(H2_psi-data(k).H2_psi)<tol && abs(DoTi-data(k).DoTi)<tol
        out = struct('w',data(k).w,'Mn_gmol',data(k).Mn_gmol, ...
            'domain_flag','source_exact','corner_ids',{{data(k).id}}, ...
            'T_C',T_C,'H2_psi',H2_psi,'DoTi',DoTi);
        return
    end
end

if abs(DoTi-1.4)>tol || T_C < 60-tol || T_C > 70+tol || H2_psi < -tol || H2_psi > 16+tol
    error('population_transfer:OutOfPrimaryDomain', ...
        'Query (T=%.3g C,H2=%.3g psi,DoTi=%.3g) is outside the primary bracketed domain.',T_C,H2_psi,DoTi);
end

Ts=[60 70]; Hs=[0 16];
alphaT=(T_C-Ts(1))/(Ts(2)-Ts(1));
alphaH=(H2_psi-Hs(1))/(Hs(2)-Hs(1));
coeff=[(1-alphaT)*(1-alphaH), (1-alphaT)*alphaH, alphaT*(1-alphaH), alphaT*alphaH];
ids={'60_D','60_DH','70_D','70_DH'};
C=repmat(struct('w',[],'Mn',[]),1,4);
for c=1:4
    idx=find(strcmp({data.id},ids{c}),1);
    C(c).w=data(idx).w; C(c).Mn=data(idx).Mn_gmol;
end

wq=zeros(1,5); Mnq=nan(1,5);
for j=1:5
    wc=[C(1).w(j) C(2).w(j) C(3).w(j) C(4).w(j)];
    wq(j)=sum(coeff.*wc);
    if wq(j)>tol
        mvals=[C(1).Mn(j) C(2).Mn(j) C(3).Mn(j) C(4).Mn(j)];
        present=isfinite(mvals) & wc>0 & coeff>tol;
        if ~any(present)
            error('No present-corner Mn available for active interpolated population %d.',j);
        end
        a=coeff(present); a=a/sum(a);
        Mnq(j)=exp(sum(a.*log(mvals(present))));
    end
end
wq=max(wq,0); wq=wq/sum(wq);
Mnq(wq<=tol)=NaN;

out=struct('w',wq,'Mn_gmol',Mnq,'domain_flag','primary_bracketed', ...
    'corner_ids',{ids},'T_C',T_C,'H2_psi',H2_psi,'DoTi',DoTi);
end
