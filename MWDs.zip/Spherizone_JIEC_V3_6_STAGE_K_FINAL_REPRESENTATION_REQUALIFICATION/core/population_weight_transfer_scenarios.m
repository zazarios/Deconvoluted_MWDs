function W = population_weight_transfer_scenarios(npop, span)
%POPULATION_WEIGHT_TRANSFER_SCENARIOS Relative second-stage population-yield stress set.
% The Alshaiban w_j values are PP-derived polymer-population mass fractions.
% Their direct transfer to E/P copolymerization is not experimentally identified.
% Zhang et al. (2021) shows active-center concentrations can shift strongly with
% E/P feed ratio and center class, but those quantitative values belong to a
% different catalyst. Therefore these multipliers are deliberately symmetric
% model-form stress factors, NOT catalyst-specific kinetic parameters or a
% statistical uncertainty distribution.
%
% W0: inherited weights, multiplier [1 1 1 1 1]
% W1: ordered factor-two stresses, both directions
% W2: all unique permutations of [0.5 0.5 1 2 2]

if nargin<1, npop=5; end
if nargin<2, span=2; end
if npop~=5, error('Current weight-transfer scenario library is defined for five MWD populations.'); end
if span<=1, error('span must exceed one.'); end

W=struct('name',{},'class',{},'yield_multiplier',{},'status',{});
W(end+1)=struct('name','W0_inherited_population_weights','class','W0', ...
    'yield_multiplier',ones(1,5),'status','BASELINE_INHERITED_WEIGHT_TRANSFER');

ordered=exp(linspace(-log(span),log(span),5));
W(end+1)=struct('name','W1_order_lowMW_to_highMW','class','W1', ...
    'yield_multiplier',ordered,'status','FACTOR_TWO_MODEL_FORM_STRESS');
W(end+1)=struct('name','W1_order_highMW_to_lowMW','class','W1', ...
    'yield_multiplier',fliplr(ordered),'status','FACTOR_TWO_MODEL_FORM_STRESS');

v=[1/span 1/span 1 span span];
P=unique(perms(v),'rows');
for k=1:size(P,1)
    W(end+1)=struct('name',sprintf('W2_mixed_%02d',k),'class','W2', ...
        'yield_multiplier',P(k,:),'status','FACTOR_TWO_MODEL_FORM_STRESS'); %#ok<AGROW>
end
end
