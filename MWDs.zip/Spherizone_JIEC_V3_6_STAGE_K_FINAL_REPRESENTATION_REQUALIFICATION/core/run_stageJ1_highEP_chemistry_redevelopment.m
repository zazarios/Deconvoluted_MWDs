function result = run_stageJ1_highEP_chemistry_redevelopment(cfg,outdir)
%RUN_STAGEJ1_HIGHEP_CHEMISTRY_REDEVELOPMENT Physically anchored set redevelopment.
% Stage-J external ICP/hiPP observations remain held out. The new chemistry
% support is built only from Zhang et al. 2021 high-E/P kinetic evidence and
% preserves the entire qualified Stage-J chemistry family as a legacy branch.
if ~exist(outdir,'dir'),mkdir(outdir);end
ROOT=fileparts(fileparts(mfilename('fullpath')));

E=stageJ1_mechanistic_chemistry_evidence(); writetable(E,fullfile(outdir,'StageJ1_Zhang_highEP_kinetic_evidence.csv'));
[Support,Contrast]=stageJ1_derive_chemistry_support(cfg,E);
writetable(Support,fullfile(outdir,'StageJ1_mechanistic_support_summary.csv'));
writetable(Contrast,fullfile(outdir,'StageJ1_mechanistic_condition_contrast.csv'));
P=stageJ1_pattern_library(cfg); writetable(P,fullfile(outdir,'StageJ1_pattern_library.csv'));
SHi=stageJ1_highEP_scenario_library(cfg,P); writetable(SHi,fullfile(outdir,'StageJ1_highEP_scenario_library.csv'));

Tset=stageJ_build_T80_challenge_set(cfg); Sp=stageJ_primary_sorption_set(cfg);
anchor=ex2_sorption_anchor_envelope_B1(cfg);
surf=reactivity_feasible_surface(anchor.f1_grid,cfg.EX2.target_C2_wtfrac,cfg.EX2.primary_r1_bounds,cfg.EX2.primary_r2_bounds,cfg.EX2.primary_n_r2,'PRIMARY_SCREEN_70C_ANCHOR');
fA=unique(surf.f1_EX2,'stable'); r2u=unique(surf.r2,'stable');
nT=numel(Tset);nS=numel(Sp);nA=numel(fA);nK=numel(r2u);
if height(surf)~=nA*nK,error('StageJ1:NonRectangularSurface','EX2 surface is not rectangular.');end

% Frozen legacy Stage-J chemistry branch.
SLeg=site_response_scenarios(5,cfg.site_response.odds_span); nLeg=numel(SLeg);
C2Leg=zeros(nT,nS,nLeg,nA,nK);
for it=1:nT
 for is=1:nS
  for ic=1:nLeg
   c=stage_c2_vectorized(Tset(it),Sp(is).f1_sorbed,surf.r1,surf.r2,SLeg(ic));
   C2Leg(it,is,ic,:,:)=reshape(reshape(c,[nK nA])',[1 1 1 nA nK]);
  end
 end
end
legMin=min(C2Leg(:));legMax=max(C2Leg(:));

% New high-E/P mechanistic branch: level x exchangeable pattern.
nL=numel(cfg.StageJ1.kappa_reference_levels);nP=height(P);
C2Hi=zeros(nT,nS,nL,nP,nA,nK);
for it=1:nT
 for is=1:nS
  for il=1:nL
   for ip=1:nP
    q=SHi.LevelIndex==il & SHi.PatternIndex==ip;
    if sum(q)~=1,error('StageJ1:ScenarioLibraryIndex','High-E/P scenario lookup is not unique.');end
    kap=[SHi.kappa1(q) SHi.kappa2(q) SHi.kappa3(q) SHi.kappa4(q) SHi.kappa5(q)];
    r=struct('name',sprintf('J1_L%d_P%d',il,ip),'class','J1_HIGH_EP','ethylene_odds_multiplier',kap);
    c=stage_c2_vectorized(Tset(it),Sp(is).f1_sorbed,surf.r1,surf.r2,r);
    C2Hi(it,is,il,ip,:,:)=reshape(reshape(c,[nK nA])',[1 1 1 1 nA nK]);
   end
  end
 end
end
hiMin=min(C2Hi(:));hiMax=max(C2Hi(:));
unionMin=min(legMin,hiMin);unionMax=max(legMax,hiMax);

Domain=table({'LEGACY_STAGE_J';'HIGH_EP_MECHANISTIC';'FINAL_UNION'}, ...
    [legMin;hiMin;unionMin],[legMax;hiMax;unionMax],[legMax-legMin;hiMax-hiMin;unionMax-unionMin], ...
    {'Frozen Stage-J odds-span=2 family retained unchanged.';'Zhang-anchored effective high-E/P preference support.';'Set union; Stage J is a strict subset of J.1.'}, ...
    'VariableNames',{'Domain','StageC2Min','StageC2Max','StageC2Width','Interpretation'});
writetable(Domain,fullfile(outdir,'StageJ1_composition_domain_summary.csv'));
% Source-tight versus outward-rounded support sensitivity. This uses only the
% Zhang kinetic-source bounds; held-out ICP/hiPP challenge data are not read.
[stLo,~,~,~]=stageJ1_homogeneous_kappa_range(Tset(1),Sp,surf,Support.Observed_kpE_over_kpP_Min);
[~,stHi,~,~]=stageJ1_homogeneous_kappa_range(Tset(1),Sp,surf,Support.Observed_kpE_over_kpP_Max);
[rdLo,~,~,~]=stageJ1_homogeneous_kappa_range(Tset(1),Sp,surf,cfg.StageJ1.kappa_support(1));
[~,rdHi,~,~]=stageJ1_homogeneous_kappa_range(Tset(1),Sp,surf,cfg.StageJ1.kappa_support(2));
SupportSensitivity=table({'SOURCE_TIGHT_OBSERVED_BOUNDS';'OUTWARD_ROUNDED_PRIMARY_BOUNDS'}, ...
    [Support.Observed_kpE_over_kpP_Min;cfg.StageJ1.kappa_support(1)],[Support.Observed_kpE_over_kpP_Max;cfg.StageJ1.kappa_support(2)], ...
    [stLo;rdLo],[stHi;rdHi],{'Zhang-only source-tight diagnostic';'Primary J.1 outward-rounded support'}, ...
    'VariableNames',{'SupportCase','KappaMin','KappaMax','StageC2Min','StageC2Max','Interpretation'});
writetable(SupportSensitivity,fullfile(outdir,'StageJ1_support_sensitivity.csv'));

% Extremum witnesses by linear index.
Wit=cell(0,9);
[a,ia]=min(C2Leg(:));[b,ib]=max(C2Leg(:));
[it,is,ic,ja,jk]=ind2sub(size(C2Leg),ia);Wit(end+1,:)={'LEGACY_STAGE_J','MIN',a,Tset(it).name,Sp(is).name,SLeg(ic).name,surf.f1_EX2((ja-1)*nK+jk),surf.r1((ja-1)*nK+jk),surf.r2((ja-1)*nK+jk)}; %#ok<AGROW>
[it,is,ic,ja,jk]=ind2sub(size(C2Leg),ib);Wit(end+1,:)={'LEGACY_STAGE_J','MAX',b,Tset(it).name,Sp(is).name,SLeg(ic).name,surf.f1_EX2((ja-1)*nK+jk),surf.r1((ja-1)*nK+jk),surf.r2((ja-1)*nK+jk)}; %#ok<AGROW>
[a,ia]=min(C2Hi(:));[b,ib]=max(C2Hi(:));
[it,is,il,ip,ja,jk]=ind2sub(size(C2Hi),ia);q=SHi.LevelIndex==il&SHi.PatternIndex==ip;Wit(end+1,:)={'HIGH_EP_MECHANISTIC','MIN',a,Tset(it).name,Sp(is).name,sprintf('L=%g;%s',SHi.ReferenceKappa(q),SHi.PatternID{q}),surf.f1_EX2((ja-1)*nK+jk),surf.r1((ja-1)*nK+jk),surf.r2((ja-1)*nK+jk)}; %#ok<AGROW>
[it,is,il,ip,ja,jk]=ind2sub(size(C2Hi),ib);q=SHi.LevelIndex==il&SHi.PatternIndex==ip;Wit(end+1,:)={'HIGH_EP_MECHANISTIC','MAX',b,Tset(it).name,Sp(is).name,sprintf('L=%g;%s',SHi.ReferenceKappa(q),SHi.PatternID{q}),surf.f1_EX2((ja-1)*nK+jk),surf.r1((ja-1)*nK+jk),surf.r2((ja-1)*nK+jk)}; %#ok<AGROW>
Witnesses=cell2table(Wit,'VariableNames',{'Domain','Extremum','StageC2_wtfrac','TScenario','SorptionScenario','ChemistryScenario','EX2_f1_sorbed','r1','r2'});
writetable(Witnesses,fullfile(outdir,'StageJ1_composition_witnesses.csv'));

% Final bulk-C2 partial-identification intervals for pure-PP matrix bookkeeping.
BR=cell(numel(cfg.StageJ1.EPC),5);
for i=1:numel(cfg.StageJ1.EPC)
 e=cfg.StageJ1.EPC(i);BR(i,:)={e,e*unionMin,e*unionMax,e*(unionMax-unionMin),'FINAL_C2_WTFRAC__PURE_PP_MATRIX_BOOKKEEPING'};
end
Bulk=cell2table(BR,'VariableNames',{'EPC_wtfrac','BulkC2Min','BulkC2Max','BulkC2Width','Quantity'});writetable(Bulk,fullfile(outdir,'StageJ1_bulk_C2_intervals.csv'));
PR=cell(0,7);
for i=1:height(Bulk)
 for j=i+1:height(Bulk)
  margin=Bulk.BulkC2Min(j)-Bulk.BulkC2Max(i);PR(end+1,:)={Bulk.EPC_wtfrac(i),Bulk.EPC_wtfrac(j),Bulk.BulkC2Max(i),Bulk.BulkC2Min(j),margin,margin<=0,tern(margin<=0,'OVERLAP_AT_FULL_J1_DOMAIN','SEPARATED_AT_FULL_J1_DOMAIN')}; %#ok<AGROW>
 end
end
Pairwise=cell2table(PR,'VariableNames',{'LowerEPC','HigherEPC','LowerGradeUpperC2','HigherGradeLowerC2','SeparationMargin','IntervalsOverlap','Status'});writetable(Pairwise,fullfile(outdir,'StageJ1_bulk_C2_pairwise_overlap.csv'));
Critical=stageJ1_critical_kappa_upper(cfg,Tset(1),Sp,surf);writetable(Critical,fullfile(outdir,'StageJ1_mechanistic_critical_kappa_upper.csv'));

% Deterministic composition VOI. Primary union treats chemistry state as one
% block; mechanistic-only audit separates reference level from pattern.
C2HiFlat=reshape(C2Hi,[nT nS nL*nP nA nK]);
C2Union=cat(3,C2Leg,C2HiFlat);
UnionVOI=stageJ1_singleton_voi(C2Union,{'FBR_H2_AND_T80_STATE','FBR_SORPTION','HIGH_EP_CHEMISTRY_MODEL_STATE','EX2_SORBED_F1','REACTIVITY_CURVE_COORD'},'FINAL_UNION');
HighVOI=stageJ1_singleton_voi(C2Hi,{'FBR_H2_AND_T80_STATE','FBR_SORPTION','HIGH_EP_SELECTIVITY_LEVEL','POPULATION_SELECTIVITY_PATTERN','EX2_SORBED_F1','REACTIVITY_CURVE_COORD'},'HIGH_EP_MECHANISTIC');
Selected=stageJ1_selected_subset_voi(C2Hi,{'FBR_H2_AND_T80_STATE','FBR_SORPTION','HIGH_EP_SELECTIVITY_LEVEL','POPULATION_SELECTIVITY_PATTERN','EX2_SORBED_F1','REACTIVITY_CURVE_COORD'},[3 4],'HIGH_EP_MECHANISTIC');
writetable(UnionVOI,fullfile(outdir,'StageJ1_union_VOI_singletons.csv'));writetable(HighVOI,fullfile(outdir,'StageJ1_mechanistic_VOI_singletons.csv'));writetable(Selected,fullfile(outdir,'StageJ1_selected_VOI_subsets.csv'));

% Frozen Stage-J baseline regression.
J=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageJQualifiedOutputs','StageJ_composition_ranges_by_span.csv'));
q=J.ChemistryOddsSpan==cfg.site_response.odds_span & strcmp(string(J.H2BranchScope),'UNION_ALL_H2_BRANCHES');
if sum(q)~=1,error('StageJ1:StageJBaseline','Qualified Stage-J legacy composition row missing.');end
Regression=table(J.StageC2Min(q),J.StageC2Max(q),legMin,legMax,abs(J.StageC2Min(q)-legMin),abs(J.StageC2Max(q)-legMax), ...
 'VariableNames',{'FrozenStageJLegacyMin','FrozenStageJLegacyMax','StageJ1LegacyMin','StageJ1LegacyMax','MinAbsDiff','MaxAbsDiff'});writetable(Regression,fullfile(outdir,'StageJ1_frozen_StageJ_regression.csv'));

% Held-out external challenge. These rows are read only AFTER the J.1 support
% and tensors have been constructed.
Ext=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageJQualifiedOutputs','StageJ_external_evidence_registry.csv'));
qStage=ismember(string(Ext.QuantityCode),["RUBBER_RICH_C2_WTFRAC","COPOLYMER_C2_WTFRAC","XYLENE_SOLUBLE_C2_WTFRAC"]);Es=Ext(qStage,:);HR=cell(0,10);
for i=1:height(Es)
 lo=Es.ValueLo(i);hi=Es.ValueHi(i);ov=unionMax>=lo&&unionMin<=hi;ct=unionMin<=lo&&unionMax>=hi;gap=max([lo-unionMax,unionMin-hi,0]);
 HR(end+1,:)={char(string(Es.ID(i))),char(string(Es.Source(i))),char(string(Es.QuantityCode(i))),char(string(Es.Comparability(i))),lo,hi,ov,ct,gap,'HELD_OUT_NOT_USED_TO_SET_J1_SUPPORT'}; %#ok<AGROW>
end
HoldStage=cell2table(HR,'VariableNames',{'EvidenceID','Source','ExternalQuantity','Comparability','ExternalLo','ExternalHi','AnyOverlap','ContainsExternalDatumOrRange','Gap','Status'});
qBulk=strcmp(string(Ext.Comparability),'DIRECT_BULK_C2_AT_MATCHED_NOMINAL_EPC');Eb=Ext(qBulk,:);HB=cell(0,10);
for i=1:height(Eb)
 e=Eb.EPC_wtfrac(i);obs=Eb.ValueLo(i);lo=e*unionMin;hi=e*unionMax;cv=obs>=lo&&obs<=hi;gap=max([obs-hi,lo-obs,0]);
 HB(end+1,:)={char(string(Eb.ID(i))),char(string(Eb.Source(i))),e,lo,hi,obs,cv,gap,char(string(Eb.Comparability(i))),'HELD_OUT_NOT_USED_TO_SET_J1_SUPPORT'}; %#ok<AGROW>
end
HoldBulk=cell2table(HB,'VariableNames',{'EvidenceID','Source','EPC_wtfrac','ModelBulkC2Min','ModelBulkC2Max','ExternalBulkC2','ExternalPointCovered','Gap','Comparability','Status'});
writetable(HoldStage,fullfile(outdir,'StageJ1_external_stage_holdout_coverage.csv'));writetable(HoldBulk,fullfile(outdir,'StageJ1_external_bulk_holdout_coverage.csv'));

% Claim requalification and strict scope.
claims={'StageF_second_stage_C2_interval';'StageD1_C2_critical_rho';'StageF_composition_VOI_percentages';'StageG_positive_joint_W1';'StageH_to_H2_orders_under_final_J1_state_domain';'Matched_industrial_Spherizone_validation'};
status={'SUPERSEDED_BY_J1_SET_UNION_INTERVAL';'SUPERSEDED_AS_FINAL_CHEMISTRY_ROBUSTNESS_METRIC';'SUPERSEDED_BY_J1_COMPOSITION_VOI';'REMAINS_QUALIFIED_AFTER_STAGE_J';'NOT_REQUALIFIED_IN_STAGE_J1';'NOT_ESTABLISHED'};
meaning={'The legacy interval remains a valid subset but is not the final physically admissible high-E/P composition domain.'; ...
 'Full J.1 bulk-C2 intervals overlap at baseline; no positive legacy rho_C threshold is retained as a final claim. Mechanistic-only kappa-upper crossings are diagnostics.'; ...
 'J.1 reports deterministic oracle contractions under the final union and mechanistic-only chemistry domains.'; ...
 'Stage J already demonstrated W1 survival over expanded FBR-H2/T80 branches; J.1 changes composition chemistry, while Stage-G DP repeat-mass support spans the full E/P repeat-mass interval.'; ...
 'H/H.1/H.2 representation-order claims require a later rerun over the finalized state/model-form domain.'; ...
 'Held-out external datasets remain comparators/challenges and do not become matched validation.'};
Claims=table(claims,status,meaning,'VariableNames',{'Claim','Status','Meaning'});writetable(Claims,fullfile(outdir,'StageJ1_claim_requalification.csv'));
sc={'ZHANG_KPE_KPP_TRANSFERRED_AS_ALSHAIBAN_KINETIC_CONSTANTS';'J1_KAPPA_EQUALS_MAYO_LEWIS_REACTIVITY_RATIO';'CANCELAS_BOTHA_WANG_USED_TO_SET_KAPPA_SUPPORT';'HELDOUT_COVERAGE_EQUALS_MODEL_VALIDATION';'LEGACY_STAGEJ_DOMAIN_RETAINED_AS_SUBSET';'H_H1_H2_REQUALIFIED_IN_STAGEJ1'};
ss={'NOT_ESTABLISHED';'NOT_ESTABLISHED';'PROHIBITED_AND_NOT_DONE';'NOT_ESTABLISHED';'ESTABLISHED_BY_CONSTRUCTION';'NO'};
sm={'Zhang data motivate outward model-form support only; numerical catalyst constants are not transferred.';'Kappa is a reduced-order effective preference coordinate on sorbed E/P odds, not r1 or r2.';'Challenge data are read only after support/tensor construction.';'Coverage is an external consistency challenge, not matched validation.';'The frozen Stage-J chemistry family is explicitly unioned with the new mechanistic branch.';'Representation-order requalification is deferred until composition chemistry is frozen.'};
Scope=table(sc,ss,sm,'VariableNames',{'Statement','Status','Interpretation'});writetable(Scope,fullfile(outdir,'StageJ1_scope.csv'));

result=struct('Evidence',E,'Support',Support,'Contrast',Contrast,'SupportSensitivity',SupportSensitivity,'Patterns',P,'HighScenarios',SHi,'Domain',Domain,'Witnesses',Witnesses,'Bulk',Bulk,'Pairwise',Pairwise,'Critical',Critical, ...
 'UnionVOI',UnionVOI,'HighVOI',HighVOI,'SelectedVOI',Selected,'Regression',Regression,'HoldStage',HoldStage,'HoldBulk',HoldBulk,'Claims',Claims,'Scope',Scope, ...
 'FinalStageC2Min',unionMin,'FinalStageC2Max',unionMax,'HighStageC2Min',hiMin,'HighStageC2Max',hiMax,'AllStageHoldoutCovered',all(HoldStage.ContainsExternalDatumOrRange),'AllBulkHoldoutCovered',all(HoldBulk.ExternalPointCovered));
end

function y=tern(c,a,b)
if c,y=a;else,y=b;end
end
