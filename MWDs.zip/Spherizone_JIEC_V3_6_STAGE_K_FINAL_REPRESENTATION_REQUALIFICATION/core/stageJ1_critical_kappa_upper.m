function T = stageJ1_critical_kappa_upper(cfg,pop,Sp,surf)
%STAGEJ1_CRITICAL_KAPPA_UPPER Mechanistic-only nested-support overlap audit.
% Lower kappa is held at 2; upper kappa expands continuously to 32. This is a
% deterministic support-width coordinate, not a fitted kinetic parameter.
kl=cfg.StageJ1.kappa_support(1); kuMax=cfg.StageJ1.kappa_support(2);
[minLo,~,~,~]=stageJ1_homogeneous_kappa_range(pop,Sp,surf,kl);
E=cfg.StageJ1.EPC; rows=cell(0,8);
for i=1:numel(E)
 for j=i+1:numel(E)
  e1=E(i); e2=E(j);
  [~,mxLo,~,~]=stageJ1_homogeneous_kappa_range(pop,Sp,surf,kl);
  margin0=e2*minLo-e1*mxLo;
  [~,mxHi,~,~]=stageJ1_homogeneous_kappa_range(pop,Sp,surf,kuMax);
  marginHi=e2*minLo-e1*mxHi;
  if margin0<=0
   crit=kl; stat='OVERLAP_AT_LOWER_SUPPORT_BOUND'; bracket=0;
  elseif marginHi>0
   crit=NaN; stat='NO_OVERLAP_WITHIN_DECLARED_SUPPORT'; bracket=NaN;
  else
   a=kl; b=kuMax;
   for it=1:cfg.StageJ1.critical_max_iter
    m=0.5*(a+b); [~,mx,~,~]=stageJ1_homogeneous_kappa_range(pop,Sp,surf,m); marg=e2*minLo-e1*mx;
    if marg>0,a=m;else,b=m;end
    if b-a<=cfg.StageJ1.critical_kappa_tol,break;end
   end
   crit=0.5*(a+b); bracket=b-a; stat='REFINED_POSITIVE_TO_OVERLAP_CROSSING';
  end
  rows(end+1,:)={e1,e2,minLo,margin0,marginHi,crit,bracket,stat}; %#ok<AGROW>
 end
end
T=cell2table(rows,'VariableNames',{'LowerEPC','HigherEPC','MechanisticStageC2MinAtKappa2','MarginAtKappaUpper2','MarginAtKappaUpper32','CriticalKappaUpper','BracketWidth','Status'});
end
