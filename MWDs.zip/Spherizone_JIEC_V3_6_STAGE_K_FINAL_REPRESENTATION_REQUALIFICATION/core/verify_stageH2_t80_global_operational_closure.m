function V=verify_stageH2_t80_global_operational_closure(cfg,outdir,result)
%VERIFY_STAGEH2_T80_GLOBAL_OPERATIONAL_CLOSURE Executable H.2 qualification.
ROOT=fileparts(fileparts(mfilename('fullpath')));Gate={};Status={};Detail={};
add('H2_0_STAGE_H1_PREREQUISITE',gateH1(),'Qualified v3.1.1 Stage-H.1 output is present.');
add('H2_1_COMPLETENESS',height(result.Supports)==62 && height(result.Descriptors)==5436 && height(result.PartTable)==156 && height(result.Summary)==90 && height(result.OrderMap)==54, ...
    'Expected 31 groups x 2 transfer supports; 5436 descriptor rows; 156 partition rows; 90 minimax rows; 54 tolerance rows.');
[okS,detS]=mirrorSupports();add('H2_2_INDEPENDENT_GLOBAL_SUPPORT_MIRROR',okS,detS);
add('H2_3_T80_AND_HIDDEN_STATE_ACCESS_REMOVED',all(strcmp(result.Descriptors.T80BranchAccess,'NONE')) && all(strcmp(result.Descriptors.HiddenWeightAlphaAccess,'NONE')) && all(strcmp(result.Descriptors.DescriptorRule,'T80_GLOBAL_TARGET_MINIMAX_FIXED_SCALAR')), ...
    'Every descriptor is fixed without T80-branch, hidden-weight, or DP-alpha access.');
[okC,detC]=containsH1Supports();add('H2_4_GLOBAL_SUPPORT_CONTAINS_H1_BRANCH_SUPPORTS',okC,detC);
[okP,detP]=mirrorPartition();add('H2_5_INDEPENDENT_PARTITION_MIRROR',okP,detP);
[okM,detM]=mirrorSummary();add('H2_6_INDEPENDENT_MINIMAX_MIRROR',okM,detM);
add('H2_7_BOUND_ORDER',max(result.PartTable.DRel_lower-result.PartTable.DRel_upper)<=1e-12,'D witness lower bounds do not exceed conservative upper bounds.');
add('H2_8_MONOTONE_WITH_K',monotoneSummary(),'Best T80-global closure errors are nonincreasing with K.');
[okO,detO]=mirrorOrder();add('H2_9_INDEPENDENT_ORDER_MAP_MIRROR',okO,detO);
O=result.OrderMap;no=contains(O.GlobalClosureStatus,'NO_T80_GLOBAL');
add('H2_10_NO_FORCED_K_WHEN_GLOBAL_CLOSURE_FAILS',all(isnan(O.K_global_certified_sufficient(no))),'No failed T80-global closure is silently relabeled K=5.');
add('H2_11_RESTRICTION_DOMINANCE_OVER_H1',all(result.PenaltyTable.GlobalNotBetterGuard) && min(result.PenaltyTable.UpperPenaltyAbs)>=-1e-12, ...
    'Removing T80-branch access never improves the H.1 minimax upper error.');
[okR,detR]=mirrorPenalty();add('H2_12_INDEPENDENT_H1_TO_H2_PENALTY_MIRROR',okR,detR);
add('H2_13_NO_INVALID_GLOBAL_ORDER_IMPROVEMENT',~any(contains(result.GapTable.T80GlobalizationEffect,'INVALID_')), ...
    'A stronger T80-global restriction never creates a lower certified order than H.1.');
q=strcmp(result.MetricScope.Metric,'FINAL_D_REL');
add('H2_14_D_SCOPE_GUARD',any(q) && contains(result.MetricScope.Status{find(q,1)},'CONSERVATIVE'),'D remains explicitly bracketed rather than mislabeled exact.');
q=strcmp(result.ClaimScope.Claim,'ONE_DESCRIPTOR_SET_ACROSS_BOTH_TRANSFER_FORMULATIONS');
add('H2_15_TRANSFER_FORMULATION_SCOPE_GUARD',any(q) && strcmp(result.ClaimScope.ClaimStatus{find(q,1)},'NOT_ESTABLISHED'),'H.2 remains conditional on the declared DIRECT versus DP formulation.');
q=strcmp(result.ClaimScope.Claim,'ONE_UNIFIED_REDUCED_MODEL_FOR_ALL_TARGETS');
add('H2_16_TARGET_SPECIFIC_SCOPE_GUARD',any(q) && strcmp(result.ClaimScope.ClaimStatus{find(q,1)},'NOT_ESTABLISHED'),'Target-specific descriptors are not relabeled as one universal reduced model.');
add('H2_17_CLOSURE_FAILURE_IS_SCIENTIFIC_OUTCOME',all(ismember(unique(O.GlobalClosureStatus),{'NO_T80_GLOBAL_FIXED_SCALAR_CLOSURE_EVEN_POSSIBLE','NO_CERTIFIED_T80_GLOBAL_FIXED_SCALAR_CLOSURE','CERTIFIED_T80_GLOBAL_FIXED_SCALAR_KSTAR','T80_GLOBAL_FIXED_SCALAR_KSTAR_BRACKETED'})), ...
    'No-K outcomes are permitted scientific results and do not fail executable qualification.');
V=table(Gate',Status',Detail','VariableNames',{'Gate','Status','Detail'});writetable(V,fullfile(outdir,'StageH2_verification.csv'));

 function add(n,ok,d),Gate{end+1}=n;if ok,Status{end+1}='PASS';else,Status{end+1}='FAIL';end;Detail{end+1}=d;end
 function ok=gateH1()
  f=fullfile(ROOT,'inputs','StageH1QualifiedOutputs','STAGE_H1_STATUS.txt');ok=exist(f,'file')==2 && contains(fileread(f),'STAGE_H1_T80_CONDITIONAL_FIXED_DESCRIPTOR_CLOSURE_QUALIFIED');
 end
 function [ok,detail]=mirrorSupports()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH2_expected_global_group_supports.csv'));S=result.Supports;d=[];bad=0;tbad=0;
  for r=1:height(E)
   ix=strcmp(S.GroupCode,E.GroupCode{r}) & strcmp(S.TransferMode,E.TransferMode{r});if sum(ix)~=1,bad=bad+1;continue;end
   d(end+1)=abs(S.Support_Mlo_gmol(ix)-E.ExpectedSupport_Mlo_gmol(r));d(end+1)=abs(S.Support_Mhi_gmol(ix)-E.ExpectedSupport_Mhi_gmol(r)); %#ok<AGROW>
   if ~strcmp(S.T_at_Mlo{find(ix,1)},E.Expected_T_at_Mlo{r}) || ~strcmp(S.T_at_Mhi{find(ix,1)},E.Expected_T_at_Mhi{r}),tbad=tbad+1;end
  end
  md=max(d);ok=bad==0 && tbad==0 && md<=cfg.StageH2.support_mirror_abs_tol_gmol;detail=sprintf('62 global supports; missing=%d; T-extrema mismatches=%d; max discrepancy=%.6g g/mol',bad,tbad,md);
 end
 function [ok,detail]=containsH1Supports()
  H=readtable(fullfile(ROOT,'inputs','StageH1QualifiedOutputs','StageH1_fixed_group_descriptors.csv'));S=result.Supports;
  H=unique(H(:,{'GroupCode','TScenario','TransferMode','Support_Mlo_gmol','Support_Mhi_gmol'}));
  tol=cfg.StageH2.containment_abs_tol_gmol;missing=0;maxLoViolation=0;maxHiViolation=0;
  for r=1:height(H)
   ix=strcmp(S.GroupCode,H.GroupCode{r}) & strcmp(S.TransferMode,H.TransferMode{r});
   if sum(ix)~=1,missing=missing+1;continue;end
   maxLoViolation=max(maxLoViolation,max(0,S.Support_Mlo_gmol(ix)-H.Support_Mlo_gmol(r)));
   maxHiViolation=max(maxHiViolation,max(0,H.Support_Mhi_gmol(r)-S.Support_Mhi_gmol(ix)));
  end
  ok=missing==0 && maxLoViolation<=tol && maxHiViolation<=tol;
  detail=sprintf('%d H.1 branch supports; missing=%d; max lower/upper containment violations=%.6g/%.6g g/mol; tolerance=%.6g g/mol',height(H),missing,maxLoViolation,maxHiViolation,tol);
 end
 function [ok,detail]=mirrorPartition()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH2_expected_partition_bounds.csv'));P=result.PartTable;d=[];bad=0;
  fields={'MnRel_lower','MnRel_upper','MwRel_lower','MwRel_upper','DRel_lower','DRel_upper','W1_lower_decades','W1_upper_decades','Tail90_lower_abs','Tail90_upper_abs','Tail99_lower_abs','Tail99_upper_abs'};
  for r=1:height(E)
   ix=strcmp(P.PartitionCode,E.PartitionCode{r}) & P.K==E.K(r) & abs(P.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12;if sum(ix)~=1,bad=bad+1;continue;end
   for k=1:numel(fields),d(end+1)=abs(P.(fields{k})(ix)-E.(fields{k})(r));end %#ok<AGROW>
  end
  md=max(d);ok=bad==0 && md<=cfg.StageH2.mirror_abs_tol;detail=sprintf('156 partition rows; mismatches=%d; max discrepancy=%.6g',bad,md);
 end
 function [ok,detail]=mirrorSummary()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH2_expected_target_minimax_summary.csv'));S=result.Summary;d=[];bad=0;pbad=0;
  for r=1:height(E)
   ix=strcmp(S.Target,E.Target{r}) & abs(S.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12 & S.K==E.K(r);if sum(ix)~=1,bad=bad+1;continue;end
   d(end+1)=abs(S.MinimaxLower(ix)-E.ExpectedMinimaxLower(r));d(end+1)=abs(S.MinimaxUpper(ix)-E.ExpectedMinimaxUpper(r)); %#ok<AGROW>
   rr=find(ix,1);if ~strcmp(S.BestPartitionLower{rr},E.ExpectedBestPartitionLower{r}) || ~strcmp(S.BestPartitionUpper{rr},E.ExpectedBestPartitionUpper{r}),pbad=pbad+1;end
  end
  md=max(d);ok=bad==0 && pbad==0 && md<=cfg.StageH2.mirror_abs_tol;detail=sprintf('90 minimax rows; missing=%d; partition mismatches=%d; max discrepancy=%.6g',bad,pbad,md);
 end
 function ok=monotoneSummary()
  S=result.Summary;ok=true;tg=unique(S.Target,'stable');ep=unique(S.EPC_wtfrac);
  for a=1:numel(tg),for b=1:numel(ep),ix=strcmp(S.Target,tg{a}) & abs(S.EPC_wtfrac-ep(b))<1e-12;X=S(ix,:);[~,o]=sort(X.K);X=X(o,:);ok=ok&&all(diff(X.MinimaxLower)<=1e-10)&&all(diff(X.MinimaxUpper)<=1e-10);end,end
 end
 function [ok,detail]=mirrorOrder()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH2_expected_target_order_map.csv'));O=result.OrderMap;bad=0;
  for r=1:height(E)
   ix=strcmp(O.Target,E.Target{r}) & abs(O.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12 & strcmp(O.ToleranceLabel,E.ToleranceLabel{r});if sum(ix)~=1,bad=bad+1;continue;end
   a=O.K_global_possible_lower(ix);b=E.Expected_K_global_possible_lower(r);if ~(isnan(a)&&isnan(b)) && a~=b,bad=bad+1;end
   a=O.K_global_certified_sufficient(ix);b=E.Expected_K_global_certified_sufficient(r);if ~(isnan(a)&&isnan(b)) && a~=b,bad=bad+1;end
   if ~strcmp(O.GlobalClosureStatus{find(ix,1)},E.ExpectedStatus{r}),bad=bad+1;end
  end
  ok=bad==0;detail=sprintf('54 order rows; field/status mismatches=%d',bad);
 end
 function [ok,detail]=mirrorPenalty()
  E=readtable(fullfile(ROOT,'Independent_Audit','StageH2_expected_H1_to_H2_penalty.csv'));P=result.PenaltyTable;d=[];bad=0;
  fields={'H1_T80Conditional_MinimaxLower','H1_T80Conditional_MinimaxUpper','H2_T80Global_MinimaxLower','H2_T80Global_MinimaxUpper','UpperPenaltyAbs'};
  for r=1:height(E)
   ix=strcmp(P.Target,E.Target{r}) & abs(P.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12 & P.K==E.K(r);if sum(ix)~=1,bad=bad+1;continue;end
   for k=1:numel(fields),d(end+1)=abs(P.(fields{k})(ix)-E.(fields{k})(r));end %#ok<AGROW>
  end
  md=max(d);ok=bad==0 && md<=cfg.StageH2.mirror_abs_tol;detail=sprintf('90 H.1->H.2 penalty rows; mismatches=%d; max discrepancy=%.6g',bad,md);
 end
end
