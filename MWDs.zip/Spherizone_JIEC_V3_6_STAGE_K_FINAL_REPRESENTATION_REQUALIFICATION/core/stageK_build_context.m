function ctx = stageK_build_context(cfg)
%STAGEK_BUILD_CONTEXT Final representation-order state support.
% Chemistry is not re-enumerated here: the DP formulation in H/H.1/H.2
% already permits alpha_j independently over the full E/P repeat-mass range
% [M2/M3,1], which is a superset of every J.1 composition realization.
Tset = stageJ_build_T80_challenge_set(cfg);
if numel(Tset) ~= cfg.StageK.expected_T_state_count
    error('StageK:TStateCount','Expected %d Stage-J H2/T80 states; found %d.',cfg.StageK.expected_T_state_count,numel(Tset));
end
for ib=1:numel(cfg.StageK.expected_branch_names)
    n=sum(strcmp({Tset.H2Branch},cfg.StageK.expected_branch_names{ib}));
    if n~=cfg.StageK.expected_branch_counts(ib)
        error('StageK:BranchCount','Branch %s expected %d states; found %d.',cfg.StageK.expected_branch_names{ib},cfg.StageK.expected_branch_counts(ib),n);
    end
end
ctx=struct('Tp',Tset,'modes',{{'DIRECT_MN_TRANSFER','DP_REPEAT_MASS_CORRECTED'}}, ...
    'EPC',cfg.StageH.EPC,'AlphaMin',cfg.StageH.M2_gmol/cfg.StageH.M3_gmol,'AlphaMax',1);
end
