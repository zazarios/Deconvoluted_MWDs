function [vmax,tbest] = stageH_maximize_t(fun,cfg)
%STAGEH_MAXIMIZE_T Deterministic 1-D global search on t in [0,1].
% A fixed seed grid is followed by local bounded refinements around the top
% seed values. No uncertainty-state-dependent tolerance or target is selected.
ng=cfg.StageH.t_seed_points;
tg=linspace(0,1,ng); vg=zeros(size(tg));
for i=1:ng, vg(i)=fun(tg(i)); end
[vmax,ib]=max(vg); tbest=tg(ib);
[~,ord]=sort(vg,'descend'); nr=min(cfg.StageH.t_refine_top,numel(ord));
opts=optimset('TolX',cfg.StageH.t_tol,'Display','off');
for k=1:nr
    i=ord(k); lo=tg(max(1,i-1)); hi=tg(min(ng,i+1));
    if hi<=lo, continue; end
    [tt,fneg]=fminbnd(@(t)-fun(t),lo,hi,opts); vv=-fneg;
    if vv>vmax, vmax=vv; tbest=tt; end
end
if vmax<0 && vmax>-1e-12, vmax=0; end
end
