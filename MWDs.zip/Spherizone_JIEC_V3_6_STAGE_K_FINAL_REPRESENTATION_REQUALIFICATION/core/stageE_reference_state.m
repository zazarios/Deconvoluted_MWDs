function ref = stageE_reference_state(cfg,ctx,transferMode)
%STAGEE_REFERENCE_STATE Transparent Stage-B reference state, extended to a transfer mode.
% This is a computational reference, not a posterior mean or best estimate.

it=find(strcmp({ctx.Tp.name},cfg.StageB.reference.TScenario),1);
if isempty(it), error('Stage-E reference T scenario missing.'); end
is=find(strcmp({ctx.Sp.name},cfg.StageB.reference.FBR_sorption),1);
if isempty(is), error('Stage-E reference sorption scenario missing.'); end
C=site_response_scenarios(5,cfg.site_response.odds_span);
ic=find(strcmp({C.name},cfg.StageB.reference.chemistry),1);
if isempty(ic), error('Stage-E reference chemistry scenario missing.'); end
fmid=0.5*(ctx.anchor.f1_min+ctx.anchor.f1_max);
r2target=cfg.EX2.primary_r2_bounds(1)+cfg.StageB.reference.r2_fraction_of_screen*diff(cfg.EX2.primary_r2_bounds);
d=((ctx.surf.f1_EX2-fmid)/(ctx.anchor.f1_max-ctx.anchor.f1_min)).^2 + ...
  ((ctx.surf.r2-r2target)/diff(cfg.EX2.primary_r2_bounds)).^2;
[~,ir]=min(d);
pop=ctx.Tp(it);
st=stage_population_state(pop,ctx.Sp(is).f1_sorbed,ctx.surf.r1(ir),ctx.surf.r2(ir),C(ic),transferMode);
MnJ=st.MnJ(1,:);
w=pop.w(:)'; active=w>0 & isfinite(MnJ); w(~active)=0; w=w/sum(w);
ref=struct('TransferMode',transferMode,'TIndex',it,'TScenario',pop.name, ...
    'SorptionIndex',is,'SorptionScenario',ctx.Sp(is).name,'FBR_f1_sorbed',ctx.Sp(is).f1_sorbed, ...
    'ChemistryIndex',ic,'ChemistryScenario',C(ic).name,'ChemistryMultiplier',C(ic).ethylene_odds_multiplier, ...
    'ReactivityIndex',ir,'EX2_f1_anchor',ctx.surf.f1_EX2(ir),'r1',ctx.surf.r1(ir),'r2',ctx.surf.r2(ir), ...
    'WeightScenario','W0_inherited_population_weights','WeightMultiplier',ones(1,5), ...
    'stage_w',w,'stage_Mn_population_gmol',MnJ);
end
