function out = stageH_group_support_bounds(Mn_gmol,members,mode,e,matrixMw,Mgrid,Mtail90,Mtail99,cfg)
%STAGEH_GROUP_SUPPORT_BOUNDS Certified/conservative group reduction bounds.
% For groups of >=2 labels, reciprocal-Mn support is enlarged to its continuous
% hull. W1/tail use Jensen-envelope bounds. Mw/D use the exact endpoint-mixture
% maximum; those endpoints are admissible because the group contains >=2 labels.
if numel(members)<=1
    out=struct('W1_upper_final_decades',0,'MwRel_exact',0,'DRel_exact',0, ...
        'Tail90_upper_final_abs',0,'Tail99_upper_final_abs',0,'sLo',NaN,'sHi',NaN,'t_Mw',NaN);
    return
end
Mn=Mn_gmol(members); sLo=min(1./Mn);
if strcmpi(mode,'DIRECT_MN_TRANSFER')
    sHi=max(1./Mn);
elseif strcmpi(mode,'DP_REPEAT_MASS_CORRECTED')
    a0=cfg.StageH.M2_gmol/cfg.StageH.M3_gmol;
    sHi=max(1./(a0.*Mn));
else
    error('StageH:Mode','Unknown transfer mode.');
end
HB=stageG_jensen_support_bounds(Mgrid,sLo,sHi,cfg.StageH.finite_grid_cdf_pad,cfg.StageH.root_tol,cfg.StageH.max_bisection_iter);
x=log10(Mgrid(:)'); W1stage=trapz(x,max(abs(HB.hmin),abs(HB.hmax)));
% Exact scalar relative-error maximum over the continuous hull endpoints.
fm=@(t) stageH_pair_Mw_rel_support(sLo,sHi,t,e,matrixMw);
[MwRel,tMw]=stageH_maximize_t(fm,cfg);
% Pointwise tail-mass bounds over the same hull. Preserve the Stage-G CDF pad.
pad=2*cfg.StageH.finite_grid_cdf_pad;
R90=stageG_jensen_gap_u_interval(Mtail90*sLo,Mtail90*sHi,cfg.StageH.root_tol,cfg.StageH.max_bisection_iter);
R99=stageG_jensen_gap_u_interval(Mtail99*sLo,Mtail99*sHi,cfg.StageH.root_tol,cfg.StageH.max_bisection_iter);
T90=min(1,max(abs([R90.hmin-pad,R90.hmax+pad])));
T99=min(1,max(abs([R99.hmin-pad,R99.hmax+pad])));
out=struct('W1_upper_final_decades',e*W1stage,'MwRel_exact',MwRel,'DRel_exact',MwRel, ...
    'Tail90_upper_final_abs',e*T90,'Tail99_upper_final_abs',e*T99,'sLo',sLo,'sHi',sHi,'t_Mw',tMw);
end

function r=stageH_pair_Mw_rel_support(s1,s2,t,e,matrixMw)
sb=t*s1+(1-t)*s2;
A=t/s1+(1-t)/s2; B=1/sb;
full=(1-e)*matrixMw+2*e*A; red=(1-e)*matrixMw+2*e*B;
r=max(0,(full-red)/full);
end
