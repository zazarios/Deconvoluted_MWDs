function T = stageF_minimax_subset_table(A,blockNames,targetName,transferMode,EPC)
%STAGEF_MINIMAX_SUBSET_TABLE Deterministic set-based block-resolution audit.
% For each subset of resolved epistemic blocks, condition on every possible
% resolved-block state, allow all unresolved blocks to vary, and report the
% largest residual target width. The guaranteed contraction is minimax and
% uses no probability distribution.
if nargin<5, EPC=NaN; end
nB=numel(blockNames);
sz=size(A); if numel(sz)<nB, sz(end+1:nB)=1; end
if numel(sz)~=nB, error('StageF:TensorDimensionMismatch','Target tensor must have one dimension per information block.'); end
baseline=max(A(:))-min(A(:));
rows=cell(2^nB,11);
for mask=0:(2^nB-1)
    resolved=find(bitget(uint32(mask),1:nB));
    unresolved=setdiff(1:nB,resolved,'stable');
    if isempty(unresolved)
        worst=0; best=0;
    else
        perm=[resolved unresolved];
        B=permute(A,perm);
        if isempty(resolved), nR=1; else, nR=prod(sz(resolved)); end
        nU=prod(sz(unresolved));
        B=reshape(B,[nR nU]);
        widths=max(B,[],2)-min(B,[],2);
        worst=max(widths); best=min(widths);
    end
    if isempty(resolved), label='NONE'; else, label=strjoin(blockNames(resolved),'+'); end
    if baseline>0
        g=1-worst/baseline; bc=1-best/baseline;
    else
        g=NaN; bc=NaN;
    end
    rows{mask+1,1}=targetName;
    rows{mask+1,2}=transferMode;
    rows{mask+1,3}=EPC;
    rows{mask+1,4}=mask;
    rows{mask+1,5}=numel(resolved);
    rows{mask+1,6}=label;
    rows{mask+1,7}=baseline;
    rows{mask+1,8}=worst;
    rows{mask+1,9}=best;
    rows{mask+1,10}=g;
    rows{mask+1,11}=bc;
end
T=cell2table(rows,'VariableNames',{'Target','TransferMode','EPC_wtfrac','ResolvedMask','Cardinality','ResolvedBlocks', ...
    'BaselineWidth','WorstResidualWidth','BestResidualWidth','GuaranteedContractionFraction','BestCaseContractionFraction'});
end
