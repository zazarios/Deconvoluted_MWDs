function [Wit,Reg] = find_stageE_worst_structural_witnesses(cfg,ctx,outdir)
%FIND_STAGEE_WORST_STRUCTURAL_WITNESSES Reconstruct the adverse B2 structural witnesses.
% Witness selection is pre-specified by the Stage-B2 objective:
% minimum (D_resolved - D_phasewise_singleFlory) under the independent
% factor-two population-weight transfer stress. Stage E does NOT select cases
% by maximizing its own distribution-distance metrics.

C=site_response_scenarios(5,cfg.site_response.odds_span);
W=population_weight_transfer_scenarios(5,cfg.site_response.odds_span);
EPC=cfg.StageE.EPC(:)';
modes={'DIRECT_MN_TRANSFER','DP_REPEAT_MASS_CORRECTED'};
matrix=ctx.matrix;

% One record per transfer mode and EPC fraction.
best=repmat(struct('DeltaD',inf,'mode','','epc',NaN,'it',NaN,'is',NaN,'ic',NaN,'ir',NaN,'iw',NaN, ...
    'StageMn',NaN,'StageMw',NaN,'FinalMn',NaN,'FinalMw',NaN,'FinalD',NaN,'ComparatorD',NaN),numel(modes),numel(EPC));
for im=1:numel(modes)
    for ie=1:numel(EPC), best(im,ie).mode=modes{im}; best(im,ie).epc=EPC(ie); end
end

% DIRECT_MN_TRANSFER: MWD is invariant to sorption, reactivity, and latent
% chemistry. Search only T scenario x population-weight stress; retain the
% first primary sorption/reactivity point and C0 as a transparent witness label.
im=1; mode=modes{im};
is=1; ic=find(strcmp({C.name},'C0_homogeneous'),1); ir=1;
for it=1:numel(ctx.Tp)
    pop=ctx.Tp(it); active=pop.w>0 & isfinite(pop.Mn_gmol);
    w0=pop.w(:)'; w0(~active)=0; w0=w0/sum(w0);
    Wmat=zeros(numel(W),sum(active));
    for iw=1:numel(W)
        we=w0.*W(iw).yield_multiplier(:)'; we(~active)=0; we=we/sum(we);
        Wmat(iw,:)=we(active);
    end
    MnA=pop.Mn_gmol(active);
    stageMn=1./((1./MnA)*Wmat');
    stageMw=2*(MnA*Wmat');
    for ie=1:numel(EPC)
        e=EPC(ie);
        Bmn=1./((1-e)/matrix.Mn_gmol + e./stageMn);
        Bmw=(1-e)*matrix.Mw_gmol + e.*stageMw;
        Bd=Bmw./Bmn;
        Smw=(1-e)*(2*matrix.Mn_gmol) + e.*(2*stageMn);
        Sd=Smw./Bmn;
        delta=Bd-Sd;
        [v,iw]=min(delta);
        if v<best(im,ie).DeltaD
            best(im,ie)=packbest_E(it,is,ic,ir,iw,v,stageMn(iw),stageMw(iw),Bmn(iw),Bmw(iw),Bd(iw),Sd(iw),mode,e);
        end
    end
end

% DP_REPEAT_MASS_CORRECTED: search the full primary T x sorption x endpoint
% chemistry x EX2 feasible surface x population-weight stress set, using the
% same vectorized algebra as Stage B2.
im=2; mode=modes{im};
for it=1:numel(ctx.Tp)
    pop=ctx.Tp(it);
    for is=1:numel(ctx.Sp)
        for ic=1:numel(C)
            P=stage_properties_weight_ensemble_B2(pop,ctx.Sp(is).f1_sorbed,ctx.surf.r1,ctx.surf.r2,C(ic),mode,W);
            for ie=1:numel(EPC)
                e=EPC(ie);
                Bmn=1./((1-e)/matrix.Mn_gmol + e./P.Mn_gmol);
                Bmw=(1-e)*matrix.Mw_gmol + e.*P.Mw_gmol;
                Bd=Bmw./Bmn;
                Smw=(1-e)*(2*matrix.Mn_gmol) + e.*(2*P.Mn_gmol);
                Sd=Smw./Bmn;
                delta=Bd-Sd;
                [v,lin]=min(delta(:));
                if v<best(im,ie).DeltaD
                    [ir,iw]=ind2sub(size(delta),lin);
                    best(im,ie)=packbest_E(it,is,ic,ir,iw,v,P.Mn_gmol(ir,iw),P.Mw_gmol(ir,iw), ...
                        Bmn(ir,iw),Bmw(ir,iw),Bd(ir,iw),Sd(ir,iw),mode,e);
                end
            end
        end
    end
end

rows=cell(0,35);
for im=1:numel(modes)
    for ie=1:numel(EPC)
        b=best(im,ie); pop=ctx.Tp(b.it); s=ctx.Sp(b.is); c=C(b.ic); wsc=W(b.iw);
        rows(end+1,:)={b.mode,b.epc,b.DeltaD,pop.name,pop.admissibility,s.name,s.f1_sorbed,c.name,c.class, ...
            ctx.surf.f1_EX2(b.ir),ctx.surf.r1(b.ir),ctx.surf.r2(b.ir),wsc.name,wsc.class, ...
            wsc.yield_multiplier(1),wsc.yield_multiplier(2),wsc.yield_multiplier(3),wsc.yield_multiplier(4),wsc.yield_multiplier(5), ...
            c.ethylene_odds_multiplier(1),c.ethylene_odds_multiplier(2),c.ethylene_odds_multiplier(3),c.ethylene_odds_multiplier(4),c.ethylene_odds_multiplier(5), ...
            b.StageMn,b.StageMw,b.FinalMn,b.FinalMw,b.FinalD,b.ComparatorD,b.it,b.is,b.ic,b.ir,b.iw}; %#ok<AGROW>
    end
end
names={'TransferMode','EPC_wtfrac','MinDeltaD_vs_phasewise_singleFlory','TScenario','TAdmissibility','SorptionScenario','FBR_f1_sorbed', ...
    'ChemistryScenario','ChemistryClass','EX2_f1_anchor','r1','r2','WeightScenario','WeightClass', ...
    'Wm1','Wm2','Wm3','Wm4','Wm5','Cm1','Cm2','Cm3','Cm4','Cm5', ...
    'StageMn_gmol','StageMw_gmol','FinalMn_gmol','FinalMw_gmol','FinalD','ComparatorD','TIndex','SorptionIndex','ChemistryIndex','ReactivityIndex','WeightIndex'};
Wit=cell2table(rows,'VariableNames',names);
writetable(Wit,fullfile(outdir,'StageE_worst_structural_witnesses.csv'));

% Regression to the exact Stage-B2 envelope minima that qualified the
% structural claim. This makes witness selection independently auditable.
root=fileparts(fileparts(mfilename('fullpath')));
B2=readtable(fullfile(root,'inputs','StageB2Outputs','StageB2_MWD_weight_transfer_envelopes.csv'));
B2=B2(strcmp(B2.WeightTransferLayer,'WI_INDEPENDENT_FACTOR_TWO_STRESS'),:);
maxRel=0; rrows=cell(height(Wit),6);
for i=1:height(Wit)
    j=find(strcmp(B2.TransferMode,Wit.TransferMode{i}) & abs(B2.EPC_wtfrac-Wit.EPC_wtfrac(i))<1e-12,1);
    if isempty(j), error('Stage-E B2 witness regression row missing.'); end
    ref=B2.MinDeltaD_vs_sameMn_singleFlory(j); got=Wit.MinDeltaD_vs_phasewise_singleFlory(i);
    rel=abs(got-ref)/max(abs(ref),1);
    maxRel=max(maxRel,rel);
    rrows(i,:)={Wit.TransferMode{i},Wit.EPC_wtfrac(i),ref,got,rel,rel<cfg.StageE.regression_rel_tol};
end
Reg=cell2table(rrows,'VariableNames',{'TransferMode','EPC_wtfrac','StageB2_MinDeltaD','StageE_ReconstructedMinDeltaD','RelativeDifference','Pass'});
writetable(Reg,fullfile(outdir,'StageE_B2_witness_regression.csv'));
if maxRel>=cfg.StageE.regression_rel_tol, warning('Stage-E B2 witness regression exceeds configured tolerance.'); end
end

function b=packbest_E(it,is,ic,ir,iw,v,stageMn,stageMw,finalMn,finalMw,finalD,compD,mode,e)
b=struct('DeltaD',v,'mode',mode,'epc',e,'it',it,'is',is,'ic',ic,'ir',ir,'iw',iw, ...
    'StageMn',stageMn,'StageMw',stageMw,'FinalMn',finalMn,'FinalMw',finalMw,'FinalD',finalD,'ComparatorD',compD);
end
