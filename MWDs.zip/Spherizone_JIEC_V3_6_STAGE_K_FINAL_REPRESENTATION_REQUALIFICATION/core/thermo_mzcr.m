function out = thermo_mzcr(T_C, P_bar, gas)
%THERMO_MZCR Source-traceable simple ternary correlations with domain flags.
% C3 correlation: Kulajanpeng et al. 2025 SI Eq. S16.
% C2-in-RCP correlation: Eq. S18, valid only near 8-9 mol% C2 in C2/C3.
% Correlation concentration units are retained consistently for ratios.

req={'C3H6','C2H4','H2','C3H8'};
for k=1:numel(req)
    if ~isfield(gas,req{k}), error('Missing gas field %s.',req{k}); end
end
s=gas.C3H6+gas.C2H4+gas.H2+gas.C3H8;
if abs(s-1)>1e-8, error('Gas mole fractions must sum to 1.'); end
T=T_C+273.15;
PC3=gas.C3H6*P_bar; PC2=gas.C2H4*P_bar; PP=gas.C3H8*P_bar;

C3=(0.00010875*T^2 - 0.072807*T + 12.0)*PC3^2 + (-0.5656*T + 233.3)*PC3;
C2=(-0.0010838*T^2 + 0.76655*T - 135.6)*PC2^2 + (-2.9744*T + 1099.1)*PC2;
C3=max(C3,0); C2=max(C2,0);
reactive=gas.C3H6+gas.C2H4;
if reactive>0, xC2react=gas.C2H4/reactive; else, xC2react=NaN; end
if gas.C3H6+gas.C3H8>0, rC3P=gas.C3H6/(gas.C3H6+gas.C3H8); else, rC3P=NaN; end
validC3=(T_C>=70 && T_C<=85 && PC3<=20+1e-12 && PP<=10+1e-12 && rC3P>=0.77-1e-12 && rC3P<=0.80+1e-12);
validC2=(T_C>=70 && T_C<=85 && PC2<=10+1e-12 && xC2react>=0.08-1e-12 && xC2react<=0.09+1e-12);

out=struct();
out.C3_corr=C3; out.C2_corr=C2;
out.PC3_bar=PC3; out.PC2_bar=PC2; out.Ppropane_bar=PP;
out.xC2_reactive=xC2react; out.C3_propane_ratio=rC3P;
out.valid_C3=validC3; out.valid_C2=validC2;
if C3+C2>0, out.f1_sorbed=C3/(C3+C2); else, out.f1_sorbed=NaN; end
out.note='Use numerical concentrations only when the corresponding domain flag is true.';
end
