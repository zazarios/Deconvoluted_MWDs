function B = stageE1_weight_simplex_h_bounds(M_gmol,Mn_population_gmol,nT,chunk,cdfPad)
%STAGEE1_WEIGHT_SIMPLEX_H_BOUNDS Certified pointwise CDF-mismatch bounds.
%
% h(w,M)=sum_j w_j F_j(M)-F_Flory(M; Mn_harmonic(w)), w on full simplex.
% The map w -> (s,L) with s=sum(w_j/Mn_j), L=sum(w_j F_j) is the convex
% hull of population points (1/Mn_j,F_j). For fixed M, extrema of
% L-Q(s) over that hull occur on its lower/upper boundary, hence on an edge.
% Evaluating all population-pair segments therefore covers every hull edge.
% A deterministic t-grid plus a derivative Lipschitz pad encloses continuous
% edge extrema. `cdfPad` additionally covers analytical-vs-finite-grid CDF
% discrepancy for both the resolved mixture and collapsed Flory CDF.
M=M_gmol(:)'; Mn=Mn_population_gmol(:)';
active=isfinite(Mn) & Mn>0; Mn=Mn(active);
if isempty(Mn), error('StageE1:NoActivePopulations','No active populations.'); end
if nargin<3 || isempty(nT), nT=801; end
if nargin<4 || isempty(chunk), chunk=80; end
if nargin<5 || isempty(cdfPad), cdfPad=0; end
if nT<3, error('StageE1:EdgeGrid','nT must be at least 3.'); end
p=numel(Mn); n=numel(M);
if p==1
    z=zeros(1,n);
    B=struct('hmin',z-2*cdfPad,'hmax',z+2*cdfPad,'edge_pad',zeros(1,n), ...
        'max_edge_pad',0,'cdf_pad_total',2*cdfPad,'n_active',1,'n_edges',0);
    return
end
F=zeros(p,n); a=1./Mn;
for j=1:p, F(j,:)=stageE1_flory_weight_cdf_exact(M,Mn(j)); end
hmin=zeros(1,n); hmax=zeros(1,n); % vertices give h=0 exactly
Lmax=zeros(1,n);
t=linspace(0,1,nT)'; dt=1/(nT-1);
for i=1:p
    for j=i+1:p
        ai=a(i); aj=a(j); ci=F(i,:); cj=F(j,:);
        localMin=inf(1,n); localMax=-inf(1,n);
        for k=1:chunk:nT
            kk=k:min(k+chunk-1,nT); tt=t(kk);
            s=aj + (ai-aj).*tt;                    % nt x 1
            L=bsxfun(@plus,cj,bsxfun(@times,tt,(ci-cj)));
            u=s*M;                                  % nt x nM
            Q=1-exp(-u).*(1+u);
            H=L-Q;
            localMin=min(localMin,min(H,[],1));
            localMax=max(localMax,max(H,[],1));
        end
        hmin=min(hmin,localMin); hmax=max(hmax,localMax);
        slo=min(ai,aj); shi=max(ai,aj);
        sstar=min(max(1./M,slo),shi);               % maximizes q'(s) on edge
        qprime=M.^2.*sstar.*exp(-M.*sstar);
        Lder=abs(ci-cj)+abs(ai-aj).*qprime;
        Lmax=max(Lmax,Lder);
    end
end
edgePad=0.5*dt.*Lmax;
numPad=2*cdfPad;
hmin=hmin-edgePad-numPad;
hmax=hmax+edgePad+numPad;
% True CDF difference is always within [-1,1]; clipping is still conservative.
hmin=max(-1,hmin); hmax=min(1,hmax);
B=struct('hmin',hmin,'hmax',hmax,'edge_pad',edgePad,'max_edge_pad',max(edgePad), ...
    'cdf_pad_total',numPad,'n_active',p,'n_edges',p*(p-1)/2);
end
