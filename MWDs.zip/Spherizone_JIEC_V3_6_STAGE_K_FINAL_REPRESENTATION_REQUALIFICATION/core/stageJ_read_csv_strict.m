function T = stageJ_read_csv_strict(filename)
%STAGEJ_READ_CSV_STRICT Read frozen CSV with an explicit comma delimiter.
% MATLAB readtable delimiter auto-detection can misclassify one-row CSVs
% whose headers contain many underscores (observed in R2025b for the frozen
% Stage-G structural-claim closure file).  Stage J therefore forces the
% CSV contract explicitly and preserves the original header names.
%
% This helper changes only file parsing. It does not modify any numerical
% value, model equation, uncertainty domain, or upstream qualified output.

if ~isfile(filename)
    error('StageJ:MissingCSV','Required CSV was not found: %s',filename);
end

T = readtable(filename, ...
    'Delimiter', ',', ...
    'VariableNamingRule', 'preserve', ...
    'TextType', 'string');
end
