function out = stageG_jensen_gap_u_interval(a,b,rootTol,maxIter)
%STAGEG_JENSEN_GAP_U_INTERVAL Exact Jensen-gap extrema for Flory CDF Q(u).
%
% Q(u)=1-(1+u)exp(-u), u>=0. Q is convex for u<1 and concave for u>1.
% For any probability distribution supported on [a,b], the Jensen gap
%   h = E[Q(U)] - Q(E[U])
% lies in [hmin,hmax]. The extrema are obtained from the lower convex and
% upper concave envelopes of Q on [a,b]. The construction below uses the
% exact tangent/chord geometry of the single-inflection Flory CDF.
if nargin<3 || isempty(rootTol), rootTol=1e-13; end
if nargin<4 || isempty(maxIter), maxIter=90; end
if ~(isfinite(a) && isfinite(b) && a>=0 && b>=a)
    error('StageG:JensenInterval','Require finite 0 <= a <= b.');
end
if b-a <= max(rootTol,1e-15*max(1,b))
    out=struct('hmin',0,'hmax',0,'case_hmin','DEGENERATE','case_hmax','DEGENERATE');
    return
end
qa=qfun(a); qb=qfun(b);

% Upper concave envelope -> maximum positive Jensen gap.
if a>=1
    hmax=0; caseMax='CONCAVE_Q_EXACT';
else
    if b<=1
        d=b; caseMax='CONVEX_INTERVAL_CHORD';
    else
        g1=secant(a,1,qa,qfun(1))-qprime(1);
        gb=secant(a,b,qa,qb)-qprime(b);
        if g1<=rootTol && gb>=-rootTol
            d=bisect(@(z) secant(a,z,qa,qfun(z))-qprime(z),1,b,rootTol,maxIter);
            caseMax='LEFT_ENDPOINT_TO_TANGENCY';
        else
            d=b; caseMax='WHOLE_INTERVAL_CHORD';
        end
    end
    qd=qfun(d); m=secant(a,d,qa,qd);
    hi=min(1,d);
    r=bisect(@(z) qprime(z)-m,a,hi,rootTol,maxIter);
    hmax=max(0,qa+m*(r-a)-qfun(r));
end

% Lower convex envelope -> minimum negative Jensen gap.
if b<=1
    hmin=0; caseMin='CONVEX_Q_EXACT';
else
    if a>=1
        c=a; caseMin='CONCAVE_INTERVAL_CHORD';
    else
        ga=secant(a,b,qa,qb)-qprime(a);
        g1=secant(1,b,qfun(1),qb)-qprime(1);
        if ga>=-rootTol && g1<=rootTol
            c=bisect(@(z) secant(z,b,qfun(z),qb)-qprime(z),a,1,rootTol,maxIter);
            caseMin='TANGENCY_TO_RIGHT_ENDPOINT';
        else
            c=a; caseMin='WHOLE_INTERVAL_CHORD';
        end
    end
    qc=qfun(c); m=secant(c,b,qc,qb);
    lo=max(1,c);
    r=bisect(@(z) qprime(z)-m,lo,b,rootTol,maxIter);
    hmin=min(0,qc+m*(r-c)-qfun(r));
end
out=struct('hmin',hmin,'hmax',hmax,'case_hmin',caseMin,'case_hmax',caseMax);
end

function y=qfun(u)
% Stable evaluation of 1-(1+u)e^-u.
if u>745
    y=1;
else
    y=-expm1(-u)-u*exp(-u);
end
y=max(0,min(1,y));
end

function y=qprime(u)
if u>745, y=0; else, y=u*exp(-u); end
end

function m=secant(a,b,qa,qb)
if b<=a, error('StageG:Secant','Degenerate secant interval.'); end
m=(qb-qa)/(b-a);
end

function r=bisect(fun,lo,hi,tol,maxIter)
flo=fun(lo); fhi=fun(hi);
scale=max([1,abs(flo),abs(fhi)]);
if abs(flo)<=tol*scale, r=lo; return; end
if abs(fhi)<=tol*scale, r=hi; return; end
if flo*fhi>0
    error('StageG:RootBracket','Jensen-envelope root is not bracketed: [%.16g, %.16g], f=[%.3g, %.3g].',lo,hi,flo,fhi);
end
for k=1:maxIter
    mid=0.5*(lo+hi); fm=fun(mid);
    if abs(fm)<=tol*max(1,abs(fm)) || (hi-lo)<=tol*max(1,abs(mid))
        r=mid; return
    end
    if flo*fm<=0
        hi=mid; fhi=fm; %#ok<NASGU>
    else
        lo=mid; flo=fm;
    end
end
r=0.5*(lo+hi);
end
