function V = verify_stageH_target_aware_reduction(cfg,outdir,result)
%VERIFY_STAGEH_TARGET_AWARE_REDUCTION Executable qualification gates H0-H13.
ROOT=fileparts(fileparts(mfilename('fullpath')));
Gate={};Status={};Detail={};
add('H0_STAGE_G_PREREQUISITE',gate_stageG(),'Stage-G qualified output is the frozen uncertainty-domain prerequisite.');
counts=zeros(1,5);for k=1:5,counts(k)=sum([result.Partitions.K]==k);end
add('H1_ALL_52_PARTITIONS',numel(result.Partitions)==52 && isequal(counts,[1 15 25 10 1]),sprintf('count=%d; by K=[%s]',numel(result.Partitions),num2str(counts)));
mxInv=max(result.Invariants.Relative_difference);
add('H2_MN_PRESERVATION',mxInv<1e-12,sprintf('max reference-state relative Mn difference=%.3g',mxInv));
S=result.Summary;
ix5=S.K==5;mx5=max([S.MinimaxLower(ix5);S.MinimaxUpper(ix5)]);
add('H3_K5_IDENTITY',mx5<1e-12,sprintf('max K=5 reduction error=%.3g',mx5));
add('H4_BOUND_ORDER',all(S.MinimaxLower<=S.MinimaxUpper+1e-12),sprintf('max lower-upper violation=%.3g',max(S.MinimaxLower-S.MinimaxUpper)));
add('H5_MONOTONE_WITH_K',gate_monotone(S),'Minimax lower/upper error bounds are nonincreasing with retained order K.');
[okMir,detMir]=gate_mirror();add('H6_INDEPENDENT_MINIMAX_MIRROR',okMir,detMir);
[okLow,detLow]=gate_lowlevel_mirror();add('H6A_INDEPENDENT_PAIR_SUPPORT_MIRROR',okLow,detLow);
[okPart,detPart]=gate_partition_mirror();add('H6B_INDEPENDENT_PARTITION_MIRROR',okPart,detPart);
add('H7_MW_D_EQUIVALENCE',max(abs(result.PartTable.MwRel_upper-result.PartTable.DRel_upper))<1e-14,'D relative loss equals Mw relative loss because Mn is preserved exactly.');
[okCan,detCan]=gate_cancellation();add('H8_MATRIX_CANCELLATION_W1',okCan,detCan);
O=result.OrderMap;
add('H9_PRESPECIFIED_TOLERANCE_MAP',height(O)==54 && numel(unique(O.ToleranceLabel))==3,'Expected 6 targets x 3 EPC x 3 fixed tolerance bands = 54 rows.');
add('H10_PARTITION_NOT_STATE_DEPENDENT',all(cellfun(@(s)~isempty(s),S.BestPartitionUpper)),'One minimax partition is selected per target/K/EPC only after maximization over all uncertainty states.');
qix=strcmp(result.MetricScope.Metric,'M50_M90_M99_QUANTILES');
add('H11_QUANTILE_SCOPE_GUARD',any(qix) && strcmp(result.MetricScope.Status{find(qix,1)},'REFERENCE_DIAGNOSTIC_ONLY'),'Quantile diagnostics are excluded from continuous-domain K* certification.');
add('H12_TARGET_ORDER_EXPORTED',all(ismember(O.ProjectionKstarStatus,{'CERTIFIED_UNIQUE_PROJECTION_KSTAR','PROJECTION_KSTAR_BRACKETED_BY_BOUNDS'})),'Scientific outcome is reported without requiring any particular hierarchy for PASS.');
[okOrd,detOrd]=gate_order_mirror();add('H13_INDEPENDENT_ORDER_MAP_MIRROR',okOrd,detOrd);
V=table(Gate',Status',Detail','VariableNames',{'Gate','Status','Detail'});
writetable(V,fullfile(outdir,'StageH_verification.csv'));

    function add(name,ok,detail)
        Gate{end+1}=name; %#ok<AGROW>
        if ok,Status{end+1}='PASS';else,Status{end+1}='FAIL';end %#ok<AGROW>
        Detail{end+1}=detail; %#ok<AGROW>
    end
    function ok=gate_stageG()
        f=fullfile(ROOT,'inputs','StageGQualifiedOutputs','STAGE_G_STATUS.txt');ok=false;
        if exist(f,'file'),txt=fileread(f);ok=contains(txt,'QUALIFIED');end
    end
    function ok=gate_monotone(T)
        ok=true; tg=unique(T.Target,'stable');ep=unique(T.EPC_wtfrac);
        for a=1:numel(tg),for b=1:numel(ep)
            ix=strcmp(T.Target,tg{a}) & abs(T.EPC_wtfrac-ep(b))<1e-12; X=T(ix,:);[~,o]=sort(X.K);X=X(o,:);
            ok=ok && all(diff(X.MinimaxLower)<=1e-10) && all(diff(X.MinimaxUpper)<=1e-10);
        end,end
    end
    function [ok,detail]=gate_mirror()
        E=readtable(fullfile(ROOT,'Independent_Audit','StageH_expected_target_minimax_summary.csv'));
        dif=[];
        for r=1:height(E)
            ix=strcmp(S.Target,E.Target{r}) & abs(S.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12 & S.K==E.K(r);
            if sum(ix)~=1,dif(end+1)=Inf;continue;end %#ok<AGROW>
            dif(end+1)=abs(S.MinimaxLower(ix)-E.ExpectedMinimaxLower(r)); %#ok<AGROW>
            dif(end+1)=abs(S.MinimaxUpper(ix)-E.ExpectedMinimaxUpper(r)); %#ok<AGROW>
        end
        md=max(dif);ok=md<=cfg.StageH.mirror_abs_tol;detail=sprintf('max absolute difference to independent precheck=%.6g; tolerance=%.6g',md,cfg.StageH.mirror_abs_tol);
    end
    function [ok,detail]=gate_lowlevel_mirror()
        EP=readtable(fullfile(ROOT,'Independent_Audit','StageH_expected_pair_witness_metrics_v301.csv'));
        ER=readtable(fullfile(ROOT,'Independent_Audit','StageH_expected_support_bounds_v301.csv'));
        d=[];
        P=result.PairTable; R=result.RangeTable;
        for r=1:height(EP)
            ix=strcmp(P.TScenario,EP.TScenario{r}) & strcmp(P.TransferMode,EP.TransferMode{r}) & ...
                P.Population_i==EP.Population_i(r) & P.Population_j==EP.Population_j(r) & abs(P.EPC_wtfrac-EP.EPC_wtfrac(r))<1e-12;
            if sum(ix)~=1,d(end+1)=Inf;continue;end %#ok<AGROW>
            d(end+1)=abs(P.W1_pair_witness_final_decades(ix)-EP.Expected_W1_pair_witness_final_decades(r)); %#ok<AGROW>
            d(end+1)=abs(P.MwRel_pair_witness(ix)-EP.Expected_MwRel_pair_witness(r)); %#ok<AGROW>
            d(end+1)=abs(P.Tail90_pair_witness_final_abs(ix)-EP.Expected_Tail90_pair_witness_final_abs(r)); %#ok<AGROW>
            d(end+1)=abs(P.Tail99_pair_witness_final_abs(ix)-EP.Expected_Tail99_pair_witness_final_abs(r)); %#ok<AGROW>
        end
        for r=1:height(ER)
            ix=strcmp(R.TScenario,ER.TScenario{r}) & strcmp(R.TransferMode,ER.TransferMode{r}) & ...
                R.ExtremePopulation_i==ER.ExtremePopulation_i(r) & R.ExtremePopulation_j==ER.ExtremePopulation_j(r) & abs(R.EPC_wtfrac-ER.EPC_wtfrac(r))<1e-12;
            if sum(ix)~=1,d(end+1)=Inf;continue;end %#ok<AGROW>
            d(end+1)=abs(R.W1_support_upper_final_decades(ix)-ER.Expected_W1_support_upper_final_decades(r)); %#ok<AGROW>
            d(end+1)=abs(R.MwRel_support_exact(ix)-ER.Expected_MwRel_support_exact(r)); %#ok<AGROW>
            d(end+1)=abs(R.Tail90_support_upper_final_abs(ix)-ER.Expected_Tail90_support_upper_final_abs(r)); %#ok<AGROW>
            d(end+1)=abs(R.Tail99_support_upper_final_abs(ix)-ER.Expected_Tail99_support_upper_final_abs(r)); %#ok<AGROW>
            d(end+1)=abs(R.ReciprocalMn_sLo(ix)-ER.Expected_ReciprocalMn_sLo(r)); %#ok<AGROW>
            d(end+1)=abs(R.ReciprocalMn_sHi(ix)-ER.Expected_ReciprocalMn_sHi(r)); %#ok<AGROW>
        end
        md=max(d);ok=md<=cfg.StageH.numeric_abs_tol;detail=sprintf('300 pair + 300 support rows; max independent discrepancy=%.6g; tolerance=%.6g',md,cfg.StageH.numeric_abs_tol);
    end
    function [ok,detail]=gate_partition_mirror()
        E=readtable(fullfile(ROOT,'Independent_Audit','StageH_expected_partition_bounds_v301.csv'));
        P=result.PartTable; d=[];
        pairs={{'MnRel_lower','Expected_MnRel_lower'},{'MnRel_upper','Expected_MnRel_upper'}, ...
            {'MwRel_lower','Expected_MwRel_lower'},{'MwRel_upper','Expected_MwRel_upper'}, ...
            {'DRel_lower','Expected_DRel_lower'},{'DRel_upper','Expected_DRel_upper'}, ...
            {'W1_lower_decades','Expected_W1_lower_decades'},{'W1_upper_decades','Expected_W1_upper_decades'}, ...
            {'Tail90_lower_abs','Expected_Tail90_lower_abs'},{'Tail90_upper_abs','Expected_Tail90_upper_abs'}, ...
            {'Tail99_lower_abs','Expected_Tail99_lower_abs'},{'Tail99_upper_abs','Expected_Tail99_upper_abs'}};
        for r=1:height(E)
            ix=strcmp(P.PartitionCode,E.PartitionCode{r}) & P.K==E.K(r) & abs(P.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12;
            if sum(ix)~=1,d(end+1)=Inf;continue;end %#ok<AGROW>
            for k=1:numel(pairs)
                d(end+1)=abs(P.(pairs{k}{1})(ix)-E.(pairs{k}{2})(r)); %#ok<AGROW>
            end
        end
        md=max(d);ok=md<=cfg.StageH.numeric_abs_tol;detail=sprintf('156 partition rows; max independent discrepancy=%.6g; tolerance=%.6g',md,cfg.StageH.numeric_abs_tol);
    end
    function [ok,detail]=gate_order_mirror()
        E=readtable(fullfile(ROOT,'Independent_Audit','StageH_expected_target_order_map.csv'));
        bad=0;
        for r=1:height(E)
            ix=strcmp(O.Target,E.Target{r}) & abs(O.EPC_wtfrac-E.EPC_wtfrac(r))<1e-12 & strcmp(O.ToleranceLabel,E.ToleranceLabel{r});
            if sum(ix)~=1,bad=bad+1;continue;end
            bad=bad + (O.K_projection_possible_lower(ix)~=E.Expected_K_possible_lower(r)) + (O.K_projection_certified_sufficient(ix)~=E.Expected_K_certified_sufficient(r));
        end
        ok=(bad==0);detail=sprintf('order-map integer mismatches=%d',bad);
    end
    function [ok,detail]=gate_cancellation()
        % Recompute one deterministic reference state at each EPC for DIRECT.
        ctx=result.ctx;ref=stageE_reference_state(cfg,ctx,'DIRECT_MN_TRANSFER');
        full=mix_flory_populations(ref.stage_w,ref.stage_Mn_population_gmol,cfg.StageH.metric_M_grid);
        errs=[];
        for ie=1:numel(cfg.StageH.EPC)
            e=cfg.StageH.EPC(ie);K=3;
            ix=strcmp(S.Target,'FINAL_W1_LOG10M') & abs(S.EPC_wtfrac-e)<1e-12 & S.K==K;
            code=S.BestPartitionUpper{find(ix,1)};ip=find(strcmp({result.Partitions.Code},code),1);
            red=stageH_reduce_partition(ref.stage_w,ref.stage_Mn_population_gmol,result.Partitions(ip).Groups);
            rr=mix_flory_populations(red.w,red.Mn_gmol,cfg.StageH.metric_M_grid);
            metStage=stageE_distribution_metrics(cfg.StageH.metric_M_grid,full.dW_dlog10M,rr.dW_dlog10M);
            qix=strcmp(result.QuantileDiagnostics.TransferMode,'DIRECT_MN_TRANSFER') & abs(result.QuantileDiagnostics.EPC_wtfrac-e)<1e-12 & result.QuantileDiagnostics.K==K;
            wf=result.QuantileDiagnostics.W1_reference_decades(find(qix,1));
            errs(end+1)=abs(wf-e*metStage.W1_log10M_decades); %#ok<AGROW>
        end
        me=max(errs);ok=me<2e-6;detail=sprintf('max |W1_final - EPC*W1_stage|=%.3g decades',me);
    end
end
