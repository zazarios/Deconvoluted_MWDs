function result = run_stageK_final_representation_requalification(cfg,outdir)
%RUN_STAGEK_FINAL_REPRESENTATION_REQUALIFICATION Requalify H/H.1/H.2.
if ~exist(outdir,'dir'),mkdir(outdir);end
ROOT=fileparts(fileparts(mfilename('fullpath')));

ctx=stageK_build_context(cfg);
% Explicit state-support audit.
R=cell(numel(ctx.Tp),10);
for k=1:numel(ctx.Tp)
 p=ctx.Tp(k); pm=population_moments(p);
 R(k,:)={p.H2Branch,p.H2Role,p.H2_molfrac,p.H2_psi,p.base_name,p.name,p.admissibility,p.source_pair,pm.Mn_gmol,pm.Mw_gmol};
end
StateAudit=cell2table(R,'VariableNames',{'H2Branch','H2Role','H2_molfrac','H2_psi','TBaseScenario','TScenario','TAdmissibility','SourcePair','Stage_Mn_gmol','Stage_Mw_gmol'});
writetable(StateAudit,fullfile(outdir,'StageK_state_support.csv'));

% J.1 chemistry-to-alpha scope audit. The full E/P repeat-mass support was
% already frozen in H/H.1/H.2 and remains unchanged.
J1=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageJ1QualifiedOutputs','StageJ1_composition_domain_summary.csv'));
q=strcmp(string(J1.Domain),'FINAL_UNION');
if sum(q)~=1,error('StageK:J1Domain','Final J.1 composition-domain row missing.');end
AlphaAudit=table(J1.StageC2Min(q),J1.StageC2Max(q),cfg.StageH.M2_gmol/cfg.StageH.M3_gmol,1,1, ...
 'VariableNames',{'J1_StageC2Min','J1_StageC2Max','FrozenAlphaMin','FrozenAlphaMax','J1ContainedByFrozenRepeatMassSupport'});
writetable(AlphaAudit,fullfile(outdir,'StageK_J1_repeat_mass_support_audit.csv'));

H=run_stageK_H_oracle_requalification(cfg,outdir);
H1=run_stageK_H1_conditional_requalification(cfg,outdir);
H2=run_stageK_H2_global_requalification(cfg,outdir);

% Compare every frozen minimax row with the expanded-domain row.
CmpH=compare_summary(stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageHQualifiedOutputs','StageH_target_minimax_summary.csv')),H.Summary,'H','K_H');
CmpH1=compare_summary(stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageH1QualifiedOutputs','StageH1_target_minimax_summary.csv')),H1.Summary,'H1','K_H1');
CmpH2=compare_summary(stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageH2QualifiedOutputs','StageH2_target_minimax_summary.csv')),H2.Summary,'H2','K_H2');
writetable(CmpH,fullfile(outdir,'StageK_H_minimax_regression.csv'));
writetable(CmpH1,fullfile(outdir,'StageK_H1_minimax_regression.csv'));
writetable(CmpH2,fullfile(outdir,'StageK_H2_minimax_regression.csv'));

% Order-map changes relative to the frozen qualified H/H.1/H.2 maps.
OH=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageHQualifiedOutputs','StageH_target_order_map.csv'));
OH1=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageH1QualifiedOutputs','StageH1_target_order_map.csv'));
OH2=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageH2QualifiedOutputs','StageH2_target_order_map.csv'));
OrderH=compare_order(OH,H.OrderMap,'H');
OrderH1=compare_order(OH1,H1.OrderMap,'H1');
OrderH2=compare_order(OH2,H2.OrderMap,'H2');
writetable(OrderH,fullfile(outdir,'StageK_H_order_change.csv'));
writetable(OrderH1,fullfile(outdir,'StageK_H1_order_change.csv'));
writetable(OrderH2,fullfile(outdir,'StageK_H2_order_change.csv'));

% Compact moderate snapshot for the manuscript decision.
M=[snapshot(H.OrderMap,'H'); snapshot(H1.OrderMap,'H1'); snapshot(H2.OrderMap,'H2')];
writetable(M,fullfile(outdir,'StageK_moderate_order_snapshot.csv'));

Claim={'ORACLE_TARGET_DEPENDENCE_UNDER_FINAL_DOMAIN';'T80_CONDITIONAL_FIXED_DESCRIPTOR_CLOSURE_UNDER_FINAL_DOMAIN';'T80_GLOBAL_FIXED_DESCRIPTOR_CLOSURE_UNDER_FINAL_DOMAIN'; ...
 'J1_CHEMISTRY_REQUIRES_ALPHA_SUPPORT_BEYOND_FROZEN_H_RANGE';'ONE_UNIFIED_REDUCED_MODEL_FOR_ALL_TARGETS';'INDUSTRIAL_ICP_VALIDATION'};
Status={'REQUALIFIED_BY_STAGE_K';'REQUALIFIED_BY_STAGE_K';'REQUALIFIED_BY_STAGE_K';'NO';'NOT_ESTABLISHED';'NOT_ESTABLISHED'};
Meaning={ ...
 'Stage-H oracle projection is recomputed over the final 17-state H2/T80 union while retaining the frozen projection definitions and tolerances.'; ...
 'Stage-H.1 target-specific fixed descriptors are recomputed over every final H2/T80 branch, retaining the full hidden-weight and alpha support.'; ...
 'Stage-H.2 target-specific descriptors are recomputed before any of the 17 H2/T80 states, hidden weights, or alpha values are known.'; ...
 'No. H/H.1/H.2 already used alpha_j in [M2/M3,1], which contains every physically possible E/P repeat-mass scaling and therefore every J.1 composition realization.'; ...
 'All three representation analyses remain target-specific; Stage K does not construct a single universal reduced model.'; ...
 'No matched Spherizone ICP experiment is introduced.'};
Claims=table(Claim,Status,Meaning);writetable(Claims,fullfile(outdir,'StageK_claim_scope.csv'));

result=struct('ctx',ctx,'StateAudit',StateAudit,'AlphaAudit',AlphaAudit,'H',H,'H1',H1,'H2',H2, ...
 'CmpH',CmpH,'CmpH1',CmpH1,'CmpH2',CmpH2,'OrderH',OrderH,'OrderH1',OrderH1,'OrderH2',OrderH2,'Snapshot',M,'Claims',Claims);
end

function T=compare_summary(old,new,oldLabel,newLabel)
R=cell(height(old),12);
for i=1:height(old)
 q=strcmp(string(new.Target),string(old.Target(i))) & abs(new.EPC_wtfrac-old.EPC_wtfrac(i))<1e-12 & new.K==old.K(i);
 if sum(q)~=1,error('StageK:SummaryMatch','Summary row mismatch.');end
 nl=new.MinimaxLower(q);nu=new.MinimaxUpper(q);ol=old.MinimaxLower(i);ou=old.MinimaxUpper(i);
 R(i,:)={char(string(old.Target(i))),old.EPC_wtfrac(i),old.K(i),oldLabel,newLabel,ol,ou,nl,nu,nl-ol,nu-ou,(nl+1e-12>=ol)&&(nu+1e-12>=ou)};
end
T=cell2table(R,'VariableNames',{'Target','EPC_wtfrac','K','FrozenStage','RequalifiedStage','FrozenLower','FrozenUpper','FinalLower','FinalUpper','DeltaLower','DeltaUpper','ExpandedDomainNotBetterGuard'});
if iscell(T.ExpandedDomainNotBetterGuard),T.ExpandedDomainNotBetterGuard=cell2mat(T.ExpandedDomainNotBetterGuard);end
end

function T=compare_order(old,new,kind)
R=cell(height(old),11);
for i=1:height(old)
 q=strcmp(string(new.Target),string(old.Target(i))) & abs(new.EPC_wtfrac-old.EPC_wtfrac(i))<1e-12 & strcmp(string(new.ToleranceLabel),string(old.ToleranceLabel(i)));
 if sum(q)~=1,error('StageK:OrderMatch','Order row mismatch.');end
 if strcmp(kind,'H')
   ko=old.K_projection_certified_sufficient(i); kn=new.K_projection_certified_sufficient(q); st=char(string(new.ProjectionKstarStatus(q)));
 elseif strcmp(kind,'H1')
   ko=old.K_fixed_certified_sufficient(i); kn=new.K_fixed_certified_sufficient(q); st=char(string(new.FixedClosureStatus(q)));
 else
   ko=old.K_global_certified_sufficient(i); kn=new.K_global_certified_sufficient(q); st=char(string(new.GlobalClosureStatus(q)));
 end
 improved=(isnan(ko)&&~isnan(kn)) || (~isnan(ko)&&~isnan(kn)&&kn<ko);
 if isnan(ko)&&isnan(kn),cls='UNCHANGED_NO_CLOSURE';elseif ~isnan(ko)&&isnan(kn),cls='CLOSURE_LOST_ON_EXPANSION';elseif isnan(ko)&&~isnan(kn),cls='INVALID_IMPROVEMENT';elseif kn==ko,cls='UNCHANGED_ORDER';elseif kn>ko,cls='HIGHER_ORDER_ON_EXPANSION';else,cls='INVALID_ORDER_REDUCTION';end
 R(i,:)={char(string(old.Target(i))),old.EPC_wtfrac(i),char(string(old.ToleranceLabel(i))),kind,ko,kn,st,cls,improved,old.Tolerance(i),char(string(old.ToleranceUnit(i)))};
end
T=cell2table(R,'VariableNames',{'Target','EPC_wtfrac','ToleranceLabel','AnalysisLayer','FrozenCertifiedK','FinalCertifiedK','FinalStatus','ChangeClass','InvalidImprovement','Tolerance','ToleranceUnit'});
if iscell(T.InvalidImprovement),T.InvalidImprovement=cell2mat(T.InvalidImprovement);end
end

function T=snapshot(O,kind)
q=strcmp(string(O.ToleranceLabel),'MODERATE');O=O(q,:);R=cell(height(O),6);
for i=1:height(O)
 if strcmp(kind,'H'), k=O.K_projection_certified_sufficient(i);s=O.ProjectionKstarStatus{i};
 elseif strcmp(kind,'H1'),k=O.K_fixed_certified_sufficient(i);s=O.FixedClosureStatus{i};
 else,k=O.K_global_certified_sufficient(i);s=O.GlobalClosureStatus{i};end
 R(i,:)={kind,O.Target{i},O.EPC_wtfrac(i),k,s,O.Tolerance(i)};
end
T=cell2table(R,'VariableNames',{'Layer','Target','EPC_wtfrac','CertifiedK','Status','Tolerance'});
end
