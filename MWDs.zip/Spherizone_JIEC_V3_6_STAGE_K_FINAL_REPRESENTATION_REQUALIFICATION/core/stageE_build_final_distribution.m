function out = stageE_build_final_distribution(matrix, stage_w, stage_Mn_gmol, EPC_wtfrac, M_grid)
%STAGEE_BUILD_FINAL_DISTRIBUTION Resolved final MWD and information-collapsed comparator.
% The comparator preserves matrix Mn, second-stage Mn, and EPC mass fraction,
% but replaces each resolved multi-population phase by one Flory distribution.
% This isolates within-phase distribution information from ordinary phase blending.

if EPC_wtfrac<0 || EPC_wtfrac>=1, error('Stage-E EPC fraction must lie in [0,1).'); end
M=M_grid(:)'; x=log10(M);
if numel(matrix.M_gmol)~=numel(M) || any(abs(log10(matrix.M_gmol(:)')-x)>1e-12)
    error('Matrix MWD must be evaluated on the Stage-E metric grid.');
end
w=stage_w(:)'; MnJ=stage_Mn_gmol(:)';
active=w>0 & isfinite(MnJ) & MnJ>0;
if ~any(active), error('No active second-stage populations for Stage E.'); end
w(~active)=0; w=w/sum(w);
stage=mix_flory_populations(w,MnJ,M);
stageMn=stage.Mn_analytical_gmol; stageMw=stage.Mw_analytical_gmol;

matrixPdf=matrix.dW_dlog10M(:)'; matrixPdf=matrixPdf/trapz(x,matrixPdf);
stagePdf=stage.dW_dlog10M(:)';
detailed=(1-EPC_wtfrac)*matrixPdf + EPC_wtfrac*stagePdf;
detailed=detailed/trapz(x,detailed);

matrixCollapsed=flory_logweight_pdf(M,matrix.Mn_gmol); matrixCollapsed=matrixCollapsed/trapz(x,matrixCollapsed);
stageCollapsed=flory_logweight_pdf(M,stageMn); stageCollapsed=stageCollapsed/trapz(x,stageCollapsed);
collapsed=(1-EPC_wtfrac)*matrixCollapsed + EPC_wtfrac*stageCollapsed;
collapsed=collapsed/trapz(x,collapsed);

MnA=1/((1-EPC_wtfrac)/matrix.Mn_gmol + EPC_wtfrac/stageMn);
MwA=(1-EPC_wtfrac)*matrix.Mw_gmol + EPC_wtfrac*stageMw;
D_A=MwA/MnA;
MnC=MnA; % same phase Mn values and mass fractions => same final Mn analytically
MwC=(1-EPC_wtfrac)*(2*matrix.Mn_gmol) + EPC_wtfrac*(2*stageMn);
D_C=MwC/MnC;

out=struct('M_gmol',M,'detailed_pdf',detailed,'collapsed_pdf',collapsed, ...
    'stage_w',w,'stage_Mn_population_gmol',MnJ,'stage_Mn_gmol',stageMn,'stage_Mw_gmol',stageMw, ...
    'Mn_analytical_gmol',MnA,'Mw_analytical_gmol',MwA,'D_analytical',D_A, ...
    'Mn_collapsed_analytical_gmol',MnC,'Mw_collapsed_analytical_gmol',MwC,'D_collapsed_analytical',D_C, ...
    'DeltaD_analytical',D_A-D_C,'EPC_wtfrac',EPC_wtfrac);
end
