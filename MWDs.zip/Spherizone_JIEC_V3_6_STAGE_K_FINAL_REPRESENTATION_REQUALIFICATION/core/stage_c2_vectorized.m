function c2 = stage_c2_vectorized(pop,f1_sorbed,r1vec,r2vec,response)
%STAGE_C2_VECTORIZED Stage C2 for many r1-r2 points at one model-form state.
w=pop.w(:)'; w=max(w,0); w=w/sum(w);
mult=response.ethylene_odds_multiplier(:)';
if numel(mult)~=numel(w), error('Response multiplier length mismatch.'); end
r1=r1vec(:); r2=r2vec(:);
odds=(1-f1_sorbed)/f1_sorbed;
f1j=1./(1+mult.*odds); % 1 x npop
q=1-f1j;
den=r1.*(f1j.^2) + 2.*f1j.*q + r2.*(q.^2); % implicit expansion n x npop
if any(den(:)<=0), error('Non-positive Mayo-Lewis denominator.'); end
F1=(r1.*(f1j.^2)+f1j.*q)./den;
C2=ethylene_weight_fraction(F1);
c2=C2*w';
end
