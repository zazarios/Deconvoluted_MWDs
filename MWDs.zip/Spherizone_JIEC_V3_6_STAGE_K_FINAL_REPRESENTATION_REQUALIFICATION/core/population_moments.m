function out = population_moments(pop)
%POPULATION_MOMENTS Analytical moments for a Flory-population mixture.
w=pop.w(:)'; Mn=pop.Mn_gmol(:)';
active=w>0 & isfinite(Mn);
if ~any(active), error('No active populations.'); end
w(~active)=0; w=w/sum(w);
MnMix=1/sum(w(active)./Mn(active));
MwMix=2*sum(w(active).*Mn(active));
out=struct('Mn_gmol',MnMix,'Mw_gmol',MwMix,'D',MwMix/MnMix,'w',w,'Mn_pop_gmol',Mn);
end
