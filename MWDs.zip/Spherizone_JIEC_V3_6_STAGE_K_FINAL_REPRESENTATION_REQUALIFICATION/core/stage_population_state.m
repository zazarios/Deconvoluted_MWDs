function out = stage_population_state(pop,f1_sorbed,r1vec,r2vec,response,transferMode)
%STAGE_POPULATION_STATE Per-population composition and Mn for Stage-D bounds.
% Returns nReact x nPop arrays before population-weight aggregation.

M3=42.08; M2=28.05;
w0=pop.w(:)'; w0=max(w0,0); w0=w0/sum(w0);
Mn0=pop.Mn_gmol(:)';
active=w0>0 & isfinite(Mn0);
if ~any(active), error('No active MWD populations.'); end

mult=response.ethylene_odds_multiplier(:)';
if numel(mult)~=numel(w0), error('Response multiplier length mismatch.'); end
r1=r1vec(:); r2=r2vec(:);
odds=(1-f1_sorbed)/f1_sorbed;
f1j=1./(1+mult.*odds); % 1 x nPop
q=1-f1j;
den=r1.*(f1j.^2) + 2.*f1j.*q + r2.*(q.^2);
if any(den(:)<=0), error('Non-positive Mayo-Lewis denominator.'); end
F1=(r1.*(f1j.^2)+f1j.*q)./den;
C2J=(1-F1).*M2 ./ (F1.*M3 + (1-F1).*M2);

switch upper(transferMode)
    case 'DIRECT_MN_TRANSFER'
        MnJ=repmat(Mn0,numel(r1),1);
    case 'DP_REPEAT_MASS_CORRECTED'
        repeatM=F1.*M3 + (1-F1).*M2;
        MnJ=(Mn0./M3).*repeatM;
    otherwise
        error('Unknown transferMode: %s',transferMode);
end

% Inactive source populations must not become active through uncertainty.
C2J(:,~active)=0;
MnJ(:,~active)=NaN;
out=struct('w0',w0,'active',active,'C2J',C2J,'MnJ',MnJ,'F1J',F1, ...
    'transferMode',transferMode,'f1_sorbed',f1_sorbed);
end
