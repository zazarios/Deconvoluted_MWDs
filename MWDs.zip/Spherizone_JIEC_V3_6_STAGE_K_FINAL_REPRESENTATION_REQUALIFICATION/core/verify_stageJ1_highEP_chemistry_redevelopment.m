function V = verify_stageJ1_highEP_chemistry_redevelopment(cfg,outdir,result)
%VERIFY_STAGEJ1_HIGHEP_CHEMISTRY_REDEVELOPMENT Executable qualification.
% Gates test source transcription, set construction, arithmetic, independent
% mirrors, and scope. Held-out challenge disagreement is scientifically
% permissible and is not itself an executable failure.
ROOT=fileparts(fileparts(mfilename('fullpath')));Gate={};Status={};Detail={};
add('J1_0_STAGE_J_PREREQUISITE',gateJ(),'Qualified Stage J with J0-J20 PASS is frozen upstream evidence.');
add('J1_1_SOURCE_FEED_BRACKETS_FBR',result.Support.SourceFeedE_Min<=result.Support.NominalFBRReactiveE_fraction && result.Support.SourceFeedE_Max>=result.Support.NominalFBRReactiveE_fraction, ...
    sprintf('Nominal reactive E fraction %.6f is bracketed by source feeds %.2f-%.2f.',result.Support.NominalFBRReactiveE_fraction,result.Support.SourceFeedE_Min,result.Support.SourceFeedE_Max));
[okS,detS]=sourceGate();add('J1_2_ZHANG_KINETIC_SOURCE_AUDIT',okS,detS);
add('J1_3_OUTWARD_SUPPORT_CONTAINMENT',logical(result.Support.OutwardContainmentPass),'Rounded [2,32] support and 16-fold contrast cap outwardly contain the selected Zhang high-E/P ratios/contrasts.');
add('J1_4_PATTERN_LIBRARY_COMPLETE',height(result.Patterns)==33 && max(result.Patterns.RawContrast)<=cfg.StageJ1.max_population_contrast+1e-12, ...
    sprintf('%d exchangeable patterns; max raw contrast %.6g.',height(result.Patterns),max(result.Patterns.RawContrast)));
add('J1_5_HIGH_EP_SCENARIO_LIBRARY',height(result.HighScenarios)==numel(cfg.StageJ1.kappa_reference_levels)*height(result.Patterns) && ...
    min([result.HighScenarios.kappa1;result.HighScenarios.kappa2;result.HighScenarios.kappa3;result.HighScenarios.kappa4;result.HighScenarios.kappa5])>=cfg.StageJ1.kappa_support(1)-1e-12 && ...
    max([result.HighScenarios.kappa1;result.HighScenarios.kappa2;result.HighScenarios.kappa3;result.HighScenarios.kappa4;result.HighScenarios.kappa5])<=cfg.StageJ1.kappa_support(2)+1e-12 && ...
    max(result.HighScenarios.RealizedContrast)<=cfg.StageJ1.max_population_contrast+1e-12, ...
    sprintf('%d high-E/P level-pattern states remain within kappa support and contrast cap.',height(result.HighScenarios)));
R=result.Regression;add('J1_6_FROZEN_STAGEJ_LEGACY_REPRODUCTION',R.MinAbsDiff<=cfg.StageJ1.regression_abs_tol && R.MaxAbsDiff<=cfg.StageJ1.regression_abs_tol, ...
    sprintf('Stage-J legacy min/max reproduced; abs diff %.3g/%.3g.',R.MinAbsDiff,R.MaxAbsDiff));
[okM,detM]=supportMirror();add('J1_7_INDEPENDENT_SUPPORT_MIRROR',okM,detM);
add('J1_8_FINAL_UNION_CONTAINS_STAGEJ',result.FinalStageC2Min<=R.FrozenStageJLegacyMin+1e-12 && result.FinalStageC2Max>=R.FrozenStageJLegacyMax-1e-12, ...
    'Final J.1 set union contains the full qualified Stage-J composition interval.');
[okB,detB]=bulkArithmetic();add('J1_9_BULK_C2_ARITHMETIC',okB,detB);
[okP,detP]=pairwiseArithmetic();add('J1_10_PAIRWISE_OVERLAP_ARITHMETIC',okP,detP);
[okC,detC]=criticalMirror();add('J1_11_MECHANISTIC_CRITICAL_KAPPA_MIRROR',okC,detC);
[okUV,detUV]=voiMirror(result.UnionVOI,'StageJ1_expected_union_VOI.csv');add('J1_12_UNION_VOI_MIRROR',okUV,detUV);
[okHV,detHV]=voiMirror(result.HighVOI,'StageJ1_expected_mechanistic_VOI.csv');add('J1_13_MECHANISTIC_VOI_MIRROR',okHV,detHV);
add('J1_14_VOI_FRACTION_BOUNDS',all(result.UnionVOI.GuaranteedContractionFraction>=-1e-10 & result.UnionVOI.GuaranteedContractionFraction<=1+1e-10) && ...
    all(result.HighVOI.GuaranteedContractionFraction>=-1e-10 & result.HighVOI.GuaranteedContractionFraction<=1+1e-10),'All singleton deterministic contractions lie in [0,1] within tolerance.');
[okHS,detHS]=holdStageArithmetic();add('J1_15_HELDOUT_STAGE_COVERAGE_ARITHMETIC',okHS,detHS);
[okHB,detHB]=holdBulkArithmetic();add('J1_16_HELDOUT_BULK_COVERAGE_ARITHMETIC',okHB,detHB);
add('J1_17_HELDOUT_COVERAGE_NOT_VALIDATION',scopeIs('HELDOUT_COVERAGE_EQUALS_MODEL_VALIDATION','NOT_ESTABLISHED'),'External coverage remains a physical-consistency challenge, not matched validation.');
add('J1_18_ZHANG_CONSTANT_TRANSFER_GUARD',scopeIs('ZHANG_KPE_KPP_TRANSFERRED_AS_ALSHAIBAN_KINETIC_CONSTANTS','NOT_ESTABLISHED') && scopeIs('J1_KAPPA_EQUALS_MAYO_LEWIS_REACTIVITY_RATIO','NOT_ESTABLISHED'), ...
    'The mechanistic source is not relabeled as Alshaiban catalyst kinetics or Mayo-Lewis reactivity ratios.');
add('J1_19_CHALLENGE_DATA_NOT_USED_TO_SET_SUPPORT',scopeIs('CANCELAS_BOTHA_WANG_USED_TO_SET_KAPPA_SUPPORT','PROHIBITED_AND_NOT_DONE'),'Held-out challenge observations do not define J.1 support.');
add('J1_20_H_TO_H2_NOT_REQUALIFIED',scopeIs('H_H1_H2_REQUALIFIED_IN_STAGEJ1','NO'),'H/H.1/H.2 order maps are not silently extended.');
add('J1_21_SCIENTIFIC_CHALLENGE_OUTCOME_PERMITTED',islogical(result.AllStageHoldoutCovered)||isnumeric(result.AllStageHoldoutCovered),'Held-out coverage may pass or fail without invalidating executable integrity.');
V=table(Gate',Status',Detail','VariableNames',{'Gate','Status','Detail'});writetable(V,fullfile(outdir,'StageJ1_verification.csv'));

 function add(n,ok,d),Gate{end+1}=n;if all(ok),Status{end+1}='PASS';else,Status{end+1}='FAIL';end;Detail{end+1}=d;end
 function ok=gateJ()
  f=fullfile(ROOT,'inputs','StageJQualifiedOutputs','STAGE_J_STATUS.txt');v=fullfile(ROOT,'inputs','StageJQualifiedOutputs','StageJ_verification.csv');
  ok=isfile(f)&&contains(fileread(f),'All executable Stage-J integrity/scope gates pass: 1')&&contains(fileread(f),'STRUCTURAL_W1_SURVIVES__HIGH_EP_COMPOSITION_DOMAIN_REQUIRES_REDEVELOPMENT');
  if ok&&isfile(v),T=stageJ_read_csv_strict(v);ok=height(T)==22&&all(string(T.Status)=="PASS");else,ok=false;end
 end
 function [ok,d]=sourceGate()
  E=result.Evidence;raw=[290/87;310/130;190/6.8;270/99;300/29;160/7.3;310/93;300/137;190/6.3;280/103;310/55;220/11.2];
  md=max(abs(E.kpE_over_kpP-raw));ok=height(E)==12&&md<=1e-12;d=sprintf('12 Zhang SI rows; max ratio transcription discrepancy %.3g.',md);
 end
 function [ok,d]=supportMirror()
  X=stageJ_read_csv_strict(fullfile(ROOT,'Independent_Audit','StageJ1_expected_support_summary.csv'));D=result.Domain;
  h=D(strcmp(string(D.Domain),'HIGH_EP_MECHANISTIC'),:);u=D(strcmp(string(D.Domain),'FINAL_UNION'),:);
  vals=[result.Support.Observed_kpE_over_kpP_Min,result.Support.Observed_kpE_over_kpP_Max,result.Support.ObservedMaxWithinConditionContrast,result.Support.KappaSupportMin,result.Support.KappaSupportMax,result.Support.KappaMaxPopulationContrast,h.StageC2Min,h.StageC2Max,u.StageC2Min,u.StageC2Max];
  ex=[X.ExpectedObservedMin_kpE_over_kpP,X.ExpectedObservedMax_kpE_over_kpP,X.ExpectedMaxWithinConditionContrast,X.ExpectedKappaSupportMin,X.ExpectedKappaSupportMax,X.ExpectedContrastCap,X.ExpectedHighEPStageC2Min,X.ExpectedHighEPStageC2Max,X.ExpectedFinalUnionStageC2Min,X.ExpectedFinalUnionStageC2Max];
  md=max(abs(vals-ex));ok=md<=cfg.StageJ1.regression_abs_tol;d=sprintf('Independent support/domain mirror max discrepancy %.3g.',md);
 end
 function [ok,d]=bulkArithmetic()
  B=result.Bulk;md=0;for z=1:height(B),md=max([md abs(B.BulkC2Min(z)-B.EPC_wtfrac(z)*result.FinalStageC2Min) abs(B.BulkC2Max(z)-B.EPC_wtfrac(z)*result.FinalStageC2Max)]);end
  ok=md<=1e-12;d=sprintf('Bulk-C2 product arithmetic max discrepancy %.3g.',md);
 end
 function [ok,d]=pairwiseArithmetic()
  P=result.Pairwise;bad=0;for z=1:height(P),m=P.HigherGradeLowerC2(z)-P.LowerGradeUpperC2(z);bad=bad+(abs(m-P.SeparationMargin(z))>1e-12)+((m<=0)~=P.IntervalsOverlap(z));end
  ok=bad==0;d=sprintf('%d pairwise rows; arithmetic/status mismatches=%d.',height(P),bad);
 end
 function [ok,d]=criticalMirror()
  X=stageJ_read_csv_strict(fullfile(ROOT,'Independent_Audit','StageJ1_expected_critical_kappa.csv'));C=result.Critical;md=0;bad=0;
  for z=1:height(X)
   q=abs(C.LowerEPC-X.LowerEPC(z))<1e-12 & abs(C.HigherEPC-X.HigherEPC(z))<1e-12;if sum(q)~=1,bad=bad+1;continue;end
   md=max(md,abs(C.CriticalKappaUpper(q)-X.ExpectedCriticalKappaUpper(z)));bad=bad+(string(C.Status(q))~=string(X.ExpectedStatus(z)));
  end
  ok=bad==0&&md<=2*cfg.StageJ1.critical_kappa_tol;d=sprintf('Critical-kappa rows=%d; status/missing=%d; max discrepancy %.3g.',height(X),bad,md);
 end
 function [ok,d]=voiMirror(A,file)
  X=stageJ_read_csv_strict(fullfile(ROOT,'Independent_Audit',file));md=0;bad=0;
  for z=1:height(X)
   q=string(A.ResolvedBlock)==string(X.ResolvedBlock(z));if sum(q)~=1,bad=bad+1;continue;end
   vals=[A.BaselineWidth(q),A.WorstResidualWidth(q),A.BestResidualWidth(q),A.GuaranteedContractionFraction(q),A.BestCaseContractionFraction(q)];
   ex=[X.ExpectedBaselineWidth(z),X.ExpectedWorstResidualWidth(z),X.ExpectedBestResidualWidth(z),X.ExpectedGuaranteedContractionFraction(z),X.ExpectedBestCaseContractionFraction(z)];md=max(md,max(abs(vals-ex)));
  end
  ok=bad==0&&md<=cfg.StageJ1.voi_abs_tol;d=sprintf('%d VOI rows; missing=%d; max discrepancy %.3g.',height(X),bad,md);
 end
 function [ok,d]=holdStageArithmetic()
  H=result.HoldStage;bad=0;for z=1:height(H),ov=result.FinalStageC2Max>=H.ExternalLo(z)&&result.FinalStageC2Min<=H.ExternalHi(z);ct=result.FinalStageC2Min<=H.ExternalLo(z)&&result.FinalStageC2Max>=H.ExternalHi(z);bad=bad+(ov~=H.AnyOverlap(z))+(ct~=H.ContainsExternalDatumOrRange(z));end
  ok=bad==0;d=sprintf('%d held-out stage/proxy rows; arithmetic mismatches=%d.',height(H),bad);
 end
 function [ok,d]=holdBulkArithmetic()
  H=result.HoldBulk;bad=0;md=0;for z=1:height(H),lo=H.EPC_wtfrac(z)*result.FinalStageC2Min;hi=H.EPC_wtfrac(z)*result.FinalStageC2Max;md=max([md abs(lo-H.ModelBulkC2Min(z)) abs(hi-H.ModelBulkC2Max(z))]);cv=H.ExternalBulkC2(z)>=lo&&H.ExternalBulkC2(z)<=hi;bad=bad+(cv~=H.ExternalPointCovered(z));end
  ok=bad==0&&md<=1e-12;d=sprintf('%d held-out bulk rows; mismatches=%d; max arithmetic discrepancy %.3g.',height(H),bad,md);
 end
 function ok=scopeIs(statement,status)
  q=string(result.Scope.Statement)==string(statement);idx=find(q,1);ok=sum(q)==1&&~isempty(idx)&&string(result.Scope.Status(idx))==string(status);
 end
end
