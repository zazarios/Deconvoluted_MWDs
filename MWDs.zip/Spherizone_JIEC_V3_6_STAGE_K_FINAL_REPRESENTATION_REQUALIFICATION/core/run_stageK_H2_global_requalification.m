function result=run_stageK_H2_global_requalification(cfg,outdir)
%RUN_STAGEK_H2_GLOBAL_REQUALIFICATION One fixed descriptor before T80.
if ~exist(outdir,'dir'),mkdir(outdir);end
ROOT=fileparts(fileparts(mfilename('fullpath')));
ctx=stageK_build_context(cfg);P=stageH_generate_partitions(5);
Tm=readtable(fullfile(ROOT,'inputs','StageFQualifiedOutputs','StageF_matrix_moment_consistency.csv'));
matrixMn=Tm.StageF_Mn_gmol(1);matrixMw=Tm.StageF_Mw_gmol(1);
Te=readtable(fullfile(ROOT,'inputs','StageEQualifiedOutputs','StageE_source_to_MZCR_distribution_retention.csv'));
ir=find(strcmp(Te.State,'MZCR_MATRIX'),1);M90=Te.M90_detailed_gmol(ir);M99=Te.M99_detailed_gmol(ir);
Targets={'FINAL_Mn_REL','FINAL_Mw_REL','FINAL_D_REL','FINAL_W1_LOG10M','TAIL_MASS_AT_MATRIX_M90_ABS','TAIL_MASS_AT_MATRIX_M99_ABS'};
modes=ctx.modes;

% Unique T80-global supports for every nonempty group encountered in the 52 partitions.
G=struct([]);seen={};
for ip=1:numel(P)
    for ig=1:numel(P(ip).Groups)
        g=P(ip).Groups{ig};gc=groupcode_H2(g);
        if ~any(strcmp(seen,gc)),seen{end+1}=gc;G=append_H2(G,struct('GroupCode',gc,'Members',g));end %#ok<AGROW>
    end
end
Supports=struct([]);
for ig=1:numel(G)
    for im=1:numel(modes)
        s=stageH2_group_global_support(ctx,G(ig).Members,modes{im},cfg);
        Supports=append_H2(Supports,struct('GroupCode',G(ig).GroupCode,'TransferMode',modes{im}, ...
            'Support_Mlo_gmol',s.Mlo_gmol,'Support_Mhi_gmol',s.Mhi_gmol,'T_at_Mlo',s.T_at_Mlo,'T_at_Mhi',s.T_at_Mhi, ...
            'Population_at_Mlo',s.Population_at_Mlo,'Population_at_Mhi',s.Population_at_Mhi,'AlphaMin',s.AlphaMin,'AlphaMax',s.AlphaMax)); %#ok<AGROW>
    end
end
SupportTable=struct2table(Supports);writetable(SupportTable,fullfile(outdir,'StageK_H2_T80_global_group_supports.csv'));

Desc=struct([]);Part=struct([]);
for ip=1:numel(P)
    part=P(ip);
    for ie=1:numel(cfg.StageH2.EPC)
        e=cfg.StageH2.EPC(ie);
        L=zeros(1,numel(Targets));U=zeros(1,numel(Targets));
        for im=1:numel(modes)
            mode=modes{im};d_rmw=[];d_rmn=[];d_lower=0;
            for iy=1:numel(Targets)
                target=Targets{iy};localL=0;localU=0;
                for ig=1:numel(part.Groups)
                    g=part.Groups{ig};d=stageH2_group_minimax_descriptor(target,g,mode,e,ctx,matrixMn,matrixMw,M90,M99,cfg);
                    Desc=append_H2(Desc,struct('PartitionCode',part.Code,'K',part.K,'GroupCode',groupcode_H2(g), ...
                        'Target',target,'EPC_wtfrac',e,'TransferMode',mode,'Mhat_gmol',d.Mhat_gmol, ...
                        'Support_Mlo_gmol',d.Mlo_gmol,'Support_Mhi_gmol',d.Mhi_gmol,'T_at_Mlo',d.Support.T_at_Mlo,'T_at_Mhi',d.Support.T_at_Mhi, ...
                        'GroupLower',d.GroupLower,'GroupUpper',d.GroupUpper,'DescriptorRule','T80_GLOBAL_TARGET_MINIMAX_FIXED_SCALAR', ...
                        'HiddenWeightAlphaAccess','NONE','T80BranchAccess','NONE')); %#ok<AGROW>
                    localL=max(localL,d.GroupLower);localU=max(localU,d.GroupUpper);
                    if strcmp(target,'FINAL_D_REL')
                        A=(1-e)/matrixMn;B=(1-e)*matrixMw;a0=cfg.StageH2.M2_gmol/cfg.StageH2.M3_gmol;
                        for it=1:numel(ctx.Tp)
                            Mn=ctx.Tp(it).Mn_gmol;
                            for jj=g
                                if strcmpi(mode,'DIRECT_MN_TRANSFER'),mm=Mn(jj);else,mm=[a0*Mn(jj),Mn(jj)];end
                                for q=1:numel(mm)
                                    m=mm(q);d_rmw(end+1)=(B+2*e*d.Mhat_gmol)/(B+2*e*m); %#ok<AGROW>
                                    d_rmn(end+1)=(A+e/m)/(A+e/d.Mhat_gmol); %#ok<AGROW>
                                end
                            end
                        end
                        d_lower=max(d_lower,d.GroupLower);
                    end
                end
                if ~strcmp(target,'FINAL_D_REL'),L(iy)=max(L(iy),localL);U(iy)=max(U(iy),localU);end
            end
            if ~isempty(d_rmw)
                iy=find(strcmp(Targets,'FINAL_D_REL'));L(iy)=max(L(iy),d_lower);
                U(iy)=max(U(iy),max(abs(min(d_rmw)/max(d_rmn)-1),abs(max(d_rmw)/min(d_rmn)-1)));
            end
        end
        Part=append_H2(Part,struct('PartitionCode',part.Code,'K',part.K,'EPC_wtfrac',e, ...
            'MnRel_lower',L(1),'MnRel_upper',U(1),'MwRel_lower',L(2),'MwRel_upper',U(2), ...
            'DRel_lower',L(3),'DRel_upper',U(3),'W1_lower_decades',L(4),'W1_upper_decades',U(4), ...
            'Tail90_lower_abs',L(5),'Tail90_upper_abs',U(5),'Tail99_lower_abs',L(6),'Tail99_upper_abs',U(6))); %#ok<AGROW>
    end
end
DescTable=struct2table(Desc);PartTable=struct2table(Part);
writetable(DescTable,fullfile(outdir,'StageK_H2_T80_global_fixed_descriptors.csv'));
writetable(PartTable,fullfile(outdir,'StageK_H2_all_partition_closure_bounds.csv'));

Cols={{'MnRel_lower','MnRel_upper'},{'MwRel_lower','MwRel_upper'},{'DRel_lower','DRel_upper'},{'W1_lower_decades','W1_upper_decades'},{'Tail90_lower_abs','Tail90_upper_abs'},{'Tail99_lower_abs','Tail99_upper_abs'}};
Sum=struct([]);
for ie=1:numel(cfg.StageH2.EPC)
    e=cfg.StageH2.EPC(ie);
    for iy=1:numel(Targets)
        for K=1:5
            ix=PartTable.K==K & abs(PartTable.EPC_wtfrac-e)<1e-12;idx=find(ix);
            lo=PartTable.(Cols{iy}{1})(ix);up=PartTable.(Cols{iy}{2})(ix);[vl,il]=min(lo);[vu,iu]=min(up);
            Sum=append_H2(Sum,struct('Target',Targets{iy},'EPC_wtfrac',e,'K',K,'MinimaxLower',vl,'MinimaxUpper',vu, ...
                'BestPartitionLower',PartTable.PartitionCode{idx(il)},'BestPartitionUpper',PartTable.PartitionCode{idx(iu)},'BoundWidth',max(0,vu-vl))); %#ok<AGROW>
        end
    end
end
Summary=struct2table(Sum);writetable(Summary,fullfile(outdir,'StageK_H2_target_minimax_summary.csv'));

Ord=struct([]);
for ie=1:numel(cfg.StageH2.EPC)
    e=cfg.StageH2.EPC(ie);
    for iy=1:numel(Targets)
        [tols,labels,unit]=tolset_H2(Targets{iy},cfg);
        ix=strcmp(Summary.Target,Targets{iy}) & abs(Summary.EPC_wtfrac-e)<1e-12;S=Summary(ix,:);[~,o]=sort(S.K);S=S(o,:);
        for itol=1:numel(tols)
            tol=tols(itol);kp=find(S.MinimaxLower<=tol+1e-15,1);ks=find(S.MinimaxUpper<=tol+1e-15,1);
            if isempty(kp),kp=NaN;end;if isempty(ks),ks=NaN;end
            if isnan(kp),status='NO_T80_GLOBAL_FIXED_SCALAR_CLOSURE_EVEN_POSSIBLE';
            elseif isnan(ks),status='NO_CERTIFIED_T80_GLOBAL_FIXED_SCALAR_CLOSURE';
            elseif kp==ks,status='CERTIFIED_T80_GLOBAL_FIXED_SCALAR_KSTAR';
            else,status='T80_GLOBAL_FIXED_SCALAR_KSTAR_BRACKETED';end
            Ord=append_H2(Ord,struct('Target',Targets{iy},'EPC_wtfrac',e,'ToleranceLabel',labels{itol},'Tolerance',tol,'ToleranceUnit',unit, ...
                'K_global_possible_lower',kp,'K_global_certified_sufficient',ks,'GlobalClosureStatus',status)); %#ok<AGROW>
        end
    end
end
OrderMap=struct2table(Ord);writetable(OrderMap,fullfile(outdir,'StageK_H2_target_order_map.csv'));

% Direct comparison with qualified H.1 T80-conditional closure.
H1S=stageJ_read_csv_strict(fullfile(outdir,'StageK_H1_target_minimax_summary.csv'));Penalty=struct([]);
for r=1:height(Summary)
    ix=strcmp(H1S.Target,Summary.Target{r}) & abs(H1S.EPC_wtfrac-Summary.EPC_wtfrac(r))<1e-12 & H1S.K==Summary.K(r);
    if sum(ix)~=1,error('StageH2:H1Summary','H.1 summary row mismatch.');end
    h1lo=H1S.MinimaxLower(ix);h1up=H1S.MinimaxUpper(ix);h2lo=Summary.MinimaxLower(r);h2up=Summary.MinimaxUpper(r);
    if h1up>0,rat=h2up/h1up;else,rat=NaN;end
    Penalty=append_H2(Penalty,struct('Target',Summary.Target{r},'EPC_wtfrac',Summary.EPC_wtfrac(r),'K',Summary.K(r), ...
        'H1_T80Conditional_MinimaxLower',h1lo,'H1_T80Conditional_MinimaxUpper',h1up, ...
        'H2_T80Global_MinimaxLower',h2lo,'H2_T80Global_MinimaxUpper',h2up,'UpperPenaltyAbs',h2up-h1up,'UpperPenaltyRatio',rat, ...
        'GlobalNotBetterGuard',h2up+1e-14>=h1up)); %#ok<AGROW>
end
PenaltyTable=struct2table(Penalty);writetable(PenaltyTable,fullfile(outdir,'StageK_H2_H1_to_H2_T80_penalty.csv'));

H1O=stageJ_read_csv_strict(fullfile(outdir,'StageK_H1_target_order_map.csv'));Gap=struct([]);
for r=1:height(OrderMap)
    ix=strcmp(H1O.Target,OrderMap.Target{r}) & abs(H1O.EPC_wtfrac-OrderMap.EPC_wtfrac(r))<1e-12 & strcmp(H1O.ToleranceLabel,OrderMap.ToleranceLabel{r});
    if sum(ix)~=1,error('StageH2:H1Order','H.1 order row mismatch.');end
    kh1=H1O.K_fixed_certified_sufficient(ix);kh2=OrderMap.K_global_certified_sufficient(r);
    if isnan(kh1) && isnan(kh2),delta=NaN;cls='ALREADY_FAILED_T80_CONDITIONALLY';
    elseif ~isnan(kh1) && isnan(kh2),delta=NaN;cls='T80_MODEL_FORM_CLOSURE_BARRIER';
    elseif isnan(kh1) && ~isnan(kh2),delta=NaN;cls='INVALID_GLOBAL_IMPROVEMENT__CHECK_IMPLEMENTATION';
    elseif kh2==kh1,delta=0;cls='SAME_CERTIFIED_ORDER';
    elseif kh2>kh1,delta=kh2-kh1;cls='HIGHER_ORDER_REQUIRED_BY_T80_GLOBALIZATION';
    else,delta=kh2-kh1;cls='INVALID_GLOBAL_ORDER_REDUCTION__CHECK_IMPLEMENTATION';end
    Gap=append_H2(Gap,struct('Target',OrderMap.Target{r},'EPC_wtfrac',OrderMap.EPC_wtfrac(r),'ToleranceLabel',OrderMap.ToleranceLabel{r}, ...
        'K_H1_T80Conditional_certified',kh1,'K_H2_T80Global_certified',kh2,'DeltaK_global_minus_conditional',delta,'T80GlobalizationEffect',cls)); %#ok<AGROW>
end
GapTable=struct2table(Gap);writetable(GapTable,fullfile(outdir,'StageK_H2_H1_to_H2_order_gap.csv'));

Metric={'FINAL_Mn_REL';'FINAL_Mw_REL';'FINAL_D_REL';'FINAL_W1_LOG10M';'TAIL_MASS_AT_MATRIX_M90_ABS';'TAIL_MASS_AT_MATRIX_M99_ABS'};
Status={'EXACT_GLOBAL_FIXED_SCALAR_MINIMAX';'EXACT_GLOBAL_FIXED_SCALAR_MINIMAX';'WITNESS_TO_CONSERVATIVE_RATIO_BOUND';'EXACT_GLOBAL_FIXED_SCALAR_MINIMAX';'EXACT_GLOBAL_FIXED_SCALAR_MINIMAX';'EXACT_GLOBAL_FIXED_SCALAR_MINIMAX'};
Meaning={'One scalar descriptor per group is fixed before T80, weights and alpha.';'One scalar descriptor per group is fixed before T80, weights and alpha.';'D is nonseparable; lower/upper are reported.';'Scale-family W1 minimax over attained T80-global extrema.';'Fixed-threshold tail minimax over attained T80-global extrema.';'Fixed-threshold tail minimax over attained T80-global extrema.'};
MetricScope=table(Metric,Status,Meaning);writetable(MetricScope,fullfile(outdir,'StageK_H2_metric_scope.csv'));
Claim={'T80_GLOBAL_TARGET_SPECIFIC_FIXED_SCALAR_ORDER';'ONE_DESCRIPTOR_SET_ACROSS_BOTH_TRANSFER_FORMULATIONS';'ONE_UNIFIED_REDUCED_MODEL_FOR_ALL_TARGETS';'POPULATION_SPECIFIC_CHEMISTRY_IDENTIFIED';'GROUP_WEIGHT_DYNAMICS_CLOSED';'INDUSTRIAL_ICP_VALIDATION'};
ClaimStatus={'ALLOWED_ONLY_FOR_TARGET_EPC_TOLERANCE_ROWS_WITH_CERTIFIED_K';'NOT_ESTABLISHED';'NOT_ESTABLISHED';'NOT_ESTABLISHED';'NOT_ESTABLISHED';'NOT_ESTABLISHED'};
ClaimMeaning={'H.2 fixes descriptors before the T80 branch, hidden weights and DP alpha, conditional on the declared transfer formulation.';'DIRECT and DP remain alternative declared model structures.';'Descriptors remain target-specific and can trade fidelity in other outputs.';'Residual DP alpha uncertainty is deliberately unresolved.';'Group weights remain set-valued within the Stage-G uncertainty domain.';'No matched ICP experiment is introduced.'};
ClaimScope=table(Claim,ClaimStatus,ClaimMeaning);writetable(ClaimScope,fullfile(outdir,'StageK_H2_claim_scope.csv'));

result=struct('Partitions',P,'Supports',SupportTable,'Descriptors',DescTable,'PartTable',PartTable,'Summary',Summary,'OrderMap',OrderMap, ...
    'PenaltyTable',PenaltyTable,'GapTable',GapTable,'MetricScope',MetricScope,'ClaimScope',ClaimScope,'ctx',ctx,'matrixMn',matrixMn,'matrixMw',matrixMw,'M90',M90,'M99',M99);
end

function A=append_H2(A,r)
if isempty(A),A=r;return;end
if ~isequal(fieldnames(A),fieldnames(r)),error('StageH2:StructSchema','Record schema mismatch.');end
A(end+1)=r;
end
function s=groupcode_H2(g)
s=sprintf('%d-',g);s=s(1:end-1);
end
function [tols,labels,unit]=tolset_H2(target,cfg)
labels=cfg.StageH2.tolerance_labels;
if strcmp(target,'FINAL_W1_LOG10M'),tols=cfg.StageH2.W1_tolerances_decades;unit='decades';
elseif contains(target,'TAIL_MASS'),tols=cfg.StageH2.tail_mass_abs_tolerances;unit='absolute_mass_fraction';
else,tols=cfg.StageH2.scalar_rel_tolerances;unit='relative_fraction';end
end
