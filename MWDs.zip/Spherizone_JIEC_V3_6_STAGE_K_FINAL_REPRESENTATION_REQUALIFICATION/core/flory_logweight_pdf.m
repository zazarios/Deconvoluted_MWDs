function g = flory_logweight_pdf(M_gmol, Mn_gmol)
%FLORY_LOGWEIGHT_PDF One Flory most-probable weight density dW/dlog10(M).
% g(x) = ln(10) M^2/Mn^2 exp(-M/Mn), x=log10(M).

if ~(isscalar(Mn_gmol) && isfinite(Mn_gmol) && Mn_gmol > 0)
    error('Mn_gmol must be a finite positive scalar for an active population.');
end
M = M_gmol;
if any(~isfinite(M(:))) || any(M(:) <= 0)
    error('M_gmol must contain finite positive values.');
end
g = log(10) .* (M.^2 ./ Mn_gmol.^2) .* exp(-M ./ Mn_gmol);
end
