function [lo,hi,loWit,hiWit] = stageJ1_homogeneous_kappa_range(pop,Sp,surf,kappa)
%STAGEJ1_HOMOGENEOUS_KAPPA_RANGE Range for one homogeneous kappa level.
r=struct('name',sprintf('J1_kappa_%g',kappa),'class','J1','ethylene_odds_multiplier',kappa*ones(1,5));
lo=Inf; hi=-Inf; loWit=[]; hiWit=[];
for is=1:numel(Sp)
 c=stage_c2_vectorized(pop,Sp(is).f1_sorbed,surf.r1,surf.r2,r);
 [a,ia]=min(c); [b,ib]=max(c);
 if a<lo,lo=a;loWit={Sp(is).name,surf.f1_EX2(ia),surf.r1(ia),surf.r2(ia)};end
 if b>hi,hi=b;hiWit={Sp(is).name,surf.f1_EX2(ib),surf.r1(ib),surf.r2(ib)};end
end
end
