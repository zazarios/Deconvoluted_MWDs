function out = stage_properties_weight_ensemble_B2(pop,f1_sorbed,r1vec,r2vec,response,transferMode,Wscenarios)
%STAGE_PROPERTIES_WEIGHT_ENSEMBLE_B2 Stage composition/MWD across weight-transfer stresses.
% Returns nReact x nWeight matrices for C2, Mn, Mw and D.
% Population weights are renormalized after applying relative-yield multipliers.
% No multiplier is interpreted as a probability or catalyst-specific activity.

M3=42.08; M2=28.05;
w0=pop.w(:)'; w0=max(w0,0); w0=w0/sum(w0);
Mn0=pop.Mn_gmol(:)';
active=w0>0 & isfinite(Mn0);
if ~any(active), error('No active MWD populations.'); end

mult=response.ethylene_odds_multiplier(:)';
if numel(mult)~=numel(w0), error('Response multiplier length mismatch.'); end
r1=r1vec(:); r2=r2vec(:);
odds=(1-f1_sorbed)/f1_sorbed;
f1j=1./(1+mult.*odds); % 1 x npop
q=1-f1j;
den=r1.*(f1j.^2) + 2.*f1j.*q + r2.*(q.^2); % nReact x npop
if any(den(:)<=0), error('Non-positive Mayo-Lewis denominator.'); end
F1=(r1.*(f1j.^2)+f1j.*q)./den;
C2J=(1-F1).*M2 ./ (F1.*M3 + (1-F1).*M2);

switch upper(transferMode)
    case 'DIRECT_MN_TRANSFER'
        MnJ=repmat(Mn0,numel(r1),1);
    case 'DP_REPEAT_MASS_CORRECTED'
        repeatM=F1.*M3 + (1-F1).*M2;
        MnJ=(Mn0./M3).*repeatM;
    otherwise
        error('Unknown transferMode: %s',transferMode);
end

nW=numel(Wscenarios);
Wmat=zeros(nW,numel(w0));
for iw=1:nW
    a=Wscenarios(iw).yield_multiplier(:)';
    if numel(a)~=numel(w0) || any(~isfinite(a)) || any(a<=0)
        error('Invalid population-yield multiplier in scenario %d.',iw);
    end
    we=w0.*a;
    we(~active)=0;
    if sum(we)<=0, error('Weight-transfer scenario eliminates all active populations.'); end
    Wmat(iw,:)=we/sum(we);
end

% Matrix multiplication performs all relative-weight scenarios at once.
% Restrict moment algebra to active populations so NaN descriptors for
% absent populations cannot contaminate 0-weight matrix products.
WA=Wmat(:,active);
C2A=C2J(:,active);
MnA=MnJ(:,active);
out.C2_wtfrac=C2A*WA';
out.Mn_gmol=1./((1./MnA)*WA');
out.Mw_gmol=2*(MnA*WA');
out.D=out.Mw_gmol./out.Mn_gmol;
out.Wmat=Wmat;
out.transferMode=transferMode;
end
