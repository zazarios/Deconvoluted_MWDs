function row = stageJ1_selected_subset_voi(A,blockNames,resolved,label)
%STAGEJ1_SELECTED_SUBSET_VOI One deterministic multi-block oracle contraction.
nb=numel(blockNames); sz=size(A); if numel(sz)<nb, sz(end+1:nb)=1; end
unresolved=setdiff(1:nb,resolved,'stable'); base=max(A(:))-min(A(:));
if isempty(unresolved), worst=0; best=0;
else
 perm=[resolved unresolved]; B=permute(A,perm); nR=prod(sz(resolved)); nU=prod(sz(unresolved)); B=reshape(B,[nR nU]);
 widths=max(B,[],2)-min(B,[],2); worst=max(widths); best=min(widths);
end
if base>0, g=1-worst/base; gb=1-best/base; else, g=NaN; gb=NaN; end
row=table({label},{strjoin(blockNames(resolved),'+')},numel(resolved),base,worst,best,g,gb, ...
 'VariableNames',{'Domain','ResolvedBlocks','Cardinality','BaselineWidth','WorstResidualWidth','BestResidualWidth','GuaranteedContractionFraction','BestCaseContractionFraction'});
end
