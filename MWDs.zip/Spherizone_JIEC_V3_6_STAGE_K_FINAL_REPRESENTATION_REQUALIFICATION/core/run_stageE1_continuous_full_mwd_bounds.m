function result = run_stageE1_continuous_full_mwd_bounds(cfg,outdir)
%RUN_STAGEE1_CONTINUOUS_FULL_MWD_BOUNDS Continuous Stage-E.1 robustness bounds.
% No new physical model is introduced. The analysis is marginal, matching
% Stage D: U_W is evaluated at C0 chemistry; U_C retains inherited weights.
if ~exist(outdir,'dir'), mkdir(outdir); end
M=cfg.StageE.metric_M_grid(:)'; x=log10(M); xdiam=x(end)-x(1);

% Rebuild qualified Stage-E matrix on the same high-accuracy grid.
cfgH=cfg; cfgH.M_output_grid=M;
mz=run_normalized_mzcr_demo(cfgH); matrix=mz.matrix;
MC=stageE1_matrix_cdf_difference(matrix,M);
ctx=stageD1_build_context(cfg);
Aalpha=stageE1_c0_dp_alpha_range(ctx);
alphaMid=10^(0.5*(log10(Aalpha.alpha_min)+log10(Aalpha.alpha_max)));
LF=log(10)*4/exp(2); % max |d Flory CDF / d log10(scale)|
alphaPad=2*LF*0.5*(log10(Aalpha.alpha_max)-log10(Aalpha.alpha_min));

% -------------------------------------------------------------------------
% U_W: full simplex is the maximal TV-radius domain and covers every
% Stage-D TV ball. C0 is retained exactly as in Stage D.
UW=struct([]); n=0;
for it=1:numel(ctx.Tp)
    pop=ctx.Tp(it);
    for im=1:numel(ctx.modes)
        mode=ctx.modes{im};
        if strcmpi(mode,'DIRECT_MN_TRANSFER')
            MnBound=pop.Mn_gmol;
            alphaLo=1; alphaHi=1; alphaExtra=0;
        else
            MnBound=alphaMid.*pop.Mn_gmol;
            alphaLo=Aalpha.alpha_min; alphaHi=Aalpha.alpha_max; alphaExtra=alphaPad;
        end
        HB=stageE1_weight_simplex_h_bounds(M,MnBound,cfg.StageE1.edge_t_points, ...
            cfg.StageE1.edge_chunk,cfg.StageE1.finite_grid_cdf_pad);
        hmin=HB.hmin-alphaExtra; hmax=HB.hmax+alphaExtra;
        hmin=max(-1,hmin); hmax=min(1,hmax);
        for ie=1:numel(cfg.StageE1.EPC)
            e=cfg.StageE1.EPC(ie);
            B=stageE1_w1_lower_from_h_bounds(M,MC.A,hmin,hmax,e);
            n=n+1;
            rr=struct(); rr.Coordinate='U_W'; rr.TransferMode=mode; rr.EPC_wtfrac=e;
            rr.TScenario=pop.name; rr.TAdmissibility=pop.admissibility;
            rr.W1_certified_lower_decades=B.W1_lower_decades;
            rr.W1_attainable_upper_on_global_min_decades=(1-e)*MC.W1_decades;
            rr.JS_certified_lower_bits=stageE1_js_lower_from_w1(B.W1_lower_decades,xdiam);
            rr.Alpha_min=alphaLo; rr.Alpha_max=alphaHi; rr.Edge_t_points=cfg.StageE1.edge_t_points;
            rr.Max_edge_Lipschitz_pad=HB.max_edge_pad; rr.Alpha_Lipschitz_pad=alphaExtra;
            rr.FiniteGrid_CDF_pad_per_CDF=cfg.StageE1.finite_grid_cdf_pad;
            rr.DomainStatement='Full active-population simplex; therefore covers every TV(w,w0)<=delta_W for 0<=delta_W<=1.';
            if strcmpi(mode,'DP_REPEAT_MASS_CORRECTED')
                rr.Note='C0 common repeat-mass scale enclosed continuously over exact Stage-D alpha range.';
            else
                rr.Note='C0 DIRECT transfer: population Mn fixed; full simplex is exact maximal U_W weight domain.';
            end
            UW=append_E1(UW,rr); %#ok<AGROW>
        end
    end
end
UWT=struct2table(UW); writetable(UWT,fullfile(outdir,'StageE1_UW_fullsimplex_W1_bounds_by_T.csv'));

% -------------------------------------------------------------------------
% U_C: inherited weights. DIRECT is exactly chemistry-invariant in MWD.
% DP uses independent alpha_j in [M2/M3,1], a conservative superset of the
% exact continuous chemistry manifold.
a0=cfg.StageE1.M2_gmol/cfg.StageE1.M3_gmol;
UC=struct([]); n=0;
for it=1:numel(ctx.Tp)
    pop=ctx.Tp(it);
    for im=1:numel(ctx.modes)
        mode=ctx.modes{im};
        for ie=1:numel(cfg.StageE1.EPC)
            e=cfg.StageE1.EPC(ie); n=n+1; rr=struct();
            rr.Coordinate='U_C'; rr.TransferMode=mode; rr.EPC_wtfrac=e;
            rr.TScenario=pop.name; rr.TAdmissibility=pop.admissibility;
            if strcmpi(mode,'DIRECT_MN_TRANSFER')
                d=stageE_build_final_distribution(matrix,pop.w,pop.Mn_gmol,e,M);
                met=stageE_distribution_metrics(M,d.detailed_pdf,d.collapsed_pdf);
                lb=met.W1_log10M_decades; ub=lb;
                rr.BoundConstruction='EXACT_DIRECT_MWD_INVARIANCE_TO_UC';
                rr.ScaleDomain='alpha_j = 1 exactly for DIRECT_MN_TRANSFER';
                rr.Note='Chemistry changes composition only; DIRECT population Mn and inherited weights are unchanged.';
            else
                HB=stageE1_uc_dp_superset_h_bounds(M,pop.w,pop.Mn_gmol,a0,cfg.StageE1.finite_grid_cdf_pad);
                B=stageE1_w1_lower_from_h_bounds(M,MC.A,HB.hmin,HB.hmax,e); lb=B.W1_lower_decades;
                % Attainable C0 endpoint candidates from exact Stage-D alpha range.
                vals=zeros(1,2); aa=[Aalpha.alpha_min,Aalpha.alpha_max];
                for k=1:2
                    d=stageE_build_final_distribution(matrix,pop.w,aa(k).*pop.Mn_gmol,e,M);
                    met=stageE_distribution_metrics(M,d.detailed_pdf,d.collapsed_pdf);
                    vals(k)=met.W1_log10M_decades;
                end
                ub=min(vals);
                rr.BoundConstruction='CONSERVATIVE_INDEPENDENT_REPEAT_MASS_SCALE_SUPERSET';
                rr.ScaleDomain=sprintf('Independent alpha_j in [%.10g,1]; exact U_C is a subset.',a0);
                rr.Note='Superset permits more DP Mn variation than Stage-D U_C; positive lower bound is therefore conservative.';
            end
            rr.W1_certified_lower_decades=lb;
            rr.W1_attainable_upper_on_global_min_decades=ub;
            rr.JS_certified_lower_bits=stageE1_js_lower_from_w1(lb,xdiam);
            rr.FiniteGrid_CDF_pad_per_CDF=cfg.StageE1.finite_grid_cdf_pad;
            UC=append_E1(UC,rr); %#ok<AGROW>
        end
    end
end
UCT=struct2table(UC); writetable(UCT,fullfile(outdir,'StageE1_UC_continuous_W1_bounds_by_T.csv'));

% -------------------------------------------------------------------------
% Global coordinate/mode/EPC summary across all primary T scenarios.
Sum=struct([]);
for coord={'U_W','U_C'}
    if strcmp(coord{1},'U_W'), T=UWT; else, T=UCT; end
    for im=1:numel(ctx.modes)
        mode=ctx.modes{im};
        for ie=1:numel(cfg.StageE1.EPC)
            e=cfg.StageE1.EPC(ie);
            ix=strcmp(T.TransferMode,mode) & abs(T.EPC_wtfrac-e)<1e-12;
            lo=min(T.W1_certified_lower_decades(ix));
            up=min(T.W1_attainable_upper_on_global_min_decades(ix));
            rr=struct('Coordinate',coord{1},'TransferMode',mode,'EPC_wtfrac',e, ...
                'W1_certified_lower_decades',lo,'W1_attainable_upper_on_global_min_decades',up, ...
                'W1_global_min_bracket_width_decades',up-lo, ...
                'JS_certified_lower_bits',stageE1_js_lower_from_w1(lo,xdiam), ...
                'SupportDiameter_log10M_decades',xdiam);
            Sum=append_E1(Sum,rr); %#ok<AGROW>
        end
    end
end
SummaryT=struct2table(Sum); writetable(SummaryT,fullfile(outdir,'StageE1_continuous_W1_bounds_summary.csv'));

% Metric-scope guard: only W1 and the mathematically derived JS floor are
% globally bounded. Quantiles/tails remain Stage-E magnitude diagnostics.
Metric={'W1_log10M';'JS_divergence_bits';'M90_ratio';'M99_ratio';'TailExcessAboveCollapsedM90'};
Status={'CERTIFIED_CONTINUOUS_LOWER_BOUND';'DERIVED_CONSERVATIVE_LOWER_BOUND_FROM_W1'; ...
    'MAGNITUDE_ONLY_NOT_GLOBAL_BOUND';'MAGNITUDE_ONLY_NOT_GLOBAL_BOUND';'MAGNITUDE_ONLY_NOT_GLOBAL_BOUND'};
Meaning={'Primary E.1 result.';'Pinsker plus W1<=diameter*TV; generally loose.'; ...
    'Use Stage-E adverse-witness values only; do not call a continuous minimum.'; ...
    'Use Stage-E adverse-witness values only; do not call a continuous minimum.'; ...
    'Use Stage-E adverse-witness values only; do not call a continuous minimum.'};
ScopeT=table(Metric,Status,Meaning); writetable(ScopeT,fullfile(outdir,'StageE1_metric_scope.csv'));

% Carry forward Stage-E magnitude context without re-labeling it as a global bound.
Wfile=fullfile(fileparts(fileparts(mfilename('fullpath'))),'inputs','StageEQualifiedOutputs','StageE_worst_witness_full_distribution_metrics.csv');
if exist(Wfile,'file')==2
    W=readtable(Wfile);
    Ctx=table(min(W.W1_log10M_decades),min(W.JS_divergence_bits), ...
        min(W.M90_detailed_gmol./W.M90_collapsed_gmol),min(W.M99_detailed_gmol./W.M99_collapsed_gmol), ...
        min(W.TailExcessAboveCollapsedM90), ...
        'VariableNames',{'StageE_min_W1_decades','StageE_min_JS_bits','StageE_min_M90_ratio','StageE_min_M99_ratio','StageE_min_tail_excess'});
else
    Ctx=table(NaN,NaN,NaN,NaN,NaN,'VariableNames',{'StageE_min_W1_decades','StageE_min_JS_bits','StageE_min_M90_ratio','StageE_min_M99_ratio','StageE_min_tail_excess'});
end
writetable(Ctx,fullfile(outdir,'StageE1_StageE_magnitude_context.csv'));

Diag=table(MC.W1_decades,Aalpha.alpha_min,Aalpha.alpha_max,Aalpha.n_exact_states,Aalpha.max_population_ratio_spread, ...
    alphaMid,alphaPad,a0,cfg.StageE1.edge_t_points,cfg.StageE1.finite_grid_cdf_pad, ...
    'VariableNames',{'Matrix_W1_decades','C0_DP_alpha_min','C0_DP_alpha_max','C0_DP_exact_state_count','C0_DP_max_population_scale_spread', ...
    'C0_DP_alpha_log_midpoint','C0_DP_alpha_Lipschitz_pad','UC_DP_independent_alpha_min','Edge_t_points','FiniteGrid_CDF_pad_per_CDF'});
writetable(Diag,fullfile(outdir,'StageE1_numerical_diagnostics.csv'));

result=struct('UWByT',UWT,'UCByT',UCT,'Summary',SummaryT,'MetricScope',ScopeT,'MagnitudeContext',Ctx, ...
    'Diagnostics',Diag,'matrixW1',MC.W1_decades,'alphaRange',Aalpha,'matrix',matrix);
end

function A=append_E1(A,r)
if isempty(A), A=r; return; end
if ~isequal(fieldnames(A),fieldnames(r)), error('StageE1:StructSchemaMismatch','Stage-E.1 record schema mismatch.'); end
A(end+1)=r;
end
