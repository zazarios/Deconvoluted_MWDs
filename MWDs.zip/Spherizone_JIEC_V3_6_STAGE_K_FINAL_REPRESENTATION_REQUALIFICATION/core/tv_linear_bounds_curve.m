function [vmin,vmax] = tv_linear_bounds_curve(w0,C,delta_grid)
%TV_LINEAR_BOUNDS_CURVE Exact linear-functional bounds over a TV ball.
%   U(delta)={w>=0,sum(w)=1,0.5*sum(abs(w-w0))<=delta}.
% C is nState x nPop; outputs are nState x nDelta.
%
% For a linear functional, the exact maximum moves mass from the lowest
% coefficients toward the maximum-coefficient support; the minimum is the
% reverse. This implementation evaluates the resulting piecewise-linear
% curves vectorially and requires no Optimization Toolbox.

w0=w0(:)';
if any(w0<0) || abs(sum(w0)-1)>1e-10, error('w0 must be a simplex vector.'); end
if size(C,2)~=numel(w0), error('C column count must match w0 length.'); end
if any(~isfinite(C(:))), error('Coefficient matrix contains nonfinite entries.'); end
delta_grid=delta_grid(:)';
if any(delta_grid<0) || any(delta_grid>1+1e-12), error('TV radii must lie in [0,1].'); end

n=size(C,1); nd=numel(delta_grid); p=numel(w0);
base=sum(C.*w0,2);
tol=1e-12;

% Maximum: remove from ascending coefficients and add to cmax.
[Casc,Iasc]=sort(C,2,'ascend');
Wasc=w0(Iasc);
cmax=max(C,[],2);
gainMax=cmax-Casc;
WdonMax=Wasc.*(gainMax>tol);
cumPrevMax=[zeros(n,1),cumsum(WdonMax(:,1:end-1),2)];

% Minimum: remove from descending coefficients and add to cmin.
[Cdesc,Idesc]=sort(C,2,'descend');
Wdesc=w0(Idesc);
cmin=min(C,[],2);
gainMin=Cdesc-cmin;
WdonMin=Wdesc.*(gainMin>tol);
cumPrevMin=[zeros(n,1),cumsum(WdonMin(:,1:end-1),2)];

vmax=zeros(n,nd); vmin=zeros(n,nd);
for id=1:nd
    d=delta_grid(id);
    moved=max(d-cumPrevMax,0);
    moved=min(moved,WdonMax);
    vmax(:,id)=base+sum(moved.*gainMax,2);

    moved=max(d-cumPrevMin,0);
    moved=min(moved,WdonMin);
    vmin(:,id)=base-sum(moved.*gainMin,2);
end
end
