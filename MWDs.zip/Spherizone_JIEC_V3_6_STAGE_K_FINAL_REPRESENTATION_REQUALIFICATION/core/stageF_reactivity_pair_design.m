function [D,S] = stageF_reactivity_pair_design(cfg,surf)
%STAGEF_REACTIVITY_PAIR_DESIGN Ideal two-composition Mayo-Lewis design audit.
% Existing EX2 C2 plus independently measured EX2 sorbed f1 supplies the
% first linear equation in (r1,r2). A second RCP composition at a distinct,
% independently characterized sorbed f1 supplies the second equation.
% This routine chooses the second f1 prospectively to maximize the normalized
% row-angle determinant. It assumes exact readout only to test structural
% identifiability; condition numbers are exported because exact uniqueness
% does not imply robust estimation with noisy measurements.
flo=min(surf.f1_EX2); fhi=max(surf.f1_EX2);
fCand=linspace(flo,fhi,cfg.StageF.second_RCP_f1_points);
Ftar=propylene_mole_fraction_from_C2wt(cfg.EX2.target_C2_wtfrac);
n=height(surf);
rows=cell(n,10);
for i=1:n
    fA=surf.f1_EX2(i); r1=surf.r1(i); r2=surf.r2(i);
    [v1,a1,b1,c1]=roweq(fA,Ftar);
    q=1-fCand;
    den=r1.*fCand.^2 + 2.*fCand.*q + r2.*q.^2;
    F2=(r1.*fCand.^2 + fCand.*q)./den;
    a=fCand.^2.*(F2-1); b=F2.*q.^2;
    nr=sqrt(a.^2+b.^2); va=a./nr; vb=b./nr;
    score=abs(v1(1).*vb-v1(2).*va);
    [best,j]=max(score);
    fB=fCand(j); Fbest=F2(j);
    [v2,a2,b2,c2]=roweq(fB,Fbest);
    An=[v1;v2]; cnd=cond(An);
    A=[a1 b1; a2 b2]; rhs=[c1;c2]; sol=A\rhs;
    err=max(abs(sol-[r1;r2])./max(abs([r1;r2]),1e-12));
    rows(i,:)={fA,r1,r2,fB,Fbest,best,cnd,sol(1),sol(2),err};
end
D=cell2table(rows,'VariableNames',{'EX2_f1_sorbed','r1_true','r2_true','Optimal_second_f1_sorbed','Second_polymer_F1', ...
    'NormalizedDeterminant','NormalizedConditionNumber','r1_recovered','r2_recovered','MaxRelativeRecoveryError'});
tol=1e-12;
lo=abs(D.Optimal_second_f1_sorbed-flo)<tol; hi=abs(D.Optimal_second_f1_sorbed-fhi)<tol;
S=table(flo,fhi,min(D.NormalizedDeterminant),max(D.NormalizedConditionNumber),min(D.NormalizedConditionNumber), ...
    mean(lo),mean(hi),mean(lo|hi),max(D.MaxRelativeRecoveryError), ...
    'VariableNames',{'f1_min','f1_max','MinNormalizedDeterminant','MaxNormalizedConditionNumber','MinNormalizedConditionNumber', ...
    'FractionOptimalAtLowerEndpoint','FractionOptimalAtUpperEndpoint','FractionOptimalAtEitherEndpoint','MaxRelativeExactRecoveryError'});
end

function [vn,a,b,c] = roweq(f,F)
q=1-f;
a=f^2*(F-1); b=F*q^2; c=-f*q*(2*F-1);
n=sqrt(a^2+b^2); vn=[a b]/n;
end
