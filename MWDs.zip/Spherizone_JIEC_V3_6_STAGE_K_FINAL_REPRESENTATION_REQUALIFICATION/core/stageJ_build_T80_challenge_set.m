function Tset = stageJ_build_T80_challenge_set(cfg)
%STAGEJ_BUILD_T80_CHALLENGE_SET Build qualified T80 branches for Stage J.
% Each branch uses the pre-existing population_T80_envelope at a declared H2
% boundary/stress value. Only the primary Stage-B admissibility classes are
% retained. External literature defines the challenge branch, not fitted Mn/w.

Tset=struct([]);
for ib=1:numel(cfg.StageJ.H2_molfrac)
    h2mol=cfg.StageJ.H2_molfrac(ib);
    h2psi=h2mol*cfg.FBR.P_bar*14.5037738;
    Tall=population_T80_envelope(h2psi,cfg.MZCR.DoTi);
    keep=false(1,numel(Tall));
    for k=1:numel(Tall)
        keep(k)=any(strcmp(Tall(k).admissibility,cfg.StageB.primary_T_classes));
    end
    T=Tall(keep);
    for k=1:numel(T)
        T(k).base_name=T(k).name;
        T(k).H2Branch=cfg.StageJ.H2_branch_names{ib};
        T(k).H2Role=cfg.StageJ.H2_roles{ib};
        T(k).H2_molfrac=h2mol;
        T(k).H2_psi=h2psi;
        T(k).name=sprintf('%s__%s',T(k).H2Branch,T(k).base_name);
    end
    if isempty(Tset), Tset=T; else, Tset=[Tset T]; end %#ok<AGROW>
end
end
