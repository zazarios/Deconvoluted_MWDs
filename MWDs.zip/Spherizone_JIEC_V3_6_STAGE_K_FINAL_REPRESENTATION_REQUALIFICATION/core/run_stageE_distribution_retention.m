function result = run_stageE_distribution_retention(cfg,outdir)
%RUN_STAGEE_DISTRIBUTION_RETENTION Full-MWD information-retention analysis.
% Scope:
%  1) EX1-source -> MZCR matrix retention of resolved MWD information.
%  2) Transparent reference final distributions for EPC 10/20/30 wt%.
%  3) Full-distribution metrics at the adverse witnesses that minimized the
%     already-qualified Stage-B2 dispersity-excess structural objective.
%  4) Source-supported H2 full-MWD trend challenge against Yang et al. 2026.
%
% Stage E intentionally does not claim an exhaustive minimization of W1/JSD
% over the continuous Stage-D U_W/U_C sets.

if ~exist(outdir,'dir'), mkdir(outdir); end
M=cfg.StageE.metric_M_grid(:)'; x=log10(M);

% Re-evaluate the same normalized MZCR property model on the high-accuracy
% Stage-E metric grid. This changes numerical quadrature resolution only.
cfgH=cfg; cfgH.M_output_grid=M;
mz=run_normalized_mzcr_demo(cfgH);
matrix=mz.matrix;

% -------------------------------------------------------------------------
% EX1 source and MZCR matrix information-retention baseline.
ex1=mz.EX1_conditioning;
srcPop=population_transfer(cfg.EX1.T_C,ex1.H2_psi,cfg.EX1.DoTi);
srcMix=mix_flory_populations(srcPop.w,srcPop.Mn_gmol,M);
srcMom=population_moments(srcPop);
srcCollapse=flory_logweight_pdf(M,srcMom.Mn_gmol); srcCollapse=srcCollapse/trapz(x,srcCollapse);
ms=stageE_distribution_metrics(M,srcMix.dW_dlog10M,srcCollapse);
% Runtime self-test for MATLAB struct-array append semantics. This catches
% schema/initialization defects before the main Stage-E record loops run.
stageE_struct_append_selftest_E(ms,srcMom);
matCollapse=flory_logweight_pdf(M,matrix.Mn_gmol); matCollapse=matCollapse/trapz(x,matCollapse);
mm=stageE_distribution_metrics(M,matrix.dW_dlog10M,matCollapse);
sourceW1=ms.W1_log10M_decades; matrixW1=mm.W1_log10M_decades;

S(1)=metric_struct_E('EX1_CONDITIONED_SOURCE','',0,ms,srcMom.Mn_gmol,srcMom.Mw_gmol,srcMom.D, ...
    srcMom.Mn_gmol,2*srcMom.Mn_gmol,2,1,NaN,'Conditioning state; not external validation.'); %#ok<AGROW>
S(2)=metric_struct_E('MZCR_MATRIX','',0,mm,matrix.Mn_gmol,matrix.Mw_gmol,matrix.D, ...
    matrix.Mn_gmol,2*matrix.Mn_gmol,2,matrixW1/sourceW1,1, ...
    'Two-zone normalized MZCR propagation on Stage-E metric grid.'); %#ok<AGROW>
SourceT=struct2table(S);
writetable(SourceT,fullfile(outdir,'StageE_source_to_MZCR_distribution_retention.csv'));

% Export source/matrix curves on the high-accuracy grid.
Cur0=table(M(:),srcMix.dW_dlog10M(:),srcCollapse(:),matrix.dW_dlog10M(:),matCollapse(:), ...
    'VariableNames',{'M_gmol','EX1_source_resolved','EX1_source_sameMn_singleFlory','MZCR_matrix_resolved','MZCR_matrix_sameMn_singleFlory'});
writetable(Cur0,fullfile(outdir,'StageE_source_matrix_MWD_curves.csv'));

% Rebuild exact Stage-D context for admissible T/sorption/reactivity objects.
ctx=stageD1_build_context(cfg);

% -------------------------------------------------------------------------
% Transparent reference full-distribution cases.
modes={'DIRECT_MN_TRANSFER','DP_REPEAT_MASS_CORRECTED'};
RefRec=struct([]); refCurveData=M(:); refNames={'M_gmol'}; nr=0;
for im=1:numel(modes)
    ref=stageE_reference_state(cfg,ctx,modes{im});
    for ie=1:numel(cfg.StageE.EPC)
        e=cfg.StageE.EPC(ie);
        d=stageE_build_final_distribution(matrix,ref.stage_w,ref.stage_Mn_population_gmol,e,M);
        met=stageE_distribution_metrics(M,d.detailed_pdf,d.collapsed_pdf);
        nr=nr+1;
        note=sprintf('T=%s | sorption=%s | chemistry=%s | r1=%.8g | r2=%.8g | W0 inherited', ...
            ref.TScenario,ref.SorptionScenario,ref.ChemistryScenario,ref.r1,ref.r2);
        rr=metric_struct_E('REFERENCE_FINAL',modes{im},e,met,d.Mn_analytical_gmol,d.Mw_analytical_gmol,d.D_analytical, ...
            d.Mn_collapsed_analytical_gmol,d.Mw_collapsed_analytical_gmol,d.D_collapsed_analytical, ...
            met.W1_log10M_decades/sourceW1,met.W1_log10M_decades/matrixW1,note);
        RefRec=append_struct_record_E(RefRec,rr,'RefRec'); %#ok<AGROW>
        refCurveData=[refCurveData d.detailed_pdf(:) d.collapsed_pdf(:)]; %#ok<AGROW>
        tag=sprintf('%s_EPC_%02d',shortmode_E(modes{im}),round(100*e));
        refNames=[refNames {[tag '_resolved'],[tag '_phasewise_collapsed']}]; %#ok<AGROW>
    end
end
RefT=struct2table(RefRec);
writetable(RefT,fullfile(outdir,'StageE_reference_full_distribution_metrics.csv'));
RefCur=array2table(refCurveData,'VariableNames',matlab.lang.makeValidName(refNames));
writetable(RefCur,fullfile(outdir,'StageE_reference_MWD_curves.csv'));

% -------------------------------------------------------------------------
% Adverse witnesses from the already-qualified B2 structural objective.
[Wit,Reg]=find_stageE_worst_structural_witnesses(cfg,ctx,outdir);
C=site_response_scenarios(5,cfg.site_response.odds_span);
W=population_weight_transfer_scenarios(5,cfg.site_response.odds_span);
WorstRec=struct([]); worstCurveData=M(:); worstNames={'M_gmol'}; nw=0;
for i=1:height(Wit)
    pop=ctx.Tp(Wit.TIndex(i)); s=ctx.Sp(Wit.SorptionIndex(i)); c=C(Wit.ChemistryIndex(i)); wsc=W(Wit.WeightIndex(i));
    st=stage_population_state(pop,s.f1_sorbed,Wit.r1(i),Wit.r2(i),c,Wit.TransferMode{i});
    MnJ=st.MnJ(1,:);
    we=pop.w(:)'.*wsc.yield_multiplier(:)';
    active=we>0 & isfinite(MnJ) & MnJ>0; we(~active)=0; we=we/sum(we);
    e=Wit.EPC_wtfrac(i);
    d=stageE_build_final_distribution(matrix,we,MnJ,e,M);
    met=stageE_distribution_metrics(M,d.detailed_pdf,d.collapsed_pdf);
    nw=nw+1;
    note=sprintf('B2 adverse witness: T=%s | sorption=%s | chemistry=%s | W=%s | r1=%.8g | r2=%.8g', ...
        pop.name,s.name,c.name,wsc.name,Wit.r1(i),Wit.r2(i));
    rr=metric_struct_E('B2_MIN_DELTA_D_WITNESS',Wit.TransferMode{i},e,met,d.Mn_analytical_gmol,d.Mw_analytical_gmol,d.D_analytical, ...
        d.Mn_collapsed_analytical_gmol,d.Mw_collapsed_analytical_gmol,d.D_collapsed_analytical, ...
        met.W1_log10M_decades/sourceW1,met.W1_log10M_decades/matrixW1,note);
    rr.StageB2_MinDeltaD=Wit.MinDeltaD_vs_phasewise_singleFlory(i);
    rr.StageE_HighGrid_DeltaD_Analytical=d.DeltaD_analytical;
    rr.TScenario=pop.name; rr.SorptionScenario=s.name; rr.ChemistryScenario=c.name; rr.WeightScenario=wsc.name;
    rr.r1=Wit.r1(i); rr.r2=Wit.r2(i);
    WorstRec=append_struct_record_E(WorstRec,rr,'WorstRec'); %#ok<AGROW>
    worstCurveData=[worstCurveData d.detailed_pdf(:) d.collapsed_pdf(:)]; %#ok<AGROW>
    tag=sprintf('%s_EPC_%02d',shortmode_E(Wit.TransferMode{i}),round(100*e));
    worstNames=[worstNames {[tag '_resolved'],[tag '_phasewise_collapsed']}]; %#ok<AGROW>
end
WorstT=struct2table(WorstRec);
writetable(WorstT,fullfile(outdir,'StageE_worst_witness_full_distribution_metrics.csv'));
WorstCur=array2table(worstCurveData,'VariableNames',matlab.lang.makeValidName(worstNames));
writetable(WorstCur,fullfile(outdir,'StageE_worst_witness_MWD_curves.csv'));

% -------------------------------------------------------------------------
% Distribution-level H2 trend and external Yang-2026 challenge.
H2T=stageE_h2_distribution_trend(cfg,M);
writetable(H2T,fullfile(outdir,'StageE_H2_distribution_trend.csv'));
qcols={'M10_gmol','M50_gmol','M90_gmol','M99_gmol'};
qdown=true;
for j=1:numel(qcols), qdown=qdown && all(diff(H2T.(qcols{j}))<0); end
Dtrend=sign(H2T.D(end)-H2T.D(1));
Ext=stageE_external_challenge_table_E(qdown,Dtrend);
writetable(Ext,fullfile(outdir,'StageE_Yang2026_external_challenge.csv'));

% Return core objects for executable verification.
result=struct('SourceTable',SourceT,'ReferenceTable',RefT,'WitnessTable',Wit,'WitnessRegression',Reg, ...
    'WorstMetrics',WorstT,'H2Trend',H2T,'ExternalChallenge',Ext,'sourceW1',sourceW1,'matrixW1',matrixW1, ...
    'matrix',matrix,'EX1SourceMoments',srcMom);
end

function r=metric_struct_E(state,mode,e,met,MnA,MwA,DA,MnC,MwC,DC,Rsource,Rmatrix,note)
r=struct('State',state,'TransferMode',mode,'EPC_wtfrac',e, ...
    'W1_log10M_decades',met.W1_log10M_decades,'JS_divergence_bits',met.JS_divergence_bits, ...
    'M10_detailed_gmol',met.M10_detailed,'M50_detailed_gmol',met.M50_detailed,'M90_detailed_gmol',met.M90_detailed,'M99_detailed_gmol',met.M99_detailed, ...
    'M10_collapsed_gmol',met.M10_collapsed,'M50_collapsed_gmol',met.M50_collapsed,'M90_collapsed_gmol',met.M90_collapsed,'M99_collapsed_gmol',met.M99_collapsed, ...
    'M90_over_M10_detailed',met.M90_over_M10_detailed,'M90_over_M10_collapsed',met.M90_over_M10_collapsed, ...
    'TailMassAboveCollapsedM90_detailed',met.TailMassAboveCollapsedM90_detailed, ...
    'TailMassAboveCollapsedM90_collapsed',met.TailMassAboveCollapsedM90_collapsed, ...
    'TailExcessAboveCollapsedM90',met.TailExcessAboveCollapsedM90, ...
    'Mn_analytical_gmol',MnA,'Mw_analytical_gmol',MwA,'D_analytical',DA, ...
    'Mn_collapsed_analytical_gmol',MnC,'Mw_collapsed_analytical_gmol',MwC,'D_collapsed_analytical',DC, ...
    'DeltaD_analytical',DA-DC,'Mn_detailed_numerical_gmol',met.Mn_detailed_numerical, ...
    'Mw_detailed_numerical_gmol',met.Mw_detailed_numerical,'D_detailed_numerical',met.D_detailed_numerical, ...
    'Mn_collapsed_numerical_gmol',met.Mn_collapsed_numerical,'Mw_collapsed_numerical_gmol',met.Mw_collapsed_numerical, ...
    'D_collapsed_numerical',met.D_collapsed_numerical,'DeltaD_numerical',met.DeltaD_numerical, ...
    'W1_ratio_to_EX1_source',Rsource,'W1_ratio_to_MZCR_matrix',Rmatrix,'Note',note);
end

function A=append_struct_record_E(A,r,label)
%APPEND_STRUCT_RECORD_E MATLAB-safe append for dynamically built struct arrays.
% `struct([])` has no fields, so direct subscripted assignment of a populated
% struct can raise "Subscripted assignment between dissimilar structures."
if isempty(A)
    A=r;
    return;
end
if ~isequal(fieldnames(A),fieldnames(r))
    error('StageE:StructSchemaMismatch', ...
        'Stage-E struct schema mismatch while appending %s.',label);
end
A(end+1)=r;
end

function stageE_struct_append_selftest_E(met,mom)
%STAGEE_STRUCT_APPEND_SELFTEST_E Fail fast on record-schema/append regressions.
r=metric_struct_E('STRUCT_APPEND_SELFTEST','SELFTEST',0,met,mom.Mn_gmol,mom.Mw_gmol,mom.D, ...
    mom.Mn_gmol,2*mom.Mn_gmol,2,1,1,'runtime struct append self-test');
A=struct([]);
A=append_struct_record_E(A,r,'SelfTestBase');
A=append_struct_record_E(A,r,'SelfTestBase');
if numel(A)~=2
    error('StageE:StructAppendSelfTestFailed','Base Stage-E struct append self-test failed.');
end
r.StageB2_MinDeltaD=0;
r.StageE_HighGrid_DeltaD_Analytical=0;
r.TScenario='SELFTEST'; r.SorptionScenario='SELFTEST'; r.ChemistryScenario='SELFTEST'; r.WeightScenario='SELFTEST';
r.r1=1; r.r2=1;
B=struct([]);
B=append_struct_record_E(B,r,'SelfTestWitness');
B=append_struct_record_E(B,r,'SelfTestWitness');
if numel(B)~=2
    error('StageE:StructAppendSelfTestFailed','Witness Stage-E struct append self-test failed.');
end
end

function s=shortmode_E(mode)
if strcmpi(mode,'DIRECT_MN_TRANSFER'), s='DIRECT'; else, s='DP'; end
end

function T=stageE_external_challenge_table_E(qdown,Dtrend)
rows=cell(5,6);
rows(1,:)={'Y1_MULTIFLORY_MMD_STRUCTURE','STRUCTURAL_CONSISTENCY', ...
    'Yang et al. 2026 fit industrial ICP GPC MMD using superposed Flory distributions; four populations were selected as the minimum adequate representation versus three.', ...
    'Stage E preserves resolved multi-population MWDs and compares them with phase-wise information-collapsed Flory representations.', ...
    'Qualitative structural comparator only; different catalyst/model/data.', '10.1021/acs.iecr.6c02664'};
if qdown, st='DIRECTIONAL_CONSISTENCY'; else, st='DIRECTIONAL_DIVERGENCE'; end
rows(2,:)={'Y2_H2_FULL_MWD_SHIFT',st, ...
    'Yang et al. 2026 reports that increasing MZCR H2/propylene shifts the final ICP MMD slightly toward lower molar masses.', ...
    'At 70 C and Do/Ti=1.4, Stage-E source-supported H2=0,8,16 psi reconstruction tests monotonic M10/M50/M90/M99 movement.', ...
    'Cross-catalyst directional challenge only; not numerical validation.', '10.1021/acs.iecr.6c02664'};
if Dtrend>0, ds='DIRECTIONAL_CONSISTENCY'; elseif Dtrend<0, ds='CATALYST_DEPENDENT_DIVERGENCE'; else, ds='NO_CHANGE'; end
rows(3,:)={'Y3_H2_DISPERSITY_TREND',ds, ...
    'Yang et al. 2026 reports a slight dispersity increase with increasing MZCR H2/propylene.', ...
    'The Alshaiban-based source reconstruction provides an independent dispersity direction over H2=0,8,16 psi.', ...
    'Opposite direction must be retained as catalyst/model dependence; do not force agreement.', '10.1021/acs.iecr.6c02664'};
rows(4,:)={'Y4_FBR_ETHYLENE_RATIO','NOT_DIRECTLY_TESTABLE', ...
    'Yang et al. 2026 varies FBR ethylene ratio and predicts increases in ICP Mn and mass-average molar mass with a slight dispersity decrease.', ...
    'The present reduced-order framework conditions on EPC fraction and does not propagate FBR ethylene feed through a site-resolved kinetic rate law.', ...
    'No pass/fail validation claim is allowed.', '10.1021/acs.iecr.6c02664'};
rows(5,:)={'Y5_STAGEE_RETENTION_METRIC','NO_DIRECT_YANG_EQUIVALENT', ...
    'Yang et al. 2026 reports MMD curves but does not define the present phase-wise information-collapsed comparator or W1/JS retention metric.', ...
    'Stage-E W1, JS, quantile, and tail-retention metrics are internal structural diagnostics.', ...
    'Do not call these externally validated by Yang et al.', '10.1021/acs.iecr.6c02664'};
T=cell2table(rows,'VariableNames',{'ChallengeID','Status','Yang2026Evidence','PresentModelTest','PermittedInterpretation','DOI'});
end
