function out = stageE1_w1_lower_from_h_bounds(M_gmol,matrixA,hmin,hmax,EPC)
%STAGEE1_W1_LOWER_FROM_H_BOUNDS Lower bound final W1 from pointwise CDF interval.
M=M_gmol(:)'; x=log10(M); A=matrixA(:)'; lo=hmin(:)'; hi=hmax(:)';
if EPC<0 || EPC>=1, error('StageE1:EPC','EPC must lie in [0,1).'); end
Dlo=(1-EPC).*A + EPC.*lo;
Dhi=(1-EPC).*A + EPC.*hi;
if any(Dlo>Dhi+1e-12), error('StageE1:IntervalOrder','Invalid CDF-difference interval.'); end
cross=(Dlo<=0 & Dhi>=0);
absLB=min(abs(Dlo),abs(Dhi)); absLB(cross)=0;
W1lb=trapz(x,absLB);
out=struct('W1_lower_decades',W1lb,'Dlo',Dlo,'Dhi',Dhi,'abs_lower',absLB);
end
