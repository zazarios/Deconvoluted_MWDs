function gas = build_gas_struct(C3,C2,H2,C3H8)
%BUILD_GAS_STRUCT Convenience constructor with normalization check.
gas=struct('C3H6',C3,'C2H4',C2,'H2',H2,'C3H8',C3H8);
s=C3+C2+H2+C3H8;
if abs(s-1)>1e-10, error('Gas fractions sum to %.12g, not 1.',s); end
end
