function S = site_response_scenarios(npop, odds_span)
%SITE_RESPONSE_SCENARIOS Latent population-to-comonomer-response stress ensemble.
% multiplier >1 means greater ethylene/propylene odds at the population level.
% These are model-form stress factors, not catalyst-specific constants.

if nargin<1, npop=5; end
if nargin<2, odds_span=2; end
if npop~=5, error('Current scenario library is defined for five MWD populations.'); end
S=struct('name',{},'class',{},'ethylene_odds_multiplier',{});
S(end+1)=struct('name','C0_homogeneous','class','C0','ethylene_odds_multiplier',ones(1,5));
base=exp(linspace(-log(odds_span),log(odds_span),5));
S(end+1)=struct('name','C1_order_lowMW_to_highMW','class','C1','ethylene_odds_multiplier',base);
S(end+1)=struct('name','C1_order_highMW_to_lowMW','class','C1','ethylene_odds_multiplier',fliplr(base));

% C2: enumerate all unique permutations of two low-response, one neutral,
% two high-response populations. This deliberately avoids choosing a mapping.
v=[1/odds_span 1/odds_span 1 odds_span odds_span];
P=unique(perms(v),'rows');
for k=1:size(P,1)
    S(end+1)=struct('name',sprintf('C2_mixed_%02d',k),'class','C2','ethylene_odds_multiplier',P(k,:)); %#ok<AGROW>
end
end
