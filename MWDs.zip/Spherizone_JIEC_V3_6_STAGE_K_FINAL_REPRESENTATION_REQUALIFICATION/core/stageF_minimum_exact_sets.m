function M = stageF_minimum_exact_sets(T,relTol,absTol)
%STAGEF_MINIMUM_EXACT_SETS Smallest block subsets giving numerical point identification.
if nargin<2, relTol=1e-10; end
if nargin<3, absTol=1e-12; end
e=T.EPC_wtfrac; e(isnan(e))=-1;
keys=cell(height(T),1);
for i=1:height(T), keys{i}=sprintf('%s|%s|%.12g',T.Target{i},T.TransferMode{i},e(i)); end
uk=unique(keys,'stable');
rows={}; n=0;
for k=1:numel(uk)
    idx=find(strcmp(keys,uk{k}));
    base=T.BaselineWidth(idx(1)); tol=max(absTol,relTol*base);
    ok=idx(T.WorstResidualWidth(idx)<=tol);
    if isempty(ok), continue; end
    minCard=min(T.Cardinality(ok)); ok=ok(T.Cardinality(ok)==minCard);
    for j=1:numel(ok)
        i=ok(j); n=n+1;
        rows(n,:)={T.Target{i},T.TransferMode{i},T.EPC_wtfrac(i),minCard,T.ResolvedBlocks{i},T.WorstResidualWidth(i),tol}; %#ok<AGROW>
    end
end
M=cell2table(rows,'VariableNames',{'Target','TransferMode','EPC_wtfrac','MinExactCardinality','ResolvedBlocks','ResidualWidth','Tolerance'});
end
