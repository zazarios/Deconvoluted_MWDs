function S = stageJ_nested_chemistry_scenarios(cfg,maxSpan)
%STAGEJ_NESTED_CHEMISTRY_SCENARIOS Union of all pre-specified spans <= maxSpan.
% Prefixing names preserves provenance. Duplicate numerical C0 states are
% retained deliberately; they do not change extrema/minimax widths.
S=struct('name',{},'class',{},'ethylene_odds_multiplier',{});
for i=1:numel(cfg.StageJ.chemistry_odds_spans)
    span=cfg.StageJ.chemistry_odds_spans(i);
    if span>maxSpan+1e-12, continue; end
    A=site_response_scenarios(5,span);
    for k=1:numel(A)
        A(k).name=sprintf('SPAN_%g__%s',span,A(k).name);
        S(end+1)=A(k); %#ok<AGROW>
    end
end
if isempty(S), error('StageJ:EmptyChemistrySet','No chemistry scenarios at span %g.',maxSpan); end
end
