function P = stageH_generate_partitions(n)
%STAGEH_GENERATE_PARTITIONS Canonical set partitions via restricted-growth strings.
% For n=5 this returns Bell number B5=52 partitions with Stirling counts
% K=1..5: [1 15 25 10 1]. Numerical labels are MWD-population labels only.
if nargin<1, n=5; end
if n~=5
    error('StageH:PartitionN','Stage H is frozen for the five resolved MWD populations.');
end
R=[];
for a2=1:2
 for a3=1:(max([1 a2])+1)
  for a4=1:(max([1 a2 a3])+1)
   for a5=1:(max([1 a2 a3 a4])+1)
    r=[1 a2 a3 a4 a5]; %#ok<AGROW>
    % Restricted-growth condition is enforced by the loop limits.
    R=[R; r]; %#ok<AGROW>
   end
  end
 end
end
% Deduplicate defensively.
R=unique(R,'rows','stable');
P=repmat(struct('RGS',zeros(1,n),'K',0,'Groups',{{}},'Code',''),1,size(R,1));
for i=1:size(R,1)
    r=R(i,:); K=max(r); G=cell(1,K); parts=cell(1,K);
    for g=1:K
        G{g}=find(r==g);
        parts{g}=sprintf('%d-',G{g}); parts{g}=parts{g}(1:end-1);
    end
    P(i).RGS=r; P(i).K=K; P(i).Groups=G; P(i).Code=strjoin(parts,'|');
end
end
