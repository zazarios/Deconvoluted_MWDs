function T = reactivity_feasible_surface(f1_grid,target_C2_wtfrac,r1_bounds,r2_bounds,n_r2,label)
%REACTIVITY_FEASIBLE_SURFACE Set-valued EX2 conditioning over sorption anchor.
% For each sorbed propylene fraction f1, solve the exact Mayo-Lewis relation
% for r1 along a deterministic r2 grid. Retain only points inside the stated
% screening window. No point is treated as a uniquely identified parameter.
if nargin<6, label='screen'; end
Ftarget=propylene_mole_fraction_from_C2wt(target_C2_wtfrac);
r2grid=linspace(r2_bounds(1),r2_bounds(2),n_r2)';
rows={}; n=0;
for jf=1:numel(f1_grid)
    f1=f1_grid(jf); q=1-f1;
    num=f1*q*(1-2*Ftarget) - Ftarget.*r2grid.*q.^2;
    den=f1^2*(Ftarget-1);
    r1=num./den;
    keep=isfinite(r1) & r1>=r1_bounds(1) & r1<=r1_bounds(2);
    rr1=r1(keep); rr2=r2grid(keep);
    if isempty(rr1), continue; end
    Fcalc=mayo_lewis_propylene_fraction(f1,rr1,rr2);
    C2=ethylene_weight_fraction(Fcalc);
    for k=1:numel(rr1)
        n=n+1;
        rows(n,:)={f1,rr1(k),rr2(k),C2(k),label}; %#ok<AGROW>
    end
end
if isempty(rows), error('No feasible EX2 conditioning points inside supplied bounds.'); end
T=cell2table(rows,'VariableNames',{'f1_EX2','r1','r2','C2_wtfrac','Screen'});
end
