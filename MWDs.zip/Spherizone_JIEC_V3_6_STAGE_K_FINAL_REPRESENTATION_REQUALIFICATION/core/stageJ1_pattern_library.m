function P = stageJ1_pattern_library(cfg)
%STAGEJ1_PATTERN_LIBRARY Exchangeable log2-selectivity patterns.
rows=cell(0,8); n=0;
addrow('P0_homogeneous','HOMOGENEOUS',[0 0 0 0 0]);
addrow('P1_lowMW_to_highMW','ORDERED',cfg.StageJ1.pattern_monotone_exponents);
addrow('P1_highMW_to_lowMW','ORDERED',fliplr(cfg.StageJ1.pattern_monotone_exponents));
Q=unique(perms(cfg.StageJ1.pattern_mixed_exponents),'rows');
for k=1:size(Q,1), addrow(sprintf('P2_mixed_%02d',k),'EXCHANGEABLE_MIXED',Q(k,:)); end
P=cell2table(rows,'VariableNames',{'PatternID','PatternClass','d1','d2','d3','d4','d5','RawContrast'});
 function addrow(id,cl,d)
  n=n+1; rows(n,:)={id,cl,d(1),d(2),d(3),d(4),d(5),2^(max(d)-min(d))}; %#ok<AGROW>
 end
end
