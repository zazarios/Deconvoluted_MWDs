function red = stageH_reduce_partition(w,Mn_gmol,groups)
%STAGEH_REDUCE_PARTITION Merge MWD populations while preserving mass and Mn.
% For group G: W_G=sum_j w_j and 1/Mn_G=sum_j (w_j/W_G)/Mn_j.
w=w(:)'; Mn=Mn_gmol(:)';
if numel(w)~=numel(Mn), error('StageH:ReduceSize','Weight/Mn size mismatch.'); end
active=w>0;
if any(~isfinite(Mn(active)) | Mn(active)<=0), error('StageH:ReduceMn','Active populations require finite positive Mn.'); end
if any(w<-1e-14) || sum(w)<=0, error('StageH:ReduceWeight','Invalid population weights.'); end
w=max(w,0); w=w/sum(w);
K=numel(groups); W=zeros(1,K); Mg=nan(1,K);
for g=1:K
    idx=groups{g}; W(g)=sum(w(idx));
    if W(g)>0
        wi=w(idx)/W(g); Mi=Mn(idx);
        ai=wi>0;
        Mg(g)=1/sum(wi(ai)./Mi(ai));
    end
end
use=W>0; W=W(use); Mg=Mg(use); G=groups(use);
red=struct('w',W,'Mn_gmol',Mg,'Groups',{G}, ...
    'Mn_original_gmol',1/sum(w(active)./Mn(active)), ...
    'Mn_reduced_gmol',1/sum(W./Mg));
end
