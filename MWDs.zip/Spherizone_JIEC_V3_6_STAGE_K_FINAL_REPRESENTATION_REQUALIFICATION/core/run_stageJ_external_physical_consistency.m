function result = run_stageJ_external_physical_consistency(cfg,outdir)
%RUN_STAGEJ_EXTERNAL_PHYSICAL_CONSISTENCY Prospective external challenge.
% No external datum is fitted. Stage J challenges the legacy FBR-H2 and
% high-E/P composition assumptions, reclassifies affected Stage-F/D.1 claims,
% and tests whether the certified Stage-G full-MWD separation survives an
% expanded literature-motivated H2/T80 branch set.
if ~exist(outdir,'dir'), mkdir(outdir); end
ROOT=fileparts(fileparts(mfilename('fullpath')));

Evidence=stageJ_external_evidence_registry();
writetable(Evidence,fullfile(outdir,'StageJ_external_evidence_registry.csv'));

Tset=stageJ_build_T80_challenge_set(cfg);
% Compact T80 audit table.
tr=cell(numel(Tset),12);
for k=1:numel(Tset)
    pm=population_moments(Tset(k));
    tr(k,:)={Tset(k).H2Branch,Tset(k).H2Role,Tset(k).H2_molfrac,Tset(k).H2_psi,Tset(k).base_name,Tset(k).name, ...
        Tset(k).admissibility,Tset(k).source_pair,pm.Mn_gmol,pm.Mw_gmol,pm.D,sum(Tset(k).w)};
end
T80Audit=cell2table(tr,'VariableNames',{'H2Branch','H2Role','H2_molfrac','H2_psi','TBaseScenario','TScenario','TAdmissibility','SourcePair', ...
    'Stage_Mn_gmol','Stage_Mw_gmol','Stage_D','WeightSum'});
writetable(T80Audit,fullfile(outdir,'StageJ_T80_H2_challenge_scenarios.csv'));

Sp=stageJ_primary_sorption_set(cfg);
[Ranges,Witnesses,surf]=stageJ_composition_ranges(cfg,Tset,Sp);
writetable(Ranges,fullfile(outdir,'StageJ_composition_ranges_by_span.csv'));
writetable(Witnesses,fullfile(outdir,'StageJ_composition_range_witnesses.csv'));

[StageCoverage,BulkCoverage,Thresholds]=stageJ_external_coverage(cfg,Ranges,Evidence);
writetable(StageCoverage,fullfile(outdir,'StageJ_external_stage_composition_coverage.csv'));
writetable(BulkCoverage,fullfile(outdir,'StageJ_Cancelas_bulk_C2_challenge.csv'));
writetable(Thresholds,fullfile(outdir,'StageJ_chemistry_span_thresholds.csv'));

[VOIBase,VOISingleton]=stageJ_composition_voi_by_span(cfg,Tset,Sp,surf);
writetable(VOIBase,fullfile(outdir,'StageJ_composition_VOI_baseline_by_span.csv'));
writetable(VOISingleton,fullfile(outdir,'StageJ_composition_VOI_singletons_by_span.csv'));

[W1ByT,W1Summary,W1Closure]=stageJ_joint_w1_H2_challenge(cfg,Tset);
writetable(W1ByT,fullfile(outdir,'StageJ_joint_W1_bounds_by_H2_T.csv'));
writetable(W1Summary,fullfile(outdir,'StageJ_joint_W1_bounds_summary.csv'));
writetable(W1Closure,fullfile(outdir,'StageJ_structural_survival.csv'));

% Baseline regression against frozen Stage F/G outputs.
Fbase=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageFQualifiedOutputs','StageF_baseline_target_ranges.csv'));
q=strcmp(Fbase.Target,'StageC2_wtfrac'); oldC2=Fbase(q,:);
rLegacy=Ranges(Ranges.ChemistryOddsSpan==cfg.site_response.odds_span & strcmp(Ranges.H2BranchScope,'LEGACY_5MOL_H2'),:);
if height(oldC2)~=1 || height(rLegacy)~=1, error('StageJ:LegacyCompositionBaselineMissing','Legacy Stage-F composition baseline unavailable.'); end
Gbase=stageJ_read_csv_strict(fullfile(ROOT,'inputs','StageGQualifiedOutputs','StageG_structural_claim_closure.csv'));
GbaseW1=stageJ_table_column(Gbase,'Global_W1_certified_joint_lower_decades');
if isempty(GbaseW1), error('StageJ:FrozenStageGBaselineMissing','Frozen Stage-G W1 baseline unavailable.'); end
GbaseW1=GbaseW1(1);
cLegacy=W1Closure(strcmp(W1Closure.H2BranchScope,'LEGACY_5MOL_H2'),:);
BaselineRegression=table(oldC2.Min,oldC2.Max,rLegacy.StageC2Min,rLegacy.StageC2Max, ...
    abs(oldC2.Min-rLegacy.StageC2Min),abs(oldC2.Max-rLegacy.StageC2Max), ...
    GbaseW1,cLegacy.Global_W1_certified_joint_lower_decades, ...
    abs(GbaseW1-cLegacy.Global_W1_certified_joint_lower_decades), ...
    'VariableNames',{'FrozenStageF_C2Min','FrozenStageF_C2Max','StageJLegacy_C2Min','StageJLegacy_C2Max','C2MinAbsDiff','C2MaxAbsDiff', ...
    'FrozenStageG_W1Lower','StageJLegacy_W1Lower','W1AbsDiff'});
writetable(BaselineRegression,fullfile(outdir,'StageJ_frozen_baseline_regression.csv'));

% Reclassify legacy claims rather than silently overwriting them.
r2u=Ranges(Ranges.ChemistryOddsSpan==cfg.site_response.odds_span & strcmp(Ranges.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);
oldDomainCovers = height(r2u)==1 && r2u.ContainsExternalEnvelope;
b2=BulkCoverage(BulkCoverage.ChemistryOddsSpan==cfg.site_response.odds_span,:);
oldBulkCovers = ~isempty(b2) && all(b2.ExternalPointCovered);
unionC=W1Closure(strcmp(W1Closure.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);
structuralSurvives=height(unionC)==1 && unionC.Global_W1_certified_joint_lower_decades>cfg.StageJ.w1_positive_tol;
Claim={'StageF_second_stage_C2_interval';'StageD1_C2_critical_rho';'StageF_composition_VOI_ranking';'StageG_positive_joint_W1';'StageH_to_H2_orders_under_expanded_H2';'Matched_industrial_Spherizone_validation'};
if oldDomainCovers && oldBulkCovers, cstat='EXTERNALLY_CHALLENGE_COMPATIBLE_WITHIN_STAGEJ_PROXY_TESTS'; else, cstat='CONDITIONAL_ON_EXTERNALLY_UNDERCOVERING_HIGH_EP_CHEMISTRY_DOMAIN'; end
Status={cstat;cstat;cstat;tern(structuralSurvives,'SURVIVES_STAGEJ_H2_T80_CHALLENGE','DOES_NOT_SURVIVE_STAGEJ_H2_T80_CHALLENGE'); ...
    'NOT_REQUALIFIED_IN_STAGE_J__REQUIRES_EXPANDED_T80_SUPPORT_RERUN';'NOT_ESTABLISHED'};
Meaning={ ...
    'The frozen 0.01999-0.06929 second-stage C2 interval remains mathematically valid only for the old prescribed chemistry domain; Stage J tests external coverage.'; ...
    'The frozen rho_C threshold is relative to odds-span=2 and cannot be treated as final if that chemistry domain undercovers external hiPP composition.'; ...
    'The frozen singleton contraction percentages are conditional on the old chemistry/H2 domain; Stage-J span-specific finite-ensemble VOI rows are diagnostic requalifications.'; ...
    'Stage G is re-evaluated over the union of no-added-H2, 2 mol% H2 stress, and legacy 5 mol% H2 T80 branches.'; ...
    'H/H.1/H.2 use fixed T80 supports and are not silently updated by Stage J.'; ...
    'External data are different catalyst/process datasets and are challenge/comparator evidence, not matched validation.'};
LegacyClaims=table(Claim,Status,Meaning,'VariableNames',{'Claim','Status','Meaning'}); writetable(LegacyClaims,fullfile(outdir,'StageJ_legacy_claim_requalification.csv'));

Claim2={'EXTERNAL_DATA_USED_FOR_PARAMETER_FITTING';'NO_ADDED_H2_EQUALS_ZERO_RESIDUAL_H2';'RUBBER_RICH_C2_EQUALS_ALL_SECOND_STAGE_POLYMER_C2'; ...
    'CANCELAS_BULK_POINTS_ARE_MATCHED_VALIDATION';'STAGEG_DP_REPEAT_MASS_SUPPORT_COVERS_ANY_EP_REPEAT_MASS';'STRUCTURAL_W1_SURVIVES_EXPANDED_H2_T80_SET'};
Status2={'PROHIBITED_AND_NOT_DONE';'NOT_ESTABLISHED';'NOT_ESTABLISHED';'NOT_ESTABLISHED';'ESTABLISHED_BY_CONSTRUCTION';tern(structuralSurvives,'ESTABLISHED_WITHIN_STAGEJ_H2_BRANCH_SET','NOT_ESTABLISHED')};
Meaning2={ ...
    'All external observations are held out as challenge evidence.'; ...
    'Yang reports no hydrogen addition to the FBR; residual carryover concentration is not identified.'; ...
    'Soluble/rubber-rich fractions are physically relevant proxies but not definitionally identical to all polymer formed in the modeled second stage.'; ...
    'Nominal EPC matches for 10/20/30 wt% improve comparability but catalyst/process conditions remain unmatched.'; ...
    sprintf('Stage-G DP alpha_j already spans M2/M3=%.6f to 1 independently for every population.',cfg.StageG.M2_gmol/cfg.StageG.M3_gmol); ...
    'Stage-J W1 closure is a deterministic structural challenge result, not industrial validation.'};
ClaimScope=table(Claim2,Status2,Meaning2,'VariableNames',{'Claim','Status','Meaning'}); writetable(ClaimScope,fullfile(outdir,'StageJ_claim_scope.csv'));

result=struct('Evidence',Evidence,'T80Audit',T80Audit,'Ranges',Ranges,'Witnesses',Witnesses,'StageCoverage',StageCoverage, ...
    'BulkCoverage',BulkCoverage,'Thresholds',Thresholds,'VOIBase',VOIBase,'VOISingleton',VOISingleton,'W1ByT',W1ByT,'W1Summary',W1Summary, ...
    'W1Closure',W1Closure,'BaselineRegression',BaselineRegression,'LegacyClaims',LegacyClaims,'ClaimScope',ClaimScope, ...
    'StructuralSurvives',structuralSurvives,'OldCompositionDomainCovers',oldDomainCovers && oldBulkCovers);
end

function y=tern(c,a,b)
if c, y=a; else, y=b; end
end
