function T = run_uncertainty_ensemble(matrix, cfg, rcurve)
%RUN_UNCERTAINTY_ENSEMBLE Deterministic scalar scenario enumeration.
% This is a Stage-A engine; final admissible scenario pruning occurs only
% after qualification and source-domain review.

T80=population_T80_envelope(cfg.FBR.H2_psi,cfg.MZCR.DoTi);
sorb=thermo_fbr_scenarios(cfg.FBR.gas);
resp=site_response_scenarios(5,cfg.site_response.odds_span);
rtd=rtd_ensemble(cfg);
% Thin the exact r-curve deterministically for combinatorial diagnostics.
if height(rcurve)>9
    idx=unique(round(linspace(1,height(rcurve),9)));
    rcurve=rcurve(idx,:);
end
rows={}; n=0;
for it=1:numel(T80)
 for ir=1:height(rcurve)
  for is=1:numel(sorb)
   for ic=1:numel(resp)
    for ie=1:numel(cfg.FBR.EPC_wtfrac)
     p=fbr_conditional_property(matrix,T80(it),cfg.FBR.EPC_wtfrac(ie), ...
        sorb(is).f1_sorbed,rcurve.r1(ir),rcurve.r2(ir),resp(ic),matrix.M_gmol);
     for id=1:numel(rtd)
      n=n+1;
      rows(n,:)={T80(it).name,rcurve.r1(ir),rcurve.r2(ir),sorb(is).name, ...
          resp(ic).name,rtd(id).name,cfg.FBR.EPC_wtfrac(ie),p.Mn_gmol,p.Mw_gmol,p.D,p.stage_C2_wtfrac,p.total_C2_wtfrac}; %#ok<AGROW>
     end
    end
   end
  end
 end
end
T=cell2table(rows,'VariableNames',{'TScenario','r1','r2','SorptionScenario','ChemistryScenario','RTDScenario','EPC_wtfrac','Mn_gmol','Mw_gmol','D','Stage_C2_wtfrac','Total_C2_wtfrac'});
end
