function result=run_stageH1_fixed_descriptor_closure(cfg,outdir)
%RUN_STAGEH1_FIXED_DESCRIPTOR_CLOSURE Target-aware state-independent closure.
if ~exist(outdir,'dir'),mkdir(outdir);end
ROOT=fileparts(fileparts(mfilename('fullpath')));
ctx=stageD1_build_context(cfg); P=stageH_generate_partitions(5);
Tm=readtable(fullfile(ROOT,'inputs','StageFQualifiedOutputs','StageF_matrix_moment_consistency.csv'));
matrixMn=Tm.StageF_Mn_gmol(1); matrixMw=Tm.StageF_Mw_gmol(1);
Te=readtable(fullfile(ROOT,'inputs','StageEQualifiedOutputs','StageE_source_to_MZCR_distribution_retention.csv'));
ir=find(strcmp(Te.State,'MZCR_MATRIX'),1); M90=Te.M90_detailed_gmol(ir); M99=Te.M99_detailed_gmol(ir);
Targets={'FINAL_Mn_REL','FINAL_Mw_REL','FINAL_D_REL','FINAL_W1_LOG10M','TAIL_MASS_AT_MATRIX_M90_ABS','TAIL_MASS_AT_MATRIX_M99_ABS'};
Desc=struct([]); Part=struct([]); modes=ctx.modes;
for ip=1:numel(P)
  part=P(ip);
  for ie=1:numel(cfg.StageH1.EPC)
    e=cfg.StageH1.EPC(ie);
    L=zeros(1,numel(Targets)); U=zeros(1,numel(Targets));
    for it=1:numel(ctx.Tp)
      Mn=ctx.Tp(it).Mn_gmol;
      for im=1:numel(modes)
        mode=modes{im};
        % For D, collect signed vertex ratios across all groups for a safe
        % partition-level upper bound.
        d_rmw=[]; d_rmn=[]; d_lower=0;
        for iy=1:numel(Targets)
          target=Targets{iy};
          localL=0;localU=0;
          for ig=1:numel(part.Groups)
            g=part.Groups{ig}; d=stageH1_group_minimax_descriptor(target,Mn,g,mode,e,matrixMn,matrixMw,M90,M99,cfg);
            Desc=append_H1(Desc,struct('PartitionCode',part.Code,'K',part.K,'GroupCode',groupcode_H1(g), ...
              'Target',target,'EPC_wtfrac',e,'TScenario',ctx.Tp(it).name,'TransferMode',mode, ...
              'Mhat_gmol',d.Mhat_gmol,'Support_Mlo_gmol',d.Mlo_gmol,'Support_Mhi_gmol',d.Mhi_gmol, ...
              'GroupLower',d.GroupLower,'GroupUpper',d.GroupUpper,'DescriptorRule','TARGET_MINIMAX_FIXED_SCALAR','HiddenStateAccess','NONE')); %#ok<AGROW>
            localL=max(localL,d.GroupLower); localU=max(localU,d.GroupUpper);
            if strcmp(target,'FINAL_D_REL')
              A=(1-e)/matrixMn;B=(1-e)*matrixMw;a0=cfg.StageH1.M2_gmol/cfg.StageH1.M3_gmol;
              for jj=g
                if strcmpi(mode,'DIRECT_MN_TRANSFER'), mm=Mn(jj); else, mm=[a0*Mn(jj),Mn(jj)]; end
                for q=1:numel(mm)
                  m=mm(q); d_rmw(end+1)=(B+2*e*d.Mhat_gmol)/(B+2*e*m); %#ok<AGROW>
                  d_rmn(end+1)=(A+e/m)/(A+e/d.Mhat_gmol); %#ok<AGROW>
                end
              end
              d_lower=max(d_lower,d.GroupLower);
            end
          end
          if strcmp(target,'FINAL_D_REL')
            % overwritten after all groups have been visited below
          else
            L(iy)=max(L(iy),localL);U(iy)=max(U(iy),localU);
          end
        end
        if ~isempty(d_rmw)
          dl=max(d_lower,0);
          du=max(abs(min(d_rmw)/max(d_rmn)-1),abs(max(d_rmw)/min(d_rmn)-1));
          iy=find(strcmp(Targets,'FINAL_D_REL'));L(iy)=max(L(iy),dl);U(iy)=max(U(iy),du);
        end
      end
    end
    Part=append_H1(Part,struct('PartitionCode',part.Code,'K',part.K,'EPC_wtfrac',e, ...
      'MnRel_lower',L(1),'MnRel_upper',U(1),'MwRel_lower',L(2),'MwRel_upper',U(2), ...
      'DRel_lower',L(3),'DRel_upper',U(3),'W1_lower_decades',L(4),'W1_upper_decades',U(4), ...
      'Tail90_lower_abs',L(5),'Tail90_upper_abs',U(5),'Tail99_lower_abs',L(6),'Tail99_upper_abs',U(6))); %#ok<AGROW>
  end
end
DescTable=struct2table(Desc); PartTable=struct2table(Part);
writetable(DescTable,fullfile(outdir,'StageH1_fixed_group_descriptors.csv'));
writetable(PartTable,fullfile(outdir,'StageH1_all_partition_closure_bounds.csv'));
Cols={{'MnRel_lower','MnRel_upper'},{'MwRel_lower','MwRel_upper'},{'DRel_lower','DRel_upper'},{'W1_lower_decades','W1_upper_decades'},{'Tail90_lower_abs','Tail90_upper_abs'},{'Tail99_lower_abs','Tail99_upper_abs'}};
Sum=struct([]);
for ie=1:numel(cfg.StageH1.EPC)
 e=cfg.StageH1.EPC(ie);
 for iy=1:numel(Targets)
  for K=1:5
   ix=PartTable.K==K & abs(PartTable.EPC_wtfrac-e)<1e-12; idx=find(ix);
   lo=PartTable.(Cols{iy}{1})(ix);up=PartTable.(Cols{iy}{2})(ix);[vl,il]=min(lo);[vu,iu]=min(up);
   Sum=append_H1(Sum,struct('Target',Targets{iy},'EPC_wtfrac',e,'K',K,'MinimaxLower',vl,'MinimaxUpper',vu, ...
    'BestPartitionLower',PartTable.PartitionCode{idx(il)},'BestPartitionUpper',PartTable.PartitionCode{idx(iu)},'BoundWidth',max(0,vu-vl))); %#ok<AGROW>
  end
 end
end
Summary=struct2table(Sum);writetable(Summary,fullfile(outdir,'StageH1_target_minimax_summary.csv'));
% Fixed tolerance map. Unlike Stage H, no K is forced when K=5 fails.
Ord=struct([]);
for ie=1:numel(cfg.StageH1.EPC)
 e=cfg.StageH1.EPC(ie);
 for iy=1:numel(Targets)
  [tols,labels,unit]=tolset_H1(Targets{iy},cfg);
  ix=strcmp(Summary.Target,Targets{iy}) & abs(Summary.EPC_wtfrac-e)<1e-12;S=Summary(ix,:);[~,o]=sort(S.K);S=S(o,:);
  for itol=1:numel(tols)
   tol=tols(itol);kp=find(S.MinimaxLower<=tol+1e-15,1);ks=find(S.MinimaxUpper<=tol+1e-15,1);
   if isempty(kp), kp=NaN; end; if isempty(ks),ks=NaN;end
   if isnan(kp),status='NO_FIXED_SCALAR_CLOSURE_EVEN_POSSIBLE';
   elseif isnan(ks),status='NO_CERTIFIED_FIXED_SCALAR_CLOSURE';
   elseif kp==ks,status='CERTIFIED_FIXED_SCALAR_KSTAR';else,status='FIXED_SCALAR_KSTAR_BRACKETED';end
   Ord=append_H1(Ord,struct('Target',Targets{iy},'EPC_wtfrac',e,'ToleranceLabel',labels{itol},'Tolerance',tol,'ToleranceUnit',unit, ...
    'K_fixed_possible_lower',kp,'K_fixed_certified_sufficient',ks,'FixedClosureStatus',status)); %#ok<AGROW>
  end
 end
end
OrderMap=struct2table(Ord);writetable(OrderMap,fullfile(outdir,'StageH1_target_order_map.csv'));
% Compare against qualified Stage-H oracle projection order.
OH=readtable(fullfile(ROOT,'inputs','StageHQualifiedOutputs','StageH_target_order_map.csv'));Gap=struct([]);
for r=1:height(OrderMap)
 ix=strcmp(OH.Target,OrderMap.Target{r}) & abs(OH.EPC_wtfrac-OrderMap.EPC_wtfrac(r))<1e-12 & strcmp(OH.ToleranceLabel,OrderMap.ToleranceLabel{r});
 if sum(ix)~=1,error('StageH1:OracleMap','Stage-H oracle row mismatch.');end
 ko=OH.K_projection_certified_sufficient(ix); kf=OrderMap.K_fixed_certified_sufficient(r);
 if isnan(kf),delta=NaN;cls='NO_FIXED_SCALAR_CLOSURE';elseif kf==ko,delta=0;cls='SAME_ORDER';elseif kf>ko,delta=kf-ko;cls='HIGHER_FIXED_TARGET_ORDER';else,delta=kf-ko;cls='LOWER_TARGET_SPECIFIC_FIXED_ORDER__CROSS_TARGET_FIDELITY_NOT_PRESERVED';end
 Gap=append_H1(Gap,struct('Target',OrderMap.Target{r},'EPC_wtfrac',OrderMap.EPC_wtfrac(r),'ToleranceLabel',OrderMap.ToleranceLabel{r}, ...
  'K_oracle_certified',ko,'K_fixed_certified',kf,'DeltaK_fixed_minus_oracle',delta,'ClosureComparison',cls)); %#ok<AGROW>
end
GapTable=struct2table(Gap);writetable(GapTable,fullfile(outdir,'StageH1_oracle_to_fixed_closure_gap.csv'));
Metric={'FINAL_Mn_REL';'FINAL_Mw_REL';'FINAL_D_REL';'FINAL_W1_LOG10M';'TAIL_MASS_AT_MATRIX_M90_ABS';'TAIL_MASS_AT_MATRIX_M99_ABS'};
Status={'EXACT_FIXED_SCALAR_MINIMAX';'EXACT_FIXED_SCALAR_MINIMAX';'WITNESS_TO_CONSERVATIVE_RATIO_BOUND';'EXACT_FIXED_SCALAR_MINIMAX';'EXACT_FIXED_SCALAR_MINIMAX';'EXACT_FIXED_SCALAR_MINIMAX'};
Meaning={'Fixed descriptor cannot use hidden reciprocal-Mn state.';'Fixed descriptor cannot use hidden population Mn/alpha state.';'D is nonseparable under mixtures; lower/upper are reported.';'Scale-family W1 minimax with fixed group descriptor.';'Fixed threshold tail-mass minimax.';'Fixed threshold tail-mass minimax.'};
Scope=table(Metric,Status,Meaning);writetable(Scope,fullfile(outdir,'StageH1_metric_scope.csv'));
Claim={'TARGET_SPECIFIC_FIXED_SCALAR_ORDER';'T80_GLOBAL_FIXED_DESCRIPTOR_CLOSURE';'ONE_UNIFIED_REDUCED_MODEL_FOR_ALL_TARGETS';'POPULATION_SPECIFIC_CHEMISTRY_IDENTIFIED';'GROUP_WEIGHT_DYNAMICS_CLOSED';'INDUSTRIAL_ICP_VALIDATION'};
ClaimStatus={'ALLOWED_WITH_TOLERANCE_AND_T80_BRANCH_CONDITIONING';'NOT_ESTABLISHED';'NOT_ESTABLISHED';'NOT_ESTABLISHED';'NOT_ESTABLISHED';'NOT_ESTABLISHED'};
ClaimMeaning={'Each target may use its own fixed minimax descriptor set and partition conditional on the declared T80 branch and transfer formulation.';'H.1 does not construct one fixed descriptor set that is invariant across the T80 model-form branches.';'Target-specific descriptors can trade fidelity in other outputs; H.1 does not certify one universal reduced model.';'Residual DP alpha uncertainty is deliberately unresolved.';'Group total weights remain set-valued within the inherited uncertainty framework.';'No matched ICP experiment is introduced.'};
ClaimScope=table(Claim,ClaimStatus,ClaimMeaning);writetable(ClaimScope,fullfile(outdir,'StageH1_claim_scope.csv'));
result=struct('Partitions',P,'Descriptors',DescTable,'PartTable',PartTable,'Summary',Summary,'OrderMap',OrderMap,'GapTable',GapTable,'MetricScope',Scope,'ClaimScope',ClaimScope,'ctx',ctx,'matrixMn',matrixMn,'matrixMw',matrixMw,'M90',M90,'M99',M99);
end
function A=append_H1(A,r)
if isempty(A),A=r;return;end
if ~isequal(fieldnames(A),fieldnames(r)),error('StageH1:StructSchema','Record schema mismatch.');end
A(end+1)=r;
end
function s=groupcode_H1(g)
s=sprintf('%d-',g);s=s(1:end-1);
end
function [tols,labels,unit]=tolset_H1(target,cfg)
labels=cfg.StageH1.tolerance_labels;
if strcmp(target,'FINAL_W1_LOG10M'),tols=cfg.StageH1.W1_tolerances_decades;unit='decades';
elseif contains(target,'TAIL_MASS'),tols=cfg.StageH1.tail_mass_abs_tolerances;unit='absolute_mass_fraction';
else,tols=cfg.StageH1.scalar_rel_tolerances;unit='relative_fraction';end
end
