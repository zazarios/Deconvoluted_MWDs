function out = run_normalized_mzcr_demo(cfg)
%RUN_NORMALIZED_MZCR_DEMO Two-zone normalized-property MZCR demonstration.
% This is a structural qualification case, not an industrial throughput result.

ex1=condition_ex1_h2(cfg);
xH2=ex1.H2_psi/(cfg.MZCR.P_bar*14.5037738);
xPropane=0.20;
xC3=1-xH2-xPropane;
gas=build_gas_struct(xC3,0,xH2,xPropane);

mfeed=cfg.MZCR.normalized.mcat_feed_gph;
Rp=cfg.MZCR.normalized.Rp_sp_g_gcat_h;

R=cfg.MZCR.riser; VR=R.L_m*R.A_m2; invR=mfeed*R.tau_h;
pr=struct('T_C',cfg.MZCR.T_C,'P_bar',cfg.MZCR.P_bar,'DoTi',cfg.MZCR.DoTi, ...
    'L_m',R.L_m,'A_m2',R.A_m2,'u_g_m_s',R.u_g_m_s,'rho_cat_bed_g_m3',invR/VR, ...
    'Rp_sp_g_gcat_h',Rp,'gas_in',gas,'mode','homo','r1',NaN,'r2',NaN,'n_eval',161);
D=cfg.MZCR.downer; VD=D.L_m*D.A_m2; invD=mfeed*D.tau_h;
pd=struct('T_C',cfg.MZCR.T_C,'P_bar',cfg.MZCR.P_bar,'DoTi',cfg.MZCR.DoTi, ...
    'L_m',D.L_m,'A_m2',D.A_m2,'u_g_m_s',D.u_g_m_s,'rho_cat_bed_g_m3',invD/VD, ...
    'Rp_sp_g_gcat_h',Rp,'gas_in',gas,'mode','homo','r1',NaN,'r2',NaN,'n_eval',161);

zr=mzcr_zone_pfr(pr); zd=mzcr_zone_pfr(pd);
ir=integrate_zone_properties(zr,cfg.M_output_grid);
id=integrate_zone_properties(zd,cfg.M_output_grid);
comb=combine_mzcr_zones(ir,id);
out=struct('EX1_conditioning',ex1,'riser_zone',zr,'downer_zone',zd,'riser_product',ir,'downer_product',id,'matrix',comb);
end
