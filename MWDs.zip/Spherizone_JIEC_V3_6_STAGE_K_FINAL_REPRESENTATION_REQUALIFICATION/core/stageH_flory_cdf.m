function F = stageH_flory_cdf(M_gmol,s_per_gmol)
%STAGEH_FLORY_CDF Weight CDF Q=1-exp(-Ms)(1+Ms), s=1/Mn.
M=M_gmol; s=s_per_gmol;
u=M.*s;
F=-expm1(-u)-u.*exp(-u);
F(u>745)=1;
F=max(0,min(1,F));
end
