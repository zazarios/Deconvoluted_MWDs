function wC2 = ethylene_weight_fraction(F1)
%ETHYLENE_WEIGHT_FRACTION Convert polymer propylene mole fraction to ethylene wt fraction.
M3=42.08; M2=28.05;
wC2=(1-F1).*M2 ./ (F1.*M3 + (1-F1).*M2);
end
