function out = final_blend_moments(matrixMn,matrixMw,stageMn,stageMw,EPC)
%FINAL_BLEND_MOMENTS Exact weight-blend moments of normalized MWDs.
if EPC<=0 || EPC>=1, error('EPC must be in (0,1).'); end
Mn=1/((1-EPC)/matrixMn + EPC/stageMn);
Mw=(1-EPC)*matrixMw + EPC*stageMw;
out=struct('Mn_gmol',Mn,'Mw_gmol',Mw,'D',Mw/Mn);
end
