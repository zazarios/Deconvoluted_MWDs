function Sp = stageJ_primary_sorption_set(cfg)
%STAGEJ_PRIMARY_SORPTION_SET Reuse qualified primary FBR sorption stress set.
S=thermo_fbr_scenarios(cfg.FBR.gas);
keep=false(1,numel(S));
for k=1:numel(S), keep(k)=any(strcmp(S(k).name,cfg.StageJ.primary_sorption_names)); end
Sp=S(keep);
if numel(Sp)~=numel(cfg.StageJ.primary_sorption_names)
    error('StageJ:SorptionScenarioMismatch','Primary FBR sorption scenario mismatch.');
end
end
