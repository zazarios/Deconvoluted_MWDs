function F = stageE1_numerical_cdf(M_gmol,pdf)
%STAGEE1_NUMERICAL_CDF Normalized CDF on the Stage-E log10(M) grid.
M=M_gmol(:)'; x=log10(M); p=pdf(:)';
if numel(M)~=numel(p), error('StageE1:CDFGridMismatch','CDF grid mismatch.'); end
Z=trapz(x,p);
if ~(isfinite(Z) && Z>0), error('StageE1:CDFNormalization','Non-positive CDF normalization.'); end
p=p/Z;
F=cumtrapz(x,p);
if F(end)<=0, error('StageE1:CDFNormalization','CDF endpoint is non-positive.'); end
F=F/F(end);
F=max(0,min(1,F));
end
