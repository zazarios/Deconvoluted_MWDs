function [Summary,ConditionContrast] = stageJ1_derive_chemistry_support(cfg,E)
%STAGEJ1_DERIVE_CHEMISTRY_SUPPORT Derive outward-rounded high-E/P support.
obsMin=min(E.kpE_over_kpP); obsMax=max(E.kpE_over_kpP);
Donors=unique(E.Donor,'stable'); Feeds=unique(E.E_feed_fraction,'stable');
rows=cell(0,5); maxContrast=0;
for i=1:numel(Donors)
 for j=1:numel(Feeds)
  q=strcmp(E.Donor,Donors{i}) & abs(E.E_feed_fraction-Feeds(j))<1e-12;
  if ~any(q), continue; end
  v=E.kpE_over_kpP(q); c=max(v)/min(v); maxContrast=max(maxContrast,c);
  rows(end+1,:)={Donors{i},Feeds(j),min(v),max(v),c}; %#ok<AGROW>
 end
end
ConditionContrast=cell2table(rows,'VariableNames',{'Donor','E_feed_fraction','ObservedMinRatio','ObservedMaxRatio','WithinConditionContrast'});
lo=cfg.StageJ1.kappa_support(1); hi=cfg.StageJ1.kappa_support(2); cap=cfg.StageJ1.max_population_contrast;
Summary=table(cfg.StageJ1.nominal_FBR_reactive_E_fraction,min(cfg.StageJ1.source_feed_E_fraction),max(cfg.StageJ1.source_feed_E_fraction), ...
    obsMin,obsMax,maxContrast,lo,hi,cap, ...
    lo<=obsMin && hi>=obsMax && cap>=maxContrast, ...
    {'OUTWARD_ROUNDED_MODEL_FORM_SUPPORT_NOT_TRANSFERRED_KINETIC_CONSTANTS'}, ...
    'VariableNames',{'NominalFBRReactiveE_fraction','SourceFeedE_Min','SourceFeedE_Max','Observed_kpE_over_kpP_Min','Observed_kpE_over_kpP_Max', ...
    'ObservedMaxWithinConditionContrast','KappaSupportMin','KappaSupportMax','KappaMaxPopulationContrast','OutwardContainmentPass','Status'});
end
