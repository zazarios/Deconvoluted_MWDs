function F = stageE1_flory_weight_cdf_exact(M_gmol,Mn_gmol)
%STAGEE1_FLORY_WEIGHT_CDF_EXACT Exact infinite-support Flory weight CDF.
% For dW/dM = M/Mn^2 exp(-M/Mn),
% F(M)=1-exp(-u)*(1+u), u=M/Mn.
if ~(isscalar(Mn_gmol) && isfinite(Mn_gmol) && Mn_gmol>0)
    error('StageE1:InvalidMn','Mn must be a finite positive scalar.');
end
M=M_gmol(:)';
if any(~isfinite(M)) || any(M<=0), error('StageE1:InvalidMGrid','M grid must be positive and finite.'); end
u=M./Mn_gmol;
F=1-exp(-u).*(1+u);
F=max(0,min(1,F));
end
