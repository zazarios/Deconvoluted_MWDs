function [StageCoverage,BulkCoverage,Thresholds] = stageJ_external_coverage(cfg,Ranges,Evidence)
%STAGEJ_EXTERNAL_COVERAGE Compare model stress ranges with independent data.
% Comparisons are diagnostic only. Stage/rubber-rich proxies are explicitly
% kept separate from direct bulk-C2 comparisons.

% Stage/rubber-rich composition proxy evidence.
q=ismember(Evidence.QuantityCode,{'RUBBER_RICH_C2_WTFRAC','COPOLYMER_C2_WTFRAC','XYLENE_SOLUBLE_C2_WTFRAC'});
E=Evidence(q,:);
spans=cfg.StageJ.chemistry_odds_spans(:);
rows=cell(0,14);
for i=1:numel(spans)
    s=spans(i);
    r=Ranges(Ranges.ChemistryOddsSpan==s & strcmp(Ranges.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);
    if height(r)~=1, error('StageJ:UnionRangeMissing','Union composition range missing for span %g.',s); end
    for j=1:height(E)
        elo=E.ValueLo(j); ehi=E.ValueHi(j); mlo=r.StageC2Min; mhi=r.StageC2Max;
        overlap=(mhi>=elo && mlo<=ehi);
        contains=(mlo<=elo && mhi>=ehi);
        gap=max([elo-mhi,mlo-ehi,0]);
        rows(end+1,:)={s,E.ID{j},E.Source{j},E.QuantityCode{j},E.Comparability{j},elo,ehi,mlo,mhi,overlap,contains,gap,E.EPC_wtfrac(j),'EXTERNAL_CHALLENGE_NOT_CALIBRATION'}; %#ok<AGROW>
    end
end
StageCoverage=cell2table(rows,'VariableNames',{'ChemistryOddsSpan','EvidenceID','Source','ExternalQuantity','Comparability','ExternalLo','ExternalHi', ...
    'ModelStageC2Min','ModelStageC2Max','AnyOverlap','ContainsExternalDatumOrRange','Gap','ExternalEPC_wtfrac','Status'});

% Direct bulk-C2 challenge at matched nominal EPC from Cancelas.
rows=cell(0,12);
for i=1:numel(spans)
    s=spans(i);
    r=Ranges(Ranges.ChemistryOddsSpan==s & strcmp(Ranges.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);
    for j=1:numel(cfg.StageJ.cancelas_EPC)
        e=cfg.StageJ.cancelas_EPC(j); obs=cfg.StageJ.cancelas_bulk_C2(j);
        lo=e*r.StageC2Min; hi=e*r.StageC2Max;
        covered=(obs>=lo && obs<=hi);
        gap=max([obs-hi,lo-obs,0]);
        rows(end+1,:)={s,e,lo,hi,obs,covered,gap,'Cancelas et al. 2018','10.1002/mren.201700063', ...
            'TOTAL_C2_WTFRAC','DIRECT_BULK_C2_AT_MATCHED_NOMINAL_EPC','NO_FITTING'}; %#ok<AGROW>
    end
end
BulkCoverage=cell2table(rows,'VariableNames',{'ChemistryOddsSpan','EPC_wtfrac','ModelBulkC2Min','ModelBulkC2Max','ExternalBulkC2', ...
    'ExternalPointCovered','Gap','Source','DOI','Quantity','Comparability','Status'});

% Threshold summary.
unionR=Ranges(strcmp(Ranges.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);
minOverlap=NaN; minContain=NaN;
for i=1:height(unionR)
    if isnan(minOverlap) && unionR.AnyOverlapWithExternalEnvelope(i), minOverlap=unionR.ChemistryOddsSpan(i); end
    if isnan(minContain) && unionR.ContainsExternalEnvelope(i), minContain=unionR.ChemistryOddsSpan(i); end
end
minAllBulk=NaN;
for i=1:numel(spans)
    q=BulkCoverage.ChemistryOddsSpan==spans(i);
    if all(BulkCoverage.ExternalPointCovered(q)), minAllBulk=spans(i); break; end
end
Thresholds=table(minOverlap,minContain,minAllBulk,cfg.StageJ.external_stage_C2_challenge(1),cfg.StageJ.external_stage_C2_challenge(2), ...
    'VariableNames',{'MinimumSpanForAnyExternalStageOverlap','MinimumSpanForFullExternalStageEnvelopeContainment','MinimumSpanCoveringAllCancelasBulkPoints', ...
    'ExternalStageEnvelopeMin','ExternalStageEnvelopeMax'});
end
