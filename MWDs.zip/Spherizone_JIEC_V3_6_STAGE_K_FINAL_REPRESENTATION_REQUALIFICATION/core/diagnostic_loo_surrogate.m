function T = diagnostic_loo_surrogate(M_grid)
%DIAGNOSTIC_LOO_SURROGATE Scaled inverse-distance LOO diagnostic over all 16 points.
% Diagnostic only; never used by the primary model.

data=data_flory_populations(); n=numel(data);
X=[[data.T_C]' [data.H2_psi]' [data.DoTi]'];
lo=min(X,[],1); hi=max(X,[],1); Xs=(X-lo)./(hi-lo);
IAE=zeros(n,1); eMn=zeros(n,1); eMw=zeros(n,1); eD=zeros(n,1);
for k=1:n
    train=setdiff(1:n,k);
    d=sqrt(sum((Xs(train,:)-Xs(k,:)).^2,2));
    wt=1./max(d,1e-8).^2; wt=wt/sum(wt);
    wp=zeros(1,5); Mnp=nan(1,5);
    for j=1:5
        wvals=arrayfun(@(ii)data(ii).w(j),train);
        wp(j)=sum(wt'.*wvals);
        present=arrayfun(@(ii)isfinite(data(ii).Mn_gmol(j)) && data(ii).w(j)>0,train);
        if wp(j)>1e-12 && any(present)
            a=wt(present); a=a/sum(a);
            vals=arrayfun(@(ii)data(ii).Mn_gmol(j),train(present));
            Mnp(j)=exp(sum(a'.*log(vals)));
        end
    end
    wp=max(wp,0); wp=wp/sum(wp); Mnp(wp<=1e-12)=NaN;
    pred=mix_flory_populations(wp,Mnp,M_grid);
    ref=mix_flory_populations(data(k).w,data(k).Mn_gmol,M_grid);
    x=log10(M_grid);
    IAE(k)=trapz(x,abs(pred.dW_dlog10M-ref.dW_dlog10M));
    eMn(k)=(pred.Mn_analytical_gmol-ref.Mn_analytical_gmol)/ref.Mn_analytical_gmol;
    eMw(k)=(pred.Mw_analytical_gmol-ref.Mw_analytical_gmol)/ref.Mw_analytical_gmol;
    eD(k)=(pred.D_analytical-ref.D_analytical)/ref.D_analytical;
end
T=table({data.id}',IAE,eMn,eMw,eD,'VariableNames',{'SourceID','MWD_IAE','Mn_relerr','Mw_relerr','D_relerr'});
end
