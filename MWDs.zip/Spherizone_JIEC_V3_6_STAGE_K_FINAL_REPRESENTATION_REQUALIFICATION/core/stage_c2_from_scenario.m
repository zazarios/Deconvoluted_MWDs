function c2 = stage_c2_from_scenario(pop,f1_sorbed,r1,r2,response)
%STAGE_C2_FROM_SCENARIO Conditional second-stage ethylene weight fraction.
w=pop.w(:)'; w=max(w,0); w=w/sum(w);
mult=response.ethylene_odds_multiplier(:)';
if numel(mult)~=numel(w), error('Response multiplier length mismatch.'); end
odds=(1-f1_sorbed)/f1_sorbed;
f1j=1./(1+mult.*odds);
F1j=mayo_lewis_propylene_fraction(f1j,r1,r2);
C2j=ethylene_weight_fraction(F1j);
c2=sum(w.*C2j);
end
