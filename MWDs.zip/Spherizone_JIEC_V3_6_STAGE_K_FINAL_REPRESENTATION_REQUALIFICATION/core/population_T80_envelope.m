function scenarios = population_T80_envelope(H2_psi, DoTi)
%POPULATION_T80_ENVELOPE Boundary-hold + empirical matched 10 C slope ensemble.
% No scenario is labelled a statistical confidence interval.

if nargin<2, DoTi=1.4; end
if abs(DoTi-1.4)>1e-12
    error('Primary T80 envelope currently requires Do/Ti=1.4 baseline.');
end
base=population_transfer(70,H2_psi,DoTi);
data=data_flory_populations();

pairs={};
for i=1:numel(data)
    for j=1:numel(data)
        if abs((data(j).T_C-data(i).T_C)-10)<1e-12 && ...
           abs(data(j).H2_psi-data(i).H2_psi)<1e-12 && ...
           abs(data(j).DoTi-data(i).DoTi)<1e-12
            pairs(end+1,:)={data(i).id,data(j).id}; %#ok<AGROW>
        end
    end
end

n=1+size(pairs,1);
scenarios=repmat(struct('name','','w',zeros(1,5),'Mn_gmol',nan(1,5), ...
    'source_pair','','truncated_weights',false,'mn_delta_missing',false, ...
    'admissibility','','admissibility_reason',''),1,n);
scenarios(1).name='T80_boundary_hold_70C';
scenarios(1).w=base.w; scenarios(1).Mn_gmol=base.Mn_gmol;
scenarios(1).source_pair='70C boundary hold';
scenarios(1).admissibility='PRIMARY_BOUNDARY';
scenarios(1).admissibility_reason='No out-of-domain population extrapolation; 70 C boundary values held at 80 C as the primary conservative representation.';

for k=1:size(pairs,1)
    lo=data(strcmp({data.id},pairs{k,1}));
    hi=data(strcmp({data.id},pairs{k,2}));
    dw=hi.w-lo.w;
    wnew=base.w+dw;
    neg=wnew<0;
    wnew(neg)=0;
    if sum(wnew)<=0, error('Temperature scenario produced zero total weight.'); end
    wnew=wnew/sum(wnew);
    Mnnew=base.Mn_gmol;
    missing=false;
    for pop=1:5
        if wnew(pop)<=1e-12
            Mnnew(pop)=NaN;
        elseif isfinite(lo.Mn_gmol(pop)) && isfinite(hi.Mn_gmol(pop)) && isfinite(base.Mn_gmol(pop))
            dlog=log(hi.Mn_gmol(pop))-log(lo.Mn_gmol(pop));
            Mnnew(pop)=exp(log(base.Mn_gmol(pop))+dlog);
        else
            % Missing population identity across the pair: hold the baseline Mn
            % and record the model-form gap rather than inventing a slope.
            missing=true;
            if ~isfinite(Mnnew(pop))
                candidates=[lo.Mn_gmol(pop),hi.Mn_gmol(pop)];
                candidates=candidates(isfinite(candidates));
                if isempty(candidates), error('No Mn available for active population.'); end
                Mnnew(pop)=exp(mean(log(candidates)));
            end
        end
    end
    scenarios(k+1).name=sprintf('T80_empiricalSlope_%s_to_%s',lo.id,hi.id);
    scenarios(k+1).w=wnew;
    scenarios(k+1).Mn_gmol=Mnnew;
    scenarios(k+1).source_pair=sprintf('%s -> %s',lo.id,hi.id);
    scenarios(k+1).truncated_weights=any(neg);
    scenarios(k+1).mn_delta_missing=missing;
    if strcmp(lo.id,'60_D') || strcmp(hi.id,'60_D')
        scenarios(k+1).admissibility='EXCLUDE_SOURCE_INCONSISTENCY';
        scenarios(k+1).admissibility_reason='Uses published 60_D deconvolution row, whose component-implied Mw is internally inconsistent with the reported whole-polymer Mw.';
    elseif any(neg)
        scenarios(k+1).admissibility='STRESS_ONLY_WEIGHT_TRUNCATION';
        scenarios(k+1).admissibility_reason='Linear 10 C weight slope produces a negative population weight before clipping; retain only as extrapolation-failure stress test.';
    elseif missing
        scenarios(k+1).admissibility='STRESS_ONLY_MISSING_IDENTITY';
        scenarios(k+1).admissibility_reason='A population identity is absent in one source condition, so the Mn temperature increment is not identified.';
    else
        scenarios(k+1).admissibility='ADMISSIBLE_EMPIRICAL_STRESS';
        scenarios(k+1).admissibility_reason='Matched 10 C source-pair slope remains nonnegative with defined active-population Mn increments; use only as model-form stress, not as statistical confidence bound.';
    end
end
end
