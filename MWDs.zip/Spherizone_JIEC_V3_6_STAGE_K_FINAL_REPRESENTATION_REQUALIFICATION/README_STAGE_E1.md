# Spherizone JIEC v2.7.1 — Stage E.1
## Continuous full-MWD retention bounds

### Scientific purpose
Stage E showed substantial full-MWD separation at six pre-specified Stage-B2 adverse witnesses, but did not establish a lower bound over the continuous Stage-D uncertainty coordinates. Stage E.1 closes that gap without adding catalyst kinetics, fitting ICP data, or changing the Stage-E phase-wise comparator.

The primary question is:

> Does the resolved-versus-collapsed full-MWD separation remain strictly positive over the maximal marginal Stage-D uncertainty domains?

Stage E.1 follows the Stage-D marginal construction. `U_W` is varied at homogeneous C0 chemistry; `U_C` retains inherited population weights. No joint `U_W x U_C` robustness claim is made.

### Primary bounded metric
The certified metric is Wasserstein-1 distance in `log10(M)` (decades), identical in meaning to Stage E.

For each uncertainty coordinate, Stage E.1 reports:

- a deterministic lower bound on the true minimum W1;
- an attainable upper bound on that true minimum where available;
- the resulting bracket for the unknown exact minimum;
- a conservative Jensen-Shannon floor derived from the W1 lower bound.

The JS floor is mathematically valid but intentionally not used as a materiality criterion.

### U_W bound construction
The Stage-D set is

`TV(w,w0) <= delta_W`, `0 <= delta_W <= 1`.

At `delta_W = 1`, every active-population simplex vector is admissible. Therefore a lower bound over the full simplex is automatically valid for every smaller Stage-D TV ball.

For fixed population Mn values, define

`h(w,M) = F_resolved_stage(M) - F_sameMn_singleFlory_stage(M)`.

For each M, `h` depends on the weights only through two linear functionals: the resolved CDF mixture and the inverse stage Mn. The image of the simplex is the convex hull of five population points in this two-dimensional space. Extrema of `h` lie on the lower/upper hull boundaries; evaluating every population-pair edge therefore covers every possible hull edge.

Continuous edge extrema are enclosed using:

1. a deterministic edge grid;
2. an analytic derivative/Lipschitz pad between adjacent edge-grid points;
3. an explicit finite-grid CDF pad covering the difference between the exact Flory CDF and the numerically normalized Stage-E grid representation.

For `DIRECT_MN_TRANSFER`, the population Mn values are fixed.

For `DP_REPEAT_MASS_CORRECTED` under C0, every population receives the same repeat-mass scale `alpha`. Stage E.1 reconstructs the exact Stage-D C0 alpha range and encloses its full continuous interval with an analytic log-scale Lipschitz pad. This is slightly more conservative than evaluating only the finite Stage-D reactivity grid.

A simplex vertex contains only one active second-stage Flory population, so the second-stage resolved and collapsed distributions are identical there. Consequently `(1-EPC)*W1_matrix` is an attainable upper bound on the global U_W minimum.

### U_C bound construction
Population weights remain inherited, as in Stage D.

For `DIRECT_MN_TRANSFER`, chemistry does not alter population Mn. The full MWD is therefore exactly invariant to `rho_C`; the only remaining primary model-form variation is the pre-existing admissible T80 ensemble.

For `DP_REPEAT_MASS_CORRECTED`, each population repeat mass must lie between the ethylene and propylene repeat masses. Therefore

`M2/M3 <= alpha_j <= 1`.

Stage E.1 deliberately permits the five `alpha_j` values to vary independently over this box. The exact Stage-D chemistry manifold is a subset of this larger box. The resulting W1 lower bound is therefore conservative: if the lower bound is positive on the superset, it is positive on every exact Stage-D U_C realization.

### What is and is not certified
Certified/derived:

- continuous W1 lower bound;
- conservative JS lower floor implied by W1 on the finite 0–9 decade metric support.

Not certified as global continuous minima:

- M90 ratio;
- M99 ratio;
- tail excess.

These remain Stage-E magnitude diagnostics. Their adverse-witness minima are carried into the Stage-E.1 outputs for interpretation but must not be relabeled as continuous lower bounds.

### Independent executable-mirror audit and v2.7.1 hotfix
The first v2.7 MATLAB execution completed the scientific calculation but failed only
`E1_7_INDEPENDENT_W1_BOUND_MIRROR`. Audit showed that the auxiliary pre-execution
expected-summary table was inconsistent with the all-primary-T calculation. The MATLAB
core was then reconstructed independently in Python from the packaged source-population
data, the executed Stage-E matrix distribution, the exact Flory CDF, the same full-simplex
edge enclosure, the finite-grid pad, and the conservative U_C scale box.

The independent reconstruction matched every one of the 60 MATLAB by-T bounds to
machine precision (maximum absolute discrepancy below 3e-15 decades), establishing that
the v2.7 core calculation was correct and the stale expected table was the defect.

v2.7.1 therefore:
- replaces `StageE1_expected_continuous_W1_lower_bounds.csv` with the independently
  reconstructed global minima;
- adds `StageE1_expected_byT_W1_bounds.csv` containing all 60 independent by-T bounds;
- strengthens E1.7 to verify the 60 by-T values and the 12 global minima separately;
- makes no change to the physical model, uncertainty domains, CDF bounds, W1 definition,
  or Stage-E comparator.

The corrected independent global lower bounds predict the smallest certified value at
EPC = 30 wt% under `U_W` and `DP_REPEAT_MASS_CORRECTED`:
approximately **0.177640 decades**.

### One-button execution
Run:

`Run_JIEC_V2_StageE1_ContinuousFullMWDBounds.m`

The script creates `Outputs_StageE1/` and packages it as:

`JIEC_V2_STAGE_E1_OUTPUTS.zip`

Upload that ZIP for independent magnitude and claim-scope audit before Stage F.

### Core outputs

- `StageE1_UW_fullsimplex_W1_bounds_by_T.csv`
- `StageE1_UC_continuous_W1_bounds_by_T.csv`
- `StageE1_continuous_W1_bounds_summary.csv`
- `StageE1_metric_scope.csv`
- `StageE1_StageE_magnitude_context.csv`
- `StageE1_numerical_diagnostics.csv`
- `StageE1_verification.csv`
- `STAGE_E1_STATUS.txt`

### Verdict semantics
A passed executable verdict means the numerical lower-bound construction, uncertainty-domain containment, Stage-E prerequisite, independent mirror, finite-grid CDF pad, and metric-scope guards passed. It does not by itself establish external experimental validation or a joint `U_W x U_C` uncertainty result.
