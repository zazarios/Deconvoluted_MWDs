function cfg = stageK_config()
%STAGEK_CONFIG Final H/H.1/H.2 representation-order requalification.
% A-J.1 are frozen. Stage K changes only the admissible downstream state
% support used by H/H.1/H.2: the qualified Stage-J H2/T80 union replaces the
% legacy five-state T80 support. Projection definitions and tolerance bands
% remain exactly those qualified in H/H.1/H.2.

cfg = stageJ1_config();
cfg.release = '3.6-stageK-final-representation-requalification';

cfg.StageK.expected_T_state_count = 17;
cfg.StageK.expected_branch_names = {'NO_ADDED_H2_BOUNDARY','CONTROLLED_2MOL_H2_STRESS','LEGACY_5MOL_H2'};
cfg.StageK.expected_branch_counts = [6 6 5];
cfg.StageK.numeric_abs_tol = 5e-6;
cfg.StageK.order_mirror_tol = 1e-12;
cfg.StageK.note = ['Stage K requalifies the frozen H/H.1/H.2 representation-order questions over the finalized A-J.1 state/model-form domain. ' ...
    'J.1 high-E/P chemistry does not enlarge the molecular-weight repeat-mass support because H/H.1/H.2 already retained the full independent alpha_j interval [M2/M3,1]. ' ...
    'Accordingly, Stage K expands only the H2/T80 state support from the legacy five Stage-G states to the qualified 17-state Stage-J union. ' ...
    'No projection rule, population partition family, target metric, or TIGHT/MODERATE/COARSE tolerance is changed.'];
end
