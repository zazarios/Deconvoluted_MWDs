function cfg = stageJ_config()
%STAGEJ_CONFIG Stage-J-only configuration layered over frozen H2 defaults.
% The upstream default_config.m is retained byte-for-byte from the repaired
% Stage-H.2 v3.2.1 package so Stages A-H.2 remain reproducible under their
% original release configuration.

cfg = default_config();
cfg.release = '3.4.4-stageJ-stageI-prerequisite-hotfix';

% FBR-H2 challenge branches. These are literature-motivated challenge states,
% not inferred plant concentrations.
cfg.StageJ.H2_branch_names = {'NO_ADDED_H2_BOUNDARY','CONTROLLED_2MOL_H2_STRESS','LEGACY_5MOL_H2'};
cfg.StageJ.H2_molfrac = [0 0.02 0.05];
cfg.StageJ.H2_roles = {'PRIMARY_EXTERNAL_BOUNDARY','EXPERIMENTAL_STRESS','LEGACY_COMPARATOR'};

% Nested latent-chemistry odds spans. These are deterministic stress-domain
% amplitudes, not fitted reactivity parameters.
cfg.StageJ.chemistry_odds_spans = [2 4 8 16 32];

% External stage/rubber-rich composition proxy envelope assembled from the
% uploaded independent hiPP evidence. It is held out and never fitted.
cfg.StageJ.external_stage_C2_challenge = [0.238 0.378];

% Direct bulk-C2 challenge points from Cancelas et al. at matched nominal EPC.
cfg.StageJ.cancelas_EPC = [0.10 0.20 0.30];
cfg.StageJ.cancelas_bulk_C2 = [0.051 0.083 0.126];

cfg.StageJ.EPC = cfg.StageG.EPC;
cfg.StageJ.primary_sorption_names = cfg.StageD.primary_sorption_names;
cfg.StageJ.w1_positive_tol = cfg.StageG.w1_positive_tol;
cfg.StageJ.regression_abs_tol = 2e-6;
cfg.StageJ.baseline_reproduction_abs_tol = 5e-7;
cfg.StageJ.note = ['Stage J is an external physical-consistency challenge, not external model fitting. ' ...
    'External data may falsify or broaden an admissible-domain assumption but are never used to claim matched Spherizone validation. ' ...
    'The Stage-G DP repeat-mass chemistry support already spans the full ethylene-to-propylene repeat-mass interval; ' ...
    'therefore the high-E/P composition challenge primarily requalifies composition/VOI claims, while the FBR-H2 challenge ' ...
    'can enlarge the T80 population-transfer set and must be tested against the structural W1 closure.'];
end
