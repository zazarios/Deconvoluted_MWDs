function cfg = stageJ1_config()
%STAGEJ1_CONFIG Stage-J.1 high-E/P chemistry-domain redevelopment.
% Stage J remains frozen upstream evidence. J.1 does not fit Cancelas, Botha,
% Wang, or other held-out ICP/hiPP composition observations.

cfg = stageJ_config();
cfg.release = '3.5-stageJ1-high-EP-chemistry-redevelopment';

% The nominal FBR reactive-monomer ethylene fraction, excluding H2, is
% 0.45/(0.45+0.50)=0.473684. Zhang et al. 2021 high-E/P kinetic evidence at
% 40/60 and 50/50 E/P therefore brackets the nominal reactive feed ratio.
cfg.StageJ1.source_DOI = '10.1021/acs.iecr.1c00104';
cfg.StageJ1.source_feed_E_fraction = [0.40 0.50];
cfg.StageJ1.nominal_FBR_reactive_E_fraction = cfg.FBR.gas.C2H4/(cfg.FBR.gas.C2H4+cfg.FBR.gas.C3H6);

% Outward-rounded mechanistic support for an EFFECTIVE population-level
% ethylene-preference multiplier on sorbed E/P odds. These are model-form
% support limits, not transferred catalyst kinetic constants or reactivity ratios.
% Source audit: Zhang SI Tables S8-S9 give kpE/kpP = 2.1898...30.1587 at
% E/P=40/60 and 50/50, with maximum within-condition class contrast 13.7725.
cfg.StageJ1.kappa_support = [2 32];
cfg.StageJ1.max_population_contrast = 16;
cfg.StageJ1.kappa_reference_levels = [2 4 8 16 32];

% Exchangeable population-pattern library in log2(kappa) coordinates.
% Patterns are centered offsets around each reference level and clipped to
% the declared support. No MWD-population-to-chemical-center mapping is used.
cfg.StageJ1.pattern_monotone_exponents = [-2 -1 0 1 2];
cfg.StageJ1.pattern_mixed_exponents = [-2 -2 0 2 2];

% Conditional grade levels and deterministic critical-support audit.
cfg.StageJ1.EPC = cfg.StageJ.EPC;
cfg.StageJ1.critical_kappa_tol = 1e-6;
cfg.StageJ1.critical_max_iter = 80;
cfg.StageJ1.regression_abs_tol = 2e-6;
cfg.StageJ1.voi_abs_tol = 5e-6;
cfg.StageJ1.note = ['J.1 preserves the qualified Stage-J chemistry family as a legacy model-form branch and adds an independent high-E/P mechanistic branch. ' ...
    'The new branch is constructed only from Zhang et al. 2021 high-E/P kinetic evidence at 40/60 and 50/50 E/P. ' ...
    'Cancelas/Botha/Wang remain held-out external challenges and do not set kappa bounds, pattern weights, or any fitted parameter. ' ...
    'The kappa coordinate is an effective reduced-order ethylene-preference multiplier, not a claim that Zhang kpE/kpP transfers numerically to the Alshaiban catalyst.'];
end
