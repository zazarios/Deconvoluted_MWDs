function cfg = default_config()
%DEFAULT_CONFIG Explicit working configuration for Stage-A qualification.
% Values tagged qualification_only are code-test settings, not manuscript constants.

cfg.release = '3.2.1-stageH2-containment-tolerance-hotfix';
cfg.spec_version = '1.0';

% Numerical grids/tolerances
cfg.M_grid = logspace(0, 9, 6001);            % g/mol, audit grid
cfg.M_output_grid = logspace(2, 7.5, 1601);   % g/mol, compact export grid
cfg.norm_tol = 1e-4;
cfg.mass_balance_tol = 1e-6;
cfg.moment_rel_tol = 5e-4;
cfg.convergence_rel_tol = 1e-3;
cfg.weight_zero_tol = 1e-12;

% Source-supported principal interpolation rectangle
cfg.transfer.DoTi = 1.4;
cfg.transfer.T_bounds_C = [60 70];
cfg.transfer.H2_bounds_psi = [0 16];

% Conditioning targets
cfg.EX1.target_Mw_gmol = 400000;
cfg.EX1.T_C = 70;
cfg.EX1.DoTi = 1.4;
cfg.EX1.H2_search_psi = [0 16];

cfg.EX2.target_C2_wtfrac = 0.0300;
% Qualification-only composition used to test manifold mathematics. Final
% analysis must replace/ensemble this through explicit sorption scenarios.
cfg.EX2.f1_sorbed_qualification = 0.855;
cfg.EX2.f1_sorbed_qualification_only = true;
% Broad screening window, intentionally not interpreted as identified physics.
cfg.EX2.r1_bounds_screen = [0.25 15];
cfg.EX2.r2_bounds_screen = [0.05 1.50];
cfg.EX2.n_curve = 301;

% Nominal process geometry retained as contextual design information.
cfg.MZCR.P_bar = 30;
cfg.MZCR.T_C = 70;
cfg.MZCR.DoTi = 1.4;
cfg.MZCR.riser.L_m = 35;
cfg.MZCR.riser.A_m2 = pi*(0.9)^2;
cfg.MZCR.riser.u_g_m_s = 1.9;
cfg.MZCR.riser.tau_h = 0.02;
cfg.MZCR.downer.L_m = 20;
cfg.MZCR.downer.A_m2 = pi*(0.55)^2;
cfg.MZCR.downer.u_g_m_s = 0.5;
cfg.MZCR.downer.tau_h = 1.0;

% Normalized property mode: common arbitrary rate/catalyst scale cancels from
% normalized properties. These are intentionally small so gas depletion is
% negligible in the primary property demonstration.
cfg.MZCR.normalized.mcat_feed_gph = 1.0;      % qualification normalization
cfg.MZCR.normalized.Rp_sp_g_gcat_h = 1.0;    % qualification normalization
cfg.MZCR.normalized.qualification_only = true;

% Gas-depletion diagnostic values (synthetic qualification case only).
cfg.synthetic.P_bar = 10;
cfg.synthetic.T_C = 65;
cfg.synthetic.DoTi = 1.4;
cfg.synthetic.L_m = 1.0;
cfg.synthetic.A_m2 = 0.01;
cfg.synthetic.u_g_m_s = 0.05;
cfg.synthetic.rho_cat_bed_g_m3 = 50;
cfg.synthetic.Rp_sp_g_gcat_h = 800;
cfg.synthetic.gas.C3H6 = 0.85;
cfg.synthetic.gas.C2H4 = 0.05;
cfg.synthetic.gas.H2 = 0.01;
cfg.synthetic.gas.C3H8 = 0.09;
cfg.synthetic.qualification_only = true;

% Second-stage conditional design scenarios
cfg.FBR.T_C = 80;
cfg.FBR.P_bar = 15;
cfg.FBR.gas.C3H6 = 0.50;
cfg.FBR.gas.C2H4 = 0.45;
cfg.FBR.gas.H2 = 0.05;
cfg.FBR.gas.C3H8 = 0.0;
cfg.FBR.EPC_wtfrac = [0.10 0.20 0.30 0.40];
cfg.FBR.EPC_primary_mask = [true true true false];
cfg.FBR.H2_psi = cfg.FBR.gas.H2 * cfg.FBR.P_bar * 14.5037738;

% Model-form stress settings for latent population chemistry.
cfg.site_response.odds_span = 2.0; % ethylene/propylene odds multiplier 0.5..2

% Stage-B EX2 conditioning: the 5 mol%% EX2 recipe lies outside the exact
% composition window of the simple RCP sorption correlations. Stage B does
% NOT evaluate those correlations at EX2. Instead it derives a source-domain
% anchor envelope for sorbed propylene fraction from the documented validity
% region of the Kulajanpeng RCP correlations (70-85 C, reactive C2 fraction
% 0.08-0.09, PC3 <= 20 bar). EX2 is then conditioned over that envelope.
cfg.EX2.anchor.T_C = [70 85];
cfg.EX2.anchor.xC2_reactive = [0.08 0.09];
cfg.EX2.anchor.PC3_bar = [1 20];
cfg.EX2.anchor.nT = 31;
cfg.EX2.anchor.nx = 11;
cfg.EX2.anchor.nP = 100;
cfg.EX2.anchor.n_f1 = 11;

% Primary screening window retained from Stage A. These are screening limits,
% not identified catalyst constants. Expanded stress bounds include effective
% literature exemplars from recent industrial models and test boundary
% sensitivity explicitly.
cfg.EX2.primary_r1_bounds = [0.25 15];
cfg.EX2.primary_r2_bounds = [0.05 1.50];
cfg.EX2.primary_n_r2 = 301;
cfg.EX2.expanded_r1_bounds = [0.05 32];
cfg.EX2.expanded_r2_bounds = [0.05 32];
cfg.EX2.expanded_n_r2 = 301;

% Stage-B transparent computational reference (not a best estimate).
cfg.StageB.reference.EPC_wtfrac = 0.20;
cfg.StageB.reference.FBR_sorption = 'selectivity_C3_over_C2_4';
cfg.StageB.reference.chemistry = 'C0_homogeneous';
cfg.StageB.reference.TScenario = 'T80_boundary_hold_70C';
cfg.StageB.reference.r2_fraction_of_screen = 0.50;

% Robustness diagnostics. No probability model is implied.
cfg.StageB.primary_T_classes = {'PRIMARY_BOUNDARY','ADMISSIBLE_EMPIRICAL_STRESS'};
cfg.StageB.stress_T_classes = {'PRIMARY_BOUNDARY','ADMISSIBLE_EMPIRICAL_STRESS', ...
    'STRESS_ONLY_WEIGHT_TRUNCATION','STRESS_ONLY_MISSING_IDENTITY'};
cfg.StageB.primary_EPC = [0.10 0.20 0.30];
cfg.StageB.stress_EPC = 0.40;
cfg.StageB.output_norm_grid = cfg.M_output_grid;

% RTD alternatives. In conditional steady-property mode these may be
% mathematically invariant; that zero contribution is retained explicitly.
cfg.RTD.names = {'CSTR_N1','TIS_N2','TIS_N5','PFR_limit'};
cfg.RTD.N = [1 2 5 Inf];

% Stage-D continuous partial-identification settings.
% U_W uses the exact total-variation ball on the five-population simplex:
%   TV(w,w0)=0.5*sum(abs(w-w0)) <= delta_W.
% U_C continuously scales the symmetry-complete Stage-B chemistry directions:
%   m_j(rho_C)=exp(rho_C*log(span)*z_j), 0<=rho_C<=1.
% No probability distribution is implied by either radius.
cfg.StageD.weight_TV_grid = linspace(0,1,41);       % exact simplex-radius curve
cfg.StageD.chemistry_rho_grid = linspace(0,1,21);  % continuous amplitude curve
cfg.StageD.regression_rel_tol = 1e-10;
cfg.StageD.critical_margin_tol = 1e-12;
cfg.StageD.primary_sorption_names = {'selectivity_C3_over_C2_4','selectivity_C3_over_C2_5'};
cfg.StageD.weight_curve_chemistry = 'C0_HOMOGENEOUS_MARGINAL_AUDIT';
cfg.StageD.chemistry_curve_weight_transfer = 'W0_INHERITED';
cfg.StageD.note = ['Stage D reports deterministic partial-identification envelopes and critical-radius brackets. ' ...
    'The radii are robustness coordinates, not confidence/probability levels.'];

% Stage-D.1 hardening settings.
% Refine only genuine positive-to-nonpositive critical-radius crossings.
% The tolerance is a deterministic radius-bracket width, not statistical precision.
cfg.StageD1.critical_radius_tol = 1e-6;
cfg.StageD1.max_bisection_iter = 80;
cfg.StageD1.margin_tol = cfg.StageD.critical_margin_tol;
cfg.StageD1.note = ['Stage D.1 refines only nonzero critical-radius crossings and adds semantic diagnostics. ' ...
    'U_W composition invariance under C0 is structural by construction; rho_C=1 gives per-population multipliers 0.5 to 2 and a max/min contrast of 4.'];


% Stage-E full-distribution information-retention settings.
% The information-collapsed comparator preserves phase Mn values and EPC mass
% fraction while replacing every resolved multi-population phase with one
% Flory most-probable distribution. Thus Stage-E distance metrics isolate
% within-phase distributional information rather than ordinary matrix/EPC
% blend broadening.
cfg.StageE.metric_M_grid = cfg.M_grid;       % 1..1e9 g/mol, high-accuracy metric grid
cfg.StageE.export_M_grid = cfg.M_output_grid;
cfg.StageE.EPC = cfg.StageB.primary_EPC;
cfg.StageE.distance_tol = 1e-10;
cfg.StageE.regression_rel_tol = 1e-10;
cfg.StageE.metric_moment_rel_tol = 5e-4;
cfg.StageE.H2_trend_psi = [0 8 16];
cfg.StageE.H2_trend_T_C = 70;
cfg.StageE.H2_trend_DoTi = 1.4;
cfg.StageE.note = ['Stage E quantifies full-MWD information retention using log10-M Wasserstein-1 distance, ' ...
    'Jensen-Shannon divergence, quantiles, and an upper-tail metric. The adverse witnesses are selected by the ' ...
    'pre-existing Stage-B2 minimum-dispersity-excess objective; Stage E does not claim an exhaustive minimum of ' ...
    'Wasserstein distance over the continuous Stage-D uncertainty sets.'];


% Stage-E.1 continuous full-MWD retention bounds.
% E.1 does not introduce a new physical model. It places deterministic lower
% bounds on the Stage-E log10(M) W1 separation over the maximal Stage-D
% marginal uncertainty domains.
%
% U_W: all admissible second-stage population weights are allowed on the full
% simplex (a superset of every TV ball with delta_W <= 1). Under C0 chemistry,
% DIRECT_MN_TRANSFER has fixed population Mn; DP_REPEAT_MASS_CORRECTED applies
% one common repeat-mass scale alpha to every population. The exact Stage-D C0
% alpha range is enclosed continuously and treated with an explicit Lipschitz
% pad.
%
% U_C: inherited population weights are retained. DIRECT_MN_TRANSFER is MWD-
% invariant to chemistry by construction. For DP_REPEAT_MASS_CORRECTED, E.1
% uses the conservative independent scale box M2/M3 <= alpha_j <= 1, which is
% a superset of every exact Stage-D chemistry realization because each repeat
% mass lies between ethylene and propylene repeat masses.
cfg.StageE1.EPC = cfg.StageE.EPC;
cfg.StageE1.edge_t_points = 401;          % odd/even immaterial; endpoints included
cfg.StageE1.edge_chunk = 80;              % memory-safe edge evaluation chunk
cfg.StageE1.finite_grid_cdf_pad = 1e-5;  % conservative CDF pad; >10x prechecked grid discrepancy
cfg.StageE1.w1_positive_tol = 1e-6;
cfg.StageE1.regression_abs_tol = 5e-4;   % independent mirror tolerance for certified bounds
cfg.StageE1.M2_gmol = 28.05;
cfg.StageE1.M3_gmol = 42.08;
cfg.StageE1.note = ['Stage E.1 certifies W1 lower bounds over maximal marginal uncertainty domains. ' ...
    'The W1 bounds are deterministic numerical/analytical bounds, not confidence intervals. ' ...
    'A JS lower bound is derived from W1 using W1 <= diameter*TV and Pinsker; quantile/tail values remain magnitude diagnostics and are not claimed as global continuous minima.'];


% Stage-F prospective deterministic value-of-information audit.
% Five epistemic blocks factorize the refined Stage-B1 L3 ensemble:
%   T80 population transfer; FBR sorption; latent population chemistry;
%   EX2 sorbed-f1 anchor; and the remaining coordinate along the EX2-conditioned
%   effective reactivity curve. Resolving a block means an ideal exact oracle
%   observation. Therefore guaranteed-contraction metrics are upper bounds on
%   what a real finite-precision measurement could achieve. No probability
%   model, expected utility, or measurement-noise distribution is assumed.
cfg.StageF.block_names = {'T80_TRANSFER','FBR_SORPTION','LATENT_CHEMISTRY','EX2_SORBED_F1','REACTIVITY_CURVE_COORD'};
cfg.StageF.EPC = cfg.StageB.primary_EPC;
cfg.StageF.second_RCP_f1_points = 101;
cfg.StageF.regression_abs_tol = 1e-9;
cfg.StageF.exact_rel_tol = 1e-10;
cfg.StageF.exact_abs_tol = 1e-12;
cfg.StageF.note = ['Stage F reports deterministic minimax contraction of partial-identification widths after ideal block resolution. ' ...
    'The reactivity-curve coordinate is experimentally meaningful only after EX2 sorbed f1 is characterized. ' ...
    'Direct output measurements are classified as calibration/validation rather than transferable parameter identification.'];


% Stage-G final joint-uncertainty structural-claim closure.
% Stage G introduces no new physics. It asks whether the full-MWD separation
% remains bounded away from zero when the Stage-D population-weight and latent-
% chemistry uncertainties act simultaneously, while retaining the qualified
% primary 70->80 C population-transfer ensemble.
%
% Weight uncertainty: the maximal Stage-D TV domain is the full active-
% population simplex. Chemistry uncertainty: DIRECT_MN_TRANSFER is MWD-
% invariant; DP_REPEAT_MASS_CORRECTED is enclosed by the conservative
% independent repeat-mass scale box M2/M3 <= alpha_j <= 1. Stage G then
% enlarges the discrete/interval support of reciprocal population Mn to its
% enclosing continuous interval. For a Flory population CDF Q_M(s), s=1/Mn,
% the second-stage resolved-minus-collapsed CDF is the Jensen gap
% E[Q_M(S)]-Q_M(E[S]). Exact convex/concave-envelope extrema over the enclosing
% support interval provide deterministic pointwise bounds. A positive W1 lower
% bound over this enlarged domain is therefore conservative for the exact joint
% Stage-D uncertainty product.
cfg.StageG.EPC = cfg.StageE1.EPC;
cfg.StageG.M2_gmol = cfg.StageE1.M2_gmol;
cfg.StageG.M3_gmol = cfg.StageE1.M3_gmol;
cfg.StageG.finite_grid_cdf_pad = cfg.StageE1.finite_grid_cdf_pad;
cfg.StageG.w1_positive_tol = 1e-6;
cfg.StageG.regression_abs_tol = 5e-7;
cfg.StageG.root_tol = 1e-13;
cfg.StageG.max_bisection_iter = 90;
cfg.StageG.note = ['Stage G certifies joint U_W x U_C full-MWD retention over an enlarged support interval and the qualified primary T80 envelope. ' ...
    'The bound is deterministic and conservative, not a confidence interval. It does not certify joint composition, grade separation, quantile minima, or industrial validation.'];


% Stage-H certified target-aware population projection / resolution audit.
% Stage H reopens model development only to ask how much of the five-population
% experimentally resolved representation is required for a specified downstream
% target. No new kinetic, sorption, transport, or catalyst-identity parameter is
% introduced.
%
% Every set partition of the five numerical MWD-population labels is evaluated
% (Bell number B5 = 52). For each merged group, total mass is conserved and the
% group reciprocal-Mn is the exact weight-average reciprocal-Mn of its members.
% Thus group Mn is the harmonic mean required to preserve the group's number
% contribution, and total stage/final Mn is invariant under reduction.
%
% The projection has oracle access to the detailed state when computing each merged
% group's mass and harmonic Mn. It therefore gives an optimistic best-case
% representation error, not a closed deployable reduced model. The minimax
% partition is target-specific but may not depend on the uncertainty
% realization. The uncertainty domain is inherited from qualified Stage G:
% full population-weight simplex, both transfer formulations, the five primary
% T80 scenarios, and the conservative independent DP repeat-mass scale box.
% W1 and fixed-tail-mass errors are bounded by an admissible pair-witness lower
% bound and a continuous-support Jensen-envelope upper bound. Mw and dispersity
% relative errors have an exact endpoint-mixture minimax construction because
% the merge preserves Mn and 1/s is convex.
cfg.StageH.EPC = cfg.StageG.EPC;
cfg.StageH.M2_gmol = cfg.StageG.M2_gmol;
cfg.StageH.M3_gmol = cfg.StageG.M3_gmol;
cfg.StageH.finite_grid_cdf_pad = cfg.StageG.finite_grid_cdf_pad;
cfg.StageH.root_tol = cfg.StageG.root_tol;
cfg.StageH.max_bisection_iter = cfg.StageG.max_bisection_iter;
cfg.StageH.metric_M_grid = logspace(0,9,1601);
cfg.StageH.audit_M_grid = cfg.StageE.metric_M_grid;
cfg.StageH.witness_t_points = 101;
cfg.StageH.t_seed_points = 41;
cfg.StageH.t_refine_top = 5;
cfg.StageH.t_tol = 1e-10;
cfg.StageH.numeric_abs_tol = 5e-7;
cfg.StageH.mirror_abs_tol = 7e-4;
% Pre-specified reporting bands. They are model-reduction tolerances, not
% experimental uncertainty, confidence levels, or universal acceptability limits.
cfg.StageH.W1_tolerances_decades = [0.01 0.02 0.05];
cfg.StageH.scalar_rel_tolerances = [0.01 0.025 0.05];
cfg.StageH.tail_mass_abs_tolerances = [0.01 0.025 0.05];
cfg.StageH.tolerance_labels = {'TIGHT','MODERATE','COARSE'};
cfg.StageH.note = ['Stage H reports target-aware minimum oracle-projection population order under the Stage-G uncertainty domain. ' ...
    'A unique projection K* is claimed only when the minimax witness lower bound and certified support upper bound imply the same order. ' ...
    'Reference quantile losses are diagnostics only and are not used to select K or the tolerance bands.'];


% Stage-H.1 state-independent fixed-descriptor closure audit.
% H.1 removes the Stage-H oracle dependence of each merged group's Mn on the
% hidden within-group population weights and population-specific DP repeat-mass
% scales.  For a specified target, EPC fraction, T80 scenario, transfer mode,
% and fixed partition, every group receives ONE minimax scalar Mn descriptor
% before the latent weight/chemistry realization is known.  The descriptor may
% depend only on these declared design/model inputs, never on hidden w_j or
% alpha_j.  The full Stage-G population-weight simplex and conservative DP
% alpha interval are retained.  Failure at K=5 is therefore allowed and means
% that no fixed scalar descriptor can meet the reporting tolerance without
% retaining an additional latent chemistry/scale state.
cfg.StageH1.EPC = cfg.StageH.EPC;
cfg.StageH1.M2_gmol = cfg.StageH.M2_gmol;
cfg.StageH1.M3_gmol = cfg.StageH.M3_gmol;
cfg.StageH1.W1_tolerances_decades = cfg.StageH.W1_tolerances_decades;
cfg.StageH1.scalar_rel_tolerances = cfg.StageH.scalar_rel_tolerances;
cfg.StageH1.tail_mass_abs_tolerances = cfg.StageH.tail_mass_abs_tolerances;
cfg.StageH1.tolerance_labels = cfg.StageH.tolerance_labels;
cfg.StageH1.numeric_abs_tol = 2e-6;
cfg.StageH1.mirror_abs_tol = 5e-6;
cfg.StageH1.root_tol = 1e-12;
cfg.StageH1.max_bisection_iter = 120;
cfg.StageH1.note = ['Stage H.1 reports the best target-specific state-independent scalar closure available to a fixed population partition. ' ...
    'Group descriptors may depend on target, EPC, T80 branch and transfer formulation, but never on latent within-group weights or population-specific DP alpha values. This is therefore T80-branch-conditional fixed-descriptor closure, not a T80-global operational closure. ' ...
    'No K is forced when even K=5 cannot meet a reporting tolerance. D uses an admissible witness lower bound and conservative signed-ratio upper bound.'];


% Stage-H.2 T80-global fixed-descriptor operational-closure audit.
% H.2 removes the remaining Stage-H.1 dependence of each target-specific
% group descriptor on the T80 model-form branch. For a specified target, EPC
% fraction, transfer formulation, and fixed population partition, every group
% receives ONE scalar Mn descriptor before the T80 branch, within-group
% population weights, or population-specific DP repeat-mass scales are known.
% The descriptor may depend on target, EPC fraction, transfer formulation, and
% group membership only. The full Stage-G population-weight simplex, all five
% qualified T80 branches, and the conservative DP alpha interval are retained.
% Failure at K=5 is allowed and means that population count alone cannot close
% the target without additional state/model-form information.
cfg.StageH2.EPC = cfg.StageH1.EPC;
cfg.StageH2.M2_gmol = cfg.StageH1.M2_gmol;
cfg.StageH2.M3_gmol = cfg.StageH1.M3_gmol;
cfg.StageH2.W1_tolerances_decades = cfg.StageH1.W1_tolerances_decades;
cfg.StageH2.scalar_rel_tolerances = cfg.StageH1.scalar_rel_tolerances;
cfg.StageH2.tail_mass_abs_tolerances = cfg.StageH1.tail_mass_abs_tolerances;
cfg.StageH2.tolerance_labels = cfg.StageH1.tolerance_labels;
cfg.StageH2.numeric_abs_tol = 2e-6;
cfg.StageH2.mirror_abs_tol = 5e-6;
cfg.StageH2.support_mirror_abs_tol_gmol = 5e-6;
cfg.StageH2.containment_abs_tol_gmol = 1e-8; % numerical CSV/in-memory round-trip tolerance only
cfg.StageH2.root_tol = 1e-12;
cfg.StageH2.max_bisection_iter = 120;
cfg.StageH2.note = ['Stage H.2 reports the best target-specific fixed scalar closure available before the T80 branch and latent within-group weight/chemistry state are known. ' ...
    'Descriptors may depend on target, EPC fraction and declared transfer formulation, but not on the T80 branch, hidden within-group weights, or population-specific DP alpha values. ' ...
    'No K is forced when even K=5 cannot meet a reporting tolerance. D uses an admissible witness lower bound and conservative signed-ratio upper bound.'];

end
