# Spherizone JIEC v2.6.1 — Stage E
## Full-distribution information retention


### v2.6.1 execution hotfix
The initial v2.6 package initialized `RefRec` and `WorstRec` as `struct([])` and then used direct indexed assignment of populated records. In MATLAB this can raise `Subscripted assignment between dissimilar structures` because the empty struct has no field schema. v2.6.1 replaces both assignments with a schema-checked append helper and runs an early struct-append self-test before the Stage-E loops. No scientific equations, inputs, comparators, witness-selection rules, metrics, or qualification thresholds were changed.

### Scientific question
Stage E asks whether the experimentally resolved multi-population molecular-weight-distribution (MWD) information remains visible after reduced-order MZCR propagation and downstream EPC blending, rather than being an artifact of reporting only Mn, Mw, or dispersity.

Stage E does **not** add catalyst kinetics, identify new parameters, or claim industrial validation.

### Information-collapsed comparator
The comparator is deliberately phase-wise. For each state it preserves:

- the MZCR-matrix Mn;
- the second-stage Mn;
- the EPC polymer mass fraction;
- the same final analytical Mn implied by those phase values and mass fractions.

Each resolved multi-population phase is then replaced by one Flory most-probable distribution with the same phase Mn. Consequently, the final comparator can still be a two-phase blend; Stage E does not confound ordinary matrix/EPC blending with within-phase multi-population information.

### Primary full-MWD metrics
All metric calculations use `cfg.StageE.metric_M_grid = logspace(0,9,6001)` g/mol.

1. Wasserstein-1 distance in `log10(M)`, reported in decades.
2. Jensen-Shannon divergence, base-2, reported in bits.
3. M10, M50, M90, and M99.
4. M90/M10.
5. Mass fraction of the resolved MWD above the collapsed comparator's M90; the difference from the comparator tail is reported as tail excess.
6. Numerical Mn, Mw, and dispersity for regression against analytical moments.

No W1 or JS threshold is interpreted as a statistical confidence level or universal materiality criterion.

### Three analysis layers

#### E-A — EX1 source to MZCR matrix
The EX1-conditioned population mixture is compared with its same-Mn single-Flory collapse. The two-zone MZCR matrix is then evaluated with the same diagnostic. The ratio of MZCR W1 to source W1 is a dimensionless propagation ratio; it is not a probability or percentage of information in an information-theoretic sense.

#### E-B — transparent reference final distributions
Both transfer modes are evaluated for EPC = 0.10, 0.20, and 0.30 using the pre-existing Stage-B transparent reference state and inherited population weights. These are reference calculations only, not best estimates.

#### E-C — adverse structural witnesses
The full-distribution metrics are evaluated at the exact states minimizing the already-qualified Stage-B2 objective

`DeltaD = D_resolved - D_phasewise_singleFlory`

under the independent factor-two population-weight transfer stress. The witnesses are therefore selected by a criterion fixed before Stage E; W1 and JS are not used to choose favorable cases.

This is a stringent test of whether the moment-level structural finding has a genuine full-distribution counterpart within the Stage-B2 stress set.

### Important limitation relative to Stage D/D.1
Stage E does **not** claim an exhaustive minimization of W1 or JS over every point in the continuous Stage-D `U_W` and `U_C` sets. The continuous Stage-D analysis remains the partial-identification result for Mn, Mw, and composition. Stage E asks a different question: whether the previously qualified structural MWD signal is represented in the full distribution, including at its pre-specified adverse B2 witnesses.

### Yang et al. (2026) external challenge
Yang, Lei, and Luo (2026), DOI `10.1021/acs.iecr.6c02664`, is used only as an external structural/directional challenge.

Permitted comparisons:

- their industrial ICP MMD required multiple superposed Flory distributions; four were selected as the minimum adequate representation in that model/data set;
- they reported a lower-molar-mass shift of the ICP MMD with increasing MZCR H2/propylene;
- their slight dispersity increase with H2 can be compared directionally with the source-supported Alshaiban reconstruction.

Not permitted:

- direct validation of Stage-E W1/JS retention metrics;
- direct pass/fail comparison of their FBR ethylene-ratio perturbation with the present fixed-EPC reduced-order formulation;
- transfer of Yang kinetic parameters to the Alshaiban catalyst.

### One-button execution
Run in MATLAB:

`Run_JIEC_V2_StageE_DistributionRetention.m`

The script writes `Outputs_StageE/` and packages it as:

`JIEC_V2_STAGE_E_OUTPUTS.zip`

Upload that ZIP for independent scientific/magnitude audit before Stage F.

### Core Stage-E outputs

- `StageE_source_to_MZCR_distribution_retention.csv`
- `StageE_source_matrix_MWD_curves.csv`
- `StageE_reference_full_distribution_metrics.csv`
- `StageE_reference_MWD_curves.csv`
- `StageE_worst_structural_witnesses.csv`
- `StageE_B2_witness_regression.csv`
- `StageE_worst_witness_full_distribution_metrics.csv`
- `StageE_worst_witness_MWD_curves.csv`
- `StageE_H2_distribution_trend.csv`
- `StageE_Yang2026_external_challenge.csv`
- `StageE_verification.csv`
- `STAGE_E_STATUS.txt`

### Execution verdict semantics
A passed executable verdict means that normalization, moment reconstruction, comparator identity, B2 witness regression, nonzero distribution-distance signal, and scope guards passed. It does **not** mean the magnitude is automatically sufficient for a manuscript claim. The output ZIP must be independently audited before Stage F.
