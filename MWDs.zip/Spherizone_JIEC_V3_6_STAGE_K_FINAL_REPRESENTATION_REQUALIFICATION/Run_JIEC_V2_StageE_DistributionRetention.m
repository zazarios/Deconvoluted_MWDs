% Run_JIEC_V2_StageE_DistributionRetention.m
% One-button Stage-E full-distribution information-retention qualification.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageE');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.6.1 Stage E] Full-MWD information-retention analysis\n');
fprintf('Release: %s\n',cfg.release);

result=run_stageE_distribution_retention(cfg,outdir);
V=verify_stageE_distribution_retention(cfg,outdir,result);
allPass=all(strcmp(V.Status,'PASS'));

fid=fopen(fullfile(outdir,'STAGE_E_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.6.1 Stage-E full-distribution information-retention analysis\n');
fprintf(fid,'All executable Stage-E numerical/scope gates pass: %d\n',allPass);
fprintf(fid,'Minimum W1 at B2 adverse witnesses: %.10g decades\n',min(result.WorstMetrics.W1_log10M_decades));
fprintf(fid,'Minimum JS at B2 adverse witnesses: %.10g bits\n',min(result.WorstMetrics.JS_divergence_bits));
fprintf(fid,'MZCR/source W1 retention ratio: %.10g\n',result.matrixW1/result.sourceW1);
fprintf(fid,'Important scope: adverse full-distribution witnesses are selected by the pre-existing Stage-B2 minimum-DeltaD objective.\n');
fprintf(fid,'Stage E does not claim exhaustive minimization of W1/JS over continuous Stage-D U_W/U_C uncertainty sets.\n');
fprintf(fid,'Yang et al. 2026 is used as a directional/structural external challenge, not direct validation of Stage-E retention metrics.\n');
if allPass
    fprintf(fid,'Verdict: STAGE_E_EXECUTABLE_QUALIFIED__INDEPENDENT_MAGNITUDE_AUDIT_REQUIRED_BEFORE_STAGE_F\n');
else
    fprintf(fid,'Verdict: STAGE_E_EXECUTABLE_FAILED__DO_NOT_PROCEED\n');
end
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_E_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageE'},ROOT);

if ~allPass, error('Stage-E executable verification failed. Inspect StageE_verification.csv.'); end
fprintf('\n[JIEC v2.6.1 Stage E] COMPLETE\n');
fprintf('Verdict: STAGE_E_EXECUTABLE_QUALIFIED__INDEPENDENT_MAGNITUDE_AUDIT_REQUIRED_BEFORE_STAGE_F\n');
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
