# Stage J.1 — High-E/P chemistry-domain redevelopment

## Scientific question
Can the high-E/P composition uncertainty domain be rebuilt from independent mechanistic evidence, without fitting the held-out ICP/hiPP composition observations, while preserving the qualified Stage-J domain and requalifying the affected composition/VOI claims?

## Binding design
1. **Stage J is frozen upstream evidence.** Its complete odds-span=2 chemistry family remains an explicit legacy model-form branch.
2. **Mechanistic construction source:** Zhang et al. (2021), DOI `10.1021/acs.iecr.1c00104`, SI Tables S8-S9. Only E/P = 40/60 and 50/50 are used because they bracket the nominal FBR reactive-monomer ethylene fraction, `0.45/(0.45+0.50)=0.473684`.
3. Across two donors and three fraction-associated active-center classes, the selected source data give apparent `kpE/kpP = 2.18978...30.15873` and a maximum within-condition class contrast of `13.77249`.
4. J.1 outwardly rounds these to an **effective high-E/P ethylene-preference support** `kappa = 2...32`, with a population contrast cap of 16. `kappa` is not a transferred kinetic constant and is not a Mayo-Lewis reactivity ratio.
5. No MWD-population-to-chemical-center mapping is imposed. Five population labels receive exchangeable homogeneous, ordered, and mixed log2-patterns.
6. Cancelas, Botha, Wang and the other Stage-J ICP/hiPP observations are read only after the J.1 support and composition tensors are constructed. They remain held-out external challenges.

## Outputs requalified
- second-stage C2 partial-identification interval;
- final bulk-C2 intervals at EPC = 10, 20, 30 wt%;
- grade-interval overlap and a mechanistic-only nested-support `kappa_upper` crossing diagnostic;
- deterministic composition value of information under the final set union;
- mechanistic-only VOI separating selectivity level from population pattern;
- held-out external coverage, explicitly not validation.

## Deliberate non-actions
- Stage-G W1 is not rerun solely because of composition chemistry: its DP repeat-mass support already spans the full ethylene-to-propylene repeat-mass interval, and Stage J already requalified the expanded H2/T80 structural challenge.
- H/H.1/H.2 representation-order maps are **not** silently extended. They are deferred until the final J.1 state/model-form domain is qualified.

## Run
Run:

`Run_JIEC_V3_StageJ1_HighEPChemistryRedevelopment.m`

Upload the generated:

`JIEC_V3_STAGE_J1_OUTPUTS.zip`
