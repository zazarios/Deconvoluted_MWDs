% Run_JIEC_V3_StageH1_FixedDescriptorClosure.m
clear;clc;ROOT=fileparts(mfilename('fullpath'));addpath(genpath(ROOT));outdir=fullfile(ROOT,'Outputs_StageH1');if exist(outdir,'dir'),rmdir(outdir,'s');end;mkdir(outdir);cfg=default_config();
fprintf('[JIEC v3.1.1 Stage H.1] T80-conditional fixed-descriptor closure audit\n');
fprintf('Release: %s\n',cfg.release);
fprintf('A fixed group descriptor may depend on target/EPC/T80 branch/transfer formulation, but not hidden within-group weights or population-specific DP alpha.\n');
result=run_stageH1_fixed_descriptor_closure(cfg,outdir);V=verify_stageH1_fixed_descriptor_closure(cfg,outdir,result);allPass=all(strcmp(V.Status,'PASS'));
O=result.OrderMap;Om=O(strcmp(O.ToleranceLabel,'MODERATE'),:);fid=fopen(fullfile(outdir,'STAGE_H1_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v3.1.1 Stage-H.1 T80-conditional fixed-descriptor closure audit\nAll executable Stage-H.1 gates pass: %d\n',allPass);
fprintf(fid,'Scientific scope: target-specific minimax scalar descriptors fixed before latent weight/chemistry realization conditional on a declared T80 branch; one T80-global descriptor set is not established; group-weight dynamics remain set-valued.\n');
for r=1:height(Om)
 if isnan(Om.K_fixed_certified_sufficient(r)),ks='NO_K_LE_5';else,ks=sprintf('%d',Om.K_fixed_certified_sufficient(r));end
 fprintf(fid,'MODERATE | %s | EPC %.2f | certified fixed-scalar K = %s | %s\n',Om.Target{r},Om.EPC_wtfrac(r),ks,Om.FixedClosureStatus{r});
end
if allPass,fprintf(fid,'Verdict: STAGE_H1_T80_CONDITIONAL_FIXED_DESCRIPTOR_CLOSURE_QUALIFIED__T80_GLOBAL_OPERATIONAL_CLOSURE_NOT_ESTABLISHED\n');else,fprintf(fid,'Verdict: STAGE_H1_FAILED__DO_NOT_USE_OPERATIONAL_CLOSURE_CLAIMS\n');end
fclose(fid);zipfile=fullfile(ROOT,'JIEC_V3_STAGE_H1_OUTPUTS.zip');if exist(zipfile,'file'),delete(zipfile);end;zip(zipfile,{'Outputs_StageH1'},ROOT);
if ~allPass,error('Stage-H.1 executable verification failed. Inspect StageH1_verification.csv.');end
fprintf('\n[JIEC v3.1.1 Stage H.1] COMPLETE\nUpload: %s\n',zipfile);
