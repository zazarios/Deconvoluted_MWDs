# Stage J package static audit

Release: `3.4-stageJ-external-physical-consistency-challenge`

## Frozen-lineage check

The Stage-J source tree was compared against the repaired Stage-H.2 v3.2.1 package before release. All 114 MATLAB `.m` files inherited from Stage H.2 are present and byte-for-byte identical. Stage J is implemented only through newly added Stage-J files and `config/stageJ_config.m`; the inherited `config/default_config.m` remains byte-for-byte identical to Stage-H.2 v3.2.1.

Qualified Stage-H.2 outputs are stored under `inputs/StageH2QualifiedOutputs/` and are consumed only as prerequisite evidence. Qualified Stage-I outputs are stored under `inputs/StageIQualifiedOutputs/`.

## External-evidence scope

External Yang/Cancelas/Botha/Wang/Zhang/Urdampilleta/Khare observations are registry-held challenge evidence. No Stage-J routine estimates a parameter by minimizing error to these observations. The external composition values enter only overlap/containment diagnostics; the no-added-H2 and 2 mol% H2 values enter only as predeclared challenge branches.

## Independent pre-run mirror

The files in `Independent_Audit/StageJ_expected_*.csv` were generated from an independent low-level reconstruction before package release. The MATLAB verifier compares Stage-J outputs to those tables. The expected qualitative result is:

- the legacy odds-span-2 composition domain undercovers the independent high-E/P challenge;
- first broad stage/proxy overlap occurs at nested maximum odds span 8;
- full broad stage/proxy envelope containment occurs at span 16;
- all three matched-nominal-EPC Cancelas bulk-C2 points are covered only at span 32;
- the expanded H2/T80 W1 challenge remains certified positive, with the legacy 5 mol% H2 branch expected to remain the limiting branch at 0.197018411 decades.

These are pre-MATLAB expectations, not qualified Stage-J results. The executable MATLAB outputs and `StageJ_verification.csv` are authoritative after the user runs the package.

## Runtime limitation of this release audit

No MATLAB/Octave runtime is available in the packaging environment. Consequently, this release was statically audited and independently mirrored but not executed here. The launcher contains executable J0-J20 qualification gates and must be run in MATLAB before Stage J is scientifically frozen.
