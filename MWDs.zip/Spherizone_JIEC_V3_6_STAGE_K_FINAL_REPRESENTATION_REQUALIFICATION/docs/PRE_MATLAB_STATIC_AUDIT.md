# Pre-MATLAB independent static audit

This file records independent calculations performed outside MATLAB to catch transcription and algebra errors before the user runs the Stage-A package. It is **not** a substitute for MATLAB qualification.

## Expected core checks

- Source conditions transcribed: 16.
- Maximum source-MWD normalization error on a log10(M) grid from 1 to 1e9 g/mol: approximately **1.49e-8**.
- Maximum analytical-vs-numerical moment relative error on that grid: approximately **2.25e-4**.
- EX1 bracketed-interpolation H2 condition expected to match Mw = 400,000 g/mol: approximately **3.123146 psi**.
- At that EX1 condition: Mn approximately **56,533 g/mol**, D approximately **7.0755**.
- EX2 qualification feasible-curve points for `f1_sorbed = 0.855` and the screening bounds in `default_config.m`: **301**.
- Site-response scenario count: **33** (1 C0 + 2 C1 + 30 C2 permutations).
- FBR sorbed-propylene-fraction stress scenarios for gas C3/C2 = 0.50/0.45:
  - gas-composition baseline: **0.526316**
  - C3/C2 selectivity 4: **0.816327**
  - C3/C2 selectivity 5: **0.847458**
- Diagnostic global inverse-distance LOO MWD IAE: median approximately **0.167**, maximum approximately **0.786**. This intentionally demonstrates that the 16-point global surrogate is not uniformly reliable and supports the frozen choice to use bracketed primary interpolation.

## Expected 80 °C population-envelope behavior

FBR H2 partial pressure for 5 mol% H2 at 15 bar is approximately **10.8778 psi**. The boundary-hold plus eight matched 10 °C slope scenarios are expected to be broad. Independent calculations give stage-population Mw spanning approximately **83,284–354,804 g/mol** and D approximately **3.78–6.72**. Several empirical weight-shift scenarios require negative-weight truncation, and one matched pair contains a missing Mn slope for a disappearing population. These conditions are logged explicitly by the MATLAB code.

This breadth is scientifically meaningful: it is an early warning that U_T may dominate some final MWD outputs. The package must not silently narrow it.
