# Stage G pre-MATLAB static audit

Release: `2.9-stageG-joint-uncertainty-structural-claim-closure`

## Scope audit

- No physical-model equations upstream of Stage E are changed.
- No new catalyst kinetics, deactivation law, sorption parameters, RTD parameters, or phase assignments are introduced.
- Stage F qualified outputs are embedded as a prerequisite.
- Stage G targets only the structural full-MWD separation.

## Mathematical audit

The DP repeat-mass correction obeys `alpha_j = repeatM_j/M3`, hence `M2/M3 <= alpha_j <= 1`. With `s_j = 1/(alpha_j Mn_j)`, the detailed second-stage Flory CDF is a weighted expectation of `Q_M(s_j)` and the same-Mn collapse uses `Q_M(sum w_j s_j)`. The difference is therefore exactly a Jensen gap.

The Flory CDF `Q(u)=1-(1+u)exp(-u)` has `Q''(u)=exp(-u)(1-u)`, so it has one inflection at u=1. The lower convex and upper concave envelopes on a finite interval can therefore be constructed by endpoint chords and one tangency per side. `stageG_jensen_gap_u_interval.m` implements this geometry with bracketed bisection.

The enclosing continuous reciprocal-Mn interval is a superset of the exact discrete/support-constrained joint domain. Therefore its Jensen-gap interval is conservative. The finite-grid compatibility pad widens that interval further.

## Independent numerical mirror

The complete 30-row by-T/mode/EPC table was independently reconstructed from the qualified Stage-E matrix curves and the source T80 population-transfer rules. The expected overall minimum certified lower bound is 0.197018411054 decades. The one-population vertex gives an attainable upper bound of 0.214823034765 decades at EPC 0.30.

Five analytic Jensen-envelope unit intervals are also included in `Independent_Audit/StageG_expected_Jensen_selftest.csv`.

## Qualification logic

Stage G requires all G0–G11 gates to pass. A positive bound alone is insufficient; the MATLAB implementation must also reproduce the independent mirror, preserve the Stage-F prerequisite, verify the Jensen primitive, retain the finite-grid pad, and enforce the restricted claim scope.
