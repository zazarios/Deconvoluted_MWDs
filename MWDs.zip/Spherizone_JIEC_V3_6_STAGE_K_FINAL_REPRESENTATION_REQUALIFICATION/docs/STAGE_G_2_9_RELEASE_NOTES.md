# Stage G v2.9 release notes

Stage G is a closure analysis, not a model extension.

### Added
- simultaneous population-weight × latent-chemistry full-MWD robustness audit;
- conservative continuous reciprocal-Mn support enlargement;
- exact Flory-CDF Jensen-gap envelope calculation;
- deterministic W1 lower-bound / attainable-upper-bound brackets;
- primary T80 model-form envelope aggregation;
- G0–G11 executable qualification gates;
- independent 30-row W1 mirror and analytic Jensen self-test.

### Unchanged
All Stage A–F physical equations, source data, composition feasible sets, sorption scenarios, transfer modes, MZCR formulation, Stage-E comparator, and Stage-F information-value analysis.

### Intended endpoint
If G0–G11 pass, the model-development sequence becomes a freeze candidate. Subsequent work should reconstruct the manuscript/SI around the qualified claim set rather than continue adding mechanisms without new experimental evidence.
