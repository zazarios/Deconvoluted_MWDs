# Pre-MATLAB static audit — Stage H.2

## Frozen question
Can a target-specific fixed scalar population representation be selected before the T80 population-transfer branch and hidden within-group state are known, while preserving the Stage-H reporting tolerance over the qualified Stage-G uncertainty domain?

## Anti-cherry-picking rules
- all 52 partitions are evaluated;
- tolerances are inherited unchanged from Stage H;
- partition/descriptor selection may depend on target, EPC, and declared transfer formulation only;
- no T80-branch, hidden weight, or population-specific alpha access is permitted;
- no K is forced if K=5 fails;
- DIRECT and DP remain explicit alternative model formulations;
- no universal cross-target reduced model is claimed.

## Independent precheck
See `Independent_Audit/STAGE_H2_INDEPENDENT_PRECHECK.txt` and the associated mirror CSV files.
