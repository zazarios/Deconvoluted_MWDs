# Stage-E.1 pre-MATLAB static audit

## Frozen scope
- Stage-E phase-wise information-collapsed comparator unchanged.
- No new kinetic constants or catalyst-specific fitting.
- No ICP-specific calibration.
- Same Stage-D marginal uncertainty logic: U_W at C0; U_C at inherited weights.
- No joint U_W x U_C claim.

## Bound logic audit
### U_W
- Full simplex contains every TV ball with delta_W <= 1.
- Weight uncertainty is therefore bounded at the maximal admissible domain rather than at selected radii.
- Pointwise stage-CDF mismatch extrema are enclosed over all simplex edges.
- Continuous edge gaps are covered by an analytic derivative pad.
- DP C0 common-alpha uncertainty is covered by a continuous log-scale Lipschitz pad.

### U_C
- DIRECT_MN_TRANSFER MWD is chemistry-invariant by construction.
- DP_REPEAT_MASS_CORRECTED uses the independent box M2/M3 <= alpha_j <= 1.
- This box is a conservative superset of the exact Stage-D chemistry manifold.

## Numerical safeguards
- Metric grid remains logspace(0,9,6001) g/mol.
- Exact Flory CDF is used inside analytical bound construction.
- A finite-grid CDF pad of 1e-5 per CDF is included; the executable audit samples the full relevant Mn range and requires the observed exact-vs-grid discrepancy to remain below that pad.
- Independent pre-execution W1 lower bounds are bundled and checked at run time.

## Claim discipline
- W1: certified continuous lower bound.
- JS: derived conservative floor from W1; not a materiality threshold.
- M90/M99/tail: magnitude-only context from Stage E; not a global continuous minimum.
- No statistical/confidence interpretation of any radius or bound.
