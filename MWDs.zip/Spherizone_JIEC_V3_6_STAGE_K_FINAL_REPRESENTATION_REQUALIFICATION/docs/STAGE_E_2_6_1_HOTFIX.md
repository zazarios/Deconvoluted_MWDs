# Stage E v2.6.1 hotfix

Observed MATLAB error in v2.6:

`Subscripted assignment between dissimilar structures.`

Root cause: `RefRec=struct([])` and `WorstRec=struct([])` created empty structures with no fields. Direct indexed assignment of a populated metric structure is not schema-compatible in MATLAB.

Changes:
- Added `append_struct_record_E`, which assigns the first record directly and checks field schema before subsequent appends.
- Applied the helper to both `RefRec` and `WorstRec`.
- Added `stageE_struct_append_selftest_E` before the main Stage-E record loops, testing both base metric records and witness-extended records.
- Release identifier changed to `2.6.1-stageE-struct-schema-hotfix`.

Scientific model status: unchanged from v2.6. No equations, source data, uncertainty sets, transfer modes, distribution metrics, external-challenge rules, or qualification tolerances were modified.
