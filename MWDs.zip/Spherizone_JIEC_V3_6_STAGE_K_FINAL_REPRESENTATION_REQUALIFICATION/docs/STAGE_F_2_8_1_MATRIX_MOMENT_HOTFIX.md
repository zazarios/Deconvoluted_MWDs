# Stage F v2.8.1 matrix-moment consistency hotfix

The v2.8 MATLAB run completed the 1,092,630-state Stage-F calculation but failed F2-F4. Audit showed that the executed Stage-F baseline exactly reproduced the qualified Stage-B1 MWD envelopes, whereas the independent mirror used the later Stage-E analytical/high-resolution matrix moments.

This exposed a small inherited numerical inconsistency rather than a scientific disagreement: Stage B1 obtained the matrix moments by numerical integration on the compact export grid, while Stage E reconstructed the same matrix with the full-distribution framework. The compact-grid values are approximately Mn=56,786.33 g/mol and Mw=400,001.58 g/mol; the qualified Stage-E analytical values are approximately Mn=56,535.72 g/mol and Mw=400,000.00 g/mol. The Mn bias is ~0.443%.

Stage F.1 uses the Stage-E analytical matrix moments for all final MWD-moment targets, exports both references in StageF_matrix_moment_consistency.csv, and adds gate F1A. No uncertainty set, source datum, chemistry model, sorption model, transfer model, or value-of-information definition is changed.

Independent Python reconstruction of the complete Stage-F tensor reproduces the existing independent F2-F4 mirror tables with absolute numerical differences at floating-point scale when the Stage-E analytical matrix moments are used. The key data-priority hierarchy is unchanged.
