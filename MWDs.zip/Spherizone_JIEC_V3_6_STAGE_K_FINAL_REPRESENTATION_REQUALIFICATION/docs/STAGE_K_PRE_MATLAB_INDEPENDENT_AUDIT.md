# Stage K pre-MATLAB independent audit

The independent reconstruction uses the frozen source population data and the qualified Stage-J H2/T80 branch definition. No external challenge datum is fitted.

## Final state support
- NO_ADDED_H2_BOUNDARY: 6 admissible T80 states
- CONTROLLED_2MOL_H2_STRESS: 6 admissible T80 states
- LEGACY_5MOL_H2: 5 admissible T80 states
- Total: 17 states

The legacy five Stage-H T80 states are an exact subset of the final support.

## Why J.1 chemistry does not require a second molecular-weight-scale expansion
Stages H/H.1/H.2 already permit each DP repeat-mass factor independently over alpha_j in [28.05/42.08, 1] = [0.6665874525, 1]. This is the complete ethylene-to-propylene repeat-mass interval and contains every J.1 E/P composition realization. Stage K therefore expands H2/T80 support only.

## Predicted MODERATE oracle changes relative to frozen Stage H
- EPC 0.10: Mw 3 -> 4; D 3 -> 4. Other targets unchanged.
- EPC 0.20: matrix-M90 tail 2 -> 3. Other targets unchanged.
- EPC 0.30: Mw 4 -> 5; D 4 -> 5; matrix-M90 tail 2 -> 3. Other targets unchanged.
- W1 orders are predicted to remain 3, 5, 5 for EPC 0.10, 0.20, 0.30.

## Predicted MODERATE H.1 changes
Only the EPC-0.20 matrix-M90-tail row is predicted to change: K=2 -> 3. The other moderate H.1 rows are predicted to retain their frozen status/order.

## Predicted MODERATE H.2 result
The frozen H.2 moderate map is predicted to remain unchanged: no T80-global fixed-scalar closure for Mn, Mw, D, W1, or matrix-M90 tail at any EPC; matrix-M99 tail remains K=1 at EPC 0.10, 0.20, and 0.30.

These are independent pre-run expectations, not qualified results. The Stage-K MATLAB executable and K0-K22 gates are authoritative.
