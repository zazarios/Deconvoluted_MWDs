# Stage-E pre-MATLAB static audit

## Frozen scientific scope
- No new catalyst-specific kinetic parameters.
- No ICP-specific fitting.
- No change to Stage-D.1 uncertainty coordinates or critical radii.
- No chemical identity assigned to numerical Flory population labels.
- No industrial-validation claim.

## Comparator audit
The Stage-E final comparator is phase-wise information collapse, not an overall one-Flory grade surrogate. Matrix and second-stage Mn values and EPC mass fraction are preserved. This prevents phase blending itself from being mislabeled as retained multi-population information.

## Witness-selection audit
Adverse cases are selected by the prior Stage-B2 minimum-DeltaD objective. Stage-E W1/JS values cannot influence which adverse cases are chosen.

## Numerical audit design
- Full MWD metric grid: 6001 logarithmic points from 1 to 1e9 g/mol.
- Each density is renormalized in log10(M).
- Numerical Mn/Mw are checked against analytical moments.
- Final resolved and phase-wise collapsed distributions must have identical analytical Mn.
- Reconstructed adverse-witness DeltaD values must regress to Stage-B2 envelope minima within 1e-10 relative tolerance.

## Independent equation-mirror precheck
`Independent_Audit/` contains expected Stage-B2 adverse witnesses, EX1-source distribution metrics, and the source-supported H2 moment trend calculated independently of the MATLAB Stage-E implementation.

## External challenge scope
Yang et al. (2026), DOI 10.1021/acs.iecr.6c02664, supports a multisite MMD structural comparator and qualitative H2 distribution-shift challenge. It does not contain the present phase-wise collapsed comparator or W1/JS retention metric. The FBR ethylene-ratio perturbation is not directly comparable to fixed-EPC conditioning.

## Known unresolved question
Whether the minimum Stage-E W1/JS signal across the adverse witnesses is scientifically large enough to justify a manuscript-level 'information retention' statement is intentionally not hard-coded. That judgment is made only after executable results are inspected.
