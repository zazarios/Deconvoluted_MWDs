# Stage J.1 package static audit

- Base package: qualified Stage-J v3.4.4 Stage-I prerequisite hotfix.
- Inherited files checked byte-for-byte before packaging: **362 identical; 0 changed; 0 missing**, excluding the intentionally updated top-level `README.md`, `VERSION.txt`, and regenerated manifests.
- Qualified Stage-J output prerequisite embedded under `inputs/StageJQualifiedOutputs`: **22/22 J0-J20 gates PASS**.
- J.1 support construction reads only Zhang et al. 2021 mechanistic kinetic evidence plus frozen model inputs.
- Held-out Stage-J external evidence is read only after the J.1 support, legacy/high-E/P composition tensors, bulk intervals, critical-support audit, and VOI tensors are constructed.
- No Cancelas/Botha/Wang numerical challenge value is present in `stageJ1_config.m` or the J.1 chemistry scenario generator.
- Expected source audit: apparent `kpE/kpP` 2.189781...30.158730; maximum within-condition contrast 13.772487.
- Primary outward-rounded support: kappa 2...32; contrast cap 16.
- Independent mirrors are included for support/domain extrema, mechanistic critical-kappa crossings, union VOI, and mechanistic-only VOI.
- MATLAB execution remains authoritative. The pre-MATLAB mirrors are qualification expectations, not substituted results.
