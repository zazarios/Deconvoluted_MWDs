# Pre-MATLAB static audit — Stage H

- New physical parameters: **none**.
- New catalyst-site identities: **none**; labels 1–5 remain MWD populations.
- Stage-G uncertainty domain preserved: **yes**.
- All five primary T80 scenarios retained: **yes**.
- All set partitions of five labels: expected Bell number 52, Stirling counts `[1,15,25,10,1]`.
- Merge rule pre-specified: mass + reciprocal-Mn conservation.
- Target-specific partition allowed: **yes**, but only after uncertainty maximization.
- State-specific partition allowed: **no**.
- State-specific group mass/harmonic-Mn projection: **yes, explicitly oracle/informed by the detailed state**; therefore Stage H is not yet an operational reduced model.
- Tolerance bands chosen after results: **no**.
- W1 passive matrix-retention artifact: removed algebraically because common matrix cancels.
- Quantile diagnostics used for K*: **no**.
- K* claimed when lower/upper order bounds disagree: **no**.
- Independent numerical mirror supplied: `Independent_Audit/StageH_expected_target_minimax_summary.csv`.
