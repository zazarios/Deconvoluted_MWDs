# Stage-D pre-MATLAB static audit

## 1. Exactness of U_W bounds
For fixed per-population coefficients `c_j`, Stage D solves

`min/max sum_j c_j w_j`

subject to `w>=0`, `sum(w)=1`, and `TV(w,w0)<=delta`.

For the maximum, probability mass is removed from the lowest-`c` populations and transferred to a maximum-`c` population until either the TV budget is exhausted or all mass lies on the maximum-coefficient support. The minimum is the reverse. This is the exact solution of the linear program and requires no optimization toolbox.

The following model quantities reduce to linear functionals of the uncertain second-stage population weights for fixed model state:

- stage `1/Mn = sum(w_j/Mn_j)`;
- stage `Mw = sum(w_j*2Mn_j)`;
- stage ethylene weight fraction `sum(w_j*C2_j)`.

Final blend `Mn`, `Mw`, and total C2 are obtained monotonically from those exact stage bounds. Final `D` in the U_W output is deliberately reported only as a conservative outer interval because separately optimized `Mn` and `Mw` need not occur at the same uncertain weight vector.

## 2. Continuous U_C construction
The prior chemistry endpoint library is written as log-odds directions `z_j`. Stage D introduces

`m_j(rho)=exp(rho*log(2)*z_j)`, `0<=rho<=1`.

Thus `rho=0` is homogeneous response and `rho=1` exactly reconstructs the previous C0/C1/C2 factor-two library. All 30 permutations of `[-1,-1,0,1,1]`, both ordered directions, and the homogeneous direction are retained.

## 3. Required endpoint regressions
- U_W at `delta=0` must reproduce U_C at `rho=0` for the same C0/W0 marginal model.
- U_C at `rho=1` must reproduce Stage-B2 `W0_INHERITED` `Mn/Mw/C2` endpoint envelopes.
- V0-V8 preflight must remain PASS.

## 4. Interpretation
`delta_W` and `rho_C` are deterministic robustness coordinates. They are not posterior probabilities, standard deviations, or confidence levels. Stage D produces partial-identification envelopes and critical-radius brackets only.

## 5. Computational scope
U_W varies weights continuously at homogeneous C0 chemistry while retaining the primary temperature, sorption, and EX2-reactivity sets. U_C holds inherited weights while varying chemistry amplitude continuously. Stage B2 remains the joint endpoint stress test. No arbitrary probabilistic coupling between the two epistemic coordinates is introduced.
