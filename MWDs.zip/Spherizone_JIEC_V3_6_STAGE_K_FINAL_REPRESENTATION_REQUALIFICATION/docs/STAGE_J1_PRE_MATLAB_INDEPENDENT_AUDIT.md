# Stage J.1 pre-MATLAB independent reconstruction audit

The independent reconstruction mirrors the J.1 equations without using the held-out Cancelas/Botha/Wang values to construct the chemistry support.

## Mechanistic source audit
From Zhang et al. (2021) SI Tables S8-S9 at E/P = 40/60 and 50/50:

- minimum apparent `kpE/kpP` = **2.1897810219**;
- maximum = **30.1587301587**;
- maximum within-condition three-class contrast = **13.7724867725**.

The primary J.1 support `[2,32]`, contrast cap `16`, is an outward power-of-two enclosure.

## Expected composition-domain results
- high-E/P mechanistic branch: **0.047834685 to 0.827849286** stage C2 mass fraction;
- frozen Stage-J legacy branch: **0.019993364 to 0.070009709**;
- final set union: **0.019993364 to 0.827849286**.

The source-tight homogeneous bounds using 2.189781...30.158730 are expected to remain close to the rounded result (approximately 0.0519 to 0.8165), so held-out coverage is not created by the outward rounding alone.

## Expected final bulk-C2 intervals
For a pure-PP matrix bookkeeping identity `wC2_bulk = EPC * wC2_stage`:

- EPC 10 wt%: approximately **0.00200 to 0.08278**;
- EPC 20 wt%: approximately **0.00400 to 0.16557**;
- EPC 30 wt%: approximately **0.00600 to 0.24835**.

All three intervals are expected to overlap pairwise over the final J.1 domain.

## Mechanistic-only nested-support diagnostic
Holding the mechanistic lower support at kappa=2 and expanding only the upper support:

- EPC 10→20 crossing: **kappa_upper ≈ 2.08811235**;
- EPC 10→30 crossing: **kappa_upper ≈ 2.93803971**;
- EPC 20→30: overlap already at kappa_upper=2.

These are deterministic support-width coordinates, not fitted kinetic constants.

## Expected composition VOI
Final union, singleton guaranteed contraction:

- high-E/P chemistry model/state: **~36.48%**;
- FBR sorption: **~0.64%**;
- EX2 sorbed f1: **~0.62%**;
- H2/T80 state: approximately **0%**;
- reactivity-curve coordinate alone: **0%**.

Within the mechanistic branch, resolving the high-E/P reference selectivity level is expected to guarantee about **20.72%** contraction, whereas resolving the population-pattern coordinate alone gives **0%** worst-case guarantee because the unresolved global selectivity level dominates.

## Interpretation
If the executable reproduces these results, J.1 will not yield a unique high-E/P composition prediction. It will instead replace an externally underinclusive chemistry domain with a literature-anchored, explicitly set-valued domain while preserving Stage J as a subset. Held-out coverage is an external consistency result, not validation.
