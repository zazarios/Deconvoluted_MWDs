# Stage F pre-MATLAB static audit

## Scientific scope
Stage F is a **prospective deterministic set-based information audit**, not a Bayesian or economic expected-value-of-information calculation. The primary output is the worst-case residual partial-identification width after one or more epistemic blocks are treated as exactly resolved. This is an oracle upper bound on the value of a real finite-precision experiment.

## Factorization audit
The refined Stage-B1 L3 ensemble factorizes as:
- 5 admissible T80 population-transfer scenarios;
- 2 source-motivated FBR sorption scenarios;
- 33 endpoint latent-chemistry scenarios;
- 11 EX2 sorbed-f1 anchors;
- 301 coordinates along each exact EX2-conditioned reactivity curve.

The expected tensor therefore contains 1,092,630 states. The MATLAB implementation verifies rectangular EX2 factorization before allocating the target tensors.

## Minimax contraction
For a resolved block subset R and target Y, Stage F computes, for every possible realized state of R, the width of Y over all unresolved blocks. The reported residual width is the maximum of those conditional widths. Thus

`GuaranteedContraction = 1 - worst_residual_width / baseline_width`.

No state weights or probabilities are used.

## Reactivity-coordinate caveat
`REACTIVITY_CURVE_COORD` is not presented as a standalone directly measurable parameter. The existing EX2 composition plus an independently measured EX2 sorbed f1 leaves a one-dimensional effective `(r1,r2)` curve. A second RCP composition at a distinct independently known sorbed f1 generically supplies the second equation. Stage F therefore treats reactivity-coordinate resolution as conditional on EX2 sorption characterization and separately exports the two-equation condition number.

## Independent precheck
An independent Python mirror reconstructs the complete 1,092,630-state composition and DP-MWD-moment tensors. Expected baseline ranges, all singleton contractions, best cardinality frontiers, minimum exact subsets, and second-RCP conditioning diagnostics are embedded under `Independent_Audit/` and are used only as executable regression targets.

## Claim guard
Even if Stage F qualifies, it does not create experimental validation. Direct bulk-C2 or full-ICP-MWD measurements are classified separately as local calibration/validation outputs and must not be counted as independent validation if used for fitting.
