# Implementation notes — v2.0 Stage A

## Deliberate separations

1. **Flory populations are mathematical MWD populations.** They are not assigned chemical site identities.
2. **Primary MWD transfer is bracketed only.** There is no hidden nearest-neighbour extrapolation.
3. **80 °C is model-form uncertainty.** The code returns boundary-hold plus matched 10 °C empirical-slope scenarios.
4. **Absolute throughput is outside the primary model.** The generic PFR supports a nuisance absolute rate scale only for gas-depletion and unit/mass-balance qualification.
5. **EX2 does not identify a unique pair of reactivity ratios.** The exact feasible curve is returned for a specified sorbed propylene fraction.
6. **Second-stage amount is conditioned.** EPC = 10/20/30 wt% are primary design scenarios; 40 wt% is a stress case.
7. **RTD does not alter normalized properties in the current conditional steady-property mode.** It is retained explicitly as a model-form dimension; a zero RTD contribution is an admissible result rather than an invented kinetic effect.

## Working values versus scientific constants

The Stage-A configuration contains a few values used only to exercise code paths, such as a synthetic PFR nuisance rate scale and an EX2 qualification sorbed propylene fraction. They are marked `qualification_only` and must not be cited as model parameters.

## Source equations currently encoded

- Flory most-probable weight density on log10(M): Soares methodology.
- Propylene-in-iPP ternary correlation: Kulajanpeng et al. 2025 SI, Eq. S16.
- Ethylene-in-RCP low-ethylene ternary correlation: Kulajanpeng et al. 2025 SI, Eq. S18, with strict domain flags.
- High-E/P FBR sorption: no unique correlation is asserted. Gas-composition baseline and 4×/5× propylene-vs-ethylene solubility selectivity stress scenarios are returned as model-form conditions, motivated by the experimental/literature context, not as catalyst-specific equilibrium constants.
