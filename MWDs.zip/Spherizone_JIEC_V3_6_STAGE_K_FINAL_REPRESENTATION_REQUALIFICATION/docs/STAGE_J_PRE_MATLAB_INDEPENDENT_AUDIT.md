# Stage J pre-MATLAB independent audit

An independent numerical mirror was constructed outside the MATLAB Stage-J implementation before package release. It reimplemented only the low-level equations required for the Stage-J challenge:

- source population interpolation and the existing matched-pair T80 envelope rules;
- EX2 source-domain sorption anchor and feasible Mayo–Lewis surface;
- latent population odds perturbations;
- second-stage C2 calculation;
- Stage-G Flory-CDF Jensen-envelope W1 bound using the frozen matrix MWD curve.

The mirror did not call the new Stage-J MATLAB functions.

## Expected composition challenge

For the union of no-added-H2, controlled 2 mol% H2, and legacy 5 mol% H2 branches, the independently reconstructed second-stage C2 ranges are:

| maximum nested odds span | stage C2 range |
|---:|---:|
| 2 | 0.0199934–0.0700097 |
| 4 | 0.0199934–0.1428055 |
| 8 | 0.0199934–0.2762408 |
| 16 | 0.0199934–0.4337432 |
| 32 | 0.0199934–0.5478383 |

Against the held-out 0.238–0.378 stage/rubber-rich challenge envelope:

- first overlap occurs at maximum odds span 8;
- full envelope containment occurs at maximum odds span 16;
- all three matched-nominal-EPC Cancelas bulk-C2 points (0.051, 0.083, 0.126) are covered only at maximum odds span 32 because EPC = 0.10 is limiting.

These thresholds are stress-domain diagnostics, not fitted chemistry estimates.

## Expected structural W1 challenge

The independent mirror predicts that adding the no-added-H2 and controlled-2-mol%-H2 branches does **not** reduce the Stage-G global worst-case W1 lower bound below the frozen legacy result. The legacy 5 mol% H2 branch remains worst in the mirror:

- global union lower bound: 0.197018411 decades;
- attainable vertex upper bound: 0.214823035 decades;
- worst case: DP repeat-mass correction, EPC = 0.30.

Therefore the pre-MATLAB expectation is that structural full-MWD separation survives the Stage-J H2/T80 challenge, while the old high-E/P composition domain does not.

The executable MATLAB result remains authoritative for package qualification. `StageJ_verification.csv` compares the MATLAB outputs with the independent expected tables in `Independent_Audit/`.
