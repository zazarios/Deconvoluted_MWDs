# Stage B scientific notes

## Why EX2 is now a surface, not a curve

Stage A used `f1_sorbed_qualification = 0.855` only to verify the algebra of the
EX2 feasible manifold. That value came from the legacy thermodynamic treatment and
is not admissible as a final scientific constant.

The simple Kulajanpeng RCP correlations are documented for reactive ethylene fractions
of approximately 0.08-0.09, not the 0.05 EX2 recipe. Stage B therefore does not
extrapolate the correlation to EX2. It scans the documented source domain and uses the
resulting sorbed-propylene range only as an epistemic anchor. The EX2 condition then
constrains a set of `(f1_EX2, r1, r2)` points that all reproduce 3.00 wt% ethylene.

This is deliberately conservative and prevents a hidden thermodynamic assumption from
collapsing the non-identifiability.

## Primary vs stress screens

The primary r-screen is the pre-specified Stage-A screening window. An expanded screen
also covers the very different effective reactivity-ratio exemplars used by Yang et al.
(2026) and fitted by Zhang et al. (2025). The expanded screen is a stress test only; the
literature values are not transferred as constants for the Alshaiban catalyst.

## Expected interpretation

Stage B is allowed to conclude that MWD propagation is structurally robust while
composition is non-identifiable. Such a result is scientifically admissible under the frozen
specification and should not be hidden by narrowing scenario assumptions after seeing the
results.
