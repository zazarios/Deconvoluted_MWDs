# Stage B2 pre-MATLAB static audit

A separate Python mirror of the Stage-B2 algebra was used before packaging to identify expected order-of-magnitude results. These are **diagnostic expectations**, not authoritative outputs; MATLAB remains the executable qualification target.

Under the refined primary T80 and sorption scenarios, the 33 chemistry-response patterns, and an independent 33-pattern factor-two population-weight stress, the mirror gives approximately:

## DIRECT_MN_TRANSFER
- EPC 10%: Mn 38.0–56.6 kg/mol; Mw 365.0–398.3 kg/mol; D 6.78–9.70.
- EPC 20%: Mn 28.6–56.7 kg/mol; Mw 330.0–396.6 kg/mol; D 6.48–11.78.
- EPC 30%: Mn 22.9–56.8 kg/mol; Mw 295.1–394.9 kg/mol; D 6.18–13.30.
- Minimum multisite minus same-final-Mn single-Flory D remains positive, approximately 4.18 or larger.

## DP_REPEAT_MASS_CORRECTED
- EPC 10%: Mn 37.3–56.6 kg/mol; Mw 364.9–398.1 kg/mol; D 6.78–9.87.
- EPC 20%: Mn 27.8–56.6 kg/mol; Mw 329.7–396.1 kg/mol; D 6.48–12.07.
- EPC 30%: Mn 22.2–56.6 kg/mol; Mw 294.6–394.2 kg/mol; D 6.17–13.70.
- Minimum multisite minus same-final-Mn single-Flory D remains positive, approximately 4.17 or larger.

## Composition
The independent population-weight stress expands the second-stage C2 fraction to roughly 1.48–8.25 wt%, giving total-product C2 envelopes of approximately:
- EPC 10%: 0.15–0.83 wt%
- EPC 20%: 0.30–1.65 wt%
- EPC 30%: 0.44–2.48 wt%

The diagnostic expectation is therefore that structural multisite broadening survives, while quantitative EPC grade separation becomes still less identifiable.
