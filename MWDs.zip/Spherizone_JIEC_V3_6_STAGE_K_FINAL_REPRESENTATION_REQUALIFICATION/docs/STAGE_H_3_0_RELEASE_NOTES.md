# Stage H v3.0 release notes

Stage H deliberately reopens the previously frozen A–G model lineage for one narrowly defined scientific question: target-aware population-order sufficiency.

Changes relative to v2.9:

- adds no physical mechanism or fitted kinetic parameter;
- preserves the qualified Stage-G joint uncertainty domain;
- enumerates every set partition of the five resolved MWD populations;
- defines a unique non-fitted merge rule that conserves mass and reciprocal-Mn;
- computes target-specific minimax reduction-error bounds;
- introduces pre-specified tolerance bands and K* brackets;
- explicitly removes passive matrix retention from the reduction-loss metric;
- adds reference-only quantile diagnostics that cannot influence K*;
- retains all previous A–G files and qualified outputs for traceability.

Stage H does not change the Stage-F identifiability conclusions or Stage-G structural-retention bounds. It asks a new representation-sufficiency question built on those qualified results.
