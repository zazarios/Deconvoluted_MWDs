# Stage D.1 pre-MATLAB static audit

## Scope
Stage D.1 is a hardening patch to Stage D only. It does not alter the population source data, Stage-B/B1/B2 uncertainty sets, transfer modes, EX2 feasible set, sorption scenarios, or Stage-C claim restrictions.

## Changes audited
1. Added bisection refinement for rows already classified by Stage D as `CRITICAL_RADIUS_BRACKETED`.
2. Added explicit semantic classification for U_W/C2 invariance under homogeneous C0 chemistry.
3. Clarified `rho_C=1`, `span=2` as per-population multipliers 0.5–2 and a maximum/minimum contrast of 4.
4. Added executable hardening gates H1–H5.

## Independent numerical reproduction
An independent equation mirror reproduced the audited Stage-D coarse margins to numerical roundoff. The maximum absolute discrepancies at the eight crossing-defining coarse points were approximately 5e-12 for Mw margins and 1.5e-17 for C2 margins.

Expected refined thresholds at radius tolerance 1e-6 are stored under `Independent_Audit/`.

## Interpretation constraints
- Critical radii are deterministic robustness coordinates, not confidence intervals.
- The U_W/C2 flat curve under C0 is a model-structural invariance, not evidence that real downstream composition is insensitive to population redistribution.
- Direct-transfer MWD invariance to U_C is also a property of that transfer assumption and must not be generalized to real copolymerization chemistry.
- Stage D.1 does not provide industrial or pilot-plant validation.

## Execution requirement
Run `Run_JIEC_V2_StageD1_Hardening.m` in MATLAB. Stage E should be unlocked only if V0–V8, the Stage-D endpoint regression, and hardening gates H1–H5 all pass and the four refined crossing rows agree with the independent audit within the configured radius tolerance.
