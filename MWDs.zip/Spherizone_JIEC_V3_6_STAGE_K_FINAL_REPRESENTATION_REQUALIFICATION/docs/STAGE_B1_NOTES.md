# Stage B1 — coupled-property / identifiability audit

This stage was added after independent review of `JIEC_V2_STAGE_B_OUTPUTS.zip`.
It does **not** discard Stage B; it tests whether the Stage-B verdict survives four stricter corrections.

1. **EX2 source-domain anchor:** fixed at the actual 70 °C conditioning temperature. The documented propylene/propane ratio (77:23–80:20) is explicitly enforced when using the propylene correlation. The 5 mol% EX2 recipe itself is still not extrapolated through the low-C2 correlation.
2. **Primary FBR sorption:** source-motivated C3/C2 selectivity 4–5 only. The selectivity=1 gas-composition case is retained as stress-only because it dominates the old maximum composition envelope and is not an equilibrium model.
3. **MWD/composition coupling:** compare direct transfer of PP-derived population Mn with a degree-of-polymerization transfer interpretation, `DPn = Mn_PP/M_C3`, followed by repeat-mass correction using each scenario's predicted copolymer composition. This is not a full kinetic model; it is an explicit transfer-model-form audit.
4. **RTD:** in fixed-EPC conditional-property mode, no residence-time-dependent yield/chain-growth/deactivation law is identified. RTD is therefore declared quantitatively inactive rather than reported as a robustness result.

The Stage-B1 verdict deliberately separates:
- structural multisite MWD broadening,
- quantitative EPC-to-MWD grade separation,
- total-C2 identifiability.

Run:

```matlab
Run_JIEC_V2_StageB1_CoupledAudit
```

Upload `JIEC_V2_STAGE_B1_OUTPUTS.zip` for independent audit.
