% Run_JIEC_V3_StageJ_ExternalPhysicalConsistencyChallenge.m
clear;clc;ROOT=fileparts(mfilename('fullpath'));addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageJ');if exist(outdir,'dir'),rmdir(outdir,'s');end;mkdir(outdir);cfg=stageJ_config();
fprintf('[JIEC v3.4.4 Stage J] External physical-consistency challenge\n');
fprintf('Release: %s\n',cfg.release);
fprintf('External industrial/pilot/controlled hiPP evidence is held out as challenge data; no external fitting is performed.\n');
fprintf('Challenge 1: FBR H2/T80 branch. Challenge 2: high-E/P composition domain. Challenge 3: structural W1 survival.\n\n');
result=run_stageJ_external_physical_consistency(cfg,outdir);
V=verify_stageJ_external_physical_consistency(cfg,outdir,result);allPass=all(strcmp(V.Status,'PASS'));

U=result.W1Closure(strcmp(result.W1Closure.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);
R=result.Ranges(result.Ranges.ChemistryOddsSpan==cfg.site_response.odds_span & strcmp(result.Ranges.H2BranchScope,'UNION_ALL_H2_BRANCHES'),:);
Th=result.Thresholds;
if result.StructuralSurvives && result.OldCompositionDomainCovers
    verdict='STAGE_J_EXTERNAL_PHYSICAL_CONSISTENCY_QUALIFIED__STRUCTURAL_AND_COMPOSITION_CHALLENGES_COMPATIBLE_WITHIN_DECLARED_PROXY_SCOPE';
elseif result.StructuralSurvives
    verdict='STAGE_J_EXTERNAL_PHYSICAL_CONSISTENCY_QUALIFIED__STRUCTURAL_W1_SURVIVES__HIGH_EP_COMPOSITION_DOMAIN_REQUIRES_REDEVELOPMENT';
else
    verdict='STAGE_J_EXTERNAL_PHYSICAL_CONSISTENCY_QUALIFIED__STRUCTURAL_W1_NOT_CERTIFIED_OVER_EXPANDED_H2_T80_SET__MODEL_REDEVELOPMENT_REQUIRED';
end
fid=fopen(fullfile(outdir,'STAGE_J_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v3.4.4 Stage-J Stage-I prerequisite hotfix\n');
fprintf(fid,'All executable Stage-J integrity/scope gates pass: %d\n',allPass);
fprintf(fid,'External data fitted to model: NO\n');
fprintf(fid,'Matched independent Spherizone validation claimed: NO\n');
fprintf(fid,'Legacy odds-span=2 union stage-C2 range: %.9f to %.9f wt fraction\n',R.StageC2Min,R.StageC2Max);
fprintf(fid,'External rubber-rich/copolymer challenge envelope: %.3f to %.3f wt fraction\n',cfg.StageJ.external_stage_C2_challenge(1),cfg.StageJ.external_stage_C2_challenge(2));
fprintf(fid,'Minimum nested chemistry span for any external stage overlap: %g\n',Th.MinimumSpanForAnyExternalStageOverlap);
fprintf(fid,'Minimum nested chemistry span for full external stage-envelope containment: %g\n',Th.MinimumSpanForFullExternalStageEnvelopeContainment);
fprintf(fid,'Minimum nested chemistry span covering all matched-EPC Cancelas bulk points: %g\n',Th.MinimumSpanCoveringAllCancelasBulkPoints);
fprintf(fid,'Expanded-H2/T80 global certified W1 lower bound: %.12f decades\n',U.Global_W1_certified_joint_lower_decades);
fprintf(fid,'Expanded-H2/T80 attainable-vertex upper bound: %.12f decades\n',U.Global_W1_attainable_vertex_upper_decades);
fprintf(fid,'Structural W1 survival: %d\n',result.StructuralSurvives);
fprintf(fid,'Legacy composition domain externally challenge-compatible: %d\n',result.OldCompositionDomainCovers);
fprintf(fid,'H/H.1/H.2 expanded-H2 order-map requalification performed in Stage J: NO\n');
fprintf(fid,'Verdict: %s\n',verdict);
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V3_STAGE_J_OUTPUTS.zip');if exist(zipfile,'file'),delete(zipfile);end;zip(zipfile,{'Outputs_StageJ'},ROOT);
if ~allPass,error('Stage-J executable verification failed. Inspect StageJ_verification.csv.');end
fprintf('\n[JIEC v3.4.4 Stage J] COMPLETE\n');
fprintf('Verdict: %s\n',verdict);
fprintf('Upload: %s\n',zipfile);
