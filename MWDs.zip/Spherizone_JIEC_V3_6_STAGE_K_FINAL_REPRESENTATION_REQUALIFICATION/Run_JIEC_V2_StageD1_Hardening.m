% Run_JIEC_V2_StageD1_Hardening.m
% One-button Stage-D.1 critical-radius refinement and semantic hardening.
clear; clc;
ROOT=fileparts(mfilename('fullpath'));
addpath(genpath(ROOT));
outdir=fullfile(ROOT,'Outputs_StageD1');
if exist(outdir,'dir'), rmdir(outdir,'s'); end
mkdir(outdir);
cfg=default_config();

fprintf('[JIEC v2.5.1 Stage D.1] Critical-radius refinement and semantic hardening\n');
fprintf('Release: %s\n',cfg.release);

% Re-run the same Stage-D executable qualification into the D.1 output tree.
preflightDir=fullfile(outdir,'Preflight'); mkdir(preflightDir);
report=verify_all(cfg,preflightDir);
writetable(report,fullfile(outdir,'StageD_preflight_verification.csv'));
required=ismember(report.Gate,{'V0','V1','V2','V3','V4','V5','V6','V7','V8'});
preflightPass=all(strcmp(report.Status(required),'PASS'));
if ~preflightPass, error('Stage-D.1 preflight failed.'); end

tvtest=verify_stageD_tv_solver();
writetable(tvtest,fullfile(outdir,'StageD_TV_solver_unit_test.csv'));
if ~tvtest.Pass(1), error('Stage-D TV solver unit test failed.'); end

stageCStatus=fullfile(ROOT,'inputs','StageCOutputs','STAGE_C_STATUS.txt');
if ~exist(stageCStatus,'file'), error('Embedded Stage-C status file is missing.'); end
stageCText=fileread(stageCStatus);
if isempty(strfind(stageCText,'V9_PASS_WITH_SCOPE_RESTRICTIONS')) || ...
        isempty(strfind(stageCText,'GO_FOR_JIEC_RECONSTRUCTION_WITH_NARROW_STRUCTURAL_AND_IDENTIFIABILITY_CLAIMS')) %#ok<STREMP>
    error('Embedded Stage-C qualification is not the expected passed-with-restrictions state.');
end

verdictD=run_stageD_continuous_partial_identification(cfg,outdir);
if ~verdictD.RegressionPass, error('Stage-D regression failed inside D.1.'); end
R=refine_stageD_critical_radii_D1(cfg,outdir);
H=verify_stageD1_hardening(cfg,outdir,R);
hardeningPass=all(strcmp(H.Status,'PASS'));
if ~hardeningPass, error('Stage-D.1 hardening verification failed.'); end

fid=fopen(fullfile(outdir,'STAGE_D1_STATUS.txt'),'w');
fprintf(fid,'Spherizone JIEC v2.5.1 Stage-D.1 hardening\n');
fprintf(fid,'Preflight V0-V8 pass: %d\n',preflightPass);
fprintf(fid,'Stage-D endpoint regression pass: %d\n',verdictD.RegressionPass);
fprintf(fid,'D.1 hardening gates pass: %d\n',hardeningPass);
fprintf(fid,'Refined genuine crossings: %d\n',sum(R.RefinementApplied));
fprintf(fid,'U_W/C2 invariance under C0 is structural by construction, not empirical robustness.\n');
fprintf(fid,'rho_C=1 means per-population multipliers 0.5..2 for span=2; maximum-to-minimum contrast is 4.\n');
fprintf(fid,'Verdict: STAGE_D1_HARDENING_QUALIFIED__PROCEED_TO_STAGE_E\n');
fclose(fid);

zipfile=fullfile(ROOT,'JIEC_V2_STAGE_D1_OUTPUTS.zip');
if exist(zipfile,'file'), delete(zipfile); end
zip(zipfile,{'Outputs_StageD1'},ROOT);
fprintf('\n[JIEC v2.5.1 Stage D.1] COMPLETE\n');
fprintf('Verdict: STAGE_D1_HARDENING_QUALIFIED__PROCEED_TO_STAGE_E\n');
fprintf('Upload this file for independent audit:\n  %s\n',zipfile);
