function data = data_source_whole_moments()
%DATA_SOURCE_WHOLE_MOMENTS Whole-polymer GPC values reported beside the
% deconvolved Flory populations in the peer-reviewed Alshaiban & Soares
% papers. These values are independent diagnostics; they are NOT used to
% alter or refit the published population descriptors.
%
% 60/70 C: Macromol. React. Eng. 2013, 7, 135-145, Tables 3-4.
% 55/65 C: Macromol. React. Eng. 2014, 8, 723-735, Tables 5-6.
%
% Note: the published 60_D row is internally inconsistent: its listed
% population weights/Mn imply a much larger whole-polymer Mw than the
% reported whole-polymer Mw. This code deliberately preserves both
% published quantities and flags the discrepancy rather than silently
% correcting either one.

records = {
'60_D',      34000, 130000, 3.7;
'60_0',      29000, 150000, 5.1;
'60_DH',     17000,  91000, 5.3;
'60_H',      15000,  72000, 4.5;
'70_D',      84000, 500000, 5.9;
'70_0',      14000,  73000, 5.3;
'70_DH',     28000,  96000, 3.5;
'70_H',       9000,  33000, 3.5;
'55_0505',   26000, 140000, 5.3;
'55_052H',   20000, 130000, 6.2;
'55_2D05',   29000, 160000, 5.6;
'55_2D2H',   24000, 140000, 5.9;
'65_0505',   28000, 160000, 5.7;
'65_052H',   19000, 110000, 5.6;
'65_2D05',   30000, 150000, 5.2;
'65_2D2H',   22000, 140000, 5.1;
};

n=size(records,1);
data=repmat(struct('id','','Mn_reported_gmol',NaN,'Mw_reported_gmol',NaN,'D_reported',NaN),1,n);
for k=1:n
    data(k).id=records{k,1};
    data(k).Mn_reported_gmol=records{k,2};
    data(k).Mw_reported_gmol=records{k,3};
    data(k).D_reported=records{k,4};
end
end
