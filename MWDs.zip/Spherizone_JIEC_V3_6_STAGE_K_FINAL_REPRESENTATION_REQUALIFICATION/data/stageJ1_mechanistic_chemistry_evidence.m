function T = stageJ1_mechanistic_chemistry_evidence()
%STAGEJ1_MECHANISTIC_CHEMISTRY_EVIDENCE High-E/P kinetic source evidence.
% Transcribed from Zhang et al. 2021 Supporting Information Tables S8-S9.
% Only E/P=40/60 and 50/50 are used because they bracket the nominal FBR
% reactive ethylene fraction. These data define a model-form support envelope;
% they are not transferred catalyst-specific kinetic parameters.

Donor = {'CHMDMS';'CHMDMS';'CHMDMS';'CHMDMS';'CHMDMS';'CHMDMS'; ...
         'DCPDMS';'DCPDMS';'DCPDMS';'DCPDMS';'DCPDMS';'DCPDMS'};
E_feed_fraction = [0.40;0.40;0.40;0.50;0.50;0.50; 0.40;0.40;0.40;0.50;0.50;0.50];
CenterClass = {'C8_sol';'C7_sol';'C7_insol';'C8_sol';'C7_sol';'C7_insol'; ...
               'C8_sol';'C7_sol';'C7_insol';'C8_sol';'C7_sol';'C7_insol'};
kpE_Lmol_s = [290;310;190;270;300;160; 310;300;190;280;310;220];
kpP_Lmol_s = [87;130;6.8;99;29;7.3; 93;137;6.3;103;55;11.2];
kpE_over_kpP = kpE_Lmol_s./kpP_Lmol_s;
Source = repmat({'Zhang et al. 2021'},12,1);
DOI = repmat({'10.1021/acs.iecr.1c00104'},12,1);
EvidenceRole = repmat({'MECHANISTIC_SUPPORT_ONLY_NOT_PARAMETER_TRANSFER'},12,1);
T=table(Source,DOI,Donor,E_feed_fraction,CenterClass,kpE_Lmol_s,kpP_Lmol_s,kpE_over_kpP,EvidenceRole);
end
