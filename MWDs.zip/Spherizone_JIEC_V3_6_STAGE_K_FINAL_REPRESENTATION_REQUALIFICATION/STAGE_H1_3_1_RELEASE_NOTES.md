# v3.1 Stage H.1 release notes

- Adds state-independent target-minimax scalar group descriptors.
- Retains all 52 five-population partitions and the complete qualified Stage-G uncertainty scope.
- Does not force K=5 when a reporting tolerance is unattainable.
- Explicitly separates target-specific fixed closure from a universal multi-output reduced model.
- Adds independent 156-row partition, 90-row minimax and 54-row order-map mirrors.
- No new kinetics, transport correlations, site identities, probability model or experimental data are introduced.
