# Spherizone JIEC v2.2 Stage B1

Run `Run_JIEC_V2_StageB1_CoupledAudit.m` from the extracted package root.
The output is `JIEC_V2_STAGE_B1_OUTPUTS.zip`.

Stage B1 refines, rather than replaces, Stage B. See `docs/STAGE_B1_NOTES.md`.
