# Spherizone JIEC v2.5.1 — Stage D.1
## Critical-radius refinement and semantic hardening

### Purpose
Stage D.1 does **not** change the Stage-D model, uncertainty sets, transfer modes, or admissible evidence. It hardens three reporting/numerical points before Stage E.

1. **Refine only genuine nonzero critical-radius crossings.** Coarse Stage-D brackets are bisected to a radius-bracket width of `1e-6`. Rows already overlapping at radius zero are left as zero-radius non-identifiability; rows surviving through radius 1 are left as no-crossing-within-domain results.
2. **Label U_W composition invariance correctly.** Under the marginal U_W audit, latent chemistry is fixed at homogeneous C0. C0 gives identical C2 response coefficients to every active MWD population, so changing population weights cannot alter total C2. This is a structural consequence of the marginal model, **not empirical evidence that composition is robust to population redistribution**.
3. **Clarify rho_C=1 chemistry semantics.** With `span=2`, each population multiplier is in `[0.5, 2]` at `rho_C=1`. The maximum-to-minimum population contrast is therefore `4`, not `2`.

### New outputs
- `StageD1_critical_radius_refined.csv`
- `StageD1_coordinate_semantics.csv`
- `StageD1_hardening_verification.csv`
- `STAGE_D1_STATUS.txt`

### Expected refined crossings
The independent numerical audit supplied with this package gives approximately:
- `U_W_TV`, `DIRECT_MN_TRANSFER`, `Mw`, EPC 0.10→0.20: `delta_W ≈ 0.004201`
- `U_W_TV`, `DP_REPEAT_MASS_CORRECTED`, `Mw`, EPC 0.10→0.20: `delta_W ≈ 0.005081`
- `U_C_LOG_ODDS`, either transfer mode, `C2`, EPC 0.10→0.20: `rho_C ≈ 0.235587`

These are deterministic robustness thresholds under the stated Stage-D uncertainty coordinates. They are **not confidence limits** and do not constitute industrial validation.

### Run
```matlab
Run_JIEC_V2_StageD1_Hardening
```

After the MATLAB run, upload `JIEC_V2_STAGE_D1_OUTPUTS.zip` for independent verification. If all D.1 hardening gates pass and the reproduced thresholds agree with the independent audit, Stage E can proceed.
