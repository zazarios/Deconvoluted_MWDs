# Stage J v3.4.3 release notes

Release: `3.4.3-stageJ-claim-scope-hotfix`

## Reason for hotfix
Stage J v3.4.2 completed the scientific calculations and entered executable verification, but gate J13 stopped because the in-memory `ClaimScope` table was created from workspace variables named `Claim2`, `Status2`, and `Meaning2`. MATLAB therefore named its columns `Claim2`, `Status2`, and `Meaning2`, while the verifier requested `Claim` and `Status`.

## Changes
- `core/run_stageJ_external_physical_consistency.m`: `LegacyClaims` and `ClaimScope` now declare semantic variable names explicitly as `Claim`, `Status`, and `Meaning`.
- `core/verify_stageJ_external_physical_consistency.m`: `scopeIs` and `legacyStatus` resolve table columns using `stageJ_table_column` and normalize them to MATLAB strings before comparison.
- Independent Stage-J mirror CSVs are now read with `stageJ_read_csv_strict`, forcing comma delimiter and preserved headers consistently.
- Stage-J release label updated to v3.4.3.

## Scientific scope
No equations, external evidence values, H2/T80 challenge branches, chemistry stress spans, composition calculations, VOI calculations, Stage-G Jensen-envelope calculations, tolerances, or A-I qualified inputs are changed. This is a verification/table-schema compatibility hotfix only.
- Independent-mirror matching uses type-safe MATLAB string comparisons, so the strict reader's `TextType='string'` contract does not rely on cell-array brace indexing.
