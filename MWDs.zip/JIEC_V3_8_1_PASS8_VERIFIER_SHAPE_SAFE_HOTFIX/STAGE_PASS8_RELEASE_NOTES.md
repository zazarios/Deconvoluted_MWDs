# Release notes — v3.8 Pass 8

Scientific role: post-freeze tie-aware identifiability audit of partition topology.

Binding input: QUALIFIED v3.7.3 Pass-7 output archive (11/11 gates PASS).

No model rerun. No new literature data. No change to A–K. No change to Pass-7 K* maps, portability penalties, or generality verdict.

The pass tests whether `P_K*` is uniquely identifiable. It explicitly treats Mn grouping as structurally degenerate when all K-partitions are co-optimal under the reciprocal-Mn-preserving reduction.

Expected headline mirror from the frozen Pass-7 results:
- 29 primary PP states across 4 study clusters.
- Mn at K=2: all available K=2 partitions co-optimal in 29/29 primary states.
- Non-Mn K=2: unique optimum in 145/145 state-target cases at the numerical-equivalence threshold.
- Target-specific non-Mn K=2 topology in 29/29 primary states.
- Genuine non-Mn K=2 state-topology variation in 3/4 primary study clusters: Kissin_2004, Li_2015, Poorsank_2019.
- Kissin_2002 is topology-stable across its H2 series for the non-Mn K=2 targets.
