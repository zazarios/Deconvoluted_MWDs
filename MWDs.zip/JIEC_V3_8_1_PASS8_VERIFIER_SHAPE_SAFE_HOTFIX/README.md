# JIEC v3.8 Pass 8 — Tie-aware partition identifiability

This is a post-freeze, data-only hardening pass. It reads the QUALIFIED v3.7.3 Pass-7 outputs and does not run or modify the Spherizone/MZCR model, A–K model, literature transcription, target tolerances, or Pass-7 representation calculations.

## Why this pass exists
Pass 7 stored one `BestPartition` returned by a numerical minimum. For targets with exact structural invariance—most importantly Mn under reciprocal-Mn-preserving grouping—many partitions can be exactly/co-numerically optimal. A single selected label is therefore not an identifiable scientific result.

Pass 8 replaces the single-label interpretation with a co-optimal set:
`P*_K -> script-P*_K`, the set of partitions whose objective lies within a numerical-equivalence threshold of the minimum.

Primary numerical-equivalence rule:
`tau = max(1e-10, 1e-8*max(1,abs(Emin)))`.
This is a post-freeze numerical identifiability diagnostic, not a physical tolerance and not a new representation-error tolerance.

## Main outputs
- `Pass8_state_partition_identifiability.csv`
- `Pass8_family_minimax_partition_identifiability.csv`
- `Pass8_K2_state_variation_tieaware.csv`
- `Pass8_K2_target_dependence_tieaware.csv`
- `Pass8_primary_summary.csv`
- `Pass8_verification.csv`
- `PASS8_STATUS.txt`

## Run
In MATLAB R2025b, set the current folder to this package root and run:

`Run_JIEC_V3_8_Pass8_TieAwarePartitionIdentifiability`

## Claim scope
This pass can establish whether a reported optimal grouping is unique, co-optimal, target-specific, or state-dependent within the published experimental Pass-7 datasets. It does not validate Spherizone, infer chemical active-site identities, or modify the qualified Pass-7 state-information verdict.


## MATLAB R2025b hotfix
Use `Run_JIEC_V3_8_1_Pass8_TieAwarePartitionIdentifiability`.

v3.8.1 changes verifier vector-shape handling only. The scientific release and all Pass-8 calculations are unchanged.
