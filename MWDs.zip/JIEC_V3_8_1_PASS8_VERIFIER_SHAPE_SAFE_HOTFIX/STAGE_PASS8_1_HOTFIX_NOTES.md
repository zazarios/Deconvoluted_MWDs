# JIEC v3.8.1 Pass 8 verifier shape-safe hotfix

Scientific release remains `3.8-pass8-tie-aware-partition-identifiability`.

## Failure addressed
MATLAB R2025b evaluated:

`all(got==expected)`

after `got` and `expected` acquired different vector orientations. Implicit expansion produced a matrix, so `all(...)` returned a non-scalar logical vector. The subsequent `&&` operator requires a scalar logical and therefore raised an error.

## Fix
The verifier now uses orientation-independent exact set-order comparison:

`isequal(got(:), expected(:))`

The single stable-cluster check is also written shape-safely.

A uniquely named verifier and runner are used, and the runner checks the resolved verifier path before executing.

## Scientific scope
No experimental data, partition errors, numerical-equivalence threshold, target definitions, Pass-7 inputs, A-K outputs, Spherizone calculations, or scientific decision rules are changed.
