clear; clc;
ROOT=fileparts(mfilename('fullpath'));
restoredefaultpath;
addpath(ROOT);
addpath(fullfile(ROOT,'core'));
addpath(fullfile(ROOT,'verify'));
cfg=config_pass8(ROOT);

fprintf('[JIEC v3.8.1 Pass 8 verifier hotfix] Tie-aware partition identifiability audit\n');
fprintf('Scientific release: %s\n',cfg.release);
vf=which('verify_pass8_1_tieaware_partition_identifiability');
fprintf('Verifier resolved to: %s\n',vf);
expectedVerify=fullfile(ROOT,'verify','verify_pass8_1_tieaware_partition_identifiability.m');
if ~strcmpi(char(vf),char(expectedVerify))
    error('Path-safety failure: verifier resolved outside this package.');
end
fprintf('Reads qualified Pass-7 experimental outputs only; no Spherizone or A-K model is run.\n\n');

run_pass8_tieaware_partition_identifiability(cfg);
V=verify_pass8_1_tieaware_partition_identifiability(cfg);
npass=sum(string(V.Status)=="PASS");
fprintf('\nPass 8 status: %s (%d/%d gates PASS)\n', tern_local(npass==height(V),'QUALIFIED','FAILED'), npass,height(V));
fprintf('Outputs: %s\n',cfg.outDir);

zipfile=fullfile(ROOT,'Outputs_Pass8.zip');
if exist(zipfile,'file'); delete(zipfile); end
zip(zipfile,{'Outputs_Pass8'},ROOT);
fprintf('Archive: %s\n',zipfile);

if npass~=height(V)
    error('Pass 8 verification failed. Inspect Pass8_verification.csv.');
end

function y=tern_local(q,a,b)
if q; y=a; else; y=b; end
end
