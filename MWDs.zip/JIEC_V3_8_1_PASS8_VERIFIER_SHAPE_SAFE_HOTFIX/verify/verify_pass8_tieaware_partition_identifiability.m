function V=verify_pass8_tieaware_partition_identifiability(cfg)
out=cfg.outDir;
rows={};
add=@(id,ok,detail) {id, string(tern(ok,"PASS","FAIL")), string(detail)};

required=["Pass8_state_partition_identifiability.csv","Pass8_family_minimax_partition_identifiability.csv", ...
 "Pass8_K2_state_variation_tieaware.csv","Pass8_K2_target_dependence_tieaware.csv","Pass8_primary_summary.csv"];
missing=strings(0,1);
for f=required
    if ~exist(fullfile(out,f),'file'); missing(end+1)=f; end %#ok<AGROW>
end
rows(end+1,:)=add("P8_0_REQUIRED_OUTPUTS",isempty(missing),"missing="+strjoin(missing,';'));

st=fileread(fullfile(cfg.inputDir,'PASS7_STATUS.txt'));
ok=contains(st,'QUALIFIED') && contains(st,'11/11');
rows(end+1,:)=add("P8_1_QUALIFIED_PASS7_INPUT",ok,"Pass7 status checked");

S=readtable(fullfile(out,'Pass8_primary_summary.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
rows(end+1,:)=add("P8_2_PRIMARY_STATE_COUNT",S.PrimaryStateCount(1)==29,"states="+string(S.PrimaryStateCount(1)));
rows(end+1,:)=add("P8_3_MN_K2_STRUCTURAL_DEGENERACY",S.MnK2StructurallyDegenerateCases(1)==S.MnK2Cases(1) && S.MnK2Cases(1)==29, ...
    string(S.MnK2StructurallyDegenerateCases(1))+"/"+string(S.MnK2Cases(1)));
rows(end+1,:)=add("P8_4_NONMN_K2_UNIQUE_OPTIMA",S.NonMnK2UniqueOptimumCases(1)==S.NonMnK2Cases(1) && S.NonMnK2Cases(1)==145, ...
    string(S.NonMnK2UniqueOptimumCases(1))+"/"+string(S.NonMnK2Cases(1)));
rows(end+1,:)=add("P8_5_TARGET_SPECIFIC_TOPOLOGY",S.TargetSpecificK2States(1)==29 && S.PrimaryStatesForTargetTest(1)==29, ...
    string(S.TargetSpecificK2States(1))+"/29 states");

expected=sort(["Kissin_2004","Li_2015","Poorsank_2019"]);
got=sort(split(string(S.StateTopologyVariationClusterIDs(1)),';'));
ok=numel(got)==numel(expected) && all(got==expected);
rows(end+1,:)=add("P8_6_STATE_TOPOLOGY_VARIATION_CLUSTERS",ok,"clusters="+strjoin(got,';'));

stable=split(string(S.StateStableClusterIDs(1)),';');
ok=numel(stable)==1 && stable=="Kissin_2002";
rows(end+1,:)=add("P8_7_KISSIN2002_TOPOLOGY_STABLE",ok,"stable="+strjoin(stable,';'));

% Numerical mirror against the independent Python summary shipped with the package.
E=readtable(fullfile(cfg.root,'Independent_Audit','Pass8_expected_primary_summary.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
cols=["PrimaryStateCount","PrimaryStudyClusterCount","MnK2StructurallyDegenerateCases","MnK2Cases", ...
      "NonMnK2UniqueOptimumCases","NonMnK2Cases","TargetSpecificK2States","PrimaryStatesForTargetTest","StateTopologyVariationStudyClusters"];
ok=true;
for c=cols
    ok=ok && double(S.(c)(1))==double(E.(c)(1));
end
rows(end+1,:)=add("P8_8_INDEPENDENT_SUMMARY_MIRROR",ok,"headline summary mirror");

V=cell2table(rows,'VariableNames',{'GateID','Status','Detail'});
writetable(V,fullfile(out,'Pass8_verification.csv'));
npass=sum(V.Status=="PASS");
fid=fopen(fullfile(out,'PASS8_STATUS.txt'),'w');
if npass==height(V); status="QUALIFIED"; else; status="FAILED"; end
fprintf(fid,'JIEC v3.8 Pass 8 status: %s\n',status);
fprintf(fid,'Release: %s\n',cfg.release);
fprintf(fid,'Gates passed: %d/%d\n',npass,height(V));
fprintf(fid,'Post-freeze data-only diagnostic; no A-K or Pass-7 scientific output is modified.\n');
fclose(fid);
end

function y=tern(q,a,b)
if q; y=a; else; y=b; end
end
