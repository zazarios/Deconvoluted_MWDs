function cfg=config_pass8(ROOT)
cfg.release = "3.8-pass8-tie-aware-partition-identifiability";
cfg.root = ROOT;
cfg.inputDir = fullfile(ROOT,'data','Qualified_Pass7_Outputs');
cfg.outDir = fullfile(ROOT,'Outputs_Pass8');
cfg.primaryAbsTol = 1e-8;
cfg.floorAbsTol = 1e-10;
cfg.targets = ["MnRel","MwRel","DRel","W1","Tail90Abs","Tail99Abs"];
cfg.nonMnTargets = ["MwRel","DRel","W1","Tail90Abs","Tail99Abs"];
end
