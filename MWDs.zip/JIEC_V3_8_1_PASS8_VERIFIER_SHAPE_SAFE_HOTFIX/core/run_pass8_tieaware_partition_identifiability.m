function run_pass8_tieaware_partition_identifiability(cfg)
if ~exist(cfg.outDir,'dir'); mkdir(cfg.outDir); end
f=fullfile(cfg.inputDir,'Pass7_state_all_partition_errors.csv');
T=readtable(f,'Delimiter',',','VariableNamingRule','preserve','TextType','string');

req=["FamilyID","StudyCluster","Role","StateID","StateValue","J","K","PartitionCode"];
for q=req
    assert(any(string(T.Properties.VariableNames)==q),"Missing input column: "+q);
end

% Long-form tie-aware state-specific partition identifiability
R=table;
for ir=1:height(T)
    % no-op; loops below operate on grouped subsets
end
families=unique(string(T.FamilyID),'stable');
for fi=1:numel(families)
    fam=families(fi);
    Tf=T(string(T.FamilyID)==fam,:);
    states=unique(string(Tf.StateID),'stable');
    for si=1:numel(states)
        st=states(si);
        Ts=Tf(string(Tf.StateID)==st,:);
        J=Ts.J(1);
        Ks=unique(Ts.K);
        for ki=1:numel(Ks)
            K=Ks(ki);
            Tk=Ts(Ts.K==K,:);
            for ti=1:numel(cfg.targets)
                tar=cfg.targets(ti);
                e=Tk.(tar);
                emin=min(e);
                tau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(emin)));
                q=e<=emin+tau;
                codes=sort(string(Tk.PartitionCode(q)));
                bigger=e(e>emin+tau);
                if isempty(bigger); gap=NaN; else; gap=min(bigger)-emin; end
                rr=table(fam,string(Ts.StudyCluster(1)),string(Ts.Role(1)),st,J,K,tar,emin,tau,sum(q),gap,strjoin(codes,';'), ...
                    'VariableNames',{'FamilyID','StudyCluster','Role','StateID','J','K','Target','MinError','TieTolerance','CooptimalCount','GapToNext','CooptimalPartitions'});
                R=[R;rr]; %#ok<AGROW>
            end
        end
    end
end
writetable(R,fullfile(cfg.outDir,'Pass8_state_partition_identifiability.csv'));

% Family-wide minimax co-optimal sets, recomputed from raw state partition errors.
F=table;
for fi=1:numel(families)
    fam=families(fi);
    Tf=T(string(T.FamilyID)==fam,:);
    Ks=unique(Tf.K);
    for ki=1:numel(Ks)
        K=Ks(ki); Tk=Tf(Tf.K==K,:);
        codes=unique(string(Tk.PartitionCode),'stable');
        for ti=1:numel(cfg.targets)
            tar=cfg.targets(ti);
            mm=zeros(numel(codes),1);
            for pi=1:numel(codes)
                mm(pi)=max(Tk.(tar)(string(Tk.PartitionCode)==codes(pi)));
            end
            emin=min(mm);
            tau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(emin)));
            q=mm<=emin+tau;
            sel=sort(codes(q));
            bigger=mm(mm>emin+tau);
            if isempty(bigger); gap=NaN; else; gap=min(bigger)-emin; end
            rr=table(fam,string(Tf.StudyCluster(1)),string(Tf.Role(1)),K,tar,emin,tau,sum(q),gap,strjoin(sel,';'), ...
                'VariableNames',{'FamilyID','StudyCluster','Role','K','Target','MinimaxError','TieTolerance','CooptimalCount','GapToNext','CooptimalPartitions'});
            F=[F;rr]; %#ok<AGROW>
        end
    end
end
writetable(F,fullfile(cfg.outDir,'Pass8_family_minimax_partition_identifiability.csv'));

% K=2 state-topology variation using co-optimal sets rather than one arbitrary min() label.
V=table;
R2=R(R.K==2,:);
for fi=1:numel(families)
    fam=families(fi); X=R2(R2.FamilyID==fam,:);
    for ti=1:numel(cfg.targets)
        tar=cfg.targets(ti); Y=X(X.Target==tar,:);
        if isempty(Y); continue; end
        setstr=string(Y.CooptimalPartitions);
        distinctCount=numel(unique(setstr));
        common=split(setstr(1),';');
        for yi=2:height(Y)
            common=intersect(common,split(setstr(yi),';'),'stable');
        end
        if distinctCount==1
            stat="STABLE_COOPTIMAL_SET";
        elseif ~isempty(common)
            stat="VARYING_SET_WITH_COMMON_OPTIMUM";
        else
            stat="NO_COMMON_STATEWISE_OPTIMUM";
        end
        detail=strings(height(Y),1);
        for yi=1:height(Y)
            detail(yi)=string(Y.StateID(yi))+":"+setstr(yi);
        end
        rr=table(fam,string(Y.StudyCluster(1)),string(Y.Role(1)),tar,height(Y),distinctCount,numel(common),strjoin(sort(common),';'),stat,strjoin(detail,' | '), ...
            'VariableNames',{'FamilyID','StudyCluster','Role','Target','StateCount','DistinctCooptimalSetCount','CommonOptimalPartitionCount','CommonOptimalPartitions','TopologyStatus','StateCooptimalSets'});
        V=[V;rr]; %#ok<AGROW>
    end
end
writetable(V,fullfile(cfg.outDir,'Pass8_K2_state_variation_tieaware.csv'));

% K=2 target-specific topology, excluding Mn because its topology is structurally degenerate.
D=table;
P=R2(R2.Role=="PRIMARY_PP" & R2.Target~="MnRel",:);
keys=unique(P(:,{'FamilyID','StudyCluster','Role','StateID'}),'rows','stable');
for ii=1:height(keys)
    q=P.FamilyID==keys.FamilyID(ii) & P.StateID==keys.StateID(ii);
    X=P(q,:);
    distinctCount=numel(unique(string(X.CooptimalPartitions)));
    if distinctCount>1; stat="TARGET_SPECIFIC"; else; stat="COMMON_TOPOLOGY"; end
    detail=strings(height(X),1);
    for jj=1:height(X)
        detail(jj)=string(X.Target(jj))+":"+string(X.CooptimalPartitions(jj));
    end
    rr=table(string(keys.FamilyID(ii)),string(keys.StudyCluster(ii)),string(keys.Role(ii)),string(keys.StateID(ii)),height(X),distinctCount,stat,strjoin(detail,' | '), ...
        'VariableNames',{'FamilyID','StudyCluster','Role','StateID','TargetCount','DistinctNonMnK2Optima','TargetTopologyStatus','TargetOptima'});
    D=[D;rr]; %#ok<AGROW>
end
writetable(D,fullfile(cfg.outDir,'Pass8_K2_target_dependence_tieaware.csv'));

% Headline summary
Prim=R2(R2.Role=="PRIMARY_PP",:);
Mn=Prim(Prim.Target=="MnRel",:);
expected=2.^(Mn.J-1)-1; % Stirling S(J,2)
mnDeg=sum(Mn.CooptimalCount==expected);
NonMn=Prim(Prim.Target~="MnRel",:);
nonMnUnique=sum(NonMn.CooptimalCount==1);
targetDep=sum(D.TargetTopologyStatus=="TARGET_SPECIFIC");
VN=V(V.Role=="PRIMARY_PP" & V.Target~="MnRel",:);
vary=unique(string(VN.StudyCluster(VN.TopologyStatus=="NO_COMMON_STATEWISE_OPTIMUM")));
allc=unique(string(VN.StudyCluster));
stable=setdiff(allc,vary,'stable');
primaryStates=height(unique(Prim(:,{'FamilyID','StateID'}),'rows'));
S=table(1,primaryStates,numel(allc),mnDeg,height(Mn),nonMnUnique,height(NonMn),targetDep,height(D),numel(vary),numel(allc),strjoin(sort(vary),';'),strjoin(sort(stable),';'), ...
 "Mn topology is structurally non-identifiable under reciprocal-Mn-preserving reduction; non-Mn K=2 optima are unique at the numerical-equivalence threshold; genuine K=2 state-topology changes occur in three of four primary PP study clusters.", ...
 'VariableNames',{'Pass7Qualified','PrimaryStateCount','PrimaryStudyClusterCount','MnK2StructurallyDegenerateCases','MnK2Cases','NonMnK2UniqueOptimumCases','NonMnK2Cases','TargetSpecificK2States','PrimaryStatesForTargetTest','StateTopologyVariationStudyClusters','PrimaryStudyClustersForStateTest','StateTopologyVariationClusterIDs','StateStableClusterIDs','Interpretation'});
writetable(S,fullfile(cfg.outDir,'Pass8_primary_summary.csv'));

fid=fopen(fullfile(cfg.outDir,'PASS8_STATUS.txt'),'w');
fprintf(fid,'JIEC v3.8 Pass 8 computational status: COMPLETE_PENDING_VERIFICATION\n');
fprintf(fid,'Release: %s\n',cfg.release);
fprintf(fid,'This pass reads only qualified Pass-7 output and changes no A-K or Pass-7 calculation.\n');
fclose(fid);
end
