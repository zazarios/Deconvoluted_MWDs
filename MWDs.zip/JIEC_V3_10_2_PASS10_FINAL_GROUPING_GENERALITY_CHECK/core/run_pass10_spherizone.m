function run_pass10_spherizone(cfg)
T=readtable(fullfile(cfg.stageHDir,'StageH_all_partition_minimax_bounds.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
C=table; Ktab=table; B=table; Common=table;
bounds=["LOWER","UPPER"];
for ib=1:numel(bounds)
    bt=bounds(ib);
    EPCs=sort(unique(T.EPC_wtfrac));
    for ie=1:numel(EPCs)
        epc=EPCs(ie); X=T(abs(T.EPC_wtfrac-epc)<1e-12,:); Ks=sort(unique(X.K));
        for ki=1:numel(Ks)
            K=Ks(ki); Y=X(X.K==K,:); cm=false(height(Y),1);
            for r=1:height(Y); cm(r)=pass10_is_contiguous_partition(Y.PartitionCode(r)); end
            for ti=1:numel(cfg.targets)
                tar=cfg.targets(ti); col=pass10_stageH_column(tar,bt); e=Y.(col);
                eu=min(e); tau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(eu))); uco=sort(string(Y.PartitionCode(e<=eu+tau)));
                ec=min(e(cm)); ctau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(ec))); cco=sort(string(Y.PartitionCode(cm & e<=ec+ctau)));
                rr=table(bt,epc,K,tar,eu,ec,ec-eu,tau,ec<=eu+tau,strjoin(uco,';'),strjoin(cco,';'), ...
                    'VariableNames',{'BoundType','EPC_wtfrac','K','Target','UnrestrictedMinError','ContiguousMinError','DeltaError','TieTolerance','ContiguousEquivalent','UnrestrictedCooptimalPartitions','ContiguousCooptimalPartitions'});
                C=[C;rr]; %#ok<AGROW>
            end
        end
        kstar=containers.Map('KeyType','char','ValueType','double');
        for ti=1:numel(cfg.targets)
            tar=cfg.targets(ti); col=pass10_stageH_column(tar,bt); etol=pass10_target_tolerance(cfg,tar); ku=NaN; kc=NaN;
            for ki=1:numel(Ks)
                K=Ks(ki); Y=X(X.K==K,:); cm=false(height(Y),1);
                for r=1:height(Y); cm(r)=pass10_is_contiguous_partition(Y.PartitionCode(r)); end
                if isnan(ku) && min(Y.(col))<=etol+1e-12; ku=K; end
                tmp=Y.(col); if isnan(kc) && min(tmp(cm))<=etol+1e-12; kc=K; end
            end
            kstar(char(tar))=ku;
            rr=table(bt,epc,tar,etol,ku,kc,kc-ku,'VariableNames',{'BoundType','EPC_wtfrac','Target','ReferenceTolerance','KstarUnrestricted','KstarContiguous','DeltaK'});
            Ktab=[Ktab;rr]; %#ok<AGROW>
        end
        scoreByK=nan(numel(Ks),1);
        for ki=1:numel(Ks)
            K=Ks(ki); Y=X(X.K==K,:); score=zeros(height(Y),1);
            for r=1:height(Y)
                vals=zeros(numel(cfg.nonMnTargets),1);
                for ti=1:numel(cfg.nonMnTargets)
                    tar=cfg.nonMnTargets(ti); col=pass10_stageH_column(tar,bt); vals(ti)=Y.(col)(r)/pass10_target_tolerance(cfg,tar);
                end
                score(r)=max(vals);
            end
            smin=min(score); scoreByK(ki)=smin; stau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(smin)));
            tie=score<=smin+stau; tied=Y(tie,:); tiedCodes=sort(string(tied.PartitionCode));
            for ti=1:numel(cfg.nonMnTargets)
                tar=cfg.nonMnTargets(ti); col=pass10_stageH_column(tar,bt); eopt=min(Y.(col)); etau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(eopt)));
                best=min(tied.(col)); worst=max(tied.(col)); etol=pass10_target_tolerance(cfg,tar);
                rr=table(bt,epc,K,tar,smin,stau,sum(tie),strjoin(tiedCodes,';'),eopt,best,worst,best-eopt,best<=eopt+etau,eopt/etol,best/etol,worst/etol, ...
                    'VariableNames',{'BoundType','EPC_wtfrac','K','Target','TargetBlindMinimaxScore','TargetBlindTieTolerance','TargetBlindCooptimalCount','TargetBlindCooptimalPartitions','TargetSpecificMinError','BestCaseTargetBlindError','WorstCaseTargetBlindError','BestCasePenalty','BestCaseEquivalentToTargetSpecific','TargetSpecificNormError','BestCaseTargetBlindNormError','WorstCaseTargetBlindNormError'});
                B=[B;rr]; %#ok<AGROW>
            end
        end
        vals=zeros(numel(cfg.nonMnTargets),1); for ti=1:numel(cfg.nonMnTargets); vals(ti)=kstar(char(cfg.nonMnTargets(ti))); end
        maxInd=max(vals); jj=find(scoreByK<=1+1e-12,1,'first'); assert(~isempty(jj),'Full Spherizone resolution must close target-blind baseline.'); commonK=Ks(jj);
        rr=table(bt,epc,maxInd,commonK,commonK-maxInd,'VariableNames',{'BoundType','EPC_wtfrac','MaxTargetSpecificKstar','TargetBlindCommonKstar','DeltaK'});
        Common=[Common;rr]; %#ok<AGROW>
    end
end
writetable(C,fullfile(cfg.outDir,'Pass10_spherizone_contiguity_error_equivalence.csv'));
writetable(Ktab,fullfile(cfg.outDir,'Pass10_spherizone_contiguity_Kstar_comparison.csv'));
writetable(B,fullfile(cfg.outDir,'Pass10_spherizone_targetblind_minimax.csv'));
writetable(Common,fullfile(cfg.outDir,'Pass10_spherizone_targetblind_commonK.csv'));
S=table;
for ib=1:numel(bounds)
    bt=bounds(ib); c=C(C.BoundType==bt,:); k=Ktab(Ktab.BoundType==bt,:); b2=B(B.BoundType==bt & B.K==2,:); cm=Common(Common.BoundType==bt,:);
    added=b2.TargetSpecificNormError<=1+1e-12 & b2.BestCaseTargetBlindNormError>1+1e-12;
    rr=table(bt,height(cm),height(c),sum(c.ContiguousEquivalent),height(k),sum(k.DeltaK>0),height(b2),sum(~b2.BestCaseEquivalentToTargetSpecific),sum(added),sum(cm.DeltaK>0), ...
        'VariableNames',{'BoundType','EPCCount','ContiguityTargetKCases','ContiguityEquivalentCases','ContiguityKstarCases','ContiguityKstarPenaltyCases','NonMnK2TargetBlindCases','K2TargetBlindPenaltyCases','K2TargetBlindAddedFailureCases','TargetBlindCommonKPenaltyEPCs'});
    S=[S;rr]; %#ok<AGROW>
end
writetable(S,fullfile(cfg.outDir,'Pass10_spherizone_summary.csv'));
end

function col=pass10_stageH_column(tar,bt)
tar=string(tar); bt=string(bt);
if tar=="MnRel"; base="MnRel";
elseif tar=="MwRel"; base="MwRel";
elseif tar=="DRel"; base="DRel";
elseif tar=="W1"; base="W1";
elseif tar=="Tail90Abs"; base="Tail90";
elseif tar=="Tail99Abs"; base="Tail99";
else; error('Unknown target.'); end
if base=="W1"; suf=tern10(bt=="LOWER","_lower_decades","_upper_decades");
elseif startsWith(base,"Tail"); suf=tern10(bt=="LOWER","_lower_abs","_upper_abs");
else; suf=tern10(bt=="LOWER","_lower","_upper"); end
col=base+suf;
end
function y=tern10(q,a,b); if q; y=a; else; y=b; end; end
