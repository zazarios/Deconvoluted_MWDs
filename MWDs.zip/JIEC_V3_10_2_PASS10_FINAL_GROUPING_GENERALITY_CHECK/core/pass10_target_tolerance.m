function etol=pass10_target_tolerance(cfg,tar)
idx=find(cfg.targets==string(tar),1);
assert(~isempty(idx),'Unknown target.');
etol=cfg.tolerances(idx);
end
