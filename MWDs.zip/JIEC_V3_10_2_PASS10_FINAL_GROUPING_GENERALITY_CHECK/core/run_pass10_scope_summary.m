function run_pass10_scope_summary(cfg)
R=readtable(fullfile(cfg.externalDir,'External19_registry.csv'),'TextType','string');
H=readtable(fullfile(cfg.outDir,'Pass10_spherizone_targetblind_commonK.csv'),'TextType','string');
nEPC=numel(unique(H.EPC_wtfrac));
C=table(cfg.release,1,1,height(R),numel(unique(string(R.StudyCluster))),nEPC, ...
    "Post-freeze generality check of the Pass-9 grouping baselines in the broader 19-distribution PP cohort and the frozen Spherizone Stage-H projection bounds. Favorable or null outcomes do not affect qualification.", ...
    'VariableNames',{'ScientificRelease','External19Qualified','SpherizoneStageHQualified','ExternalDatasetCount','ExternalStudyClusterCount','SpherizoneEPCCount','Interpretation'});
writetable(C,fullfile(cfg.outDir,'Pass10_combined_scope_summary.csv'));
end
