function tf=pass10_is_contiguous_partition(code)
g=split(string(code),'|'); tf=true;
for ii=1:numel(g)
    a=str2double(split(g(ii),'-')); a=sort(a(:));
    if numel(a)>1 && any(diff(a)~=1); tf=false; return; end
end
end
