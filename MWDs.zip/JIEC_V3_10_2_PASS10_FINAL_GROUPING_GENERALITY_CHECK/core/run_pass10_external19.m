function run_pass10_external19(cfg)
T=readtable(fullfile(cfg.externalDir,'External19_all_partition_errors.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
R=readtable(fullfile(cfg.externalDir,'External19_registry.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
req=["DatasetID","StudyCluster","Role","J","K","PartitionCode",cfg.targets];
for q=req; assert(any(string(T.Properties.VariableNames)==q),"Missing external input column: "+q); end
R=sortrows(R,'DatasetOrder');
C=table; Ktab=table; B=table; Common=table;
for ii=1:height(R)
    did=string(R.DatasetID(ii)); cl=string(R.StudyCluster(ii)); J=R.J(ii);
    X=T(string(T.DatasetID)==did,:); assert(~isempty(X),"Missing external dataset "+did);
    Ks=sort(unique(X.K));
    for ki=1:numel(Ks)
        K=Ks(ki); Y=X(X.K==K,:);
        cm=false(height(Y),1); for r=1:height(Y); cm(r)=pass10_is_contiguous_partition(Y.PartitionCode(r)); end
        assert(any(cm),'No contiguous candidate found.');
        for ti=1:numel(cfg.targets)
            tar=cfg.targets(ti); e=Y.(tar); eu=min(e); tau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(eu)));
            uco=sort(string(Y.PartitionCode(e<=eu+tau)));
            ec=min(e(cm)); ctau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(ec)));
            cco=sort(string(Y.PartitionCode(cm & e<=ec+ctau)));
            rr=table(did,cl,"PRIMARY_EXTERNAL_PP",J,K,tar,eu,ec,ec-eu,tau,ec<=eu+tau,strjoin(uco,';'),strjoin(cco,';'), ...
                'VariableNames',{'DatasetID','StudyCluster','Role','J','K','Target','UnrestrictedMinError','ContiguousMinError','DeltaError','TieTolerance','ContiguousEquivalent','UnrestrictedCooptimalPartitions','ContiguousCooptimalPartitions'});
            C=[C;rr]; %#ok<AGROW>
        end
    end
    for ti=1:numel(cfg.targets)
        tar=cfg.targets(ti); etol=pass10_target_tolerance(cfg,tar); ku=NaN; kc=NaN;
        for ki=1:numel(Ks)
            K=Ks(ki); Y=X(X.K==K,:); cm=false(height(Y),1);
            for r=1:height(Y); cm(r)=pass10_is_contiguous_partition(Y.PartitionCode(r)); end
            if isnan(ku) && min(Y.(tar))<=etol+1e-12; ku=K; end
            tmp=Y.(tar); if isnan(kc) && min(tmp(cm))<=etol+1e-12; kc=K; end
        end
        rr=table(did,cl,"PRIMARY_EXTERNAL_PP",J,tar,etol,ku,kc,kc-ku, ...
            'VariableNames',{'DatasetID','StudyCluster','Role','J','Target','ReferenceTolerance','KstarUnrestricted','KstarContiguous','DeltaK'});
        Ktab=[Ktab;rr]; %#ok<AGROW>
    end
    scoreByK=nan(numel(Ks),1);
    for ki=1:numel(Ks)
        K=Ks(ki); Y=X(X.K==K,:); score=zeros(height(Y),1);
        for r=1:height(Y)
            vals=zeros(numel(cfg.nonMnTargets),1);
            for ti=1:numel(cfg.nonMnTargets)
                tar=cfg.nonMnTargets(ti); vals(ti)=Y.(tar)(r)/pass10_target_tolerance(cfg,tar);
            end
            score(r)=max(vals);
        end
        smin=min(score); scoreByK(ki)=smin; stau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(smin)));
        tie=score<=smin+stau; tied=Y(tie,:); tiedCodes=sort(string(tied.PartitionCode));
        for ti=1:numel(cfg.nonMnTargets)
            tar=cfg.nonMnTargets(ti); eopt=min(Y.(tar)); etau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(eopt)));
            best=min(tied.(tar)); worst=max(tied.(tar)); etol=pass10_target_tolerance(cfg,tar);
            rr=table(did,cl,"PRIMARY_EXTERNAL_PP",J,K,tar,smin,stau,sum(tie),strjoin(tiedCodes,';'),eopt,best,worst,best-eopt,best<=eopt+etau,eopt/etol,best/etol,worst/etol, ...
                'VariableNames',{'DatasetID','StudyCluster','Role','J','K','Target','TargetBlindMinimaxScore','TargetBlindTieTolerance','TargetBlindCooptimalCount','TargetBlindCooptimalPartitions','TargetSpecificMinError','BestCaseTargetBlindError','WorstCaseTargetBlindError','BestCasePenalty','BestCaseEquivalentToTargetSpecific','TargetSpecificNormError','BestCaseTargetBlindNormError','WorstCaseTargetBlindNormError'});
            B=[B;rr]; %#ok<AGROW>
        end
    end
    z=Ktab(string(Ktab.DatasetID)==did & ismember(string(Ktab.Target),cfg.nonMnTargets),:);
    maxInd=max(z.KstarUnrestricted); jj=find(scoreByK<=1+1e-12,1,'first'); assert(~isempty(jj),'Full external resolution must close target-blind baseline.');
    commonK=Ks(jj);
    rr=table(did,cl,"PRIMARY_EXTERNAL_PP",J,maxInd,commonK,commonK-maxInd, ...
        'VariableNames',{'DatasetID','StudyCluster','Role','J','MaxTargetSpecificKstar','TargetBlindCommonKstar','DeltaK'});
    Common=[Common;rr]; %#ok<AGROW>
end
writetable(C,fullfile(cfg.outDir,'Pass10_external_contiguity_error_equivalence.csv'));
writetable(Ktab,fullfile(cfg.outDir,'Pass10_external_contiguity_Kstar_comparison.csv'));
writetable(B,fullfile(cfg.outDir,'Pass10_external_targetblind_minimax.csv'));
writetable(Common,fullfile(cfg.outDir,'Pass10_external_targetblind_commonK.csv'));

clusters=unique(string(R.StudyCluster),'stable'); CS=table; B2=B(B.K==2,:);
for ci=1:numel(clusters)
    cl=clusters(ci); cs=Common(string(Common.StudyCluster)==cl,:); cc=C(string(C.StudyCluster)==cl,:); bb=B2(string(B2.StudyCluster)==cl,:);
    added=bb.TargetSpecificNormError<=1+1e-12 & bb.BestCaseTargetBlindNormError>1+1e-12;
    rr=table(cl,height(cs),height(cc),sum(cc.ContiguousEquivalent),sum(cs.DeltaK>0),sum(~bb.BestCaseEquivalentToTargetSpecific),sum(added), ...
        'VariableNames',{'StudyCluster','DatasetCount','ContiguityCases','ContiguityEquivalentCases','TargetBlindCommonKPenaltyDatasets','K2TargetBlindPenaltyCases','K2AddedFailureCases'});
    CS=[CS;rr]; %#ok<AGROW>
end
writetable(CS,fullfile(cfg.outDir,'Pass10_external_study_cluster_summary.csv'));
added=B2.TargetSpecificNormError<=1+1e-12 & B2.BestCaseTargetBlindNormError>1+1e-12;
S=table(height(Common),numel(clusters),height(C),sum(C.ContiguousEquivalent),height(Ktab),sum(Ktab.DeltaK>0),height(B2),sum(~B2.BestCaseEquivalentToTargetSpecific),sum(added),sum(Common.DeltaK>0),numel(unique(string(Common.StudyCluster(Common.DeltaK>0)))), ...
    'VariableNames',{'ExternalDatasetCount','ExternalStudyClusterCount','ContiguityStateTargetKCases','ContiguityEquivalentCases','ContiguityKstarCases','ContiguityKstarPenaltyCases','NonMnK2TargetBlindCases','K2TargetBlindPenaltyCases','K2TargetBlindAddedFailureCases','TargetBlindCommonKPenaltyDatasets','TargetBlindCommonKPenaltyStudyClusters'});
writetable(S,fullfile(cfg.outDir,'Pass10_external_summary.csv'));
end
