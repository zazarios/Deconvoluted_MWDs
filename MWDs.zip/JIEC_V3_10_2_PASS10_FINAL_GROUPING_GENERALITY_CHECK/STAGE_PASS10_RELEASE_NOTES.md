# Stage Pass 10 release notes

Scientific release: `3.10-pass10-final-grouping-generality-check`

Pass 10 is a final scientific-hardening pass, not a new model-development stage.

Frozen questions:
1. Does restricting groupings to contiguous molecular-weight ranks change the best attainable target error or K* in the broader external PP cohort?
2. Does an optimized target-blind minimax topology lose accuracy, closure, or representation economy relative to target-specific grouping in that cohort?
3. Do the same conclusions hold in the Spherizone Stage-H oracle-projection problem when witness lower and certified upper bounds are analyzed separately?

Scope guards:
- no new deconvolution;
- no new reactor calculation;
- no new kinetic parameter;
- no new uncertainty distribution;
- no new target;
- no post-result tolerance selection;
- no claim that contiguity is universally sufficient outside the tested evidence layers;
- no claim that Stage-H lower/upper bounds are exact realized errors.

After qualified Pass 10, scientific expansion of the first manuscript should stop and the results should be integrated into the manuscript/SI.


## v3.10.1 implementation hotfix
A verifier-only schema mismatch was corrected. `StageI_verification.csv` stores qualification
as numeric/logical `Pass`, while `StageH_verification.csv` stores string `Status`.
The verifier now detects either schema. Scientific release and all frozen calculations are unchanged.


## v3.10.2 implementation hotfix
Four comparison gates in v3.10.1 failed only because the independent CSV mirrors used
`True/False` and MATLAB output used `1/0` for the same Boolean fields:
`ContiguousEquivalent` and `BestCaseEquivalentToTargetSpecific`.
The verifier now compares their normalized logical values. All scientific calculations
and frozen expected results are unchanged.
