# JIEC v3.10 Pass 10 — Final grouping-generality check

## Purpose
Pass 10 is the narrow, post-freeze generality check requested after qualified Pass 9.

It asks whether the two Pass-9 findings remain supported when the same pre-specified baselines are applied to:
1. the broader 19-distribution external polypropylene cohort spanning six study clusters; and
2. the frozen Spherizone Stage-H target-aware projection bounds at EPC = 10, 20, and 30 wt%.

## Baselines
A. **Unrestricted vs molecular-weight-rank-contiguous grouping**
- unrestricted candidate class: all set partitions already present in the frozen input;
- contiguous class: every retained group contains consecutive MW-rank component labels.

B. **Target-specific vs optimized target-blind grouping**
At each K, the target-blind comparator selects one partition that minimizes the worst normalized error across:
Mw, dispersity, W1, Tail@M90, and Tail@M99.
Mn is excluded because the reciprocal-Mn-preserving reduction makes it topology-invariant.

## Spherizone bound handling
Stage H reports lower witness bounds and certified upper bounds for W1/tail errors. Pass 10 analyzes LOWER and UPPER bounds separately. It does not collapse them into a fictitious exact error.

## Anti-cherry-picking rule
Qualification depends only on exact reproduction of frozen calculations, input scope, and prerequisite qualification.
No gate requires contiguity to succeed or target-awareness to show a favorable penalty.

## Run
1. Extract the ZIP.
2. Open MATLAB in the extracted package directory.
3. Run:
   Run_JIEC_V3_10_Pass10_FinalGroupingGeneralityCheck
4. Upload the generated `Outputs_Pass10.zip`.

## Frozen inputs
- Stage-I qualified partition-error output embedded in the final Stage-K package.
- Sealed Hardening Pass-4 external-generality extension (two additional primary PP distributions).
- Stage-H qualified all-partition minimax-bound output embedded in the final Stage-K package.

No Spherizone reactor model is rerun.


## v3.10.1 verification-schema hotfix
The Stage-I prerequisite file uses the historical columns `Gate,Pass,MaxError,Detail`,
whereas the Stage-H prerequisite file uses `Gate,Status,Detail`.
The original v3.10 verifier incorrectly assumed both files contained `Status`.
v3.10.1 changes only prerequisite-status parsing and accepts either qualified schema.
No scientific calculation, frozen input, tolerance, partition rule, or independent mirror changed.


## v3.10.2 verifier hotfix
The frozen independent mirrors serialize Boolean results as `True/False`, while MATLAB
serializes the same logical table values as `1/0`. The v3.10.1 verifier compared these
fields textually, causing four false verification failures even though all numerical
differences were within machine precision. v3.10.2 normalizes the two Boolean fields
before comparison. No scientific calculation, frozen input, partition rule, tolerance,
or independent expected result changed.
