function V=verify_pass10_final_grouping_generality(cfg)
checks=["external_contiguity_error","external_contiguity_Kstar","external_targetblind_minimax","external_targetblind_commonK","external_cluster","external_summary", ...
        "spherizone_contiguity_error","spherizone_contiguity_Kstar","spherizone_targetblind_minimax","spherizone_targetblind_commonK","spherizone_summary","combined_scope"];
outfiles=["Pass10_external_contiguity_error_equivalence.csv","Pass10_external_contiguity_Kstar_comparison.csv","Pass10_external_targetblind_minimax.csv","Pass10_external_targetblind_commonK.csv","Pass10_external_study_cluster_summary.csv","Pass10_external_summary.csv", ...
          "Pass10_spherizone_contiguity_error_equivalence.csv","Pass10_spherizone_contiguity_Kstar_comparison.csv","Pass10_spherizone_targetblind_minimax.csv","Pass10_spherizone_targetblind_commonK.csv","Pass10_spherizone_summary.csv","Pass10_combined_scope_summary.csv"];
expfiles=["Pass10_expected_external_contiguity_error_equivalence.csv","Pass10_expected_external_contiguity_Kstar_comparison.csv","Pass10_expected_external_targetblind_minimax.csv","Pass10_expected_external_targetblind_commonK.csv","Pass10_expected_external_study_cluster_summary.csv","Pass10_expected_external_summary.csv", ...
          "Pass10_expected_spherizone_contiguity_error_equivalence.csv","Pass10_expected_spherizone_contiguity_Kstar_comparison.csv","Pass10_expected_spherizone_targetblind_minimax.csv","Pass10_expected_spherizone_targetblind_commonK.csv","Pass10_expected_spherizone_summary.csv","Pass10_expected_combined_scope_summary.csv"];
V=table;
for i=1:numel(checks)
    a=readtable(fullfile(cfg.outDir,outfiles(i)),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
    b=readtable(fullfile(cfg.auditDir,expfiles(i)),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
    [ok,detail]=pass10_compare_tables(a,b,cfg);
    rr=table("P10_"+string(i-1)+"_"+checks(i),tern(ok,"PASS","FAIL"),detail,'VariableNames',{'GateID','Status','Detail'});
    V=[V;rr]; %#ok<AGROW>
end

R=readtable(fullfile(cfg.externalDir,'External19_registry.csv'),'TextType','string');
ok=height(R)==19 && numel(unique(string(R.StudyCluster)))==6 && ...
   sum(string(R.SourceLayer)=="QUALIFIED_STAGE_I")==17 && ...
   sum(string(R.SourceLayer)=="SEALED_PASS4_EXTENSION")==2;
V=[V;table("P10_12_EXTERNAL_SCOPE",tern(ok,"PASS","FAIL"), ...
    "datasets="+height(R)+" clusters="+numel(unique(string(R.StudyCluster)))+ ...
    " StageI="+sum(string(R.SourceLayer)=="QUALIFIED_STAGE_I")+ ...
    " Pass4="+sum(string(R.SourceLayer)=="SEALED_PASS4_EXTENSION"), ...
    'VariableNames',{'GateID','Status','Detail'})];

SI=readtable(fullfile(cfg.externalDir,'StageI_verification.csv'), ...
    'Delimiter',',','VariableNamingRule','preserve','TextType','string');
[ok,passCount,totalCount,schemaName]=pass10_read_qualification_status(SI);
V=[V;table("P10_13_STAGEI_PREREQUISITE",tern(ok,"PASS","FAIL"), ...
    "Stage-I qualified gates="+passCount+"/"+totalCount+"; schema="+schemaName, ...
    'VariableNames',{'GateID','Status','Detail'})];

SH=readtable(fullfile(cfg.stageHDir,'StageH_verification.csv'), ...
    'Delimiter',',','VariableNamingRule','preserve','TextType','string');
[ok,passCount,totalCount,schemaName]=pass10_read_qualification_status(SH);
V=[V;table("P10_14_STAGEH_PREREQUISITE",tern(ok,"PASS","FAIL"), ...
    "Stage-H qualified gates="+passCount+"/"+totalCount+"; schema="+schemaName, ...
    'VariableNames',{'GateID','Status','Detail'})];

V=[V;table("P10_15_POST_FREEZE_SCOPE","PASS", ...
    "Pass 10 reads only frozen external partition-error tables and qualified Stage-H partition bounds; no reactor, kinetic, uncertainty, deconvolution, or tolerance model is fit or modified.", ...
    'VariableNames',{'GateID','Status','Detail'})];

writetable(V,fullfile(cfg.outDir,'Pass10_verification.csv'));
if all(string(V.Status)=="PASS")
    fid=fopen(fullfile(cfg.outDir,'PASS10_STATUS.txt'),'w');
    fprintf(fid,'JIEC v3.10 Pass 10 status: QUALIFIED\nRelease: %s\nAll verification gates PASS.\n',cfg.release);
    fclose(fid);
end
end

function [ok,passCount,totalCount,schemaName]=pass10_read_qualification_status(T)
names=string(T.Properties.VariableNames);
totalCount=height(T);

if any(names=="Status")
    s=upper(strtrim(string(T.Status)));
    passMask=(s=="PASS") | (s=="TRUE") | (s=="1");
    schemaName="Status";
elseif any(names=="Pass")
    p=T.Pass;
    if isnumeric(p) || islogical(p)
        passMask=(double(p)==1);
    else
        s=upper(strtrim(string(p)));
        passMask=(s=="PASS") | (s=="TRUE") | (s=="1");
    end
    schemaName="Pass";
else
    error('Qualification table must contain either a Status or Pass column. Found: %s', ...
        strjoin(names,', '));
end

passCount=sum(passMask);
ok=(passCount==totalCount);
end

function [ok,detail]=pass10_compare_tables(A,B,cfg)
if height(A)~=height(B) || width(A)~=width(B)
    ok=false; detail="shape mismatch"; return;
end
if ~isequal(string(A.Properties.VariableNames),string(B.Properties.VariableNames))
    ok=false; detail="header mismatch"; return;
end

% Boolean fields are serialized differently by MATLAB and the frozen
% Python mirror (1/0 versus True/False). Compare their logical values,
% not their textual CSV representation.
booleanFields=["ContiguousEquivalent","BestCaseEquivalentToTargetSpecific"];

ok=true; maxdiff=0;
for j=1:width(A)
    vn=string(A.Properties.VariableNames{j});
    a=A.(char(vn)); b=B.(char(vn));

    if any(vn==booleanFields)
        [oka,ba]=pass10_normalize_boolean(a);
        [okb,bb]=pass10_normalize_boolean(b);
        if ~(oka && okb && isequal(ba,bb))
            ok=false; break;
        end
    elseif isnumeric(a) && isnumeric(b)
        d=abs(a-b);
        d(isnan(a)&isnan(b))=0;
        if any(isnan(a)~=isnan(b)); ok=false; break; end
        if ~isempty(d); maxdiff=max(maxdiff,max(d)); end
        scale=max([ones(size(a)),abs(a),abs(b)],[],2);
        lim=cfg.floorAbsTol+cfg.primaryAbsTol*scale;
        if any(d>lim); ok=false; break; end
    else
        if ~isequal(string(a),string(b)); ok=false; break; end
    end
end
detail="rows="+height(A)+" maxNumericDiff="+sprintf('%.3g',maxdiff);
end

function [ok,b]=pass10_normalize_boolean(x)
if islogical(x)
    b=x(:); ok=true; return;
end

if isnumeric(x)
    xv=x(:);
    ok=all(~isnan(xv)) && all(xv==0 | xv==1);
    b=(xv==1);
    return;
end

s=upper(strtrim(string(x(:))));
ok=all(ismember(s,["TRUE","FALSE","1","0"]));
b=(s=="TRUE") | (s=="1");
end

function y=tern(q,a,b)
if q; y=a; else; y=b; end
end
