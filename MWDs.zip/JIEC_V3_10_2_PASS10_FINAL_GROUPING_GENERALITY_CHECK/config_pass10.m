function cfg=config_pass10(ROOT)
cfg.release="3.10-pass10-final-grouping-generality-check";
cfg.externalDir=fullfile(ROOT,'data','External19');
cfg.stageHDir=fullfile(ROOT,'data','Spherizone_StageH');
cfg.auditDir=fullfile(ROOT,'Independent_Audit');
cfg.outDir=fullfile(ROOT,'Outputs_Pass10');
cfg.targets=["MnRel","MwRel","DRel","W1","Tail90Abs","Tail99Abs"];
cfg.nonMnTargets=["MwRel","DRel","W1","Tail90Abs","Tail99Abs"];
cfg.tolerances=[0.025,0.025,0.025,0.020,0.025,0.025];
cfg.primaryAbsTol=1e-8;
cfg.floorAbsTol=1e-10;
end
