clear; clc;
ROOT=fileparts(mfilename('fullpath'));
restoredefaultpath;
addpath(ROOT); addpath(fullfile(ROOT,'core')); addpath(fullfile(ROOT,'verify'));
cfg=config_pass10(ROOT);
vf=which('verify_pass10_final_grouping_generality'); expectedVerify=fullfile(ROOT,'verify','verify_pass10_final_grouping_generality.m');
if ~strcmpi(char(vf),char(expectedVerify)); error('Path-safety failure: verifier resolved outside this package.'); end
if exist(cfg.outDir,'dir'); rmdir(cfg.outDir,'s'); end; mkdir(cfg.outDir);

fprintf('[JIEC v3.10 Pass 10] FINAL GROUPING-GENERALITY CHECK\n');
fprintf('Scientific release: %s\n',cfg.release);
fprintf('Frozen scope:\n');
fprintf('  A) Broader 19-distribution external PP cohort (six study clusters).\n');
fprintf('  B) Qualified Spherizone Stage-H projection bounds at EPC 10/20/30 wt%%.\n');
fprintf('Questions:\n');
fprintf('  1) Does the Pass-9 contiguous-partition simplification generalize?\n');
fprintf('  2) Does target-specific grouping retain value versus an optimized target-blind minimax topology?\n');
fprintf('  3) Are the Spherizone conclusions consistent for witness lower and certified upper error bounds?\n');
fprintf('No new fitting, kinetics, uncertainty model, deconvolution, or tolerance tuning is introduced.\n\n');

run_pass10_external19(cfg);
run_pass10_spherizone(cfg);
run_pass10_scope_summary(cfg);
V=verify_pass10_final_grouping_generality(cfg);
npass=sum(string(V.Status)=="PASS");
fprintf('\nPass 10 status: %s (%d/%d gates PASS)\n',tern_local(npass==height(V),'QUALIFIED','FAILED'),npass,height(V));
fprintf('Outputs: %s\n',cfg.outDir);
zipfile=fullfile(ROOT,'Outputs_Pass10.zip'); if exist(zipfile,'file'); delete(zipfile); end
zip(zipfile,{'Outputs_Pass10'},ROOT); fprintf('Archive: %s\n',zipfile);
if npass~=height(V); error('Pass 10 verification failed. Inspect Pass10_verification.csv.'); end
function y=tern_local(q,a,b); if q; y=a; else; y=b; end; end
