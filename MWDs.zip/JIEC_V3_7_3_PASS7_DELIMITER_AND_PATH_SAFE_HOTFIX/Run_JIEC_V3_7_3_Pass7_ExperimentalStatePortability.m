clear; clc;
ROOT=fileparts(mfilename('fullpath'));
% v3.7.3 verifier-only compatibility hotfix. Scientific Pass-7 inputs,
% protocol, algorithms, tolerances, and expected independent mirrors are unchanged.
restoredefaultpath;
addpath(ROOT,'-begin');
addpath(fullfile(ROOT,'core'),'-begin');
addpath(fullfile(ROOT,'verify'),'-begin');
clear functions;
rehash;
expectedVerifier=fullfile(ROOT,'verify','verify_pass7_3_experimental_state_portability.m');
resolvedVerifier=which('verify_pass7_3_experimental_state_portability');
if isempty(resolvedVerifier) || ~strcmpi(char(resolvedVerifier),char(expectedVerifier))
    error('Pass7_3:PathGuard','Wrong verifier resolved. Expected: %s\nResolved: %s',expectedVerifier,resolvedVerifier);
end
cfg=config_pass7_3();
outdir=fullfile(ROOT,'Outputs_Pass7');
if exist(outdir,'dir'),rmdir(outdir,'s');end
mkdir(outdir);
fprintf('[JIEC v3.7.3 Pass 7 delimiter/path-safe verifier hotfix] External experimental state-portability challenge\n');
fprintf('Scientific release: %s\n',cfg.release);
fprintf('Verifier resolved to: %s\n',resolvedVerifier);
fprintf('Published experimental Flory-component state series are used directly; no Spherizone reactor output is read or refitted.\n');
result=run_pass7_experimental_state_portability(cfg,outdir); %#ok<NASGU>
V=verify_pass7_3_experimental_state_portability(cfg,outdir);
pass=all(string(V.Status)=="PASS");
if pass,status='QUALIFIED';else,status='FAILED';end
fid=fopen(fullfile(outdir,'PASS7_STATUS.txt'),'w');
fprintf(fid,'JIEC v3.7 Pass 7 scientific status: %s\nScientific release: %s\nVerifier hotfix: 3.7.3 delimiter/path-safe\nGates passed: %d/%d\n',status,cfg.release,sum(string(V.Status)=="PASS"),height(V));
fclose(fid);
files=dir(fullfile(outdir,'*')); names={files(~[files.isdir]).name};
zip(fullfile(outdir,'Outputs_Pass7.zip'),names,outdir);
fprintf('\nPass 7 status: %s (%d/%d gates PASS)\n',status,sum(string(V.Status)=="PASS"),height(V));
fprintf('Outputs: %s\n',outdir);
if ~pass,error('Pass7:Qualification','Pass 7 verification failed. Inspect Pass7_verification.csv.');end
