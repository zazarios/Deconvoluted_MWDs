# Pre-MATLAB static audit — Pass 7

## Frozen-before-outcome design

The data registry, eligibility/exclusion rules, hypothesis decision rules, tolerance bands, component-alignment rule, and four representation levels were written before the independent Python mirror was evaluated. Their SHA-256 values are recorded in `PROSPECTIVE_FREEZE_SHA256.txt`.

## Independence from the Spherizone model

This package contains no `inputs/` directory and reads no A–K reactor output. Published numerical Flory-component tables are the only molecular-state inputs. Therefore Pass 7 is an external experimental challenge of the representation principle, not a requalification or validation of the MZCR model.

## Primary evidence restrictions

- At least three measured states per primary family.
- Explicit numerical component weights and molecular-weight descriptors.
- No plot digitization.
- Independent of the Alshaiban source data.
- Components are aligned by molecular-weight rank, not by asserted chemical site identity.
- Multiple state families from Li et al. (2015) remain one study cluster for cross-study generality counting.

## Source-specific limitations

- Kissin et al. (2004) analyzes crystalline fractions, not unfractionated PP.
- Li et al. (2015) deconvolutes C7-insoluble fractions.
- Poorsank et al. (2019) SI labels the component molecular-weight column as Mw, but internal whole-Mw consistency supports the scale used in the prior Stage-I audit. A pre-specified uniform factor-two sensitivity is required; target/order/topology conclusions must be invariant.
- Daftaribesheli (2009) is PE and a PhD thesis; it is secondary only.
- Tu et al. (2011) is excluded from numerical primary analysis because complete component values would require graph digitization.

## Important interpretation of Level C

Level C searches only descriptor sets anchored to an experimentally observed state. Failure of all such anchors means that an observed-state-calibrated descriptor set is not portable at the stated tolerance. It does **not** prove nonexistence of every mathematically possible unobserved fixed descriptor set.

## Important interpretation of Level D

Level D freezes both group descriptors and group masses. Because target-specific errors can exhibit compensation, Level D is a sensitivity diagnostic; its K* need not be monotone relative to Level C for every target.

## Execution status

The package has an independent Python mirror and expected output tables in `Independent_Audit/`. MATLAB execution is intentionally left to the user environment; `verify_pass7_experimental_state_portability.m` compares headline results against the independent mirror and enforces scope guards.
