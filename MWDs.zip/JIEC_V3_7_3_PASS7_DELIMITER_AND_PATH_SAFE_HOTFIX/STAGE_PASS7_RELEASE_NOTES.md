# Release notes

This is a post-freeze hardening pass. It does not introduce Stage L and does not change A–K.

Scientific question: whether target-specific representation order and grouping topology, and their dependence on experimental state information, can be reproduced directly from published deconvoluted PP state series without a Spherizone state generator.

The package elevates `P_K*` (which Flory-component ranks should be merged) alongside `K*` (how many groups are required).
