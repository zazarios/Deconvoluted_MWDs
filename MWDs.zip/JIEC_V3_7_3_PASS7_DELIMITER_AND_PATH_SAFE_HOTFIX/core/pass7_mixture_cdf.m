function F = pass7_mixture_cdf(M,w,Mn)
%PASS7_MIXTURE_CDF Weight CDF of a mixture of Flory most-probable components.
M=M(:); w=w(:)'; Mn=Mn(:)';
u=M*(1./Mn); q=1-exp(-min(u,745)).*(1+u); q(u>745)=1; F=q*w(:);
end
