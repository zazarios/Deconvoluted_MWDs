function result = run_pass7_experimental_state_portability(cfg,outdir)
%RUN_PASS7_EXPERIMENTAL_STATE_PORTABILITY
% Post-freeze, reactor-independent experimental challenge of target/state-aware
% Flory-component grouping. No A-K reactor output is changed or refitted.
if ~exist(outdir,'dir'), mkdir(outdir); end
ROOT=fileparts(fileparts(mfilename('fullpath')));
F=readtable(fullfile(ROOT,'data','pass7_state_family_registry.csv'),'TextType','string','VariableNamingRule','preserve');
C=readtable(fullfile(ROOT,'data','pass7_state_component_data.csv'),'TextType','string','VariableNamingRule','preserve');
Targets={'MnRel','MwRel','DRel','W1','Tail90Abs','Tail99Abs'};

BaseRows=struct([]); PartRows=struct([]); OptRows=struct([]); OrderRows=struct([]);
BRows=struct([]); BOrderRows=struct([]); TopoRows=struct([]);
CRows=struct([]); COrderRows=struct([]); DRows=struct([]); DOrderRows=struct([]);

for ifam=1:height(F)
    fid=F.FamilyID(ifam); role=F.Role(ifam); study=F.StudyCluster(ifam); J=F.J(ifam);
    ix=C.FamilyID==fid; Cf=C(ix,:); stateIDs=unique(Cf.StateID,'stable'); ns=numel(stateIDs);
    States=repmat(struct('StateID',"",'StateValue',0,'w',[],'Mn',[],'Meta',[],'PartMetric',[]),1,ns);
    P=pass7_generate_partitions(J); np=numel(P);
    for is=1:ns
        sid=stateIDs(is); S=Cf(Cf.StateID==sid,:); [~,o]=sort(S.Mn_gmol); S=S(o,:);
        w=S.WeightPct(:)'/sum(S.WeightPct); Mn=S.Mn_gmol(:)'; meta=pass7_full_meta(w,Mn,cfg);
        States(is).StateID=sid; States(is).StateValue=S.StateValue(1); States(is).w=w; States(is).Mn=Mn; States(is).Meta=meta;
        BaseRows=append7(BaseRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'StateID',char(sid), ...
            'StateValue',S.StateValue(1),'J',J,'WeightSum',sum(w),'Mn_full_gmol',meta.Mn,'Mw_full_gmol',meta.Mw,'D_full',meta.D,'M90_full_gmol',meta.M90,'M99_full_gmol',meta.M99));
        PM=zeros(np,numel(Targets));
        for ip=1:np
            [rw,rm]=pass7_reduce_partition(w,Mn,P(ip).Groups); V=pass7_metric_vector(meta,rw,rm,cfg);
            PM(ip,:)=[V.MnRel V.MwRel V.DRel V.W1 V.Tail90Abs V.Tail99Abs];
            PartRows=append7(PartRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'StateID',char(sid),'StateValue',S.StateValue(1), ...
                'J',J,'K',P(ip).K,'PartitionCode',P(ip).Code,'MnRel',V.MnRel,'MwRel',V.MwRel,'DRel',V.DRel,'W1',V.W1,'Tail90Abs',V.Tail90Abs,'Tail99Abs',V.Tail99Abs));
        end
        States(is).PartMetric=PM;
        for iy=1:numel(Targets)
            target=Targets{iy};
            for K=1:J
                idx=find([P.K]==K); vals=PM(idx,iy); [v,ii]=min(vals); ip=idx(ii);
                OptRows=append7(OptRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'StateID',char(sid),'Target',target,'K',K,'MinError',v,'BestPartition',P(ip).Code));
            end
            [tols,labels,~]=pass7_tolset(target,cfg);
            valsK=zeros(1,J);
            for K=1:J
                idx=find([P.K]==K); valsK(K)=min(PM(idx,iy));
            end
            for it=1:numel(tols)
                k=find(valsK<=tols(it)+1e-14,1,'first'); if isempty(k), k=NaN; end
                OrderRows=append7(OrderRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'StateID',char(sid),'Target',target,'ToleranceLabel',labels{it},'Tolerance',tols(it),'Kstar',k));
            end
        end
    end

    % State-specific topology variability.
    Otmp=struct2table(OptRows); Otmp.FamilyID=string(Otmp.FamilyID); Otmp.StateID=string(Otmp.StateID); Otmp.Target=string(Otmp.Target); Otmp.BestPartition=string(Otmp.BestPartition);
    for iy=1:numel(Targets)
        for K=1:J
            q=Otmp(Otmp.FamilyID==fid & Otmp.Target==Targets{iy} & Otmp.K==K,:);
            bp=unique(q.BestPartition); entries=strings(height(q),1);
            for r=1:height(q), entries(r)=q.StateID(r)+":"+q.BestPartition(r); end
            TopoRows=append7(TopoRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'Target',Targets{iy},'K',K,'StateCount',ns, ...
                'DistinctStateSpecificBestPartitions',numel(bp),'StateSpecificBestPartitions',char(strjoin(entries,';'))));
        end
    end

    % Level B: one topology across states; descriptors remain state-specific.
    bestB=inf(numel(Targets),J); bestBCode=strings(numel(Targets),J); bestBWorst=strings(numel(Targets),J);
    % Level C: one topology and one observed-state-anchored descriptor set;
    % evaluation-state group weights remain state-specific.
    bestC=inf(numel(Targets),J); bestCCode=strings(numel(Targets),J); bestCAnchor=strings(numel(Targets),J); bestCWorst=strings(numel(Targets),J);
    % Level D sensitivity: fully fixed observed-state-anchored reduced MWD.
    bestD=inf(numel(Targets),J); bestDCode=strings(numel(Targets),J); bestDAnchor=strings(numel(Targets),J); bestDWorst=strings(numel(Targets),J);

    for ip=1:np
        K=P(ip).K;
        % B uses the already-computed state-specific metrics for this topology.
        for iy=1:numel(Targets)
            vals=zeros(1,ns);
            for is=1:ns, vals(is)=States(is).PartMetric(ip,iy); end
            [worst,iw]=max(vals);
            if worst<bestB(iy,K), bestB(iy,K)=worst; bestBCode(iy,K)=string(P(ip).Code); bestBWorst(iy,K)=States(iw).StateID; end
        end
        % C/D: enumerate each observed state as a prospective descriptor anchor.
        for ia=1:ns
            [aw,am]=pass7_reduce_partition(States(ia).w,States(ia).Mn,P(ip).Groups);
            WC=zeros(ns,numel(Targets)); WD=zeros(ns,numel(Targets));
            for is=1:ns
                [cw,cm]=pass7_reduce_partition(States(is).w,States(is).Mn,P(ip).Groups,am,[]);
                VC=pass7_metric_vector(States(is).Meta,cw,cm,cfg);
                [dw,dm]=pass7_reduce_partition(States(is).w,States(is).Mn,P(ip).Groups,am,aw);
                VD=pass7_metric_vector(States(is).Meta,dw,dm,cfg);
                WC(is,:)=[VC.MnRel VC.MwRel VC.DRel VC.W1 VC.Tail90Abs VC.Tail99Abs];
                WD(is,:)=[VD.MnRel VD.MwRel VD.DRel VD.W1 VD.Tail90Abs VD.Tail99Abs];
            end
            for iy=1:numel(Targets)
                [wc,iwc]=max(WC(:,iy));
                if wc<bestC(iy,K), bestC(iy,K)=wc; bestCCode(iy,K)=string(P(ip).Code); bestCAnchor(iy,K)=States(ia).StateID; bestCWorst(iy,K)=States(iwc).StateID; end
                [wd,iwd]=max(WD(:,iy));
                if wd<bestD(iy,K), bestD(iy,K)=wd; bestDCode(iy,K)=string(P(ip).Code); bestDAnchor(iy,K)=States(ia).StateID; bestDWorst(iy,K)=States(iwd).StateID; end
            end
        end
    end

    for iy=1:numel(Targets)
        target=Targets{iy}; [tols,labels,~]=pass7_tolset(target,cfg);
        for K=1:J
            BRows=append7(BRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'Target',target,'K',K,'MinimaxError',bestB(iy,K),'BestCommonPartition',char(bestBCode(iy,K)),'WorstState',char(bestBWorst(iy,K))));
            CRows=append7(CRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'Target',target,'K',K,'MinimaxError',bestC(iy,K),'BestCommonPartition',char(bestCCode(iy,K)),'WorstState',char(bestCWorst(iy,K)),'BestAnchorState',char(bestCAnchor(iy,K))));
            DRows=append7(DRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'Target',target,'K',K,'MinimaxError',bestD(iy,K),'BestCommonPartition',char(bestDCode(iy,K)),'WorstState',char(bestDWorst(iy,K)),'BestAnchorState',char(bestDAnchor(iy,K))));
        end
        for it=1:numel(tols)
            kb=find(bestB(iy,:)<=tols(it)+1e-14,1); kc=find(bestC(iy,:)<=tols(it)+1e-14,1); kd=find(bestD(iy,:)<=tols(it)+1e-14,1);
            if isempty(kb), kb=NaN; sb='NO_CLOSURE'; else, sb='CLOSED'; end
            if isempty(kc), kc=NaN; sc='NO_CLOSURE'; else, sc='CLOSED'; end
            if isempty(kd), kd=NaN; sd='NO_CLOSURE'; else, sd='CLOSED'; end
            BOrderRows=append7(BOrderRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'Target',target,'ToleranceLabel',labels{it},'Tolerance',tols(it),'Kstar',kb,'ClosureStatus',sb));
            COrderRows=append7(COrderRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'Target',target,'ToleranceLabel',labels{it},'Tolerance',tols(it),'Kstar',kc,'ClosureStatus',sc));
            DOrderRows=append7(DOrderRows,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'Target',target,'ToleranceLabel',labels{it},'Tolerance',tols(it),'Kstar',kd,'ClosureStatus',sd));
        end
    end
end

% Convert/write core outputs.
Baseline=toTable7(BaseRows); AllParts=toTable7(PartRows); StateOpt=toTable7(OptRows); StateOrder=toTable7(OrderRows);
Bsum=toTable7(BRows); Bord=toTable7(BOrderRows); Topo=toTable7(TopoRows); Csum=toTable7(CRows); Cord=toTable7(COrderRows); Dsum=toTable7(DRows); Dord=toTable7(DOrderRows);
writetable(Baseline,fullfile(outdir,'Pass7_state_baseline.csv')); writetable(AllParts,fullfile(outdir,'Pass7_state_all_partition_errors.csv'));
writetable(StateOpt,fullfile(outdir,'Pass7_state_specific_optima.csv')); writetable(StateOrder,fullfile(outdir,'Pass7_state_specific_order_map.csv'));
writetable(Bsum,fullfile(outdir,'Pass7_family_fixed_topology_minimax.csv')); writetable(Bord,fullfile(outdir,'Pass7_family_fixed_topology_order_map.csv'));
writetable(Topo,fullfile(outdir,'Pass7_topology_state_variation.csv')); writetable(Csum,fullfile(outdir,'Pass7_fixed_descriptor_anchor_minimax.csv'));
writetable(Cord,fullfile(outdir,'Pass7_fixed_descriptor_order_map.csv')); writetable(Dsum,fullfile(outdir,'Pass7_fully_fixed_anchor_minimax.csv')); writetable(Dord,fullfile(outdir,'Pass7_fully_fixed_order_map.csv'));

% Moderate-tolerance portability penalties and family-level hypothesis readout.
Pen=struct([]); Fam=struct([]);
for ifam=1:height(F)
    fid=F.FamilyID(ifam); study=F.StudyCluster(ifam); role=F.Role(ifam); J=F.J(ifam);
    for iy=1:numel(Targets)
        target=Targets{iy}; q=StateOrder(StateOrder.FamilyID==fid & StateOrder.Target==target & StateOrder.ToleranceLabel=="MODERATE",:); maxState=max(q.Kstar);
        kb=singleK7(Bord,fid,target); kc=singleK7(Cord,fid,target); kd=singleK7(Dord,fid,target);
        tp=NaN; dp=NaN; if ~isnan(kb), tp=kb-maxState; end; if ~isnan(kb)&&~isnan(kc), dp=kc-kb; end
        Pen=append7(Pen,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'Target',target,'MaxStateSpecificKstar',maxState, ...
            'FamilyFixedTopologyKstar',kb,'FixedDescriptorAnchoredKstar',kc,'FullyFixedAnchoredKstar',kd,'TopologyPenalty',tp,'DescriptorPenalty',dp));
    end
    Ptmp=toTable7(Pen); pf=Ptmp(Ptmp.FamilyID==fid,:);
    strictTop=sum(~isnan(pf.FamilyFixedTopologyKstar) & pf.FamilyFixedTopologyKstar>pf.MaxStateSpecificKstar);
    descStrict=sum(~isnan(pf.FixedDescriptorAnchoredKstar) & ~isnan(pf.FamilyFixedTopologyKstar) & pf.FixedDescriptorAnchoredKstar>pf.FamilyFixedTopologyKstar);
    descNC=sum(isnan(pf.FixedDescriptorAnchoredKstar));
    tv=Topo(Topo.FamilyID==fid & Topo.K==2,:); topoTargets=sum(tv.DistinctStateSpecificBestPartitions>1);
    ss=StateOrder(StateOrder.FamilyID==fid & StateOrder.ToleranceLabel=="MODERATE",:); stateIDs=unique(ss.StateID); td=0;
    for is=1:numel(stateIDs), z=ss(ss.StateID==stateIDs(is),:); if numel(unique(z.Kstar))>1, td=td+1; end; end
    Fam=append7(Fam,struct('FamilyID',char(fid),'StudyCluster',char(study),'Role',char(role),'StateCount',F.StateCount(ifam),'J',J, ...
        'StateSpecificTargetDependentStates',td,'K2TopologyStateDependentTargets',topoTargets,'StrictCommonTopologyPenaltyTargets',strictTop, ...
        'StrictFixedDescriptorPenaltyTargets',descStrict,'FixedDescriptorNoClosureTargets',descNC));
end
PenTable=toTable7(Pen); FamStatus=toTable7(Fam); writetable(PenTable,fullfile(outdir,'Pass7_moderate_portability_penalties.csv')); writetable(FamStatus,fullfile(outdir,'Pass7_family_hypothesis_status.csv'));

% Poorsank factor-two scale sensitivity (Levels A and B). Uniform scale is
% expected to preserve relative-moment, W1-on-logM, tail, and topology order.
Scale=pass7_poorsank_scale_sensitivity(cfg,F,C,StateOpt,Bsum,Targets); writetable(Scale,fullfile(outdir,'Pass7_Poorsank_scale_sensitivity.csv'));

% Pre-specified generality verdict; study clusters, not individual states, are units of replication.
prim=FamStatus(FamStatus.Role=="PRIMARY_PP",:); clusters=unique(prim.StudyCluster); supportStrings=strings(0,1); nsupport=0;
for ic=1:numel(clusters)
    g=prim(prim.StudyCluster==clusters(ic),:); flag=any(g.StrictCommonTopologyPenaltyTargets>0 | g.StrictFixedDescriptorPenaltyTargets>0 | g.FixedDescriptorNoClosureTargets>0);
    if flag, nsupport=nsupport+1; supportStrings(end+1)=clusters(ic); end %#ok<AGROW>
end
if nsupport>=2, verdict='EXTERNAL_EXPERIMENTAL_STATE_INFORMATION_EFFECT_SUPPORTED_ACROSS_MULTIPLE_PP_STUDY_CLUSTERS';
elseif nsupport==1, verdict='EXTERNAL_EXPERIMENTAL_STATE_INFORMATION_EFFECT_MIXED_SINGLE_CLUSTER_SUPPORT';
else, verdict='EXTERNAL_EXPERIMENTAL_STATE_INFORMATION_EFFECT_NOT_REPRODUCED'; end
Generality=table(sum(F.Role=="PRIMARY_PP"),numel(unique(F.StudyCluster(F.Role=="PRIMARY_PP"))),sum(F.StateCount(F.Role=="PRIMARY_PP")),nsupport,string(strjoin(supportStrings,';')),string(verdict), ...
    'VariableNames',{'PrimaryFamilyCount','PrimaryStudyClusterCount','PrimaryStateCount','SupportingStudyClusters','SupportingStudyClusterIDs','Verdict'});
writetable(Generality,fullfile(outdir,'Pass7_generality_verdict.csv'));

result=struct('Baseline',Baseline,'AllParts',AllParts,'StateOpt',StateOpt,'StateOrder',StateOrder,'Bsum',Bsum,'Bord',Bord,'Topo',Topo,'Csum',Csum,'Cord',Cord,'Dsum',Dsum,'Dord',Dord,'Penalties',PenTable,'FamilyStatus',FamStatus,'ScaleSensitivity',Scale,'Generality',Generality);
end

function k=singleK7(O,fid,target)
q=O(O.FamilyID==fid & O.Target==target & O.ToleranceLabel=="MODERATE",:); if height(q)~=1,error('Pass7:OrderKey','Order row mismatch.');end; k=q.Kstar(1);
end
function A=append7(A,r)
if isempty(A),A=r;return;end
if ~isequal(fieldnames(A),fieldnames(r)),error('Pass7:StructSchema','Record schema mismatch.');end
A(end+1)=r;
end
function T=toTable7(S)
T=struct2table(S); vn=T.Properties.VariableNames;
for i=1:numel(vn), if iscellstr(T.(vn{i})), T.(vn{i})=string(T.(vn{i})); end; end
end

function Scale=pass7_poorsank_scale_sensitivity(cfg,F,C,StateOpt,Bsum,Targets)
fid="POORSANK2019_DONOR"; fr=F(F.FamilyID==fid,:); Cf=C(C.FamilyID==fid,:); stateIDs=unique(Cf.StateID,'stable'); P=pass7_generate_partitions(fr.J(1)); Srows=struct([]);
States=repmat(struct('StateID',"",'w',[],'Mn',[],'Meta',[]),1,numel(stateIDs));
for is=1:numel(stateIDs)
    q=Cf(Cf.StateID==stateIDs(is),:); [~,o]=sort(q.Mn_gmol); q=q(o,:); w=q.WeightPct(:)'/sum(q.WeightPct); Mn=(q.Mn_gmol(:)'/2); States(is)=struct('StateID',stateIDs(is),'w',w,'Mn',Mn,'Meta',pass7_full_meta(w,Mn,cfg));
    for iy=1:numel(Targets)
        for K=1:fr.J(1)
            idx=find([P.K]==K); vals=zeros(numel(idx),1);
            for ii=1:numel(idx), [rw,rm]=pass7_reduce_partition(w,Mn,P(idx(ii)).Groups); V=pass7_metric_vector(States(is).Meta,rw,rm,cfg); vals(ii)=V.(Targets{iy}); end
            [v,jj]=min(vals); code=string(P(idx(jj)).Code); orig=StateOpt(StateOpt.FamilyID==fid & StateOpt.StateID==stateIDs(is) & StateOpt.Target==Targets{iy} & StateOpt.K==K,:);
            Srows=append7(Srows,struct('Level','A_STATE_SPECIFIC','StateID',char(stateIDs(is)),'Target',Targets{iy},'K',K,'OriginalBestPartition',char(orig.BestPartition(1)), ...
                'Factor2BestPartition',char(code),'OriginalError',orig.MinError(1),'Factor2Error',v,'PartitionMatch',orig.BestPartition(1)==code,'ErrorAbsDiff',abs(orig.MinError(1)-v)));
        end
    end
end
for iy=1:numel(Targets)
    for K=1:fr.J(1)
        idx=find([P.K]==K); vals=zeros(numel(idx),1);
        for ii=1:numel(idx)
            e=zeros(numel(States),1);
            for is=1:numel(States), [rw,rm]=pass7_reduce_partition(States(is).w,States(is).Mn,P(idx(ii)).Groups); V=pass7_metric_vector(States(is).Meta,rw,rm,cfg); e(is)=V.(Targets{iy}); end
            vals(ii)=max(e);
        end
        [v,jj]=min(vals);code=string(P(idx(jj)).Code);orig=Bsum(Bsum.FamilyID==fid & Bsum.Target==Targets{iy} & Bsum.K==K,:);
        Srows=append7(Srows,struct('Level','B_FIXED_TOPOLOGY','StateID','ALL','Target',Targets{iy},'K',K,'OriginalBestPartition',char(orig.BestCommonPartition(1)), ...
            'Factor2BestPartition',char(code),'OriginalError',orig.MinimaxError(1),'Factor2Error',v,'PartitionMatch',orig.BestCommonPartition(1)==code,'ErrorAbsDiff',abs(orig.MinimaxError(1)-v)));
    end
end
Scale=toTable7(Srows);
end
