function V = pass7_metric_vector(S,rw,rm,cfg)
rw=rw(:)'; rm=rm(:)'; M=10.^cfg.logM_grid(:); x=cfg.logM_grid(:);
MnR=1/sum(rw./rm); MwR=sum(rw.*(2*rm)); DR=MwR/MnR;
Fr=pass7_mixture_cdf(M,rw,rm);
V.MnRel=abs(MnR/S.Mn-1); V.MwRel=abs(MwR/S.Mw-1); V.DRel=abs(DR/S.D-1);
V.W1=trapz(x,abs(S.F-Fr));
V.Tail90Abs=abs((1-pass7_mixture_cdf(S.M90,rw,rm))-0.10);
V.Tail99Abs=abs((1-pass7_mixture_cdf(S.M99,rw,rm))-0.01);
end
