function [tols,labels,unit] = pass7_tolset(target,cfg)
labels=cfg.tolerance_labels;
if strcmp(target,'W1'), tols=cfg.W1_tolerances_decades; unit='decades';
elseif startsWith(target,'Tail'), tols=cfg.tail_abs_tolerances; unit='absolute_mass_fraction';
else, tols=cfg.scalar_rel_tolerances; unit='relative_fraction'; end
end
