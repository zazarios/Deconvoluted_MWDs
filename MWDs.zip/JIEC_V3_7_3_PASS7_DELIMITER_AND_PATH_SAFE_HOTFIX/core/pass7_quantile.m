function q = pass7_quantile(p,w,Mn)
%PASS7_QUANTILE Geometric bisection quantile of Flory-mixture weight CDF.
lo=max(1e-8,min(Mn)*1e-4); hi=max(Mn)*1e4;
for k=1:100
    mid=sqrt(lo*hi); f=pass7_mixture_cdf(mid,w,Mn);
    if f<p, lo=mid; else, hi=mid; end
end
q=sqrt(lo*hi);
end
