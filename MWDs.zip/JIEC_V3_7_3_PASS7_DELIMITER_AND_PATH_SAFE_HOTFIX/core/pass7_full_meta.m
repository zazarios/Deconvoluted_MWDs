function S = pass7_full_meta(w,Mn,cfg)
w=w(:)'; Mn=Mn(:)'; w=w/sum(w); M=10.^cfg.logM_grid(:);
S.w=w; S.MnComp=Mn; S.F=pass7_mixture_cdf(M,w,Mn);
S.Mn=1/sum(w./Mn); S.Mw=sum(w.*(2*Mn)); S.D=S.Mw/S.Mn;
S.M90=pass7_quantile(0.90,w,Mn); S.M99=pass7_quantile(0.99,w,Mn);
end
