function [W,Mg] = pass7_reduce_partition(w,Mn,groups,fixedMn,fixedW)
%PASS7_REDUCE_PARTITION Merge all source components into the supplied groups.
% State-specific group descriptor is harmonic Mn unless fixedMn is supplied.
if nargin<4, fixedMn=[]; end
if nargin<5, fixedW=[]; end
w=w(:)'; Mn=Mn(:)'; w=max(w,0); w=w/sum(w);
K=numel(groups); W=zeros(1,K); Mg=zeros(1,K);
for g=1:K
    idx=groups{g}; W(g)=sum(w(idx));
    if isempty(fixedMn)
        if W(g)<=1e-15, Mg(g)=NaN; else, wi=w(idx)/W(g); Mg(g)=1/sum(wi./Mn(idx)); end
    else
        Mg(g)=fixedMn(g);
    end
end
if ~isempty(fixedW), W=fixedW(:)'; end
keep=W>1e-15; W=W(keep); Mg=Mg(keep); W=W/sum(W);
end
