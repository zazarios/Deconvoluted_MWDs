function P = pass7_generate_partitions(n)
%PASS7_GENERATE_PARTITIONS All canonical set partitions for 1<=n<=7.
if ~(isscalar(n) && n>=1 && n<=7 && n==round(n)), error('Pass7:PartitionN','n must be integer 1..7.'); end
R=0;
for pos=2:n
    T=[];
    for ir=1:size(R,1)
        m=max(R(ir,:));
        for a=0:(m+1), T(end+1,:)=[R(ir,:) a]; %#ok<AGROW>
        end
    end
    R=T;
end
P=repmat(struct('RGS',[],'K',0,'Groups',{{}},'Code',''),1,size(R,1));
for i=1:size(R,1)
    r=R(i,:); K=max(r)+1; G=cell(1,K); parts=cell(1,K);
    for g=1:K
        G{g}=find(r==(g-1));
        parts{g}=sprintf('%d-',G{g}); parts{g}=parts{g}(1:end-1);
    end
    P(i).RGS=r; P(i).K=K; P(i).Groups=G; P(i).Code=strjoin(parts,'|');
end
end
