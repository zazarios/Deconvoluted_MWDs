# JIEC v3.7 Hardening Pass 7 — External Experimental State-Portability Challenge

Release: `3.7-pass7-external-experimental-state-portability`

## Purpose

This post-freeze package tests whether target- and state-aware molecular representation is reproduced in published **experimental Flory-component state series**, without using the Spherizone/MZCR state generator. It does not alter or refit frozen A–K outputs.

The transferable outputs are:

- `K*`: minimum retained Flory-component group count meeting a target-specific tolerance.
- `P_K*`: target-specific grouping topology (which component ranks are merged).

Components are aligned **only by ascending molecular-weight rank within each measured state**. No one-to-one chemical active-site identity is assumed.

## Primary PP state families

1. Kissin, Rishina & Vizen (2002): four H2 states, five Flory components.
2. Kissin, Ohnishi & Konakazawa (2004): six temperatures, four Flory components (crystalline fraction).
3. Li et al. (2015): five cocatalyst states with DDS fixed.
4. Li et al. (2015): five cocatalyst states with DCPDMS fixed.
5. Li et al. (2015): five donor-blend states at fixed cocatalyst.
6. Poorsank et al. (2019): four donor-ratio states, five components.

The primary cohort therefore contains 29 experimental states from four publication/study clusters. A Daftaribesheli (2009) PE H2 slurry series is secondary cross-polyolefin evidence only.

## Pre-specified representation tests

**Level A — state-specific topology and descriptors.** Each state may select its own partition; group descriptors are reconstructed from that state.

**Level B — one topology across the experimental family.** The grouping topology is fixed across all measured states, but group descriptors are reconstructed from each state. This isolates topology portability.

**Level C — one topology + observed-state-anchored descriptors.** One observed state supplies group descriptors for deployment across all family states; group masses remain state-specific. This is an observed-state portability test, not a proof that no other unobserved fixed descriptor could work.

**Level D — fully fixed observed-state-anchored reduced MWD sensitivity.** Topology, group descriptors, and group masses are frozen to one observed state. This is a strict sensitivity diagnostic and is not assumed to be nested monotonically in target-specific error with Level C.

Targets and tolerance bands are frozen to the Stage-I definitions: Mn, Mw, dispersity, W1 on log10(M), Tail@M90, and Tail@M99; scalar/tail/W1 moderate tolerances are 2.5%, 0.025 absolute mass fraction, and 0.020 decades, respectively.

## Run

In MATLAB, set the current folder to this package and run:

```matlab
Run_JIEC_V3_7_Pass7_ExperimentalStatePortability
```

The script writes `Outputs_Pass7/`, performs gate-based verification, writes `PASS7_STATUS.txt`, and creates `Outputs_Pass7.zip`.

## Interpretation guardrails

Pass 7 can independently support or challenge target dependence, grouping-topology state dependence, and portability of representations selected under one experimental state. It **cannot** validate the Spherizone reactor model, identify chemical active sites, validate kinetic parameters, or establish a universal state-dependence law.
