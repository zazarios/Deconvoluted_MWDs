clear; clc;
ROOT=fileparts(mfilename('fullpath')); addpath(fullfile(ROOT,'core')); addpath(fullfile(ROOT,'verify'));
cfg=config_pass7(); outdir=fullfile(ROOT,'Outputs_Pass7'); if exist(outdir,'dir'),rmdir(outdir,'s');end;mkdir(outdir);
fprintf('[JIEC v3.7.1 Pass 7 verifier hotfix] External experimental state-portability challenge\n');
fprintf('Release: %s\n',cfg.release);
fprintf('Published experimental Flory-component state series are used directly; no Spherizone reactor output is read or refitted.\n');
result=run_pass7_experimental_state_portability(cfg,outdir); %#ok<NASGU>
V=verify_pass7_experimental_state_portability(cfg,outdir);
pass=all(string(V.Status)=="PASS");
if pass,status='QUALIFIED';else,status='FAILED';end
fid=fopen(fullfile(outdir,'PASS7_STATUS.txt'),'w');fprintf(fid,'JIEC v3.7 Pass 7 status: %s\nRelease: %s\nGates passed: %d/%d\n',status,cfg.release,sum(string(V.Status)=="PASS"),height(V));fclose(fid);
files=dir(fullfile(outdir,'*')); names={files(~[files.isdir]).name}; zip(fullfile(outdir,'Outputs_Pass7.zip'),names,outdir);
fprintf('\nPass 7 status: %s (%d/%d gates PASS)\n',status,sum(string(V.Status)=="PASS"),height(V));
fprintf('Outputs: %s\n',outdir);
if ~pass,error('Pass7:Qualification','Pass 7 verification failed. Inspect Pass7_verification.csv.');end
