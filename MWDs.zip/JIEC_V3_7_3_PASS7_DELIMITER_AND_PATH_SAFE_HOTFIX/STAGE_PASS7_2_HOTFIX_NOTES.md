# JIEC v3.7.2 Pass 7 path-safe verifier hotfix

This hotfix exists because a MATLAB session can resolve the old v3.7 verifier if the original package remains on the MATLAB path. The v3.7.2 runner and verifier have unique function names and the runner resets/adds package paths before execution.

Scientific data, prospective freeze, algorithms, expected mirrors, tolerances, cohorts, and claim scope are unchanged from v3.7.

Run **Run_JIEC_V3_7_2_Pass7_ExperimentalStatePortability.m**. The first banner line must contain `v3.7.2` and MATLAB must print the verifier path inside this package.
