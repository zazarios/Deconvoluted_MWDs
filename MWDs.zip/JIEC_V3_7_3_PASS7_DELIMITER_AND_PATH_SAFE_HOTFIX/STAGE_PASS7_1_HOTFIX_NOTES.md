# JIEC v3.7.1 Pass 7 verifier header hotfix

## Scope
Verifier-only compatibility hotfix for MATLAB R2025b. No source data, prospective protocol, state-family registry, component table, target, tolerance, partition enumeration, or scientific calculation is changed. The frozen scientific release remains `3.7-pass7-external-experimental-state-portability`.

## Failure corrected
MATLAB `readtable` auto-detection can treat the first row of an all-text CSV as data. For `data/pass7_claim_scope.csv`, this can produce generic variable names rather than `Claim`, causing the P7_9 scope guard to fail before qualification.

## Changes
1. `read7` now explicitly sets `ReadVariableNames=true`.
2. P7_9 uses a defensive named/positional column accessor for `Claim` and `Status`.
3. Gate status fields are stored as MATLAB strings.
4. The one-button runner converts verification status to string before PASS counting.

## Scientific freeze
`PROSPECTIVE_FREEZE_SHA256.txt` is unchanged. All seven frozen files and hashes are identical to v3.7.
