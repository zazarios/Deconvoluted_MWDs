# JIEC v3.7.3 Pass 7 verifier hotfix

Scientific release remains `3.7-pass7-external-experimental-state-portability`.

This hotfix changes no scientific input, experimental state family, partition search,
metric, tolerance, hypothesis decision rule, or independent expected result.

Changes:
1. unique path-safe v3.7.3 runner/verifier names;
2. explicit comma delimiter in verifier CSV reads, preventing MATLAB R2025b locale/
auto-detection from importing the all-text `pass7_claim_scope.csv` as one column;
3. matching `config_pass7_3` function/file name.

The prospective frozen data files and hashes are unchanged.
