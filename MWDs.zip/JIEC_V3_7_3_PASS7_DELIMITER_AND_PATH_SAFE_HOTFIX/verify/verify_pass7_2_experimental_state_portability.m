function V = verify_pass7_2_experimental_state_portability(cfg,outdir)
%VERIFY_PASS7_EXPERIMENTAL_STATE_PORTABILITY Gate-based verification.
ROOT=fileparts(fileparts(mfilename('fullpath'))); rows=struct([]);
req={'Pass7_state_baseline.csv','Pass7_state_all_partition_errors.csv','Pass7_state_specific_optima.csv','Pass7_state_specific_order_map.csv', ...
 'Pass7_family_fixed_topology_minimax.csv','Pass7_family_fixed_topology_order_map.csv','Pass7_topology_state_variation.csv', ...
 'Pass7_fixed_descriptor_anchor_minimax.csv','Pass7_fixed_descriptor_order_map.csv','Pass7_fully_fixed_anchor_minimax.csv','Pass7_fully_fixed_order_map.csv', ...
 'Pass7_moderate_portability_penalties.csv','Pass7_family_hypothesis_status.csv','Pass7_Poorsank_scale_sensitivity.csv','Pass7_generality_verdict.csv'};
missing={};for i=1:numel(req),if ~isfile(fullfile(outdir,req{i})),missing{end+1}=req{i};end,end %#ok<AGROW>
rows=addgate(rows,'P7_0_REQUIRED_OUTPUTS',isempty(missing),sprintf('missing=%d',numel(missing)));
if ~isempty(missing), V=struct2table(rows);writetable(V,fullfile(outdir,'Pass7_verification.csv'));return;end
B=read7(fullfile(outdir,'Pass7_state_baseline.csv')); A=read7(fullfile(outdir,'Pass7_state_all_partition_errors.csv')); O=read7(fullfile(outdir,'Pass7_state_specific_order_map.csv'));
BS=read7(fullfile(outdir,'Pass7_family_fixed_topology_minimax.csv')); BO=read7(fullfile(outdir,'Pass7_family_fixed_topology_order_map.csv'));
Fam=read7(fullfile(outdir,'Pass7_family_hypothesis_status.csv')); Scale=read7(fullfile(outdir,'Pass7_Poorsank_scale_sensitivity.csv')); G=read7(fullfile(outdir,'Pass7_generality_verdict.csv'));
F=read7(fullfile(ROOT,'data','pass7_state_family_registry.csv'));
rows=addgate(rows,'P7_1_FAMILY_COUNTS',height(F)==cfg.expected_all_families && sum(F.Role=="PRIMARY_PP")==cfg.expected_primary_families,sprintf('all=%d primary=%d',height(F),sum(F.Role=="PRIMARY_PP")));
rows=addgate(rows,'P7_2_PRIMARY_STATE_COUNT',sum(F.StateCount(F.Role=="PRIMARY_PP"))==cfg.expected_primary_states && height(B)==cfg.expected_all_states,sprintf('primary=%d all=%d',sum(F.StateCount(F.Role=="PRIMARY_PP")),height(B)));
% Bell partition cardinality: J=4 -> 15; J=5 -> 52.
ok=true;detail="";fids=unique(B.FamilyID);
for i=1:numel(fids)
 q=B(B.FamilyID==fids(i),:); J=q.J(1); expected=15;if J==5,expected=52;end
 a=A(A.FamilyID==fids(i),:); nper=height(a)/height(q);if abs(nper-expected)>1e-12,ok=false;end; detail=detail+fids(i)+":"+string(nper)+";";
end
rows=addgate(rows,'P7_3_PARTITION_CARDINALITY',ok,char(detail));
% State-specific Mn invariant: K*=1 at all tolerance rows.
q=O(O.Target=="MnRel",:); rows=addgate(rows,'P7_4_STATE_SPECIFIC_MN_INVARIANT',all(q.Kstar==1),sprintf('rows=%d K1=%d',height(q),sum(q.Kstar==1)));
% Level-B common-topology minimax cannot be less than max of state-specific minima for same family/target/K.
Opt=read7(fullfile(outdir,'Pass7_state_specific_optima.csv'));bad=0;
for r=1:height(BS)
 q=Opt(Opt.FamilyID==BS.FamilyID(r)&Opt.Target==BS.Target(r)&Opt.K==BS.K(r),:); if BS.MinimaxError(r)+1e-12<max(q.MinError),bad=bad+1;end
end
rows=addgate(rows,'P7_5_COMMON_TOPOLOGY_MINIMAX_ORDER',bad==0,sprintf('violations=%d',bad));
rows=addgate(rows,'P7_6_POORSANK_SCALE_INVARIANCE',all(Scale.PartitionMatch) && max(Scale.ErrorAbsDiff)<cfg.numeric_tol,sprintf('partition_mismatch=%d max_abs_diff=%.3g',sum(~Scale.PartitionMatch),max(Scale.ErrorAbsDiff)));
% Independent mirror: family hypothesis status.
E=read7(fullfile(ROOT,'Independent_Audit','Pass7_expected_family_hypothesis_status.csv')); [ok,detail]=compare_family_status(Fam,E); rows=addgate(rows,'P7_7_INDEPENDENT_FAMILY_STATUS_MIRROR',ok,detail);
EG=read7(fullfile(ROOT,'Independent_Audit','Pass7_expected_generality_verdict.csv'));ok=height(G)==1&&height(EG)==1&&G.PrimaryFamilyCount==EG.PrimaryFamilyCount&&G.PrimaryStudyClusterCount==EG.PrimaryStudyClusterCount&&G.PrimaryStateCount==EG.PrimaryStateCount&&G.SupportingStudyClusters==EG.SupportingStudyClusters&&G.Verdict==EG.Verdict;rows=addgate(rows,'P7_8_INDEPENDENT_GENERALITY_MIRROR',ok,char(G.Verdict));
CS=read7(fullfile(ROOT,'data','pass7_claim_scope.csv'));
[claim,statusScope]=scope_columns7(CS); q=claim=="SPHERIZONE_VALIDATION";
if sum(q)==1, scopeDetail=statusScope(q); else, scopeDetail="scope row count="+string(sum(q)); end
ok=sum(q)==1 && statusScope(q)=="PROHIBITED";
rows=addgate(rows,'P7_9_SCOPE_GUARD_NO_SPHERIZONE_VALIDATION',ok,char(scopeDetail));
rows=addgate(rows,'P7_10_POST_FREEZE_INDEPENDENCE',~isfolder(fullfile(ROOT,'inputs')),'No A-K reactor outputs or fitting inputs are read by Pass 7.');
V=struct2table(rows);writetable(V,fullfile(outdir,'Pass7_verification.csv'));
end
function T=read7(path)
% Force the first CSV row to be interpreted as variable names. MATLAB's
% auto-detection can treat an all-text header row as data (e.g.
% pass7_claim_scope.csv), yielding Var1/Var2/... instead of Claim/Status.
T=readtable(path,'TextType','string','VariableNamingRule','preserve','ReadVariableNames',true);
end
function [claim,status]=scope_columns7(T)
% Robust scope-table access for all-text CSVs. Prefer named variables, but
% fall back to the first two columns if an importer still normalizes names.
v=string(T.Properties.VariableNames);
if any(v=="Claim"), claim=string(T.(T.Properties.VariableNames{find(v=="Claim",1)})); else, claim=string(T{:,1}); end
if any(v=="Status"), status=string(T.(T.Properties.VariableNames{find(v=="Status",1)})); else, status=string(T{:,2}); end
% Defensive removal if a header was nevertheless imported as row 1.
if ~isempty(claim) && claim(1)=="Claim" && status(1)=="Status", claim(1)=[]; status(1)=[]; end
end
function R=addgate(R,id,ok,detail)
s="FAIL";if ok,s="PASS";end
r=struct('GateID',string(id),'Status',s,'Detail',string(detail));
if isempty(R),R=r;else,R(end+1)=r;end
end
function [ok,detail]=compare_family_status(A,E)
A=sortrows(A,'FamilyID');E=sortrows(E,'FamilyID');ok=height(A)==height(E);bad=0;
if ok
 fields={'StateCount','J','StateSpecificTargetDependentStates','K2TopologyStateDependentTargets','StrictCommonTopologyPenaltyTargets','StrictFixedDescriptorPenaltyTargets','FixedDescriptorNoClosureTargets'};
 for r=1:height(A)
  if A.FamilyID(r)~=E.FamilyID(r),bad=bad+1;continue;end
  for j=1:numel(fields),if A.(fields{j})(r)~=E.(fields{j})(r),bad=bad+1;end,end
 end
end
ok=ok&&bad==0;detail=sprintf('rows=%d mismatches=%d',height(A),bad);
end
