function cfg = config_pass7_3()
%CONFIG_PASS7 Frozen configuration for post-freeze experimental state-portability challenge.
cfg.release = '3.7-pass7-external-experimental-state-portability';
cfg.logM_grid = linspace(1,8.5,6001);
cfg.scalar_rel_tolerances = [0.01 0.025 0.05];
cfg.W1_tolerances_decades = [0.01 0.02 0.05];
cfg.tail_abs_tolerances = [0.01 0.025 0.05];
cfg.tolerance_labels = {'STRICT','MODERATE','COARSE'};
cfg.numeric_tol = 2e-7;
cfg.expected_primary_families = 6;
cfg.expected_primary_study_clusters = 4;
cfg.expected_primary_states = 29;
cfg.expected_all_families = 7;
cfg.expected_all_states = 33;
end
