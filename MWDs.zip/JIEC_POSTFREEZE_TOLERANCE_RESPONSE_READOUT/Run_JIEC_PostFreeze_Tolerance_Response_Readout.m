function Run_JIEC_PostFreeze_Tolerance_Response_Readout()
% Deterministic post-freeze readout of normalized-tolerance results.
% Reads only frozen Stage-K partition-bound CSV files copied into inputs/.
% MATLAB R2025b.

root = fileparts(mfilename('fullpath'));
inDir = fullfile(root,'inputs');
outDir = fullfile(root,'Outputs_ToleranceReadout');
if ~exist(outDir,'dir'); mkdir(outDir); end

H  = readtable(fullfile(inDir,'StageK_H_all_partition_minimax_bounds.csv'), ...
    'VariableNamingRule','preserve');
H1 = readtable(fullfile(inDir,'StageK_H1_all_partition_closure_bounds.csv'), ...
    'VariableNamingRule','preserve');
H2 = readtable(fullfile(inDir,'StageK_H2_all_partition_closure_bounds.csv'), ...
    'VariableNamingRule','preserve');

names = ["Mn","Mw","D","W1","Tail@M90","Tail@M99"];
lo = ["MnRel_lower","MwRel_lower","DRel_lower","W1_lower_decades","Tail90_lower_abs","Tail99_lower_abs"];
up = ["MnRel_upper","MwRel_upper","DRel_upper","W1_upper_decades","Tail90_upper_abs","Tail99_upper_abs"];
eps0 = [0.025,0.025,0.025,0.020,0.025,0.025];
units = ["relative_fraction","relative_fraction","relative_fraction","decades", ...
         "absolute_mass_fraction","absolute_mass_fraction"];
qv = [0.25,0.5,1,2,4,8,16,32];
epcv = [0.1,0.2,0.3];

% Casewise state-informed K* readout.
Q=[]; EPC=[]; Target=strings(0,1); RefTol=[]; ScaledTol=[]; Kstar=[]; Status=strings(0,1);
for iq=1:numel(qv)
    q=qv(iq);
    for ie=1:numel(epcv)
        epc=epcv(ie);
        maskE = abs(H.EPC_wtfrac-epc) < 1e-12;
        for it=1:numel(names)
            tol=q*eps0(it);
            kval=NaN;
            for K=1:5
                mask=maskE & H.K==K;
                vals=H.(char(up(it)));
                best=min(vals(mask),[],'omitnan');
                if best <= tol + 1e-14
                    kval=K; break
                end
            end
            Q(end+1,1)=q; %#ok<AGROW>
            EPC(end+1,1)=epc; %#ok<AGROW>
            Target(end+1,1)=names(it); %#ok<AGROW>
            RefTol(end+1,1)=eps0(it); %#ok<AGROW>
            ScaledTol(end+1,1)=tol; %#ok<AGROW>
            Kstar(end+1,1)=kval; %#ok<AGROW>
            if isnan(kval); Status(end+1,1)="NC"; else; Status(end+1,1)="CLOSED"; end %#ok<AGROW>
        end
    end
end
Tcase=table(Q,EPC,Target,RefTol,ScaledTol,Kstar,Status, ...
    'VariableNames',{'q','EPC_wtfrac','Target','reference_tolerance','scaled_tolerance','Kstar_certified','Status'});
writetable(Tcase,fullfile(outDir,'Tolerance_casewise_Kstar.csv'));

% Aggregate state-informed counts (SI Table S29).
C=zeros(numel(qv),7);
for iq=1:numel(qv)
    q=qv(iq); C(iq,1)=q;
    sub=Tcase(abs(Tcase.q-q)<1e-12,:);
    for K=1:5; C(iq,K+1)=sum(sub.Kstar_certified==K); end
    C(iq,7)=sum(isnan(sub.Kstar_certified));
end
Tcounts=array2table(C,'VariableNames',{'q','K1','K2','K3','K4','K5','NC'});
writetable(Tcounts,fullfile(outDir,'Tolerance_state_informed_Kstar_counts.csv'));

% Fixed-information no-closure counts (SI Table S30 / Figure 5B).
F=zeros(numel(qv),4);
for iq=1:numel(qv)
    q=qv(iq); nc1=0; nc2=0;
    for ie=1:numel(epcv)
        epc=epcv(ie);
        mask1=abs(H1.EPC_wtfrac-epc)<1e-12;
        mask2=abs(H2.EPC_wtfrac-epc)<1e-12;
        for it=1:numel(names)
            tol=q*eps0(it);
            vals1=H1.(char(up(it)));
            vals2=H2.(char(up(it)));
            close1=min(vals1(mask1),[],'omitnan') <= tol + 1e-14;
            close2=min(vals2(mask2),[],'omitnan') <= tol + 1e-14;
            nc1=nc1 + ~close1;
            nc2=nc2 + ~close2;
        end
    end
    F(iq,:)=[q,nc1,nc2,18];
end
Tfixed=array2table(F,'VariableNames',{'q','Scenario_informed_NC','State_independent_NC','N_cases'});
writetable(Tfixed,fullfile(outDir,'Tolerance_fixed_no_closure_counts.csv'));

% K=5 normalized closure floors (SI Table S31).
EPC=[]; Target=strings(0,1); RefTol=[]; TolUnit=strings(0,1);
Slo=[]; Sup=[]; Glo=[]; Gup=[];
for ie=1:numel(epcv)
    epc=epcv(ie);
    for it=1:numel(names)
        r1=H1(abs(H1.EPC_wtfrac-epc)<1e-12 & H1.K==5,:);
        r2=H2(abs(H2.EPC_wtfrac-epc)<1e-12 & H2.K==5,:);
        EPC(end+1,1)=epc; %#ok<AGROW>
        Target(end+1,1)=names(it); %#ok<AGROW>
        RefTol(end+1,1)=eps0(it); %#ok<AGROW>
        TolUnit(end+1,1)=units(it); %#ok<AGROW>
        v=r1.(char(lo(it))); Slo(end+1,1)=v(1)/eps0(it); %#ok<AGROW>
        v=r1.(char(up(it))); Sup(end+1,1)=v(1)/eps0(it); %#ok<AGROW>
        v=r2.(char(lo(it))); Glo(end+1,1)=v(1)/eps0(it); %#ok<AGROW>
        v=r2.(char(up(it))); Gup(end+1,1)=v(1)/eps0(it); %#ok<AGROW>
    end
end
Tfloors=table(EPC,Target,RefTol,TolUnit,Slo,Sup,Glo,Gup, ...
    'VariableNames',{'EPC_wtfrac','Target','reference_tolerance','ToleranceUnit', ...
    'Scenario_q_floor_lower','Scenario_q_floor_upper', ...
    'StateIndependent_q_floor_lower','StateIndependent_q_floor_upper'});
writetable(Tfloors,fullfile(outDir,'Tolerance_K5_closure_floors.csv'));

% Verification against the frozen manuscript/SI readout.
expected29 = [ ...
0.25 3 3 3 0 9 0; ...
0.50 3 3 3 2 7 0; ...
1    4 3 3 4 4 0; ...
2    6 2 5 4 1 0; ...
4    7 3 6 2 0 0; ...
8    9 5 4 0 0 0; ...
16  13 5 0 0 0 0; ...
32  18 0 0 0 0 0];
expected30 = [ ...
0.25 17 18; ...
0.50 14 17; ...
1    11 15; ...
2     9 14; ...
4     8 11; ...
8     2  8; ...
16    0  5; ...
32    0  2];

checks = ["SI_Table_S29_counts_match";"SI_Table_S30_counts_match"; ...
          "All_18_state_informed_cases_close_by_q32";"K5_closure_floor_rows_present"];
pass = [isequal(C,expected29); isequal(F(:,1:3),expected30); ...
        C(end,2)==18 && C(end,7)==0; height(Tfloors)==18];
maxerr = [max(abs(C-expected29),[],'all'); ...
          max(abs(F(:,1:3)-expected30),[],'all'); 0; 0];
Tver=table(checks,pass,maxerr,'VariableNames',{'Check','Pass','MaxError'});
writetable(Tver,fullfile(outDir,'Tolerance_readout_verification.csv'));

fid=fopen(fullfile(outDir,'TOLERANCE_READOUT_STATUS.txt'),'w');
fprintf(fid,'Status: %s\n', ternary(all(pass),'RECONSTRUCTED AND VERIFIED','FAILED VERIFICATION'));
fprintf(fid,'Model rerun: NO\nParameter fitting: NO\nUncertainty-domain change: NO\nTolerance tuning: NO\n');
fprintf(fid,'Verification checks: %d/%d PASS\n',sum(pass),numel(pass));
fclose(fid);

fprintf('[Tolerance readout] %d/%d verification checks PASS.\n',sum(pass),numel(pass));
end

function out=ternary(cond,a,b)
if cond; out=a; else; out=b; end
end
