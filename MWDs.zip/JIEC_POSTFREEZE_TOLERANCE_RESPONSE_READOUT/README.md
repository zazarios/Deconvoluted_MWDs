# JIEC Post-Freeze Tolerance-Response Readout

## Purpose

This package makes the normalized-tolerance readout used in Supporting Information
Tables S29-S31 and main-text Figure 5B explicitly reproducible from frozen Stage-K
outputs.

It is **not** a new reactor-model stage. It does not rerun the reactor model, alter
any Stage-K parameter, change an uncertainty/support domain, or tune a tolerance.

## Frozen inputs

The three CSV files in `inputs/` are byte-identical copies of the corresponding
qualified Stage-K outputs:

- `StageK_H_all_partition_minimax_bounds.csv`
- `StageK_H1_all_partition_closure_bounds.csv`
- `StageK_H2_all_partition_closure_bounds.csv`

Their source paths and SHA-256 hashes are recorded in `INPUT_PROVENANCE.csv`.

## Readout definition

Reference tolerances are:

- Mn: 0.025 relative fraction
- Mw: 0.025 relative fraction
- dispersity: 0.025 relative fraction
- W1: 0.020 decades
- Tail@M90: 0.025 absolute mass fraction
- Tail@M99: 0.025 absolute mass fraction

For normalized tolerance `q`, the applied target tolerance is
`q * epsilon_ref`.

For the state-informed calculation, the certified retained resolution at each
EPC/target/q is the smallest `K` for which the minimum **upper** error bound over
all partitions at that `K` is no greater than the scaled tolerance.

For the scenario-informed and state-independent fixed-information cases, closure
is present when at least one available partition has an upper error bound no
greater than the scaled tolerance. The no-closure counts are reported over the
18 EPC/target combinations.

The K=5 closure floors in SI Table S31 are the lower and upper K=5 error bounds
divided by the corresponding reference tolerance.

## Run

In MATLAB R2025b:

```matlab
Run_JIEC_PostFreeze_Tolerance_Response_Readout
```

Outputs are written to `Outputs_ToleranceReadout/`.

## Expected principal outputs

- `Tolerance_casewise_Kstar.csv`
- `Tolerance_state_informed_Kstar_counts.csv`
- `Tolerance_fixed_no_closure_counts.csv`
- `Tolerance_K5_closure_floors.csv`
- `Tolerance_readout_verification.csv`

The archived outputs reproduce SI Tables S29-S31 exactly.

## Archival use

The deposited directory is a frozen reproducibility artifact. To preserve its
SHA-256 manifest, run the MATLAB launcher in a working copy of the directory.
A rerun may rewrite CSV formatting or status files even when the numerical
values are unchanged.
