function run_pass9_grouping_baseline_challenge(cfg)
if ~exist(cfg.outDir,'dir'); mkdir(cfg.outDir); end
f=fullfile(cfg.inputDir,'Pass7_state_all_partition_errors.csv');
T=readtable(f,'Delimiter',',','VariableNamingRule','preserve','TextType','string');
req=["FamilyID","StudyCluster","Role","StateID","J","K","PartitionCode",cfg.targets];
for q=req
    assert(any(string(T.Properties.VariableNames)==q),"Missing input column: "+q);
end
T=T(string(T.Role)==cfg.scopeRole,:);
assert(~isempty(T),'No PRIMARY_PP Pass-7 rows found.');

% Pass 9A: unrestricted versus molecular-weight-rank-contiguous partition search.
C=table; Ktab=table;
keys=unique(T(:,{'FamilyID','StudyCluster','Role','StateID','J'}),'rows','stable');
for ii=1:height(keys)
    q=string(T.FamilyID)==string(keys.FamilyID(ii)) & string(T.StateID)==string(keys.StateID(ii));
    X=T(q,:); J=X.J(1); Ks=sort(unique(X.K));
    for ki=1:numel(Ks)
        K=Ks(ki); Y=X(X.K==K,:);
        cm=false(height(Y),1);
        for r=1:height(Y); cm(r)=pass9_is_contiguous_partition(Y.PartitionCode(r)); end
        assert(any(cm),'No contiguous candidate found.');
        for ti=1:numel(cfg.targets)
            tar=cfg.targets(ti); e=Y.(tar); eu=min(e);
            tau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(eu)));
            uco=sort(string(Y.PartitionCode(e<=eu+tau)));
            ec=min(e(cm)); ctau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(ec)));
            cco=sort(string(Y.PartitionCode(cm & e<=ec+ctau)));
            rr=table(string(keys.FamilyID(ii)),string(keys.StudyCluster(ii)),string(keys.Role(ii)),string(keys.StateID(ii)),J,K,tar,eu,ec,ec-eu,tau,ec<=eu+tau,strjoin(uco,';'),strjoin(cco,';'), ...
                'VariableNames',{'FamilyID','StudyCluster','Role','StateID','J','K','Target','UnrestrictedMinError','ContiguousMinError','DeltaError','TieTolerance','ContiguousEquivalent','UnrestrictedCooptimalPartitions','ContiguousCooptimalPartitions'});
            C=[C;rr]; %#ok<AGROW>
        end
    end
    for ti=1:numel(cfg.targets)
        tar=cfg.targets(ti); etol=pass9_target_tolerance(cfg,tar); ku=NaN; kc=NaN;
        for ki=1:numel(Ks)
            K=Ks(ki); Y=X(X.K==K,:); cm=false(height(Y),1);
            for r=1:height(Y); cm(r)=pass9_is_contiguous_partition(Y.PartitionCode(r)); end
            if isnan(ku) && min(Y.(tar))<=etol+1e-12; ku=K; end
            tmp=Y.(tar); if isnan(kc) && min(tmp(cm))<=etol+1e-12; kc=K; end
        end
        rr=table(string(keys.FamilyID(ii)),string(keys.StudyCluster(ii)),string(keys.Role(ii)),string(keys.StateID(ii)),J,tar,etol,ku,kc,kc-ku, ...
            'VariableNames',{'FamilyID','StudyCluster','Role','StateID','J','Target','ReferenceTolerance','KstarUnrestricted','KstarContiguous','DeltaK'});
        Ktab=[Ktab;rr]; %#ok<AGROW>
    end
end
writetable(C,fullfile(cfg.outDir,'Pass9_contiguity_error_equivalence.csv'));
writetable(Ktab,fullfile(cfg.outDir,'Pass9_contiguity_Kstar_comparison.csv'));

% Pass 9B: target-blind minimax topology versus target-specific grouping.
B=table; Common=table;
for ii=1:height(keys)
    q=string(T.FamilyID)==string(keys.FamilyID(ii)) & string(T.StateID)==string(keys.StateID(ii));
    X=T(q,:); J=X.J(1); Ks=sort(unique(X.K)); scoreByK=nan(numel(Ks),1);
    for ki=1:numel(Ks)
        K=Ks(ki); Y=X(X.K==K,:); score=zeros(height(Y),1);
        for r=1:height(Y)
            vals=zeros(numel(cfg.nonMnTargets),1);
            for ti=1:numel(cfg.nonMnTargets)
                tar=cfg.nonMnTargets(ti); vals(ti)=Y.(tar)(r)/pass9_target_tolerance(cfg,tar);
            end
            score(r)=max(vals);
        end
        smin=min(score); scoreByK(ki)=smin;
        stau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(smin)));
        tie=score<=smin+stau; tied=Y(tie,:); tiedCodes=sort(string(tied.PartitionCode));
        for ti=1:numel(cfg.nonMnTargets)
            tar=cfg.nonMnTargets(ti); eopt=min(Y.(tar)); etau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(eopt)));
            best=min(tied.(tar)); worst=max(tied.(tar)); etol=pass9_target_tolerance(cfg,tar);
            rr=table(string(keys.FamilyID(ii)),string(keys.StudyCluster(ii)),string(keys.Role(ii)),string(keys.StateID(ii)),J,K,tar,smin,stau,sum(tie),strjoin(tiedCodes,';'),eopt,best,worst,best-eopt,best<=eopt+etau,eopt/etol,best/etol,worst/etol, ...
                'VariableNames',{'FamilyID','StudyCluster','Role','StateID','J','K','Target','TargetBlindMinimaxScore','TargetBlindTieTolerance','TargetBlindCooptimalCount','TargetBlindCooptimalPartitions','TargetSpecificMinError','BestCaseTargetBlindError','WorstCaseTargetBlindError','BestCasePenalty','BestCaseEquivalentToTargetSpecific','TargetSpecificNormError','BestCaseTargetBlindNormError','WorstCaseTargetBlindNormError'});
            B=[B;rr]; %#ok<AGROW>
        end
    end
    z=Ktab(string(Ktab.FamilyID)==string(keys.FamilyID(ii)) & string(Ktab.StateID)==string(keys.StateID(ii)) & ismember(string(Ktab.Target),cfg.nonMnTargets),:);
    maxInd=max(z.KstarUnrestricted); jj=find(scoreByK<=1+1e-12,1,'first'); assert(~isempty(jj),'Full resolution must close target-blind baseline.'); commonK=Ks(jj);
    rr=table(string(keys.FamilyID(ii)),string(keys.StudyCluster(ii)),string(keys.Role(ii)),string(keys.StateID(ii)),J,maxInd,commonK,commonK-maxInd, ...
        'VariableNames',{'FamilyID','StudyCluster','Role','StateID','J','MaxTargetSpecificKstar','TargetBlindCommonKstar','DeltaK'});
    Common=[Common;rr]; %#ok<AGROW>
end
writetable(B,fullfile(cfg.outDir,'Pass9_targetblind_minimax.csv'));
writetable(Common,fullfile(cfg.outDir,'Pass9_targetblind_commonK.csv'));

% Study-cluster and headline summaries.
clusters=unique(string(Common.StudyCluster),'stable'); CS=table;
B2=B(B.K==2,:);
for ci=1:numel(clusters)
    cl=clusters(ci); cs=Common(string(Common.StudyCluster)==cl,:); cc=C(string(C.StudyCluster)==cl,:); bb=B2(string(B2.StudyCluster)==cl,:);
    added=bb.TargetSpecificNormError<=1+1e-12 & bb.BestCaseTargetBlindNormError>1+1e-12;
    rr=table(cl,height(cs),height(cc),sum(cc.ContiguousEquivalent),sum(cs.DeltaK>0),sum(~bb.BestCaseEquivalentToTargetSpecific),sum(added), ...
        'VariableNames',{'StudyCluster','StateCount','ContiguityCases','ContiguityEquivalentCases','TargetBlindCommonKPenaltyStates','K2TargetBlindPenaltyCases','K2AddedFailureCases'});
    CS=[CS;rr]; %#ok<AGROW>
end
writetable(CS,fullfile(cfg.outDir,'Pass9_study_cluster_summary.csv'));
added=B2.TargetSpecificNormError<=1+1e-12 & B2.BestCaseTargetBlindNormError>1+1e-12;
S=table(1,height(Common),numel(clusters),height(C),sum(C.ContiguousEquivalent),height(Ktab),sum(Ktab.DeltaK>0),height(B2),sum(~B2.BestCaseEquivalentToTargetSpecific),sum(added),sum(Common.DeltaK>0),height(Common),numel(unique(string(Common.StudyCluster(Common.DeltaK>0)))),numel(clusters), ...
    "All unrestricted minima have a contiguous co-optimum in the primary experimental cohort; unrestricted set-partition search adds no empirical error or K* advantage here. Target-specific grouping remains consequential: one target-blind common topology requires one additional retained group in 13/29 states across 3/4 study clusters and creates four robust K=2 added closure failures.", ...
    'VariableNames',{'Pass7Qualified','PrimaryStateCount','PrimaryStudyClusterCount','ContiguityStateTargetKCases','ContiguityEquivalentCases','ContiguityKstarCases','ContiguityKstarPenaltyCases','NonMnK2TargetBlindCases','K2TargetBlindPenaltyCases','K2TargetBlindAddedFailureCases','TargetBlindCommonKPenaltyStates','TargetBlindCommonKStates','TargetBlindCommonKPenaltyStudyClusters','PrimaryStudyClusters','Interpretation'});
writetable(S,fullfile(cfg.outDir,'Pass9_primary_summary.csv'));

% Search-space scaling: unrestricted Bell partitions versus all contiguous partitions.
Scale=table; bells=zeros(11,1); bells(1)=1;
for n=1:10
    s=0;
    for k=0:n-1; s=s+nchoosek(n-1,k)*bells(k+1); end
    bells(n+1)=s;
end
for N=2:10
    b=bells(N+1); c=2^(N-1); rr=table(N,b,c,1-c/b,'VariableNames',{'Nref','UnrestrictedBellCount','AllContiguousPartitionCount','FractionSearchSpaceRemoved'}); Scale=[Scale;rr]; %#ok<AGROW>
end
writetable(Scale,fullfile(cfg.outDir,'Pass9_search_space_scaling.csv'));

fid=fopen(fullfile(cfg.outDir,'PASS9_STATUS.txt'),'w');
fprintf(fid,'JIEC v3.9 Pass 9 computational status: COMPLETE_PENDING_VERIFICATION\n');
fprintf(fid,'Release: %s\n',cfg.release);
fprintf(fid,'Reads qualified Pass-7 experimental partition-error output only; no Spherizone or A-K model is run or modified.\n');
fclose(fid);
end

function etol=pass9_target_tolerance(cfg,tar)
idx=find(cfg.targets==string(tar),1); assert(~isempty(idx),'Unknown target.'); etol=cfg.tolerances(idx);
end
