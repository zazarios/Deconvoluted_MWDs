# JIEC v3.9 Pass 9 — Grouping-Baseline Challenge

## Purpose
This post-freeze scientific hardening pass asks whether the value of the current representation-selection framework comes from (i) allowing unrestricted set partitions, or (ii) selecting a grouping specifically for the downstream target.

## Frozen input
Only the qualified Pass-7 primary experimental PP state-series partition-error table is read. No Spherizone/A–K calculation is run or modified.

## Pre-specified comparisons
1. **Unrestricted vs best MW-rank-contiguous search.** A partition is contiguous only when each retained group contains consecutive component ranks. Compare minimum error and K* at the reference tolerance.
2. **Target-specific vs target-blind minimax topology.** At each state and K, choose one topology minimizing the maximum normalized error across the five non-Mn targets (Mw, Đ, W1, Tail@M90, Tail@M99). Mn is excluded because reciprocal-Mn-preserving reduction makes it topology-invariant. Compare against target-specific optima and determine the minimum K at which one topology satisfies all five targets simultaneously.

## Why this matters
A positive unrestricted-vs-contiguous penalty would justify Bell-number enumeration. A null result would instead support a simpler empirical search class and improve scalability. A target-blind penalty would establish practical value for target-aware grouping even if contiguous grouping is sufficient.

## Run
Run `Run_JIEC_V3_9_Pass9_GroupingBaselineChallenge.m` in MATLAB. The script creates `Outputs_Pass9.zip`.

## Integrity
Independent_Audit files were generated with a separate Python mirror from the frozen Pass-7 CSV and are used only for verification.
