# Stage/Pass 9 release notes

Scientific release: `3.9-pass9-grouping-baseline-challenge`

This pass was authorized after the manuscript-hardening audit identified the highest-value remaining reviewer question: whether optimized grouping materially outperforms simpler grouping restrictions. The analysis is post-freeze and reads qualified Pass-7 outputs only.

Primary interpretation is deliberately two-sided: if the contiguous restriction is equivalent, the manuscript must not claim that unrestricted Bell-number search is empirically necessary for these PP datasets. If the target-blind baseline is worse, the manuscript may claim that target-specific grouping remains consequential within the tested evidence.
