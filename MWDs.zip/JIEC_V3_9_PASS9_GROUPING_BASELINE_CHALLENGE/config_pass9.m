function cfg=config_pass9(ROOT)
cfg.release="3.9-pass9-grouping-baseline-challenge";
cfg.inputDir=fullfile(ROOT,'data','Qualified_Pass7_Outputs');
cfg.auditDir=fullfile(ROOT,'Independent_Audit');
cfg.outDir=fullfile(ROOT,'Outputs_Pass9');
cfg.targets=["MnRel","MwRel","DRel","W1","Tail90Abs","Tail99Abs"];
cfg.nonMnTargets=["MwRel","DRel","W1","Tail90Abs","Tail99Abs"];
cfg.tolerances=[0.025,0.025,0.025,0.020,0.025,0.025];
cfg.primaryAbsTol=1e-8;
cfg.floorAbsTol=1e-10;
cfg.scopeRole="PRIMARY_PP";
end
