clear; clc;
ROOT=fileparts(mfilename('fullpath'));
restoredefaultpath;
addpath(ROOT); addpath(fullfile(ROOT,'core')); addpath(fullfile(ROOT,'verify'));
cfg=config_pass9(ROOT);
vf=which('verify_pass9_grouping_baseline_challenge'); expectedVerify=fullfile(ROOT,'verify','verify_pass9_grouping_baseline_challenge.m');
if ~strcmpi(char(vf),char(expectedVerify)); error('Path-safety failure: verifier resolved outside this package.'); end
fprintf('[JIEC v3.9 Pass 9] GROUPING-BASELINE CHALLENGE\n');
fprintf('Scientific release: %s\n',cfg.release);
fprintf('Frozen scope: qualified Pass-7 primary experimental PP state-series only.\n');
fprintf('Primary questions:\n');
fprintf('  A) Does unrestricted set-partition search outperform the best MW-rank-contiguous search?\n');
fprintf('  B) Does target-specific grouping outperform one target-blind minimax topology?\n');
fprintf('No reactor fitting, new kinetics, uncertainty model, or deconvolution is introduced.\n\n');
run_pass9_grouping_baseline_challenge(cfg);
V=verify_pass9_grouping_baseline_challenge(cfg);
npass=sum(string(V.Status)=="PASS");
fprintf('\nPass 9 status: %s (%d/%d gates PASS)\n',tern_local(npass==height(V),'QUALIFIED','FAILED'),npass,height(V));
fprintf('Outputs: %s\n',cfg.outDir);
zipfile=fullfile(ROOT,'Outputs_Pass9.zip'); if exist(zipfile,'file'); delete(zipfile); end; zip(zipfile,{'Outputs_Pass9'},ROOT); fprintf('Archive: %s\n',zipfile);
if npass~=height(V); error('Pass 9 verification failed. Inspect Pass9_verification.csv.'); end
function y=tern_local(q,a,b); if q; y=a; else; y=b; end; end
