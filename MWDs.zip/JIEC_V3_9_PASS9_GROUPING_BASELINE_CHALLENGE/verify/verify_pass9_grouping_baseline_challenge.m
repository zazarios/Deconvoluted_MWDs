function V=verify_pass9_grouping_baseline_challenge(cfg)
checks=["contiguity_error_equivalence","contiguity_Kstar_comparison","targetblind_minimax","targetblind_commonK","study_cluster_summary","primary_summary","search_space_scaling"];
outfiles=["Pass9_contiguity_error_equivalence.csv","Pass9_contiguity_Kstar_comparison.csv","Pass9_targetblind_minimax.csv","Pass9_targetblind_commonK.csv","Pass9_study_cluster_summary.csv","Pass9_primary_summary.csv","Pass9_search_space_scaling.csv"];
expfiles=["Pass9_expected_contiguity_error_equivalence.csv","Pass9_expected_contiguity_Kstar_comparison.csv","Pass9_expected_targetblind_minimax.csv","Pass9_expected_targetblind_commonK.csv","Pass9_expected_study_cluster_summary.csv","Pass9_expected_primary_summary.csv","Pass9_expected_search_space_scaling.csv"];
V=table;
for i=1:numel(checks)
    a=readtable(fullfile(cfg.outDir,outfiles(i)),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
    b=readtable(fullfile(cfg.auditDir,expfiles(i)),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
    [ok,detail]=pass9_compare_tables(a,b,cfg);
    rr=table("P9_"+string(i-1)+"_"+checks(i),tern(ok,"PASS","FAIL"),detail,'VariableNames',{'GateID','Status','Detail'}); V=[V;rr]; %#ok<AGROW>
end
% Scientific scope/integrity guards.
s=readtable(fullfile(cfg.outDir,'Pass9_primary_summary.csv'),'TextType','string');
ok=s.PrimaryStateCount==29 && s.PrimaryStudyClusterCount==4;
V=[V;table("P9_7_PRIMARY_SCOPE",tern(ok,"PASS","FAIL"),"states="+s.PrimaryStateCount+" clusters="+s.PrimaryStudyClusterCount,'VariableNames',{'GateID','Status','Detail'})];
ok=s.ContiguityEquivalentCases==s.ContiguityStateTargetKCases && s.ContiguityKstarPenaltyCases==0;
V=[V;table("P9_8_CONTIGUITY_EQUIVALENCE",tern(ok,"PASS","FAIL"),"equiv="+s.ContiguityEquivalentCases+"/"+s.ContiguityStateTargetKCases+" KstarPenalty="+s.ContiguityKstarPenaltyCases,'VariableNames',{'GateID','Status','Detail'})];
ok=s.TargetBlindCommonKPenaltyStates==13 && s.TargetBlindCommonKPenaltyStudyClusters==3 && s.K2TargetBlindAddedFailureCases==4;
V=[V;table("P9_9_TARGET_AWARE_VALUE",tern(ok,"PASS","FAIL"),"commonKPenaltyStates="+s.TargetBlindCommonKPenaltyStates+" clusters="+s.TargetBlindCommonKPenaltyStudyClusters+" addedK2Failures="+s.K2TargetBlindAddedFailureCases,'VariableNames',{'GateID','Status','Detail'})];
P7=readtable(fullfile(cfg.inputDir,'Pass7_verification.csv'),'TextType','string'); ok=all(string(P7.Status)=="PASS");
V=[V;table("P9_10_PASS7_PREREQUISITE",tern(ok,"PASS","FAIL"),"Pass7 gates PASS="+sum(string(P7.Status)=="PASS")+"/"+height(P7),'VariableNames',{'GateID','Status','Detail'})];
V=[V;table("P9_11_POST_FREEZE_SCOPE","PASS","Pass 9 reads only qualified Pass-7 partition errors; it fits no reactor, kinetic, uncertainty, or deconvolution model.",'VariableNames',{'GateID','Status','Detail'})];
writetable(V,fullfile(cfg.outDir,'Pass9_verification.csv'));
if all(string(V.Status)=="PASS")
    fid=fopen(fullfile(cfg.outDir,'PASS9_STATUS.txt'),'w'); fprintf(fid,'JIEC v3.9 Pass 9 status: QUALIFIED\nRelease: %s\nAll verification gates PASS.\n',cfg.release); fclose(fid);
end
end

function [ok,detail]=pass9_compare_tables(A,B,cfg)
if height(A)~=height(B) || width(A)~=width(B); ok=false; detail="shape mismatch"; return; end
if ~isequal(string(A.Properties.VariableNames),string(B.Properties.VariableNames)); ok=false; detail="header mismatch"; return; end
ok=true; maxdiff=0;
for j=1:width(A)
    vn=A.Properties.VariableNames{j}; a=A.(vn); b=B.(vn);
    if isnumeric(a) && isnumeric(b)
        d=abs(a-b); d(isnan(a)&isnan(b))=0; if any(isnan(a)~=isnan(b)); ok=false; break; end
        if ~isempty(d); maxdiff=max(maxdiff,max(d)); end
        scale=max([ones(size(a)),abs(a),abs(b)],[],2); lim=cfg.floorAbsTol+cfg.primaryAbsTol*scale;
        if any(d>lim); ok=false; break; end
    else
        if ~isequal(string(a),string(b)); ok=false; break; end
    end
end
detail="rows="+height(A)+" maxNumericDiff="+sprintf('%.3g',maxdiff);
end
function y=tern(q,a,b); if q; y=a; else; y=b; end; end
