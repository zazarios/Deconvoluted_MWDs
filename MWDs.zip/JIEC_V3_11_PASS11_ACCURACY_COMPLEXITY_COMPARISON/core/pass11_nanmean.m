function m=pass11_nanmean(x)
x=x(~isnan(x));
if isempty(x); m=NaN; else; m=mean(x); end
end
