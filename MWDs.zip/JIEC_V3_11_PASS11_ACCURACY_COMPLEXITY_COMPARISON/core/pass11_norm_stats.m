function [n,med,worst,failfrac]=pass11_norm_stats(norms,mask,cfg)
v=norms(mask);
n=numel(v);
if n==0
    med=NaN; worst=NaN; failfrac=NaN;
else
    med=median(v); worst=max(v); failfrac=mean(v>1+cfg.closeTol);
end
end
