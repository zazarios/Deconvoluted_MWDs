function ord=pass11_target_order(cfg,tar)
idx=find(cfg.targets==string(tar),1);
assert(~isempty(idx),'Unknown Pass-11 target: %s',char(string(tar)));
ord=cfg.targetOrders(idx);
end
