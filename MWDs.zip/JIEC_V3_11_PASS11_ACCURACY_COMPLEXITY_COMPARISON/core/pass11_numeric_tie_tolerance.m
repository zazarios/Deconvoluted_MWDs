function tau=pass11_numeric_tie_tolerance(cfg,e)
tau=max(cfg.floorAbsTol,cfg.primaryAbsTol*max(1,abs(e)));
end
