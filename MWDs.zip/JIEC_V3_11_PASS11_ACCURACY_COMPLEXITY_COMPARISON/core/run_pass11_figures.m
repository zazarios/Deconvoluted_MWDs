function run_pass11_figures(cfg)
if ~exist(cfg.figDir,'dir'); mkdir(cfg.figDir); end
R=readtable(fullfile(cfg.outDir,'Pass11_representative_cases.csv'), ...
    'Delimiter',',','VariableNamingRule','preserve','TextType','string');
C=readtable(fullfile(cfg.outDir,'Pass11_representative_curve_data.csv'), ...
    'Delimiter',',','VariableNamingRule','preserve','TextType','string');

f=figure('Visible','off','Position',[100 100 1400 1000]);
for ii=1:height(R)
    subplot(2,2,ii);
    z=C(C.RepresentativeOrder==R.RepresentativeOrder(ii),:);
    z=sortrows(z,'K');
    k=z.K;
    eopt=max(z.TargetSpecificNormError,cfg.plotFloor);
    etb=max(z.BestCaseTargetBlindNormError,cfg.plotFloor);
    emed=max(z.ContiguousMedianNormError,cfg.plotFloor);
    semilogy(k,eopt,'-o','LineWidth',1.8,'MarkerSize',6); hold on;
    semilogy(k,etb,'--s','LineWidth',1.5,'MarkerSize',5);
    semilogy(k,emed,':^','LineWidth',1.2,'MarkerSize',5);
    yline(1,'-','Tolerance','LabelHorizontalAlignment','left');
    xline(R.Kstar(ii),':','K*','LabelVerticalAlignment','bottom');
    grid on;
    xlim([1 R.J(ii)]);
    xticks(1:R.J(ii));
    xlabel('Retained-group count, K');
    ylabel('Tolerance-normalized error, E_Y / \epsilon_Y');
    title(sprintf('%s | %s',char(R.DatasetID(ii)),char(R.Target(ii))),'Interpreter','none');
    if ii==1
        legend({'Target-specific minimum','Target-blind best case','Median contiguous topology','Tolerance'}, ...
            'Location','best');
    end
end
sgtitle('Pass 11: accuracy-complexity comparison for pre-specified representative cases');

png=fullfile(cfg.figDir,'Pass11_accuracy_complexity_representative.png');
figfile=fullfile(cfg.figDir,'Pass11_accuracy_complexity_representative.fig');
try
    exportgraphics(f,png,'Resolution',300);
catch
    print(f,png,'-dpng','-r300');
end
savefig(f,figfile);
close(f);
end
