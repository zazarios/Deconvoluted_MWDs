function etol=pass11_target_tolerance(cfg,tar)
idx=find(cfg.targets==string(tar),1);
assert(~isempty(idx),'Unknown Pass-11 target: %s',char(string(tar)));
etol=cfg.tolerances(idx);
end
