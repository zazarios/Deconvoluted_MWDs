function run_pass11_representatives(cfg)
K=readtable(fullfile(cfg.outDir,'Pass11_Kstar_comparison.csv'), ...
    'Delimiter',',','VariableNamingRule','preserve','TextType','string');
A=readtable(fullfile(cfg.outDir,'Pass11_allK_accuracy_complexity.csv'), ...
    'Delimiter',',','VariableNamingRule','preserve','TextType','string');

K.ContiguousSpreadNorm=K.WorstContiguousAlternativeNormErrorAtKstar-K.KstarNormError;
selected=table;
used=strings(0,1);

% 1) Strongest case in which target-specific P* closes at K* but the
% optimized target-blind comparator fails at the same K*.
c=K(K.TargetBlindAddedFailureAtKstar==1 & K.Kstar<K.J,:);
assert(~isempty(c),'No target-blind closure-rescue case available.');
c.NegPenalty=-c.TargetBlindPenaltyNormAtKstar;
c.NegResolution=-c.ResolutionReductionPct;
c=sortrows(c,{'NegPenalty','NegResolution','DatasetOrder','TargetOrder'});
r=c(1,:); selected=[selected;pass11_rep_row(r,1,"STRONGEST_TARGET_BLIND_CLOSURE_RESCUE")]; %#ok<AGROW>
used=[used;string(r.DatasetID)]; %#ok<AGROW>

% 2) Largest retained-resolution reduction among nontrivial K*>1 cases,
% using a different dataset from representative 1.
c=K(K.Kstar>1 & K.Kstar<K.J & ~ismember(string(K.DatasetID),used),:);
assert(~isempty(c),'No nontrivial resolution-saving representative available.');
c.NegResolution=-c.ResolutionReductionPct;
c.NegAltFail=-c.ContiguousAlternativeFailureFractionAtKstar;
c.NegMargin=-c.KstarToleranceMargin;
c=sortrows(c,{'NegResolution','NegAltFail','NegMargin','DatasetOrder','TargetOrder'});
r=c(1,:); selected=[selected;pass11_rep_row(r,2,"LARGEST_NONTRIVIAL_RESOLUTION_SAVING")]; %#ok<AGROW>
used=[used;string(r.DatasetID)]; %#ok<AGROW>

% 3) Largest same-K sensitivity among molecular-weight-contiguous
% alternatives, again requiring a different dataset.
c=K(K.ContiguousAlternativeCountAtKstar>0 & ~ismember(string(K.DatasetID),used),:);
assert(~isempty(c),'No topology-sensitivity representative available.');
c.NegSpread=-c.ContiguousSpreadNorm;
c=sortrows(c,{'NegSpread','DatasetOrder','TargetOrder'});
r=c(1,:); selected=[selected;pass11_rep_row(r,3,"STRONGEST_CONTIGUOUS_TOPOLOGY_SENSITIVITY")]; %#ok<AGROW>
used=[used;string(r.DatasetID)]; %#ok<AGROW>

% 4) Weak target-blind-effect control: target-blind and target-specific
% optima are as close as possible, then prefer a smaller contiguous
% alternative-failure fraction and smaller same-K spread.
c=K(K.Kstar<K.J & K.ContiguousAlternativeCountAtKstar>0 & ~ismember(string(K.DatasetID),used),:);
assert(~isempty(c),'No weak-effect control representative available.');
c.AbsTBPenalty=abs(c.TargetBlindPenaltyNormAtKstar);
c=sortrows(c,{'AbsTBPenalty','ContiguousAlternativeFailureFractionAtKstar','ContiguousSpreadNorm','DatasetOrder','TargetOrder'});
r=c(1,:); selected=[selected;pass11_rep_row(r,4,"WEAK_TARGET_BLIND_EFFECT_CONTROL")]; %#ok<AGROW>

writetable(selected,fullfile(cfg.outDir,'Pass11_representative_cases.csv'));

RC=table;
for ii=1:height(selected)
    did=string(selected.DatasetID(ii)); tar=string(selected.Target(ii));
    z=A(string(A.DatasetID)==did & string(A.Target)==tar,:);
    z=sortrows(z,'K');
    z.RepresentativeOrder=repmat(selected.RepresentativeOrder(ii),height(z),1);
    z.SelectionRole=repmat(string(selected.SelectionRole(ii)),height(z),1);
    z=movevars(z,{'RepresentativeOrder','SelectionRole'},'Before',1);
    RC=[RC;z]; %#ok<AGROW>
end
writetable(RC,fullfile(cfg.outDir,'Pass11_representative_curve_data.csv'));
end

function rr=pass11_rep_row(r,ord,role)
rr=table(ord,role,r.DatasetOrder,string(r.DatasetID),string(r.StudyCluster),r.J,r.TargetOrder,string(r.Target),r.Kstar, ...
    r.ResolutionReductionPct,r.KstarNormError,string(r.PstarPartitions), ...
    r.BestTargetBlindNormErrorAtKstar,r.TargetBlindPenaltyNormAtKstar,r.TargetBlindAddedFailureAtKstar, ...
    r.ContiguousAlternativeCountAtKstar,r.WorstContiguousAlternativeNormErrorAtKstar,r.ContiguousAlternativeFailureFractionAtKstar, ...
    'VariableNames',{'RepresentativeOrder','SelectionRole','DatasetOrder','DatasetID','StudyCluster','J','TargetOrder','Target','Kstar', ...
    'ResolutionReductionPct','KstarNormError','PstarPartitions','BestTargetBlindNormErrorAtKstar','TargetBlindPenaltyNormAtKstar', ...
    'TargetBlindAddedFailureAtKstar','ContiguousAlternativeCountAtKstar','WorstContiguousAlternativeNormErrorAtKstar', ...
    'ContiguousAlternativeFailureFractionAtKstar'});
end
