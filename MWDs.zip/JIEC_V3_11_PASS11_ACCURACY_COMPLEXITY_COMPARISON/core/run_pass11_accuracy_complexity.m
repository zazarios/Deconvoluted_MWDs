function run_pass11_accuracy_complexity(cfg)
T=readtable(fullfile(cfg.externalDir,'External19_all_partition_errors.csv'), ...
    'Delimiter',',','VariableNamingRule','preserve','TextType','string');
R=readtable(fullfile(cfg.externalDir,'External19_registry.csv'), ...
    'Delimiter',',','VariableNamingRule','preserve','TextType','string');

req=["DatasetID","StudyCluster","Role","J","K","PartitionCode",cfg.targets];
for q=req
    assert(any(string(T.Properties.VariableNames)==q), ...
        'Missing external input column: %s',char(q));
end
reqR=["DatasetID","StudyCluster","J","DatasetOrder","SourceLayer","Role"];
for q=reqR
    assert(any(string(R.Properties.VariableNames)==q), ...
        'Missing registry column: %s',char(q));
end
R=sortrows(R,'DatasetOrder');

AllK=table;
Kcomp=table;

for ii=1:height(R)
    did=string(R.DatasetID(ii));
    cl=string(R.StudyCluster(ii));
    J=R.J(ii);
    dord=R.DatasetOrder(ii);
    X=T(string(T.DatasetID)==did,:);
    assert(~isempty(X),'Missing external dataset %s',char(did));
    Ks=sort(unique(X.K));
    assert(Ks(1)==1 && Ks(end)==J,'Dataset %s must span K=1..J.',char(did));

    % ---------- All-K accuracy-complexity curves ----------
    for ki=1:numel(Ks)
        K=Ks(ki);
        Y=X(X.K==K,:);
        nrow=height(Y);
        cont=false(nrow,1);
        for r=1:nrow
            cont(r)=pass11_is_contiguous_partition(Y.PartitionCode(r));
        end
        assert(any(cont),'No contiguous candidate found for %s K=%d.',char(did),K);

        score=zeros(nrow,1);
        for r=1:nrow
            vals=zeros(numel(cfg.targets),1);
            for ti=1:numel(cfg.targets)
                tar=cfg.targets(ti);
                vals(ti)=Y.(char(tar))(r)/pass11_target_tolerance(cfg,tar);
            end
            score(r)=max(vals);
        end
        smin=min(score);
        stau=pass11_numeric_tie_tolerance(cfg,smin);
        tbMask=score<=smin+stau;
        tbCodes=sort(string(Y.PartitionCode(tbMask)));

        for ti=1:numel(cfg.targets)
            tar=cfg.targets(ti);
            tord=pass11_target_order(cfg,tar);
            etol=pass11_target_tolerance(cfg,tar);
            vals=Y.(char(tar));
            norms=vals/etol;
            eopt=min(vals);
            tau=pass11_numeric_tie_tolerance(cfg,eopt);
            optMask=vals<=eopt+tau;
            optCodes=sort(string(Y.PartitionCode(optMask)));
            contNorms=norms(cont);

            rr=table(dord,did,cl,J,K,tord,tar,etol,eopt,eopt/etol, ...
                sum(optMask),strjoin(optCodes,';'), ...
                nrow,median(norms),max(norms),mean(norms>1+cfg.closeTol), ...
                sum(cont),median(contNorms),max(contNorms),mean(contNorms>1+cfg.closeTol), ...
                smin,sum(tbMask),strjoin(tbCodes,';'),min(norms(tbMask)),max(norms(tbMask)),double(K==J), ...
                'VariableNames',{'DatasetOrder','DatasetID','StudyCluster','J','K','TargetOrder','Target','ReferenceTolerance', ...
                'TargetSpecificMinError','TargetSpecificNormError','TargetSpecificCooptimalCount','TargetSpecificCooptimalPartitions', ...
                'AllPartitionCount','AllPartitionMedianNormError','AllPartitionWorstNormError','AllPartitionFailureFraction', ...
                'ContiguousPartitionCount','ContiguousMedianNormError','ContiguousWorstNormError','ContiguousFailureFraction', ...
                'TargetBlindMinimaxScore','TargetBlindCooptimalCount','TargetBlindCooptimalPartitions', ...
                'BestCaseTargetBlindNormError','WorstCaseTargetBlindNormError','IsFullReference'});
            AllK=[AllK;rr]; %#ok<AGROW>
        end
    end

    % ---------- K* comparison with full reference and alternative topologies ----------
    for ti=1:numel(cfg.targets)
        tar=cfg.targets(ti);
        tord=pass11_target_order(cfg,tar);
        etol=pass11_target_tolerance(cfg,tar);
        kstar=NaN;
        for ki=1:numel(Ks)
            K=Ks(ki);
            Y=X(X.K==K,:);
            if min(Y.(char(tar)))<=etol+cfg.closeTol
                kstar=K; break;
            end
        end
        assert(~isnan(kstar),'Full external reference must close for %s / %s.',char(did),char(tar));

        Y=X(X.K==kstar,:);
        vals=Y.(char(tar));
        norms=vals/etol;
        eopt=min(vals);
        tau=pass11_numeric_tie_tolerance(cfg,eopt);
        optMask=vals<=eopt+tau;
        pstarCodes=sort(string(Y.PartitionCode(optMask)));
        altMask=~ismember(string(Y.PartitionCode),pstarCodes);

        cont=false(height(Y),1);
        for r=1:height(Y)
            cont(r)=pass11_is_contiguous_partition(Y.PartitionCode(r));
        end
        contAltMask=altMask & cont;

        score=zeros(height(Y),1);
        for r=1:height(Y)
            tmp=zeros(numel(cfg.targets),1);
            for tj=1:numel(cfg.targets)
                ot=cfg.targets(tj);
                tmp(tj)=Y.(char(ot))(r)/pass11_target_tolerance(cfg,ot);
            end
            score(r)=max(tmp);
        end
        smin=min(score);
        stau=pass11_numeric_tie_tolerance(cfg,smin);
        tbMask=score<=smin+stau;

        % Target-mismatched comparator set: topologies that are co-optimal for
        % another non-Mn target at this same K, excluding topologies that are
        % also co-optimal for the current target.
        mmCodes=strings(0,1);
        for tj=1:numel(cfg.targets)
            ot=cfg.targets(tj);
            if ot==tar; continue; end
            oval=Y.(char(ot));
            oe=min(oval);
            otau=pass11_numeric_tie_tolerance(cfg,oe);
            codes=string(Y.PartitionCode(oval<=oe+otau));
            mmCodes=unique([mmCodes;codes]); %#ok<AGROW>
        end
        mmCodes=setdiff(mmCodes,pstarCodes,'stable');
        mmMask=ismember(string(Y.PartitionCode),mmCodes);

        F=X(X.K==J,:);
        fullerr=min(F.(char(tar)));

        [altN,altMed,altWorst,altFail]=pass11_norm_stats(norms,altMask,cfg);
        [caltN,caltMed,caltWorst,caltFail]=pass11_norm_stats(norms,contAltMask,cfg);
        [mmN,mmMed,mmWorst,mmFail]=pass11_norm_stats(norms,mmMask,cfg);
        tbBest=min(norms(tbMask));
        tbWorst=max(norms(tbMask));

        rr=table(dord,did,cl,J,tord,tar,etol,kstar,J-kstar,100*(J-kstar)/J, ...
            eopt,eopt/etol,1-eopt/etol,sum(optMask),strjoin(pstarCodes,';'), ...
            J,fullerr,fullerr/etol, ...
            altN,altMed,altWorst,altFail, ...
            caltN,caltMed,caltWorst,caltFail, ...
            smin,sum(tbMask),tbBest,tbWorst,tbBest-eopt/etol, ...
            double((eopt/etol<=1+cfg.closeTol) && (tbBest>1+cfg.closeTol)), ...
            mmN,mmMed,mmWorst,mmFail, ...
            'VariableNames',{'DatasetOrder','DatasetID','StudyCluster','J','TargetOrder','Target','ReferenceTolerance', ...
            'Kstar','ResolutionSavingGroups','ResolutionReductionPct', ...
            'KstarMinError','KstarNormError','KstarToleranceMargin','PstarCount','PstarPartitions', ...
            'FullReferenceK','FullReferenceError','FullReferenceNormError', ...
            'AlternativeCountAtKstar','MedianAlternativeNormErrorAtKstar','WorstAlternativeNormErrorAtKstar','AlternativeFailureFractionAtKstar', ...
            'ContiguousAlternativeCountAtKstar','MedianContiguousAlternativeNormErrorAtKstar','WorstContiguousAlternativeNormErrorAtKstar','ContiguousAlternativeFailureFractionAtKstar', ...
            'TargetBlindMinimaxScoreAtKstar','TargetBlindCooptimalCountAtKstar','BestTargetBlindNormErrorAtKstar','WorstTargetBlindNormErrorAtKstar', ...
            'TargetBlindPenaltyNormAtKstar','TargetBlindAddedFailureAtKstar', ...
            'TargetMismatchedCountAtKstar','MedianTargetMismatchedNormErrorAtKstar','WorstTargetMismatchedNormErrorAtKstar','TargetMismatchedFailureFractionAtKstar'});
        Kcomp=[Kcomp;rr]; %#ok<AGROW>
    end
end

writetable(AllK,fullfile(cfg.outDir,'Pass11_allK_accuracy_complexity.csv'));
writetable(Kcomp,fullfile(cfg.outDir,'Pass11_Kstar_comparison.csv'));
end
