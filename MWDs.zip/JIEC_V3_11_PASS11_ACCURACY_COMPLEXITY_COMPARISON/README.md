# JIEC v3.11 Pass 11 — Accuracy–complexity comparison

## Purpose
Pass 11 is the direct comparison requested for the planned Results Section 3.8. It evaluates the practical value of the representation-selection model output `(K*, P*)` against:

1. the **full experimentally resolved MWD representation**;
2. **alternative topologies at the same K***;
3. the previously defined **optimized target-blind minimax topology**; and
4. **target-mismatched topologies** that are optimal for another molecular target at the same K.

The analysis uses **all 19 primary external polypropylene distributions spanning six study clusters**. Representative cases are used only for visualization; all cohort-level conclusions are calculated from all 19 distributions.

## Critical full-reference rule
The 19 external distributions do not all have five source components. Their source resolution `J` ranges from 4 to 6. Therefore the full-reference comparison is always

`K = J = N_ref(dataset)`

and is **not forced to K = 5**. For a five-component dataset, this reduces to K = 5.

## Primary KPI
For molecular target `Y`, the common accuracy KPI is the tolerance-normalized representation error

`e_Y = E_Y / epsilon_Y`.

Interpretation:
- `e_Y < 1`: representation meets the target tolerance;
- `e_Y = 1`: representation is exactly at the tolerance;
- `e_Y > 1`: representation fails.

The complexity axis is the retained-group count `K`. The selected `K*` is the smallest K whose target-specific optimum meets `e_Y <= 1`.

## Comparisons produced
### A. Model-selected representation versus full reference
Reports:
- `K*`;
- retained-group saving `J - K*`;
- retained-resolution reduction `100*(J-K*)/J`;
- normalized error at `P*`;
- normalized error of the full reference `K = J`.

This is an **accuracy–resolution** comparison. The full reference is not expected to be less accurate; it is the maximum-resolution reference from which the model removes unnecessary retained groups while maintaining the requested tolerance.

### B. P* versus alternative topologies at the same K*
Reports both unrestricted and molecular-weight-contiguous alternatives:
- median normalized error;
- worst normalized error;
- fraction of alternatives that fail `e_Y > 1`.

The contiguous-alternative statistics are the more conservative practical comparator because Pass 10 found no K* penalty from restricting the tested PP systems to molecular-weight-contiguous groups.

### C. P* versus optimized target-blind topology
At the same K*, the target-blind comparator minimizes the worst normalized error over
`Mw`, dispersity, `W1`, `Tail@M90`, and `Tail@M99`.

Reports:
- best and worst current-target error among target-blind co-optima;
- normalized target-blind penalty;
- whether target-specific P* closes while the optimized target-blind comparator fails.

### D. P* versus target-mismatched topologies
For current target Y, the target-mismatched comparator set is the union of topologies that are co-optimal for another non-Mn target at the same K*, excluding any topology also co-optimal for Y.

Reports:
- number of such topologies;
- median/worst normalized error;
- fraction that fail the current target tolerance.

## Why Mn is excluded from Pass 11
`Mn` is not included in this comparison because the reciprocal-Mn retained-group construction makes whole-distribution Mn exactly invariant to grouping. Its topology is therefore structurally non-identifiable and cannot provide a meaningful test of P* versus a different topology.

## Representative-case rule
Four examples are selected algorithmically and transparently after the all-19 analysis:
1. strongest target-blind closure-rescue case;
2. largest nontrivial retained-resolution saving (`K*>1`);
3. strongest same-K sensitivity among contiguous alternatives;
4. weak target-blind-effect control.

Each representative must come from a different dataset. These examples are illustrative only; they do not determine the cohort conclusions.

## Run
1. Extract the ZIP.
2. Open MATLAB in the extracted package directory.
3. Run:

`Run_JIEC_V3_11_Pass11_AccuracyComplexityComparison`

4. Upload the generated `Outputs_Pass11.zip`.

## Main output files
- `Pass11_allK_accuracy_complexity.csv` — all-K accuracy–complexity curves for every dataset and non-Mn target.
- `Pass11_Kstar_comparison.csv` — direct P* vs full/alternative/target-blind/target-mismatched comparisons at K*.
- `Pass11_dataset_summary.csv` — dataset-level summary over five non-Mn targets.
- `Pass11_target_summary.csv` — target-level summary over 19 datasets.
- `Pass11_cohort_summary.csv` — all-19 headline counts.
- `Pass11_representative_cases.csv` — four rule-selected illustrative cases.
- `Pass11_representative_curve_data.csv` — plot-ready data for those cases.
- `Figures/Pass11_accuracy_complexity_representative.png` — automatically generated four-panel visualization when MATLAB graphics are available.
- `Pass11_verification.csv` and `PASS11_STATUS.txt` — qualification record.

## Frozen scope
Pass 11 reads only the frozen 19-distribution external PP partition-error table and qualified Pass-10 prerequisite outputs. It does not rerun Spherizone, refit any distribution, change the deconvolution, alter the uncertainty model, or tune the tolerances.
