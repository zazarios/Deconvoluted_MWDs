function V=verify_pass11_accuracy_complexity(cfg)
checks=["allK_accuracy_complexity","Kstar_comparison","dataset_summary","target_summary","cohort_summary","representative_cases","representative_curve_data"];
outfiles=["Pass11_allK_accuracy_complexity.csv","Pass11_Kstar_comparison.csv","Pass11_dataset_summary.csv","Pass11_target_summary.csv","Pass11_cohort_summary.csv","Pass11_representative_cases.csv","Pass11_representative_curve_data.csv"];
expfiles=["Pass11_expected_allK_accuracy_complexity.csv","Pass11_expected_Kstar_comparison.csv","Pass11_expected_dataset_summary.csv","Pass11_expected_target_summary.csv","Pass11_expected_cohort_summary.csv","Pass11_expected_representative_cases.csv","Pass11_expected_representative_curve_data.csv"];
V=table;
for i=1:numel(checks)
    a=readtable(fullfile(cfg.outDir,outfiles(i)),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
    b=readtable(fullfile(cfg.auditDir,expfiles(i)),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
    [ok,detail]=pass11_compare_tables(a,b,cfg);
    V=[V;table("P11_"+string(i)+"_"+checks(i),tern(ok,"PASS","FAIL"),detail, ...
        'VariableNames',{'GateID','Status','Detail'})]; %#ok<AGROW>
end

R=readtable(fullfile(cfg.externalDir,'External19_registry.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
ok=height(R)==19 && numel(unique(string(R.StudyCluster)))==6;
V=[V;table("P11_8_EXTERNAL_SCOPE",tern(ok,"PASS","FAIL"), ...
    string(sprintf('datasets=%d clusters=%d',height(R),numel(unique(string(R.StudyCluster))))), ...
    'VariableNames',{'GateID','Status','Detail'})];

P10=readtable(fullfile(cfg.pass10Dir,'Pass10_verification.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
ok=any(string(P10.Properties.VariableNames)=="Status") && all(upper(strtrim(string(P10.Status)))=="PASS");
V=[V;table("P11_9_PASS10_PREREQUISITE",tern(ok,"PASS","FAIL"), ...
    string(sprintf('Pass10 gates=%d/%d',sum(upper(strtrim(string(P10.Status)))=="PASS"),height(P10))), ...
    'VariableNames',{'GateID','Status','Detail'})];

K=readtable(fullfile(cfg.outDir,'Pass11_Kstar_comparison.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
ok=height(K)==95 && all(K.FullReferenceK==K.J) && all(K.FullReferenceNormError<=cfg.primaryAbsTol);
V=[V;table("P11_10_FULL_REFERENCE_SELF_IDENTITY",tern(ok,"PASS","FAIL"), ...
    string(sprintf('cases=%d maxFullNorm=%.3g',height(K),max(K.FullReferenceNormError))), ...
    'VariableNames',{'GateID','Status','Detail'})];

A=readtable(fullfile(cfg.outDir,'Pass11_allK_accuracy_complexity.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
ok=true; bad=0;
for i=1:height(K)
    did=string(K.DatasetID(i)); tar=string(K.Target(i)); ks=K.Kstar(i);
    z=A(string(A.DatasetID)==did & string(A.Target)==tar,:);
    at=z.K==ks;
    if ~any(at) || min(z.TargetSpecificNormError(at))>1+cfg.closeTol
        ok=false; bad=bad+1; continue;
    end
    if ks>1
        prev=z.K<ks;
        if any(z.TargetSpecificNormError(prev)<=1+cfg.closeTol)
            ok=false; bad=bad+1;
        end
    end
end
V=[V;table("P11_11_KSTAR_FEASIBLE_MINIMAL",tern(ok,"PASS","FAIL"), ...
    string(sprintf('checked=%d bad=%d',height(K),bad)), ...
    'VariableNames',{'GateID','Status','Detail'})];

REP=readtable(fullfile(cfg.outDir,'Pass11_representative_cases.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
ok=height(REP)==4 && numel(unique(string(REP.DatasetID)))==4 && isequal(REP.RepresentativeOrder(:),(1:4)');
V=[V;table("P11_12_REPRESENTATIVE_SCOPE",tern(ok,"PASS","FAIL"), ...
    string(sprintf('representatives=%d uniqueDatasets=%d',height(REP),numel(unique(string(REP.DatasetID))))), ...
    'VariableNames',{'GateID','Status','Detail'})];


P10B=readtable(fullfile(cfg.pass10Dir,'Pass10_external_targetblind_minimax.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
P11A=readtable(fullfile(cfg.outDir,'Pass11_allK_accuracy_complexity.csv'),'Delimiter',',','VariableNamingRule','preserve','TextType','string');
key10=string(P10B.DatasetID)+"|"+string(P10B.K)+"|"+string(P10B.Target);
key11=string(P11A.DatasetID)+"|"+string(P11A.K)+"|"+string(P11A.Target);
[ks10,i10]=sort(key10); [ks11,i11]=sort(key11);
ok=isequal(ks10,ks11); maxd=Inf;
if ok
    d1=abs(P10B.TargetBlindMinimaxScore(i10)-P11A.TargetBlindMinimaxScore(i11));
    d2=abs(P10B.TargetSpecificNormError(i10)-P11A.TargetSpecificNormError(i11));
    d3=abs(P10B.BestCaseTargetBlindNormError(i10)-P11A.BestCaseTargetBlindNormError(i11));
    d4=abs(P10B.WorstCaseTargetBlindNormError(i10)-P11A.WorstCaseTargetBlindNormError(i11));
    maxd=max([d1;d2;d3;d4]);
    scale=max([ones(numel(d1)*4,1);abs([P10B.TargetBlindMinimaxScore(i10);P10B.TargetSpecificNormError(i10);P10B.BestCaseTargetBlindNormError(i10);P10B.WorstCaseTargetBlindNormError(i10)])]);
    ok=maxd<=cfg.floorAbsTol+cfg.primaryAbsTol*scale;
end
V=[V;table("P11_13_PASS10_TARGETBLIND_CONTINUITY",tern(ok,"PASS","FAIL"), ...
    string(sprintf('rows=%d maxDiff=%.3g',height(P10B),maxd)), ...
    'VariableNames',{'GateID','Status','Detail'})];
V=[V;table("P11_14_POST_FREEZE_SCOPE","PASS", ...
    "Pass 11 reads only the frozen 19-distribution external PP partition-error table and qualified Pass-10 prerequisite outputs. It introduces no reactor rerun, deconvolution, kinetic fitting, uncertainty model, or tolerance tuning.", ...
    'VariableNames',{'GateID','Status','Detail'})];

writetable(V,fullfile(cfg.outDir,'Pass11_verification.csv'));
if all(string(V.Status)=="PASS")
    fid=fopen(fullfile(cfg.outDir,'PASS11_STATUS.txt'),'w');
    fprintf(fid,'JIEC v3.11 Pass 11 status: QUALIFIED\nRelease: %s\nAll verification gates PASS.\n',cfg.release);
    fclose(fid);
end
end

function [ok,detail]=pass11_compare_tables(A,B,cfg)
if height(A)~=height(B) || width(A)~=width(B)
    ok=false; detail=string(sprintf('shape mismatch: got=%dx%d expected=%dx%d',height(A),width(A),height(B),width(B))); return;
end
if ~isequal(string(A.Properties.VariableNames),string(B.Properties.VariableNames))
    ok=false; detail="header mismatch"; return;
end
ok=true; maxdiff=0;
for j=1:width(A)
    vn=string(A.Properties.VariableNames{j});
    a=A.(char(vn)); b=B.(char(vn));
    if isnumeric(a) && isnumeric(b)
        if any(isnan(a)~=isnan(b)); ok=false; break; end
        d=abs(a-b); d(isnan(a)&isnan(b))=0;
        if ~isempty(d); maxdiff=max(maxdiff,max(d)); end
        scale=max([ones(size(a)),abs(a),abs(b)],[],2);
        lim=cfg.floorAbsTol+cfg.primaryAbsTol*scale;
        if any(d>lim); ok=false; break; end
    else
        if ~isequal(string(a),string(b)); ok=false; break; end
    end
end
detail=string(sprintf('rows=%d maxNumericDiff=%.3g',height(A),maxdiff));
end

function y=tern(q,a,b)
if q; y=a; else; y=b; end
end
