# Pre-MATLAB static audit

The Pass-11 package was assembled from the qualified Pass-10 external-PP input layer.

Static checks completed before delivery:
- input registry contains 19 datasets across six study clusters;
- source resolution J is preserved per dataset (4, 5, or 6); no forced K=5 comparator is used;
- the five non-Mn target tolerances match Pass 10;
- all-K and K* computations were independently mirrored outside MATLAB and frozen in `Independent_Audit/`;
- representative selection was independently mirrored using the same deterministic rules;
- output-table schemas and row ordering were frozen for verifier comparison;
- no Spherizone/reactor calculation is called by this package.

MATLAB itself is not available in the package-construction environment. Final executable qualification therefore occurs when the user runs the one-button MATLAB script; the package is designed to return `QUALIFIED` only when all numerical outputs reproduce the independent mirrors and all scope/invariant gates pass.
