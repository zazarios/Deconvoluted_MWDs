# Pass 11 frozen comparison protocol

## Scientific question
Given an externally published component-resolved PP MWD and a molecular target Y, does the model-selected `(K*, P*)` provide a measurable accuracy–resolution advantage relative to the full source representation or alternative ways of grouping the same source components?

## Frozen inputs
- 19 primary PP distributions / six study clusters.
- All unrestricted partition errors from the qualified Stage-I/Pass-4 external cohort.
- Reference tolerances: 2.5% for Mw and dispersity, 0.020 decades for W1, and 0.025 absolute mass fraction for Tail@M90 and Tail@M99.
- Pass-10 qualified target-blind comparator definition.

## Primary endpoints
1. `ResolutionSavingGroups = J - K*`.
2. `ResolutionReductionPct = 100*(J-K*)/J`.
3. `KstarNormError = E_Y(P*)/epsilon_Y`.
4. `ContiguousAlternativeFailureFractionAtKstar`.
5. `TargetBlindPenaltyNormAtKstar` and `TargetBlindAddedFailureAtKstar`.
6. `TargetMismatchedFailureFractionAtKstar`.

No scalar composite score combining accuracy and K is introduced, because such a score would require an arbitrary exchange rate between molecular resolution and error. The analysis intentionally presents the two axes separately.

## Anti-strawman rule
The optimized target-blind minimax topology is the primary alternative baseline because it is deliberately strong. The contiguous-alternative and target-mismatched comparisons are supplementary same-K diagnostics. Worst unrestricted alternatives are reported but should not be used alone as the manuscript headline.

## Full-reference interpretation
The full source representation at `K=J` is the zero-reduction reference, not a method that P* is expected to outperform in accuracy. The meaningful question is how far K can be reduced while remaining within the target tolerance.

## Representative visualization
All 19 distributions remain in inference. Four cases are selected only to visualize distinct behaviors, according to fixed deterministic rules in `run_pass11_representatives.m`.
