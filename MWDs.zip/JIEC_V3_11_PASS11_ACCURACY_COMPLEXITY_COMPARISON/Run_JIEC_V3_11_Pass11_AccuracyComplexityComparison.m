clear; clc;
ROOT=fileparts(mfilename('fullpath'));
restoredefaultpath;
addpath(ROOT);
addpath(fullfile(ROOT,'core'));
addpath(fullfile(ROOT,'verify'));
cfg=config_pass11(ROOT);

% Path-safety checks: core and verifier must resolve inside this package.
checks={ ...
    'run_pass11_accuracy_complexity',fullfile(ROOT,'core','run_pass11_accuracy_complexity.m'); ...
    'run_pass11_summaries',fullfile(ROOT,'core','run_pass11_summaries.m'); ...
    'run_pass11_representatives',fullfile(ROOT,'core','run_pass11_representatives.m'); ...
    'verify_pass11_accuracy_complexity',fullfile(ROOT,'verify','verify_pass11_accuracy_complexity.m')};
for i=1:size(checks,1)
    resolved=which(checks{i,1});
    if isempty(resolved) || ~strcmpi(char(resolved),char(checks{i,2}))
        error('Path-safety failure: %s resolved outside this package.',checks{i,1});
    end
end

if exist(cfg.outDir,'dir'); rmdir(cfg.outDir,'s'); end
mkdir(cfg.outDir); mkdir(cfg.figDir);

fprintf('[JIEC v3.11 Pass 11] ACCURACY-COMPLEXITY COMPARISON\n');
fprintf('Scientific release: %s\n',cfg.release);
fprintf('Frozen scope: 19 primary external PP distributions across six study clusters.\n');
fprintf('Full reference: dataset-specific K = J = N_ref (not forced to K=5).\n');
fprintf('Targets: Mw, dispersity, W1, Tail@M90, Tail@M99.\n');
fprintf('Mn is excluded because reciprocal-Mn grouping makes topology invariant.\n\n');
fprintf('Primary questions:\n');
fprintf('  1) How much retained resolution can K* remove relative to the full reference?\n');
fprintf('  2) At the same K*, how much accuracy is lost under alternative topologies?\n');
fprintf('  3) Does the optimized target-blind topology fail where target-specific P* closes?\n');
fprintf('  4) How often do topologies optimized for another target fail at the current target?\n');
fprintf('Primary KPI: tolerance-normalized error e_Y = E_Y / epsilon_Y.\n');
fprintf('No new deconvolution, fitting, reactor rerun, uncertainty model, or tolerance tuning is introduced.\n\n');

run_pass11_accuracy_complexity(cfg);
run_pass11_summaries(cfg);
run_pass11_representatives(cfg);
try
    run_pass11_figures(cfg);
catch ME
    warning('Pass11:FigureGeneration','Figure generation failed but numerical qualification will continue: %s',ME.message);
end
V=verify_pass11_accuracy_complexity(cfg);
npass=sum(string(V.Status)=="PASS");

fprintf('\nPass 11 status: %s (%d/%d gates PASS)\n',tern_local(npass==height(V),'QUALIFIED','FAILED'),npass,height(V));
fprintf('Outputs: %s\n',cfg.outDir);
zipfile=fullfile(ROOT,'Outputs_Pass11.zip');
if exist(zipfile,'file'); delete(zipfile); end
zip(zipfile,{'Outputs_Pass11'},ROOT);
fprintf('Archive: %s\n',zipfile);
if npass~=height(V)
    error('Pass 11 verification failed. Inspect Pass11_verification.csv.');
end

function y=tern_local(q,a,b)
if q; y=a; else; y=b; end
end
