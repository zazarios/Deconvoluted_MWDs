# JIEC v3.11 Pass 11 release notes

Scientific release: `3.11-pass11-accuracy-complexity-comparison`

This pass adds one post-freeze scientific question: **what practical accuracy–resolution advantage is obtained by using the target-aware model-selected representation `(K*, P*)` rather than carrying the full source resolution or using a different topology?**

The pass is designed to support the planned manuscript Section 3.8, tentatively titled **Accuracy–complexity advantage of the model-selected representation**.

No previous Pass-7/8/9/10 result is replaced. Pass 11 uses the same 19-distribution external PP cohort, same target errors, same reference tolerances, same unrestricted partition class, and same target-blind minimax definition already frozen before this pass.

The new comparison adds:
- dataset-specific full-reference `K=J` benchmark;
- retained-group saving and percent retained-resolution reduction;
- normalized accuracy at K*;
- all-alternative and contiguous-alternative same-K statistics;
- target-blind same-K statistics at K*;
- target-mismatched topology statistics;
- cohort/target/dataset summaries;
- four transparent representative-case selection rules and plot-ready curves.
