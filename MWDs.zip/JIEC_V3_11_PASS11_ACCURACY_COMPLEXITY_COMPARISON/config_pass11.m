function cfg=config_pass11(ROOT)
cfg.release="3.11-pass11-accuracy-complexity-comparison";
cfg.externalDir=fullfile(ROOT,'data','External19');
cfg.pass10Dir=fullfile(ROOT,'data','Pass10_Qualified');
cfg.auditDir=fullfile(ROOT,'Independent_Audit');
cfg.outDir=fullfile(ROOT,'Outputs_Pass11');
cfg.figDir=fullfile(cfg.outDir,'Figures');
% Mn is intentionally excluded from this comparison because the reciprocal-Mn
% retained-group construction makes Mn topology-invariant.
cfg.targets=["MwRel","DRel","W1","Tail90Abs","Tail99Abs"];
cfg.targetOrders=1:numel(cfg.targets);
cfg.tolerances=[0.025,0.025,0.020,0.025,0.025];
cfg.primaryAbsTol=1e-8;
cfg.floorAbsTol=1e-10;
cfg.closeTol=1e-12;
cfg.plotFloor=1e-6;
end
